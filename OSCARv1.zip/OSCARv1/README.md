# OSCAR

**1. Purpose**

Medical Billing and Coding is an integral component of healthcare industry. Coding accuracy is an ongoing challenge. In the context of high volume medical coding work done by Omega and the immense domain knowledge accumulated over the years, Omega leadership intends to develop its own CSC (Computer Suggested Coding) solution to improve its operational efficiencies and improve the quality of our coding work. It auto-suggests the appropriate codes to a patient chart by processing the chart notes. It uses NLP (Natural Language Processing) and ML (Machine Learning)/DL (Deep Learning) algorithms to accomplish this more effectively. The tool improves its accuracy through the ML/DL over an extended period of usage as they take in the corrections and improve their code recommendations.
The proposed solution shall be hosted in US-cloud environment to ensure HIPAA compliance requirements of our clients.  

**2. Scope**

Initial scope is confined to Radiology specialty and later extendable to other core specialties. System would expect electronic chart data as the key requirement for input feed. Once the CSC solution is successfully implemented and stabilized in such projects, at a later point, OCR/ICR can be explored to process chart images as an extension of the solution.

**3. GENERAL DESCRIPTION**

This section contains description of general features of OSCAR tool. OSCAR shall address the overall workflow needs for Omega to handle the radiology coding. 

This includes
•	Importing electronic chart notes
•	Processing the chart notes to assign codes
•	Allocation of charts to coders
•	Allocation of charts to auditors
•	Error feedback workflow between auditors and coders
•	Releasing the completed batches back to client
•	Ability to flag/mark discards with appropriate reason codes and include in the output file
•	Ability to handle RAI (Request for Additional Information) charts to be sent back to client (system) 
•	Reports/dashboards required for maintaining daily operations, invoicing and monitoring
•	Ability to configure billing rules, client and facility specific guidelines, etc.at a facility/client level

**4. Value Adds** 

•	Robust, scalable platform to enhance productivity & accuracy
•	Segregates charts upfront by specialty (IVR) & modality and routes to coders specialized in a given modality
•	Ability to Incorporate facility-specific customization of rules like PQRS/MIPS coding, supply coding
•	Groups multiple visits of the same patient together irrespective of scan date enabling appropriate coding  
•	Focused audit capability to audit High $ CPT, specific codes, updates etc.
•	Supports global coding
•	Captures Physician info (incl. Locum, Residents, NOP)
•	Color coding based on tool confidence


**5. Software Interfaces**

•	Microsoft IE10 or higher, Edge (latest version)
•	Chrome (latest version)
•   Web Browsers


**6. ROLES AND PERMISSIONS**

This section details about the Roles and permission configurable as per the user need  

The following roles must exist in the system:
•	Administrator
•	CCIS 
•	External-Customer/Client
•	Delivery Heads/BUH
•	Manager 
•	Team Lead
•	QA – L2, Compliance
•	QA – L1
•	Coder



# What's in the box

The app template is based on [HTML5](http://whatwg.org/html), [TypeScript](http://www.typescriptlang.org) and
[Sass](http://sass-lang.com). The translation files use the common [JSON](http://www.json.org) format.

#### Tools

Development, build and quality processes are based on [angular-cli](https://github.com/angular/angular-cli) and
[NPM scripts](https://docs.npmjs.com/misc/scripts), which includes:

- Optimized build and bundling process with [Webpack](https://webpack.github.io)
- [Development server](https://webpack.github.io/docs/webpack-dev-server.html) with backend proxy and live reload
- Cross-browser CSS with [autoprefixer](https://github.com/postcss/autoprefixer) and
  [browserslist](https://github.com/ai/browserslist)
- Asset revisioning for [better cache management](https://webpack.github.io/docs/long-term-caching.html)
- Unit tests using [Jasmine](http://jasmine.github.io) and [Karma](https://karma-runner.github.io)
- End-to-end tests using [Protractor](https://github.com/angular/protractor)
- Static code analysis: [TSLint](https://github.com/palantir/tslint), [Codelyzer](https://github.com/mgechev/codelyzer),
  [Stylelint](http://stylelint.io) and [HTMLHint](http://htmlhint.com/)
- Local knowledgebase server using [Hads](https://github.com/sinedied/hads)
- Automatic code formatting with [Prettier](https://prettier.io)

#### Libraries

- [Angular](https://angular.io)
- [Angular Material](https://material.angular.io)
- [Angular Flex Layout](https://github.com/angular/flex-layout)
- [Material Icons](https://material.io/icons/)
- [RxJS](http://reactivex.io/rxjs)
- [ngx-translate](https://github.com/ngx-translate/core)
- [Lodash](https://lodash.com)

#### Coding guides

- [Angular](docs/coding-guides/angular.md)
- [TypeScript](docs/coding-guides/typescript.md)
- [Sass](docs/coding-guides/sass.md)
- [HTML](docs/coding-guides/html.md)
- [Unit tests](docs/coding-guides/unit-tests.md)
- [End-to-end tests](docs/coding-guides/e2e-tests.md)

#### Other documentation

- [Browser routing](docs/routing.md)


## Routing
//Yet to write

## Development server

Run `ng serve --open` for a dev server. It will open your default browser and navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng g component component-name` to generate a new component. You can also use `ng g directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `-prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

##Author
Omega