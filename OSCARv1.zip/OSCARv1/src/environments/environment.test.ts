export const environment = {
  production: false,
  URL: 'http://3.210.160.240:8100/',
  storage: sessionStorage,
  elasticSearch_URL: 'http://10.1.2.179:8580/',
  nifi_URL: 'http://10.1.2.212:9091/'
};
