export const environment = {
  production: true,
  // URL: 'http://10.1.2.179:8300/uatdb_'
  // URL: 'http://10.1.2.179:8200/uatdb_';
  URL: 'http://10.1.2.179:8200/uatdb_oscarapigateway/uatdb_'
};
