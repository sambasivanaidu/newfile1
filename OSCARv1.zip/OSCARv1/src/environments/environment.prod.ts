export const environment = {
  production: true,
  URL: 'http://10.1.2.186:8100/',
  storage: sessionStorage,
  elasticSearch_URL: 'http://10.1.2.179:8580/',
  nifi_URL: 'http://10.1.2.201:9091/',
  nifi_URL_Save: 'http://10.1.2.201:9090/'
};
