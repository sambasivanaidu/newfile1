export const environment = {
  // ============ //
  // FOR DEV ENV
  // ============ //
  // production: false,
  // URL: 'http://10.1.2.186:8100/',
  // storage: sessionStorage,
  // elasticSearch_URL: 'http://10.1.2.179:8580/',
  // nifi_URL: 'http://10.1.2.201:9091/',
  // nifi_URL_Save: 'http://10.1.2.201:9090/',
  // ============ //
  // FOR TEST ENV
  // ============ //
  production: false,
  URL: "http://3.210.160.240:8100/",
  storage: sessionStorage,
  elasticSearch_URL: "http://3.210.160.240:8100/",
  nifi_URL: "http://54.156.120.160:9094/",
  nifi_URL_Save: "http://54.156.120.160:9090/"
};
