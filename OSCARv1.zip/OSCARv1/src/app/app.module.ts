import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserXhr, HttpModule } from '@angular/http';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule, NoopAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './imports/material.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { DatePipe } from '@angular/common';
// App Gaurd
import { AuthGuard } from './auth/auth.guard';
import { SidebarModule } from 'ng-sidebar';
// App Router Class
import { appRoutes } from './routes';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
// App Node Modules
import {
    PasswordModule,
    InputTextModule,
    PanelModule,
    DialogModule,
    MessageService,
    ConfirmDialogModule,
    ConfirmationService,
    SharedModule

} from 'primeng/primeng';

import { ChartModule } from 'primeng/chart';
import { OrganizationChartModule } from 'primeng/organizationchart';
import { DeviceDetectorModule } from 'ngx-device-detector';
import { ToastModule } from 'ng2-toastr';
import { ToastOptions } from 'ng2-toastr';
import { AgGridModule } from 'ag-grid-angular';
import { NgProgressModule, NgProgressBrowserXhr, NgProgressInterceptor } from 'ngx-progressbar';
import { CustomOption } from './imports/_utilities/toast-option/toast-option';
// App Services
import { UserService } from './users/shared/user.service';
import { HeaderAuthenticationToken } from './auth/authetication-header';
// App Component
import { RouterModule } from '@angular/router';
import { ErrorHandlingServices } from './services/error-handling.services';
import { HttpErrorInterceptor } from './http-error-interceptor';
import { NgIdleModule } from '@ng-idle/core';
import { ToastOptionModule } from './imports/_utilities/toast-option/toast-option.module';
import { TimeoutModalModule } from './imports/_utilities/timeout-modal/timeout-modal.module';
import { ClientSelectionService } from './users/client-selection/client-selection.service';
import { CommonCodeService } from './_shared-services/common-code.services';
import { UsersModule } from './users/users.module';

@NgModule({
    declarations: [
        AppComponent
    ],
    imports: [
        UsersModule,
        ToastOptionModule,
        UsersModule,
        TimeoutModalModule,
        BrowserModule,
        FormsModule,
        HttpModule,
        HttpClientModule,
        ConfirmDialogModule,
        SharedModule,
        SidebarModule.forRoot(),
        RouterModule.forRoot(
            appRoutes,
            {
                useHash: true
            }
        ),
        DeviceDetectorModule.forRoot(),
        ToastModule.forRoot(),
        AgGridModule.withComponents([]),
        BrowserAnimationsModule,
        // NoopAnimationsModule,
        FlexLayoutModule,
        MaterialModule,
        ChartModule,
        PasswordModule,
        InputTextModule,
        PanelModule,
        DialogModule,
        ReactiveFormsModule,
        NgProgressModule,
        OrganizationChartModule,
        NgIdleModule.forRoot()
    ],
    providers: [
        DatePipe,
        UserService,
        HeaderAuthenticationToken,
        ClientSelectionService,
        CommonCodeService,
        AuthGuard,
        MessageService,
        ConfirmationService,
        ErrorHandlingServices,
        {
            provide: LocationStrategy,
            useClass: HashLocationStrategy
        },
        {
            provide: ToastOptions,
            useClass: CustomOption
        },
        {
            provide: BrowserXhr,
            useClass: NgProgressBrowserXhr
        },
        {
            provide: HTTP_INTERCEPTORS,
            useClass: NgProgressInterceptor,
            multi: true
        },
        {
            provide: HTTP_INTERCEPTORS,
            useClass: HttpErrorInterceptor,
            multi: true
        }
    ],
    bootstrap: [AppComponent],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class AppModule { }
