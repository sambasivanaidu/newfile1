import { Injectable, ErrorHandler, ViewContainerRef } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastsManager } from 'ng2-toastr';
import { environment } from '../../environments/environment';
import { Router } from '@angular/router';

@Injectable()
export class ErrorHandlingServices implements ErrorHandler {
  public error: any;
  public errorMsg;
  public storage: Storage = environment.storage;

  constructor(
    public toaster: ToastsManager,
    // vcr: ViewContainerRef,
    private router: Router
  ) {
    // this.toaster.setRootViewConstainerRef(vcr);
  }

  public handleError(error: HttpErrorResponse) {
    if (error instanceof HttpErrorResponse) {
      // Server or connection error happened
      if (!navigator.onLine) {
        // Handle offline error
      } else {
        // Handle Http Error (error.status === 403, 404...)
      }
    } else {
      // Handle Client Error (Angular Error, ReferenceError...)
    }
  }

  public throwSuccess(msg) {
    this.toaster.success(msg);
  }

  public throwError(error) {
    try {
      if (error._body) {
        const err = JSON.parse(error._body);
        const msg = JSON.parse(error._body).apierror
          ? JSON.parse(error._body).apierror.message
          : JSON.parse(error._body).error;
        this.toaster.error(msg);
        if (err.message && err.message.match(/cache is empty/g)) {
          this.storage.clear();
          this.router.navigate(['/login']);
        }
      }
    } catch (e) {
      if (e instanceof SyntaxError) {
        console.error(e.name);
    } else {
        console.error(e.message);
    }
    }
  }

  public throwInfo(infoMsg) {
    this.toaster.info(infoMsg);
  }

  public throwWarning(msg) {
    this.toaster.warning(msg);
  }

  public throwStringError(message) {
    this.toaster.error(message);
  }
}
