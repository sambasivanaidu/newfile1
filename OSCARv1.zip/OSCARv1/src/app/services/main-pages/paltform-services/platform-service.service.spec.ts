import { TestBed, inject, async, ComponentFixture } from '@angular/core/testing';
import { PlatformService } from './platform-service.service';
import { Http, ConnectionBackend, HttpModule, XHRBackend, ResponseOptions, Response } from '@angular/http';
import { RequestOptions, Request, RequestMethod } from '@angular/http';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { ToastsManager } from 'ng2-toastr/src/toast-manager';
import { ToastOptions } from 'ng2-toastr';
import { NgProgress } from 'ngx-progressbar';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { HeaderAuthenticationToken } from '../../../auth/authetication-header';

describe('platformService', () => {
    let component: PlatformService;
    let fixture: ComponentFixture<PlatformService>;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [],
            imports: [
                HttpModule,
            ],
            providers: [
                PlatformService,
                ConnectionBackend,
                HttpClient,
                HttpHandler,
                HeaderAuthenticationToken,
                ToastsManager,
                ToastOptions,
                NgProgress,
                { provide: XHRBackend, useClass: MockBackend },
            ]
        }).compileComponents();
    }));

    it('should be created', inject([PlatformService], (service: PlatformService) => {
        expect(service).toBeTruthy();
    }));

    it('#fetchdataOnCountSave', inject([PlatformService], (service: PlatformService) => {
        expect(service.fetchdataOnCountSave()).toBeDefined();
    }));

    it('#countCptIcdModSmeLearning', inject([PlatformService], (service: PlatformService) => {
        expect(service.countCptIcdModSmeLearning()).toBeDefined();
    }));

    it('#fetchFeedBackCPTInfo', inject([PlatformService], (PlatformService) => {
        expect(PlatformService.fetchFeedBackCPTInfo('params')).toBeDefined();
    }));

    it('#fetchdataOnCountSave', inject([PlatformService, XHRBackend], (PlatformService, mockBackend) => {
        const mockResponse = {
            filldashboard: 1
        };
        mockBackend.connections.subscribe((connection) => {
            connection.mockRespond(new Response(new ResponseOptions({
                body: JSON.stringify(mockResponse)
            })));
        });
        PlatformService.fetchdataOnCountSave().subscribe(x => {
            expect(x).toBeDefined();
        });
    }));

    it('#try',inject([PlatformService], (service: PlatformService) => {
        expect(service.fetchdataOnCountSave()).toBeDefined();
    }));

});
