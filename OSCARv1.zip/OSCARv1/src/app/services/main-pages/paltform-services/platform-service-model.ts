export interface PlatformServiceModel {
    id: null;
    uniqueId: string;
    aapcDescription: string;
    accessionNo: string;
    codingRole: string;
    cptCode: string;
    cptDescription: string;
    dxRef: string;
    modifier: string;
    units: string;
    approved: string;
    isDiscarded: string;
    addToLearningSystem: string;
    approvedBy: string;
    approvedOn: string;
    modifiedBy: string;
    modifiedOn: string;
    isActive: boolean;
    createdBy: string;
    createdOn: string;
}
