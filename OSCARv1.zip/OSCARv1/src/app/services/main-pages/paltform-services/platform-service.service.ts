import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/forkJoin';
import { map } from 'rxjs/operators/map';
import { environment } from '../../../../environments/environment';
import { HeaderAuthenticationToken } from '../../../auth/authetication-header';
import { ChartInformation } from '../../../entities/chartinformation';
export type ResponseType = 'arraybuffer' | 'blob' | 'json' | 'text';
export interface Rational {
  sectionName: string;
  value: string;
}
@Injectable()
export class PlatformService {
  public httpOption;
  public httpOption3;
  public httpPdfHeader;
  public httpOptionNifi;
  public envURL = environment.URL;
  public envnifiURL = environment.nifi_URL;
  public envnifiURL2 = environment.nifi_URL;
  public nifi_URL_Save = environment.nifi_URL_Save;
  public storage: Storage = environment.storage;
  public infiObject;
  public userName;
  nifi_option: any;
  ICDArr: any[];
  updateEnded: {
    uniqueId: any;
    currentTime: number;
    chartStatus: any;
    updatedBy: any;
    updatedOn: number;
    auditorConflict: any;
    auditorComments: any;
    modality: any;
    role: any;
    addToLearning: boolean;
  };
  CPTArr: any[];
  nifiObject: {
    charticdinfo: any[];
    chartcptinfo: any[];
    chartinformation: any;
  };
  auditorCPTArr: any[];
  auditorICDArr: any[];
  constructor(
    private _http: Http,
    private httpClient: HttpClient,
    private __httpHeader: HeaderAuthenticationToken
  ) {
    this.httpOption = this.__httpHeader.setHeaderToken();
    this.httpPdfHeader = this.__httpHeader.setpdfHeaderToken();
    this.httpOption3 = this.__httpHeader.setFileHeader3Token();
    this.userName = this.storage.getItem('UserName');
  }
  getTlAcknowledge(param) {
    const _Cpturl =
      this.envURL + 'chartcptinfo/getCptAcknowledgeDetails?uniqueId=' + param;
    const _Icdurl =
      this.envURL + 'charticdinfo/getIcdAcknowledgeDetails?uniqueId=' + param;
    return Observable.forkJoin(
      this.httpClient.get(_Cpturl, this.httpOption).pipe(
        map((response: any) => {
          if (response) {
            return response;
          }
        })
      ),
      this.httpClient.get(_Icdurl, this.httpOption).pipe(
        map((response: any) => {
          if (response) {
            return response;
          }
        })
      )
    );
  }
  saveTlAcknowledge(cptParam, icdParam) {
    const _Cpturl = this.envURL + 'chartcptinfo/getTlAcknowledgeCptCharts';
    const _Icdurl = this.envURL + 'charticdinfo/getTlAcknowledgeIcdCharts';
    return Observable.forkJoin(
      this.httpClient.post(_Cpturl, cptParam, this.httpOption).pipe(
        map((response: any) => {
          if (response) {
            return response;
          }
        })
      ),
      this.httpClient.post(_Icdurl, icdParam, this.httpOption).pipe(
        map((response: any) => {
          if (response) {
            return response;
          }
        })
      )
    );
  }
  fetchdataOnCountSave() {
    const _url = this.envnifiURL + 'nifi-api/?userid=' + this.userName;
    return this._http.get(_url).map(res => res.json());
  }
  fetchsmelearning(obj) {
    const _url = this.envURL + 'smelearning/searchSmeLearning';
    return this.httpClient.post(_url, obj, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  updateSmeLearning(obj) {
    const _url = this.envURL + 'smelearning/updatSaveSme';
    return this.httpClient.post(_url, obj, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  countCptIcdModSmeLearning() {
    const _url = this.envURL + 'smelearning/searchCategoryCount';
    return this.httpClient.get(_url, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  fetchPdfFileData(filePath) {
    const _url =
      this.envURL + 'facilitymaster/downloadFile?filePath=' + filePath;
    return this.httpClient.get(_url, this.httpPdfHeader).pipe(
      map((res: any) => {
        return res;
      })
    );
  }
  downloadRaiFiles(path) {
    const _url = this.envURL + 'facilitymaster/downloadFile?filePath=' + path;
    return this.httpClient.get(_url, this.httpPdfHeader).pipe(
      map((res: any) => {
        return res;
      })
    );
  }
  fetchRelatedChart(params) {
    const _url = this.envURL + 'chartinformation/relatedVisit';
    return this.httpClient.post(_url, params, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  fetchPatientChart(params: string) {
    const _url =
      this.envURL + 'hl7obxsegment/patientMedicalReport?uniqueId=' + params;
    return this.httpClient.get(_url, this.httpOption);
  }
  fetchPatientInfo(params: string) {
    const _url = this.envURL + 'hl7pidsegment/patientInfo?uniqueId=' + params;
    return this.httpClient.get(_url, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  fetchPatientRecordInfo(params: string) {
    const _url =
      this.envURL + 'apicomposition/searchpatientrecordinfo?uniqueId=' + params;
    return this.httpClient.get(_url, this.httpOption).pipe(
      map((res: any) => {
        if (res) {
          return res;
        }
      })
    );
  }
  fetchPredictedICDInfo(uniqueid) {
    const _url =
      this.envURL + 'charticdprediction/icdDetails?uniqueid=' + uniqueid;
    return this.httpClient.get(_url, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  fetchPredictedCPTInfo(uniqueid) {
    const _url =
      this.envURL + 'chartcptprediction/cptDetails?uniqueid=' + uniqueid;
    return this.httpClient.get(_url, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  fetchICDInfo(params: string, platform) {
    const _url = this.envURL + 'charticdinfo/search';
    let myObj, codedBy;
    codedBy =
      platform === 'sme'
        ? ''
        : platform === 'tl'
        ? 'auditor'
        : platform === 'auditor'
        ? 'coder'
        : 'auditor';
    myObj = {
      uniqueId: params,
      codedBy: codedBy
    };
    // const myObjStr = JSON.stringify(myObj);
    return this.httpClient.post(_url, myObj, this.httpOption);
  }
  fetchFeedBackICDInfo(params) {
    const url = this.envURL + 'charticdinfo/search';
    return this.httpClient.post(url, params, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  fetchFeedBackCPTInfo(params) {
    const url = this.envURL + 'chartcptinfo/search';
    return this.httpClient.post(url, params, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  auditL2fetchICDInfo(params, platform) {
    const _url = this.envURL + 'charticdinfo/search';
    return this.httpClient.post(_url, params, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  fetchCPTInfo(params: string, platform) {
    const _url = this.envURL + 'chartcptinfo/search';
    let myObj, codedBy;
    codedBy =
      platform === 'sme'
        ? ''
        : platform === 'tl'
        ? 'auditor'
        : platform === 'auditor'
        ? 'coder'
        : 'auditor';
    myObj = {
      uniqueId: params,
      codedBy: codedBy
    };
    // const myObjStr = JSON.stringify(myObj);
    return this.httpClient.post(_url, myObj, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  auditL2fetchCPTInfo(params, platform) {
    const _url = this.envURL + 'chartcptinfo/search';
    return this.httpClient.post(_url, params, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  coderHandleCPT(CPTInfo, codingRole, UniqueID, userName) {
    this.CPTArr = [];
    let CPTObj;
    CPTInfo.forEach((CPT, index) => {
      CPTObj = {
        id: null,
        uniqueId: UniqueID,
        counter: index,
        aapcDescription: CPT.aapcCptDescription,
        accessionNo: CPT.accession,
        codingRole: codingRole,
        cptCode: CPT.predictCptCode,
        cptDescription: CPT.cptDescription,
        dxRef: CPT.dxRef,
        modifier: CPT.modifier ? CPT.modifier : '',
        units: CPT.units,
        approved: null,
        isDiscarded: null,
        addToLearningSystem: null,
        approvedBy: null,
        approvedOn: null,
        updatedBy: null,
        updatedOn: null,
        isActive: CPT.isActive === undefined ? true : CPT.isActive,
        rationaleData:
          CPT.rationaleData === undefined ? null : CPT.rationaleData,
        rationaleSection: CPT.rationaleSection,
        createdBy: userName,
        createdOn: Date.now(),
        comments: CPT.comments
      };
      this.CPTArr.push(CPTObj);
    });
    return this.CPTArr;
  }
  coderHandleICD(ICDInfo, codingRole, UniqueID, userName) {
    this.ICDArr = [];
    let ICdObj;
    ICDInfo.forEach((ICD, index) => {
      ICdObj = {
        id: null,
        uniqueId: UniqueID,
        counter: index,
        aapcDescription: ICD.aapcIcdDescription,
        accessionNo: ICD.accession,
        codingRole: codingRole,
        icdCode: ICD.predictIcdCode,
        icdDescription: ICD.icdDescription,
        isActive: ICD.isActive === undefined ? true : ICD.isActive,
        lcdStatus: ICD.lcdStatus,
        addToLearningSystem: null,
        approved: null,
        discarded: null,
        lcdPassed: null,
        approvedBy: null,
        approvedOn: null,
        updatedBy: null,
        updatedOn: null,
        createdBy: userName,
        rationaleSection: ICD.rationaleSection,
        rationaleData:
          ICD.rationaleData === undefined ? null : ICD.rationaleData,
        createdOn: Date.now(),
        comments: ICD.comments
      };
      this.ICDArr.push(ICdObj);
    });
    return this.ICDArr;
  }
  // Reourte Save isSaved=true
  coderHandleCPTReroute(CPTInfo, codingRole, UniqueID, userName) {
    this.CPTArr = [];
    let CPTObj;
    CPTInfo.forEach((CPT, index) => {
      CPTObj = {
        id: CPT.id ? CPT.id : null,
        uniqueId: UniqueID,
        counter: index,
        aapcDescription: CPT.aapcCptDescription,
        accessionNo: CPT.accession,
        codingRole: codingRole,
        cptCode: CPT.predictCptCode,
        cptDescription: CPT.cptDescription,
        dxRef: CPT.dxRef,
        modifier: CPT.modifier ? CPT.modifier : '',
        units: CPT.units,
        approved: null,
        isDiscarded: null,
        addToLearningSystem: null,
        approvedBy: null,
        approvedOn: null,
        updatedBy: null,
        updatedOn: null,
        isActive: CPT.isActive === undefined ? true : CPT.isActive,
        rationaleData:
          CPT.rationaleData === undefined ? null : CPT.rationaleData,
        rationaleSection: CPT.rationaleSection,
        createdBy: userName,
        createdOn: Date.now(),
        comments: CPT.comments
      };
      this.CPTArr.push(CPTObj);
    });
    return this.CPTArr;
  }
  coderHandleICDReroute(ICDInfo, codingRole, UniqueID, userName) {
    this.ICDArr = [];
    let ICdObj;
    ICDInfo.forEach((ICD, index) => {
      ICdObj = {
        id: ICD.id ? ICD.id : null,
        uniqueId: UniqueID,
        counter: index,
        aapcDescription: ICD.aapcIcdDescription,
        accessionNo: ICD.accession,
        codingRole: codingRole,
        icdCode: ICD.predictIcdCode,
        icdDescription: ICD.icdDescription,
        isActive: ICD.isActive === undefined ? true : ICD.isActive,
        lcdStatus: ICD.lcdStatus,
        addToLearningSystem: null,
        approved: null,
        discarded: null,
        lcdPassed: null,
        approvedBy: null,
        approvedOn: null,
        updatedBy: null,
        updatedOn: null,
        createdBy: userName,
        rationaleSection: ICD.rationaleSection,
        rationaleData:
          ICD.rationaleData === undefined ? null : ICD.rationaleData,
        createdOn: Date.now(),
        comments: ICD.comments
      };
      this.ICDArr.push(ICdObj);
    });
    return this.ICDArr;
  }
  updateCoderDetails(UniqueID, status, modality, codingRole, conflict) {
    this.updateEnded = {
      uniqueId: UniqueID,
      currentTime: Date.now(),
      chartStatus: status,
      updatedBy: this.userName,
      updatedOn: Date.now(),
      auditorConflict: null,
      auditorComments: null,
      modality: modality,
      role: codingRole,
      addToLearning: conflict ? false : true
    };
    return JSON.stringify(this.updateEnded);
  }
  // SAVE CODER ENDED ON
  saveCodedChart(
    CPTInfo: any,
    ICDInfo: any,
    UniqueID: string,
    modality,
    conflict
  ) {
    const codingRole = 'coder';
    this.coderHandleICD(ICDInfo, codingRole, UniqueID, this.userName);
    this.coderHandleCPT(CPTInfo, codingRole, UniqueID, this.userName);
    this.updateCoderDetails(UniqueID, 'coded', modality, codingRole, conflict);
    const nifiObject = {
      charticdinfo: this.ICDArr,
      chartcptinfo: this.CPTArr,
      chartinformation: this.updateEnded
    };
    return this._http
      .post(this.nifi_URL_Save + 'nifi-api', JSON.stringify(nifiObject))
      .map(res => res.json());
  }
  saveCodedChartReroute(
    CPTInfo: any,
    ICDInfo: any,
    UniqueID: string,
    modality,
    conflict
  ) {
    const codingRole = 'coder';
    this.coderHandleICDReroute(
      ICDInfo,
      codingRole,
      UniqueID,
      this.userName
    );
    this.coderHandleCPTReroute(
      CPTInfo,
      codingRole,
      UniqueID,
      this.userName
    );
    this.updateCoderDetails(
      UniqueID,
      'coded',
      modality,
      codingRole,
      conflict
    );
    const nifiObject = {
      charticdinfo: this.ICDArr,
      chartcptinfo: this.CPTArr,
      chartinformation: this.updateEnded
    };
    return this._http
      .post(this.nifi_URL_Save + 'nifi-api/', JSON.stringify(nifiObject))
      .map(res => res.json());
  }
  auditorHandleCPT(CPTInfo, UniqueID, codingRole) {
    this.auditorCPTArr = [];
    for (let i = 0; i < CPTInfo.length; i++) {
      const CPTObj = {
        id: null,
        uniqueId: UniqueID,
        counter: i,
        aapcDescription: CPTInfo[i].aapcDescription,
        accessionNo: CPTInfo[i].accessionNo,
        codingRole: codingRole,
        cptCode: CPTInfo[i].cptCode,
        cptDescription: CPTInfo[i].cptDescription,
        rationaleSection: CPTInfo[i].rationaleSection,
        isActive:
          CPTInfo[i].isActive === undefined ? true : CPTInfo[i].isActive,
        rationaleData:
          CPTInfo[i].rationaleData === undefined
            ? null
            : CPTInfo[i].rationaleData,
        isDiscarded: null,
        addToLearningSystem: null,
        dxRef: CPTInfo[i].dxRef,
        approved: null,
        modifier: CPTInfo[i].modifier ? CPTInfo[i].modifier : '',
        units: CPTInfo[i].units,
        approvedBy: null,
        approvedOn: null,
        updatedBy: null,
        updatedOn: null,
        createdBy: this.userName,
        createdOn: Date.now(),
        parentId: CPTInfo[i].id ? CPTInfo[i].id : null,
        comments: CPTInfo[i].comments
      };
      this.auditorCPTArr.push(CPTObj);
    }
    return this.auditorCPTArr;
  }
  auditorHandleICD(ICDInfo, UniqueID, codingRole) {
    this.auditorICDArr = [];
    for (let i = 0; i < ICDInfo.length; i++) {
      const ICdObj = {
        id: null,
        uniqueId: UniqueID,
        counter: i,
        aapcDescription: ICDInfo[i].aapcDescription,
        accessionNo: ICDInfo[i].accessionNo,
        codingRole: codingRole,
        icdCode: ICDInfo[i].icdCode,
        icdDescription: ICDInfo[i].icdDescription,
        isActive: ICDInfo[i].isActive,
        lcdStatus: ICDInfo[i].lcdStatus,
        rationaleSection: ICDInfo[i].rationaleSection,
        rationaleData:
          ICDInfo[i].rationaleData === undefined
            ? null
            : ICDInfo[i].rationaleData,
        addToLearningSystem: null,
        approved: null,
        discarded: null,
        lcdPassed: null,
        approvedBy: null,
        approvedOn: null,
        updatedBy: null,
        updatedOn: null,
        createdBy: this.userName,
        createdOn: Date.now(),
        comments: ICDInfo[i].comments,
        parentId: ICDInfo[i].id ? ICDInfo[i].id : null
      };
      this.auditorICDArr.push(ICdObj);
    }
    return this.auditorICDArr;
  }
  // SAVE AUDITOR ENDED ON
  saveAuditorChartInfo(param: any) {
    const codingRole = 'auditor';
    this.auditorHandleICD(
      param.ICDInfo,
      param.UniqueID,
      codingRole
    );
    this.auditorHandleCPT(
      param.CPTInfo,
      param.UniqueID,
      codingRole
    );
    const auditorChartInformation = {
      uniqueId: param.UniqueID,
      currentTime: Date.now(),
      chartStatus: param.chartStatus,
      updatedBy: this.userName,
      updatedOn: Date.now(),
      auditorConflict: param.conflicts,
      auditorComments: param.comments,
      modality: param.modality,
      addToLearning: param.conflicts ? false : true,
      role: codingRole
    };
    const nifiObject = {
      charticdinfo: this.auditorICDArr,
      chartcptinfo: this.auditorCPTArr,
      chartinformation: auditorChartInformation
    };
    return this._http
      .post(this.nifi_URL_Save + 'nifi-api/', JSON.stringify(nifiObject))
      .map(res => res.json());
  }
  saveL2AuditorChartInfo(param: any) {
    const codingRole = 'l2auditor';
    this.auditorHandleICD(
      param.ICDInfo,
      param.UniqueID,
      codingRole
    );
    this.auditorHandleCPT(
      param.CPTInfo,
      param.UniqueID,
      codingRole
    );
    const updateChartInfo = {
      auditorComments: param.comments,
      auditorConflict: param.conflicts,
      chartStatus: 'retroed',
      modality: param.modality,
      uniqueId: param.UniqueID,
      updatedBy: this.userName,
      updatedOn: Date.now(),
      auditorAllocatedTo: param.auditorAllocatedTo,
      isRetroed: param.isRetroed,
      addToLearning: param.conflicts ? false : true
    };
    return Observable.forkJoin(
      this.httpClient
        .post(
          this.envURL + 'charticdinfo/save/',
          this.auditorICDArr,
          this.httpOption
        )
        .pipe(
          map((response: any) => {
            if (response) {
              return response;
            }
          })
        ),
      this.httpClient
        .post(
          this.envURL + 'chartcptinfo/save/',
          this.auditorCPTArr,
          this.httpOption
        )
        .pipe(
          map((response: any) => {
            if (response) {
              return response;
            }
          })
        ),
      this.httpClient
        .post(
          this.envURL + 'chartinformation/updatel2auditordetails',
          updateChartInfo,
          this.httpOption
        )
        .pipe(
          map((response: any) => {
            if (response) {
              return response;
            }
          })
        )
    );
  }
  saveSMEChartInfo(param: any) {
    const codingRole = 'sme';
    const currentTime: any = Date.now();
    this.auditorHandleICD(
      param.ICDInfo,
      param.UniqueID,
      codingRole
    );
    this.auditorHandleCPT(
      param.CPTInfo,
      param.UniqueID,
      codingRole
    );
    const updateChartInfo = {
      chartStatus: param.chartStatus,
      modality: param.modality,
      updatedOn: currentTime,
      updatedBy: this.userName,
      uniqueId: param.UniqueID,
      currentTime: currentTime,
      addToLearning: param.conflicts ? false : true
    };
    return Observable.forkJoin(
      this.httpClient
        .post(
          this.envURL + 'charticdinfo/save/',
          this.auditorICDArr,
          this.httpOption
        )
        .pipe(
          map((response: any) => {
            if (response) {
              return response;
            }
          })
        ),
      this.httpClient
        .post(
          this.envURL + 'chartcptinfo/save/',
          this.auditorCPTArr,
          this.httpOption
        )
        .pipe(
          map((response: any) => {
            if (response) {
              return response;
            }
          })
        ),
      this.httpClient
        .post(
          this.envURL + 'chartinformation/updatesmedetails',
          updateChartInfo,
          this.httpOption
        )
        .pipe(
          map((response: any) => {
            return response;
          })
        )
    );
  }
  auditorChartService(event, icdInfo, cptInfo, platform) {
    let URL;
    URL =
      platform === 'sme'
        ? this.envURL +
          'mastersdata/discardReason?masterType=' +
          event +
          '&role=' +
          platform
        : this.envURL + 'mastersdata/discardReason?masterType=' + event;
    return this.httpClient.get(URL, this.httpOption).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
  smeChartService(event, icdInfo, cptInfo, platform, reason) {
    let URL;
    if (reason == 'Discard' || reason == 'Reroute') {
      URL =
        platform === 'sme'
          ? this.envURL + 'mastersdata/discardReason?masterType=' + event
          : this.envURL + 'mastersdata/discardReason?masterType=' + event;
      return this.httpClient.get(URL, this.httpOption).pipe(
        map((response: any) => {
          return response;
        })
      );
    } else {
      URL =
        platform === 'sme'
          ? this.envURL +
            'mastersdata/discardReason?masterType=' +
            event +
            '&role=' +
            platform
          : this.envURL + 'mastersdata/discardReason?masterType=' + event;
      return this.httpClient.get(URL, this.httpOption).pipe(
        map((response: any) => {
          return response;
        })
      );
    }
  }
  fetchlcdmipsccicheck(cciInput, lcdInput, mipsInput) {
    const params = {
      cciInput: cciInput,
      lcdInput: lcdInput,
      mipsInput: mipsInput
    };
    const URL = this.envURL + 'chartinformation/lcdmipsccicheck';
    return this.httpClient.post(URL, params, this.httpOption).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
  sectionSplitService(param) {
    const _url = this.envURL + 'hl7detailedobx5/sectionsplit';
    return this.httpClient.post(_url, param, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  public fetchMIPSDisableCheck(param) {
    const url =
      this.envURL +
      'facilitymaster/lookUpGuidePath?clientfacilityname=' +
      param;
    return this.httpClient.get(url, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  public getAcknowledge1(uniqueID, isFroml2Auditor, isDiscarded) {
    const cptUrl = this.envURL + 'chartcptinfo/acknowledgeCharts';
    const icdUrl = this.envURL + 'charticdinfo/acknowledgeCharts';
    const params = {
      isDiscard: isDiscarded,
      l2Auditor: isFroml2Auditor,
      uniqueId: uniqueID
    };
    return Observable.forkJoin(
      this.httpClient.post(cptUrl, params, this.httpOption).pipe(
        map(res => {
          if (res) {
            return res;
          }
        })
      ),
      this.httpClient.post(icdUrl, params, this.httpOption).pipe(
        map(res => {
          if (res) {
            return res;
          }
        })
      )
    );
  }
  public getTLFeedBack(uniqueId) {
    const cptUrl =
      this.envURL + 'chartcptinfo/acknowledgeTlCharts?uniqueId=' + uniqueId;
    const icdUrl =
      this.envURL + 'charticdinfo/acknowledgeTlCharts?uniqueId=' + uniqueId;
    return Observable.forkJoin(
      this.httpClient.get(cptUrl, this.httpOption).pipe(
        map(res => {
          if (res) {
            return res;
          }
        })
      ),
      this.httpClient.get(icdUrl, this.httpOption).pipe(
        map(res => {
          if (res) {
            return res;
          }
        })
      )
    );
  }
  public getFeebackICDInfo(params) {
    const _url = this.envURL + 'charticdinfo/searchDistinctByUniqueId';
    return this.httpClient.post(_url, params, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  public getFeedbackCPTInfo(params) {
    const _url = this.envURL + 'chartcptinfo/searchDistinctByUniqueId';
    return this.httpClient.post(_url, params, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  public searchByUniqueID(uniqueID) {
    const _url =
      this.envURL + 'chartinformation/searchByUniqueId?uniqueId=' + uniqueID;
    return this.httpClient.get(_url, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
}
