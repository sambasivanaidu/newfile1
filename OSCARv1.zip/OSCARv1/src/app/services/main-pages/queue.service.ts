import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { HeaderAuthenticationToken } from '../../auth/authetication-header';

@Injectable()
export class QueueService {
  public httpOption;
  public envURL = environment.URL;
  public httpHeaders;
  public storage: Storage = environment.storage;
  constructor(
    private httpCLient: HttpClient,
    private __httpHeader: HeaderAuthenticationToken
  ) {
    this.httpOption = this.__httpHeader.setHeaderToken();
  }

  public fetchCoderQueue(params): any {
    const url = this.envURL + 'chartinformation/searchchartinformation';
    return this.httpCLient.post(url, params, this.httpOption);
  }

  public updateStartTimeforCoder(params: String, platformNavigate): any {
    const myObj = {
      currentTime: Date.now(),
      openCoderPlatform: true,
      uniqueId: params
    };
    const url = this.envURL + 'chartinformation/' + platformNavigate;
    return this.httpCLient.post(url, myObj, this.httpOption);
  }

  public fetchWorkAllocationRules(): any {
    const TLId = this.storage.getItem('TLId');
    const WorkAllocationUrl =
      this.envURL + 'workallocationrules/getActiveRules?teamLead=' + TLId;
    return this.httpCLient.get(WorkAllocationUrl, this.httpOption);
  }

  public fetchAuditorQueue(params, serviceFor, whichTab): any {
    const URL =
      serviceFor === 'APIComposition'
        ? this.envURL + 'apicomposition/searchchartinformation'
        : this.envURL + 'chartinformation/searchchartinformation';
    return this.httpCLient.post(URL, params, this.httpOption);
  }

  public fetchModality(): any {
    const user_role = this.storage.getItem('osc-def-rol')
      ? this.storage.getItem('osc-def-rol').replace(/ /g, '')
      : null;
    const TLId = user_role === 'client' ? null : this.storage.getItem('TLId');
    const userId =
      user_role === 'client' ? null : this.storage.getItem('UserName');
    const role =
      user_role === 'client' ? null : this.storage.getItem('osc-def-rol');
    const url =
      this.envURL +
      'facilitymaster/modality?teamLead=' +
      TLId +
      '&userId=' +
      userId +
      '&role=' +
      role;
    return this.httpCLient.get(url, this.httpOption);
  }
}
