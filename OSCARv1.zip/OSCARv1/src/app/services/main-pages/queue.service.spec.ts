import { TestBed, inject } from '@angular/core/testing';

import { QueueService } from './queue.service';
import { HttpClient } from 'selenium-webdriver/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { HeaderAuthenticationToken } from '../../auth/authetication-header';

describe('QueueService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [QueueService,
        HeaderAuthenticationToken],
      imports: [
        HttpClientTestingModule
      ]
    });
  });

  it('should be created', inject([QueueService], (service: QueueService) => {
    expect(service).toBeTruthy();
  }));

  it('#fetchModality tobetruthy', inject([QueueService], (service: QueueService) => {
    expect(service.fetchModality()).toBeTruthy();
  }));

  it('#fetchWorkAllocationRules defined', inject([QueueService], (service: QueueService) => {
    expect(service.fetchWorkAllocationRules()).toBeDefined();
  }));

  it('#TLId undefined', inject([QueueService], (service: QueueService) => {
    expect(service.fetchWorkAllocationRules().TLId).toBeUndefined();
  }));

  it('#user_role tobeundefined', inject([QueueService], (service: QueueService) => {
    expect(service.fetchModality().user_role).toBeUndefined();
  }));

});
