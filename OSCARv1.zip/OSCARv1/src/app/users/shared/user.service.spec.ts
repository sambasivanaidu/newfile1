import { TestBed, ComponentFixture, inject, async, fakeAsync, tick, flushMicrotasks  } from '@angular/core/testing';
import {HttpClientModule} from '@angular/common/http';
import { UserService } from './user.service';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import { HeaderAuthenticationToken } from '../../auth/authetication-header';
import { ToastsManager } from 'ng2-toastr/src/toast-manager';
import { ToastOptions } from 'ng2-toastr/src/toast-options';
import { ViewContainerRef } from '@angular/core';
describe('UserService', () => {
    let service: UserService;
    let httpMock: HttpTestingController;
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [UserService, ViewContainerRef, HeaderAuthenticationToken, ToastsManager, ToastOptions]
        });
        service = TestBed.get(UserService);
        httpMock = TestBed.get(HttpTestingController);
    });

  it('should be created', () => {
    const service: UserService = TestBed.get(UserService);
    expect(service).toBeTruthy();
  });

  it('userAuthentication() should be able to authenticate user', () => {
    let loginDetail = {
        userid: 'sangram',
        pass: 'oscar'
        };

    service.userAuthentication(loginDetail).subscribe(data => {
      expect(data.access_token).toBe('abc');
    });
    // let url = `${service.envURL}keycloakauth/getToken?username=${loginDetail.userid}&password=${loginDetail.pass}`;
    let url = `${service.envURL}logindetails/getToken`;
    const request = httpMock.expectOne(req => req.method === 'POST' && req.url === url);
    expect(request.request.method).toBe('POST');
    request.flush({access_token: 'abc'});
  });
  afterEach(() => {
    httpMock.verify();
  });
});
