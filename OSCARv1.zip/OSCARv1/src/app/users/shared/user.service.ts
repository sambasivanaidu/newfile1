import { Injectable, ViewContainerRef } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HeaderAuthenticationToken } from '../../auth/authetication-header';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/forkJoin';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { ToastsManager } from 'ng2-toastr';

@Injectable()
export class UserService {
  public httpOption;
  public envURL = environment.URL;
  public storage: Storage = environment.storage;
  clientCount;
  specialityCount;
  locationCount;
  workflowCount;
  facilityCount;

  constructor(
    private httpClient: HttpClient,
    private httpHeader: HeaderAuthenticationToken,
    public toaster: ToastsManager,
    // private viewContainerRef: ViewContainerRef
  ) {
    this.httpOption = this.httpHeader.setHeaderToken();
    // this.toaster.setRootViewContainerRef(this.viewContainerRef);
  }

  userAuthentication(param) {
    const uri = this.envURL + 'logindetails/getToken';
    return this.httpClient.post(uri, param).pipe(
      map((response: any) => {
        if (response) {
          return response;
      }
     })
    );
  }

  userForceLogout(param) {
    const uri = this.envURL + 'logindetails/logout';
    return this.httpClient.post(uri, param).pipe(
      map((response: any) => {
        if (response) {
          return response;
      }
      }));
  }

  getUserRole() {
    this.httpOption = this.httpHeader.setHeaderToken();
    const userId = this.storage.getItem('UserName');
    const URL1 = this.envURL + 'usermaster/userId?userId=' + userId;
    const URL3 = this.envURL + 'mastersdata/predictionConfig';
    const getRole = this.httpClient.get(URL1, this.httpOption);
    const colorCodes = this.httpClient.get(URL3, this.httpOption);
    return Observable.forkJoin([getRole, colorCodes]).map((response: any) => {
      return response;
    });
  }

  selctionArr(mockClientSelection, userRoleCount, getCount) {
    this.clientCount = [];
    this.specialityCount = [];
    this.locationCount = [];
    this.workflowCount = [];
    this.facilityCount = [];
    // CLIENT
    mockClientSelection.filter((c, i) => {
      this.clientCount.push({ name: c.name });
    });

    // SPECIALITY
    mockClientSelection.map(o =>
      o.speciality.filter((s, j) => {
        if (o.name === s.clientId) {
          this.specialityCount.push({
            name: s.name
          });
        }
      })
    );

    // LOCATION
    mockClientSelection.map(c =>
      c.speciality.map(s =>
        s.location.filter((l, j) => {
          if (l.specialityId === s.name && l.clientId === c.name) {
            this.locationCount.push({
              name: l.name
            });
          }
        })
      )
    );

    // WORKFLOW
    mockClientSelection.map(c =>
      c.speciality.map(s =>
        s.location.map(l =>
          l.workflow.filter((w, j) => {
            if (
              l.specialityId === s.name &&
              l.clientId === c.name &&
              w.locationId === l.name
            ) {
              this.workflowCount.push({
                name: w.name
              });
            }
          })
        )
      )
    );

    // FACILITY
    mockClientSelection.map(c =>
      c.speciality.map(s =>
        s.location.map(l =>
          l.facility.filter((w, j) => {
            if (
              l.clientId === c.name &&
              l.specialityId === s.name &&
              w.locationId === l.name
            ) {
              this.facilityCount.push({
                name: w.name,
                modality: w.modality
              });
            }
          })
        )
      )
    );

    if (getCount) {
      return {
        clientCount: this.clientCount,
        specialityCount: this.specialityCount,
        locationCount: this.locationCount,
        workflowCount: this.workflowCount,
        facilityCount: this.facilityCount
      };
    } else {
      return this.clientCount.length === 1 &&
        this.specialityCount.length === 1 &&
        this.locationCount.length === 1 &&
        this.workflowCount.length === 1 &&
        userRoleCount.length === 1
        ? true
        : false;
    }
  }
}
