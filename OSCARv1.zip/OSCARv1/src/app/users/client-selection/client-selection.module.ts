import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClientSelectionComponent } from './client-selection.component';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { MaterialModule } from '../../imports/material.module';
import { RouterModule } from '@angular/router';
import { HttpErrorInterceptor } from '../../http-error-interceptor';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    HttpModule,
    HttpClientModule,
    MaterialModule,
    RouterModule.forChild([
      {
        path: '',
        component: ClientSelectionComponent
      }
    ])
  ],
  declarations: [ ClientSelectionComponent ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpErrorInterceptor,
      multi: true,
    },
  ]
})
export class ClientSelectionModule { }
