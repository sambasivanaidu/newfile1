import { Injectable } from '@angular/core';
import { HeaderAuthenticationToken } from '../../auth/authetication-header';
import { environment } from '../../../environments/environment';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { ToastsManager } from 'ng2-toastr';
import { CommonCodeService } from '../../_shared-services/common-code.services';

@Injectable()

export class ClientSelectionService {
  public httpOption;
  public envURL = environment.URL;
  public userName = '';
  public storage: Storage = environment.storage;
  constructor(
    private httpClient: HttpClient,
    private __httpHeader: HeaderAuthenticationToken,
    private toaster: ToastsManager,
    private _commonCode: CommonCodeService
  ) {
    this.httpOption = this.__httpHeader.setHeaderToken();
  }

  public dataReset(): Observable<any> {
    const url = this.envURL + 'facilitymaster/resetDemoData';
    return this.httpClient
      .get(url, this.httpOption)
      .pipe(
        map((response: any) => {
          if (response) {
            return response;
          }
        })
      );
  }

  public specialtyService(clientName): Observable<any> {
    const url = this.envURL + 'userprofile/user/clientSpeciality?clientName=' + clientName;
    return this.httpClient
      .get(url, this.httpOption)
      .pipe(
        map((response: any) => {
          if (response) {
            return response;
          }
        })
      );
  }

  public locationService(specialty): Observable<any> {
    const role = this.storage.getItem('osc-def-rol');
    const obj = {
      clientSpecialityName: specialty,
      role: role,
      supervisorID: this.getManager()
    };

    const url = this.envURL + 'facilitymaster/clientlocations';
    return this.httpClient
      .post(url, obj, this.httpOption)
      .pipe(
        map((response: any) => {
          if (response) {
            return response;
          }
        })
      );
  }

  public getManager() {
    this.userName = this.storage.getItem('TLId');
    return this.userName;
  }

  public getPriority(param): Observable<any> {
    const URL = this.envURL + 'chartinformation/allocateCharts';
    return this.httpClient
      .post(URL, param, this.httpOption)
      .pipe(
        map((response: any) => {
          if (response) {
            return response;
          }
        })
      );
  }
}
