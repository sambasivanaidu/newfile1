import { FormControl } from '@angular/forms';
import { Component, OnInit, ViewContainerRef, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ClientSelectionService } from './client-selection.service';
import { ToastsManager } from 'ng2-toastr';
import { MultiSelectModel } from '../../imports/_utilities/mat-dropdown-search';
import * as CryptoJS from 'crypto-js';
import { UserService } from '../shared/user.service';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import { Subject } from 'rxjs/Subject';
import { environment } from '../../../environments/environment';
import { NgProgress } from 'ngx-progressbar';
import { DeviceDetectorService } from 'ngx-device-detector';
import { CommonCodeService } from '../../_shared-services/common-code.services';
@Component({
  selector: 'app-client-selection',
  templateUrl: './client-selection.component.html',
  styleUrls: ['./client-selection.component.scss'],
  providers: [ClientSelectionService, UserService]
})
export class ClientSelectionComponent implements OnInit {
  public selectedClientModel;
  public selectedSpecialtyModel;
  public selectedLocationModel;
  public selectedWorkflowModel;
  public selectedWorkRoleModel;
  public isDisable: boolean = true;
  public clientList: any = [];
  public roleList: any = [];
  public userRole;
  public specialtyList: any = [];
  public locationList: any = [];
  public clientConfiguration: any = [];
  public clientDOJ;
  public clientType;
  public workflowList: any = [];
  public clientSelectionObject: any;
  public isDemoUser = false;
  facilityModel: any[];
  /** control for the selected facility for multi-selection */
  public facilitySelectModel: FormControl = new FormControl();
  /** control for the MatSelect filter keyword multi-selection */
  public facilitySearchModel: FormControl = new FormControl();
  /** list of facility filtered by search keyword for multi-selection */
  public facilityList: ReplaySubject<MultiSelectModel[]> = new ReplaySubject<
    MultiSelectModel[]
  >(1);
  facilityOptionDD: MultiSelectModel[] = [];
  //  temp
  facilityOptionsModel: any = [];
  /** Subject that emits when the component has been destroyed. */
  _onDestroy = new Subject<void>();
  @ViewChild('matCheck') matCheck;
  @ViewChild('matUnCheck') matUnCheck;
  public storage: Storage = environment.storage;
  public deviceInfo;
  constructor(
    private _router: Router,
    private _clientSelectionService: ClientSelectionService,
    public toaster: ToastsManager,
    // private vcRef: ViewContainerRef,
    private deviceService: DeviceDetectorService,
    public ngProgress: NgProgress,
    private _commonCode: CommonCodeService
  ) {
    // this.toaster.setRootViewContainerRef(this.vcRef);
  }
  public ngOnInit() {
    this.getRoles();
    if (this.userRole.map(res => res.code).toString() === 'admin') {
      this.isDemoUser = true;
    }
  }
  epicFunction() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
    if (this.deviceInfo.browser !== 'Chrome') {
      this._router.navigate(['/404', { msg: 'notAllowed' }]);
    }
  }
  public getRoles() {
    const data = JSON.parse(this.storage.getItem('clientConfiguration'));
    if (data) {
      this.clientConfiguration = data.userconfiguration;
      this.clientDOJ = data.doj;
      this.clientType = data.userType;
      this.userRole = data.userRole;
      this.getClientList(data.userconfiguration.client);
    }
  }
  public getClientList(data) {
    this.clientList = [];
    data.forEach(c => {
      this.clientList.push({ name: c.name });
    });
  }
  public getSpecialtyList(event): void {
    this.specialtyList = [];
    this.clientConfiguration.client.map(o =>
      o.speciality.filter((s, j) => {
        if (o.name === s.clientId) {
          this.specialtyList.push({
            name: s.name
          });
        }
      })
    );
  }
  public getLocationList(event): void {
    this.locationList = [];
    this.clientConfiguration.client.map(c =>
      c.speciality.map(s =>
        s.location.filter((l, j) => {
          if (l.specialityId === s.name && l.clientId === c.name) {
            this.locationList.push({
              name: l.name
            });
          }
        })
      )
    );
  }
  public getWorkflowList(): void {
    this.workflowList = [];
    this.clientConfiguration.client.map(c =>
      c.speciality.map(s =>
        s.location.map(l =>
          l.workflow.filter((w, j) => {
            if (
              l.specialityId === s.name &&
              l.clientId === c.name &&
              w.locationId === l.name
            ) {
              this.workflowList = [{ name: 'CODING' }];
            }
          })
        )
      )
    );
    this.getWorkroleList();
  }
  public getWorkroleList() {
    this.roleList = this.userRole;
  }
  enableStarted() {
    this.isDisable = false;
  }
  getStarted() {
    this.ngProgress.start();
    this.isDisable = true;
    this.storage.setItem('selectedRole', this.selectedWorkRoleModel.code);
    this.sessionStoreUserConfig();
    if (
      this.selectedWorkRoleModel.code === 'coder' ||
      this.selectedWorkRoleModel.code === 'auditor' ||
      this.selectedWorkRoleModel.code === 'sme'
    ) {
      this.getPriority();
    } else {
      this.ngProgress.done();
      this._router.navigate(['/index']);
    }
  }
  sessionStoreUserConfig() {
    this.clientSelectionObject = JSON.stringify({
      client: this.selectedClientModel,
      specialty: this.selectedSpecialtyModel,
      location: this.selectedLocationModel,
      workflow: this.selectedWorkflowModel,
      workRole: this.selectedWorkRoleModel,
      clientConfiguration: this.clientConfiguration,
      clientDOJ: this.clientDOJ,
      clientType: this.clientType
    });
    const clientSelection = CryptoJS.AES.encrypt(
      this.clientSelectionObject,
      'oscar'
    ).toString();
    this.storage.setItem('clientSelectionObject', clientSelection);
  }

  dataReset() {
    this._clientSelectionService.dataReset().subscribe(res => {
      if (res) {
        this.toaster.success("Data Reset Successfully")
      }
    })
  }

  reset() {
    this.selectedClientModel = [];
    this.selectedSpecialtyModel = [];
    this.selectedLocationModel = [];
    this.selectedWorkRoleModel = [];
  }
  private getPriority() {
    const clientObj = this._commonCode.get_ConfidenceColor_Clientselection(
      'clientSelectionObject'
    );
    const clientConfig = JSON.parse(
      this.storage.getItem('clientConfiguration')
    );
    const role = clientObj.workRole.role;
    const param = {
      userId: this.storage.getItem('UserName'),
      teamLeadId: this.storage.getItem('TLId'),
      role: role,
      doj: this.clientDOJ,
      location: clientObj.location,
      userConfiguration: this.clientConfiguration,
      userType: this.clientType,
      speciality: clientObj.specialty,
      client: clientObj.client,
      targetsampling: clientConfig.targetsampling
    };
    this._clientSelectionService.getPriority(param).subscribe(response => {
      this.ngProgress.done();
      this.storage.setItem('osc-coder-pri', response);
      this._router.navigate(['/index']);
    });
  }
}
