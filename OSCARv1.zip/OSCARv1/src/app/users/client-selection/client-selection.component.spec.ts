import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ClientSelectionComponent } from './client-selection.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatAutocompleteModule,
    MatExpansionModule,
    MatDialogModule
} from '@angular/material';
import { AgGridModule } from 'ag-grid-angular';
import { ToastsManager } from 'ng2-toastr';
import { ToastOptions } from 'ng2-toastr';
import { RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { FlexLayoutModule } from '@angular/flex-layout';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA, ViewContainerRef } from '@angular/core';
import { APP_BASE_HREF } from '@angular/common';
import { HttpModule } from '@angular/http';
import { of } from 'rxjs/observable/of';
import { NgProgress } from 'ngx-progressbar';
import { HeaderAuthenticationToken } from '../../auth/authetication-header';
import { ErrorHandlingServices } from '../../services/error-handling.services';
import { CommonCodeService } from '../../_shared-services/common-code.services';
import { DeviceDetectorService } from 'ngx-device-detector';
import { QueueService } from '../../services/main-pages/queue.service';
import { PlatformService } from '../../services/main-pages/paltform-services/platform-service.service';

describe('ClientSelectionComponet', () => {
  let component: ClientSelectionComponent;
  let fixture: ComponentFixture<ClientSelectionComponent>;
  let elementRefference;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClientSelectionComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        HttpModule,
        MatButtonModule,
        MatIconModule,
        MatInputModule,
        MatFormFieldModule,
        MatAutocompleteModule,
        FormsModule,
        ReactiveFormsModule,
        MatExpansionModule,
        AgGridModule.forRoot(),
        RouterModule,
        RouterTestingModule,
        MatDialogModule,
        FlexLayoutModule,
        BrowserAnimationsModule,
        HttpClientTestingModule,
    ],
    providers: [
        { provide: APP_BASE_HREF, useValue: '/' },
        PlatformService,
        ToastsManager,
        ToastOptions,
        QueueService,
        HeaderAuthenticationToken,
        ErrorHandlingServices,
        ViewContainerRef,
        NgProgress,
        CommonCodeService,
        DeviceDetectorService
    ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientSelectionComponent);
    component = fixture.componentInstance;
    elementRefference = fixture.debugElement;
  //  fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('#ngOnInit checking userRole is admin or not', () => {
    spyOn(component, 'getRoles');
    expect(component.userRole).toBe(undefined);
  });

  it('#ngOnInit ', () => {
    spyOn(component, 'getRoles');
    expect(component.isDemoUser).toBe(false);
  });

  it('#DOM check', () => {
 const compiled = fixture.debugElement.nativeElement;
 expect(compiled.querySelector('.title').textContent).toContain('Client Selection');
  });

});
