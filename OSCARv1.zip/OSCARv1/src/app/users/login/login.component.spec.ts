import {
  TestBed,
  async,
  fakeAsync,
  ComponentFixture,
  inject,
  tick
} from '@angular/core/testing';
import { BrowserModule, By } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  BrowserAnimationsModule,
  NoopAnimationsModule
} from '@angular/platform-browser/animations';
import { MatDynamicDdComponent } from '../..//imports/_utilities/mat-dynamic-dd/mat-dynamic-dd.component';
import { MaterialModule } from '../../imports/material.module';
import { LoginComponent } from './login.component';
import { ClientSelectionService } from '../client-selection/client-selection.service';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import { HeaderAuthenticationToken } from '../../auth/authetication-header';
import { ToastsManager, ToastOptions } from 'ng2-toastr/ng2-toastr';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';
import { DeviceDetectorService } from 'ngx-device-detector';
import {
  NgProgressModule,
  NgProgressBrowserXhr,
  NgProgressInterceptor
} from 'ngx-progressbar';
import { UserService } from '../shared/user.service';
import { Observable } from 'rxjs/Observable';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';
import { CommonCodeService } from '../../_shared-services/common-code.services';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let userService: UserService;
  let fixture: ComponentFixture<LoginComponent>;
  let httpMock: HttpTestingController;
  let originalTimeout;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LoginComponent],
      providers: [
        ClientSelectionService,
        CommonCodeService,
        DeviceDetectorService,
        HeaderAuthenticationToken,
        ToastsManager,
        ToastOptions,
        UserService,
        { provide: UserService, useClass: MockUser },
        ConfirmationService
      ],
      imports: [
        MaterialModule,
        BrowserModule,
        BrowserAnimationsModule,
        FormsModule,
        HttpClientTestingModule,
        RouterTestingModule,
        NgProgressModule,
        ConfirmDialogModule
      ]
    }).compileComponents();
  }));
  beforeEach(() => {
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 5000;
    // create component and test fixture
    fixture = TestBed.createComponent(LoginComponent);
    // get test component from the fixture
    component = fixture.componentInstance;
    userService = TestBed.get(UserService);
    fixture.detectChanges();
  });
  afterEach(() => {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = originalTimeout;
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // it('onsubmit() if username and password are incorrect, token should be null', () => {
  //   component.OnSubmit('abc','def');
  //   expect(component.storage.getItem('Token')).toBeNull();
  // });
  // it('onsubmit() if username and password are correct, token should not be null', fakeAsync(() => {
  //   component.OnSubmit('sangramm','oscar');
  //   spyOn(userService, 'userAuthentication').and.returnValue({access_token:'abcsdsdsgsfsffsf'});
  //   let loginDetail = {
  //     userid: 'sangram',
  //     pass: 'oscar'
  //     };

  //   let data:any = userService.userAuthentication(loginDetail);
  //   tick();
  //   expect(data.access_token).toBe('abcsdsdsgsfsffsf');
  //   expect(userService.userAuthentication).toHaveBeenCalled();
  // }));

  it('sanitizeHtml(input) should return sanitized string', () => {
    let input = 'user<script>qwerty</script>';
    component.sanitizeHtml(input);
    expect(component.sanitizeHtml(input)).not.toBe(input);
  });
});

class MockUser {
  userAuthentication(loginDetail) {
    if (loginDetail.pass !== 'oscar') {
      return { access_token: null };
    } else {
      return { access_token: 'abcsdsdsgsfsffsf' };
    }
  }
}
