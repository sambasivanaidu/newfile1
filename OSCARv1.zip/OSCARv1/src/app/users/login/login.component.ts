import { NgProgress } from 'ngx-progressbar';
import {
  Component,
  OnInit,
  ViewContainerRef,
  SecurityContext
} from '@angular/core';
import { UserService } from '../shared/user.service';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import * as CryptoJS from 'crypto-js';
import { environment } from '../../../environments/environment';
import { ClientSelectionService } from '../client-selection/client-selection.service';
import { DomSanitizer } from '@angular/platform-browser';
import { DeviceDetectorService } from 'ngx-device-detector';
import { ConfirmationService } from 'primeng/components/common/api';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  providers: [UserService, ClientSelectionService]
})
export class LoginComponent implements OnInit {
  public storage: Storage = environment.storage;
  public isLoginError = false;
  public isUserLoggedIn: boolean;
  public clientConfiguration;
  public confidenceColorCode;
  public clientSelectionObject: any;
  public workroleCode: any;
  public deviceInfo;
  clientCount;
  specialityCount;
  locationCount;
  workflowCount;
  hide;
  msgs = [];
  icon;

  constructor(
    private _userService: UserService,
    private _router: Router,
    public _toastr: ToastsManager,
    private _clientSelectionService: ClientSelectionService,
    public ngProgress: NgProgress,
    private _sanitizer: DomSanitizer,
    private deviceService: DeviceDetectorService,
    private confirmationService: ConfirmationService
  ) {
  }

  confirm(msg, loginDetail) {
    this.icon = 'fa-question-circle';
    this.confirmationService.confirm({
      message: msg,
      header: 'Confirmation',
      accept: () => {
        const param = {
          userid: loginDetail.userid,
          updatedby: loginDetail.userid
        };
        this._userService.userForceLogout(param).subscribe(data => {
          if (data === 1) {
            sessionStorage.clear();
            this.OnSubmit(loginDetail.userid, loginDetail.password);
          }
        });
      }
    });
  }

  epicFunction() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
    if (this.deviceInfo.browser !== 'Chrome') {
      this._router.navigate(['/404', { msg: 'notAllowed' }]);
    }
  }

  public ngOnInit() {}
  sanitizeHtml(input) {
    return this._sanitizer.sanitize(SecurityContext.HTML, input);
  }
  public OnSubmit(userName, password) {
    this.ngProgress.start();
    sessionStorage.clear();
    const loginDetail = {
      userid: this.sanitizeHtml(userName).toLowerCase(),
      password: password
    };
    const userNameLoweCase = userName.toLowerCase();
    this._userService.userAuthentication(loginDetail).subscribe(
      data => {
        if (data.access_token != null && data.access_token.length > 50) {
          this.storage.setItem('Token', data.access_token);
          this.storage.setItem('UserName', userNameLoweCase);
          this._userService.getUserRole().subscribe(roleData => {
            this.clientConfiguration = roleData[0].userMaster;
            this.confidenceColorCode = CryptoJS.AES.encrypt(
              JSON.stringify(roleData[1]),
              'oscar'
            ).toString();
            this.setUserRole(this.clientConfiguration, roleData[0].userTarget);
            if (this.clientConfiguration.userRole[0].role === 'CLIENT') {
              this._router.navigate(['index/rai/raidashboard']);
            } else if (
              this.clientConfiguration.userRole[0].role === 'SENIOR MANAGER'
            ) {
              this.sessionStoreUserConfig();
              const getfacility: any = this._userService.selctionArr(
                this.clientConfiguration.userconfiguration.client,
                this.clientConfiguration.userRole,
                true
              );
              if (getfacility.facilityCount.length > 0) {
                this.storage.setItem(
                  'facilityList',
                  JSON.stringify(getfacility.facilityCount)
                );
              }
              this._router.navigate(['index/managerdashboard']);
            } else if ( this._userService.selctionArr( this.clientConfiguration.userconfiguration.client,  this.clientConfiguration.userRole, false)) {
              const getfacility: any = this._userService.selctionArr(
                 this.clientConfiguration.userconfiguration.client,
                 this.clientConfiguration.userRole,
                true
              );
              if (getfacility.facilityCount.length > 0) {
                this.storage.setItem(
                  'facilityList',
                  JSON.stringify(getfacility.facilityCount)
                );
              }
              this.skipClientSelection();
            } else {
              const getfacility: any = this._userService.selctionArr(
                 this.clientConfiguration.userconfiguration.client,
                 this.clientConfiguration.userRole,
                true
              );
              if (getfacility.facilityCount.length > 0) {
                this.storage.setItem(
                  'facilityList',
                  JSON.stringify(getfacility.facilityCount)
                );
                this._router.navigate(['welcome/login/clientselection']);
              } else {
                this._toastr.info(
                  'Something missing in client configuration',
                  'Info',
                  'Oops!'
                );
              }
            }
          });
        } else {
          if (data.access_token === 'User already Logged In') {
            const txt = 'User already logged in. Click YES to continue.';
            this.confirm(txt, loginDetail);
          } else {
            this.isLoginError = true;
            this._toastr.info(data.access_token, 'Info', 'Oops!');
          }
        }
        this.ngProgress.done();
      }
    );
  }

  setUserRole(data, target) {
    this.storage.setItem('confidenceColorCode', this.confidenceColorCode);
    this.storage.setItem('clientConfiguration', JSON.stringify(data));
    const userFname = data.userfirstname ? data.userfirstname : '';
    const userMname = data.usermiddlename ? data.usermiddlename : '';
    const userLname = data.userlastname ? data.userlastname : '';
    const user = (userFname + ' ' + userMname + ' ' + userLname).toLowerCase();
    this.storage.setItem('osc-usr', user);
    this.storage.setItem('osc-def-rol', data.defaultRole);

    const roleData = CryptoJS.AES.encrypt(
      JSON.stringify(data.userRole),
      'oscar'
    ).toString();
    this.storage.setItem('TLId', data.teamlead);
    this.storage.setItem('Role', roleData);
    this.storage.setItem('samplingPercent', data.samplingpercentage);
    this.storage.setItem('targetSampling', JSON.stringify(data.targetsampling));
  }

  private skipClientSelection() {
    this.sessionStoreUserConfig();
    if (
      this.workroleCode === 'coder' ||
      this.workroleCode === 'auditor' ||
      this.workroleCode === 'sme'
    ) {
      this.getPriority();
    } else {
      this._router.navigate(['/index']);
    }
  }

  sessionStoreUserConfig() {
    const userConfiguration = this.clientConfiguration.userconfiguration;
    this.workroleCode = this.clientConfiguration.userRole[0].code;
    this.clientSelectionObject = JSON.stringify({
      client: userConfiguration.client.length === 1 ? userConfiguration.client[0].name : userConfiguration.client,
      specialty: userConfiguration.client[0].speciality[0].name,
      location: userConfiguration.client[0].speciality[0].location[0].name,
      workflow:
        userConfiguration.client[0].speciality[0].location[0].workflow[0],
      workRole: this.clientConfiguration.userRole[0],
      clientConfiguration: userConfiguration,
      clientDOJ: this.clientConfiguration.doj,
      clientType: this.clientConfiguration.userType
    });
    const clientSelection = CryptoJS.AES.encrypt(
      this.clientSelectionObject,
      'oscar'
    ).toString();
    this.storage.setItem('clientSelectionObject', clientSelection);
  }

  private getPriority() {
    const clientObj = JSON.parse(
      CryptoJS.AES.decrypt(
        this.storage.getItem('clientSelectionObject'),
        'oscar'
      ).toString(CryptoJS.enc.Utf8)
    );
    const role = clientObj.workRole.role;
    const param = {
      userId: this.storage.getItem('UserName'),
      teamLeadId: this.storage.getItem('TLId'),
      role: role,
      doj: clientObj.clientDOJ,
      location: clientObj.location,
      userConfiguration: clientObj.clientConfiguration,
      userType: clientObj.clientType,
      speciality: clientObj.specialty,
      client: clientObj.client
    };
    this._clientSelectionService.getPriority(param).subscribe(response => {
      this.storage.setItem('osc-coder-pri', response);
      this._router.navigate(['/index']);
    });
  }
}
