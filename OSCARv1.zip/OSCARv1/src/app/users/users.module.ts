import { Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UsersComponent } from './users.component';
import { RouterModule } from '@angular/router';
import { MatMessageDialogModule } from '../imports/_utilities/mat-message-dialog/mat-message-dialog.module';
const routes: Routes = [
  {
    path: 'login',
    component: UsersComponent,
    children: [
      {
        path: '',
        loadChildren: 'app/users/login/login.module#LoginModule'
      },
      {
        path: 'clientselection',
        loadChildren:
          'app/users/client-selection/client-selection.module#ClientSelectionModule'
      }
    ]
  }
];
@NgModule({
  imports: [
    CommonModule,
    MatMessageDialogModule,
    RouterModule.forChild(routes)
  ],
  declarations: [UsersComponent]
})
export class UsersModule {}
