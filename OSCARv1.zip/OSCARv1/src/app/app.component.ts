import { Component, ViewContainerRef } from '@angular/core';
import { ToastsManager } from 'ng2-toastr';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  title = 'OSCAR';
  public viewContainerRef: ViewContainerRef;
  constructor(
    public toaster: ToastsManager,
    vcRef: ViewContainerRef
  ) {
    this.viewContainerRef = vcRef;
    this.toaster.setRootViewContainerRef(vcRef);
  }
}
