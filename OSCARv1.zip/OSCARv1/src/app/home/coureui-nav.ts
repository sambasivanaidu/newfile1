interface NavAttributes {
    [propName: string]: any;
  }
  interface NavWrapper {
    attributes: NavAttributes;
    element: string;
  }
  interface NavBadge {
    text: string;
    variant: string;
  }
  interface NavLabel {
    class?: string;
    variant: string;
  }

  export interface NavData {
    name?: string;
    url?: string;
    icon?: string;
    badge?: NavBadge;
    title?: boolean;
    children?: NavData[];
    variant?: string;
    attributes?: NavAttributes;
    divider?: boolean;
    class?: string;
    label?: NavLabel;
    wrapper?: NavWrapper;
  }

  export const coderNavItems: NavData[] = [
    {
      name: 'Home',
      url: '',
      icon: 'icon-speedometer',
      badge: {
        variant: 'info',
        text: 'NEW'
      }
    },
    {
      divider: true
    },
    {
      title: true,
      name: 'Coders'
    },
    {
      name: 'My Queue',
      url: '/Coders/my-queue',
      icon: 'icon-drop'
    }
  ];
  export const auditorsNavItems: NavData[] = [
    {
      name: 'Home',
      url: '',
      icon: 'icon-speedometer',
      badge: {
        variant: 'info',
        text: 'NEW'
      }
    },
    {
      divider: true
    },
    {
      title: true,
      name: 'Auditors'
    },
    {
      name: 'My Queue',
      url: '',
      icon: 'icon-drop'
    }
  ];

  export const tlNavItems: NavData[] = [
    {
      name: 'Home',
      url: '',
      icon: 'icon-speedometer',
      badge: {
        variant: 'info',
        text: 'NEW'
      }
    },
    {
      divider: true
    },
    {
      title: true,
      name: 'Team Lead'
    },
    {
      name: 'Rebuttal Review',
      url: '',
      icon: 'icon-drop'
    },
    {
      name: 'Inventory Tracker',
      url: '',
      icon: 'icon-drop'
    },
    {
      name: 'Inventory Upload',
      url: '',
      icon: 'icon-drop'
    },
    {
      name: 'Facility on-boarding',
      url: '',
      icon: 'icon-drop'
    },
    {
      name: 'User mapping',
      url: '',
      icon: 'icon-drop'
    },
    {
      divider: true
    },
    {
      title: true,
      name: 'Reports'
    },
    {
      name: 'Test',
      url: '',
      icon: 'icon-drop'
    },
  ];
