import { NgProgress } from 'ngx-progressbar';
import {
  Component,
  OnInit,
  NgZone,
  ViewChild,
  OnDestroy,
  Inject
} from '@angular/core';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';
import { HeaderAuthenticationToken } from '../auth/authetication-header';
import * as CryptoJS from 'crypto-js';
import { HomeComponentService } from './home.component.service';
import { DateFormatter } from '../imports/_utilities/date-formatter';
import { ToastsManager } from 'ng2-toastr';
import { FormGroup } from '@angular/forms';
import { MatSidenavContainer, MatDialog } from '@angular/material';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
import { TimeoutModalComponent } from '../imports/_utilities/timeout-modal/timeout-modal.component';
import { UserService } from '../users/shared/user.service';
import { CommonCodeService } from '../_shared-services/common-code.services';
import { DOCUMENT } from '@angular/platform-browser';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  providers: [HomeComponentService, DateFormatter, Keepalive, UserService]
})
export class HomeComponent implements OnInit, OnDestroy {
  idleState = 'Not started.';
  timedOut = false;
  lastPing?: Date = null;
  width;
  height;
  mode: string = 'push';
  open = 'true';
  title = 'Oscar';
  navList: NavList[];
  navListHeader = [];
  userClaims: any;
  userName;
  userRole;
  toggleLogoExpanded: boolean = false;
  usernameLogged;
  public envURL = environment.URL;
  public httpOption;
  public clientObj;
  public dashboardName: string;
  public sidenavMode: string = 'side';
  public isClicked: boolean = false;
  public isCoder: boolean = false;
  public isAuditor: boolean = false;
  public isClient: boolean = false;
  public isTl: boolean = false;
  public isSme: boolean = false;
  public isMgr: boolean = false;
  public colorCodes;
  public dashboardSummary: any;
  public userCode: string;
  public menuClicked: boolean = true;
  public dialogRef;
  public clientRole: any;
  public isAdmin: boolean = false;
  public deviceInfo;
  options: FormGroup;
  @ViewChild(MatSidenavContainer) sidenavContainer: MatSidenavContainer;
  @ViewChild('navBarToggle') navBarToggle;
  public storage: Storage = environment.storage;
  isLogout = false;
  constructor(
    public ngZone: NgZone,
    public _router: Router,
    private __httpHeader: HeaderAuthenticationToken,
    private homecomponentService: HomeComponentService,
    private dateFormatter: DateFormatter,
    public toaster: ToastsManager,
    public dialog: MatDialog,
    private idle: Idle,
    private keepalive: Keepalive,
    private _userService: UserService,
    public ngProgress: NgProgress,
    private _commonCode: CommonCodeService,
    @Inject(DOCUMENT) private document: Document
  ) {
    this.usernameLogged = this.storage.getItem('UserName');
    this.navListInit();
    this.userName = this.storage.getItem('osc-usr').toUpperCase();
    this.httpOption = this.__httpHeader.setHeaderToken();
    this.ngKeepAliveInit();
    const clientConfigObj = this.storage.getItem('clientConfiguration');
    this.clientRole = JSON.parse(clientConfigObj).userRole[0].role;
  }
  ngKeepAliveInit() {
    if (this.dialog) {
      // sets an idle timeout of 20 minutes.
      this.idle.setIdle(1200);
    }
    // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
    this.idle.setTimeout(10);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
    this.idle.onIdleStart.subscribe(() => {
      this.idleState = 'You have gone idle!';
      this.openSessionTimeOutModal(this.idle, this.idleState, false);
    });
    // sets the ping interval to 15 seconds
    this.keepalive.interval(15);
    this.keepalive.onPing.subscribe(() => (this.lastPing = new Date()));
    this.reset();
  }
  openSessionTimeOutModal(idle, idleState, keepalive) {
    this.dialogRef = this.dialog.open(TimeoutModalComponent, {
      hasBackdrop: true,
      disableClose: true,
      width: '400px',
      data: {
        idle: idle,
        keepalive: keepalive,
        idleState: idleState,
        dialog: this.dialog,
        role: this.userRole
      }
    });
    this.dialogRef.afterClosed().subscribe(result => {
      this.dialog.closeAll();
    });
  }
  ngOnDestroy() {
    this.dialogRef = null;
    this.dialog.closeAll();
  }
  public reset() {
    this.idle.watch();
    this.idleState = 'Started.';
    this.timedOut = false;
  }
  ngOnInit() {}
  toggleCollapse() {
    let collapsedSidenav = document.body.classList; // document.body.querySelectorAll('.brand-minimized .sidebar-minimized');
    const array = Array.from(collapsedSidenav);
    if (
      array.includes('brand-minimized') &&
      array.includes('sidebar-minimized')
    ) {
      document.body.classList.remove('brand-minimized');
      document.body.classList.remove('sidebar-minimized');
    } else {
      document.body.classList.add('brand-minimized');
      document.body.classList.add('sidebar-minimized');
    }
  }
  toggleNavOption(eve) {
    let navEl = eve.currentTarget.classList;
    const array = Array.from(navEl);
    if (array.includes('open')) {
      navEl.remove('open');
      return;
    } else {
      navEl.add('open');
      return;
    }
  }
  windowOnresize() {
    window.onresize = e => {
      this.ngZone.run(() => {
        this.changeMode();
      });
    };
  }
  navListInit() {
    const isClientObj = this.storage.getItem('clientSelectionObject');
    let clientRoleList = this.storage.getItem('Role');
    let clientRole = JSON.parse(
      CryptoJS.AES.decrypt(clientRoleList, 'oscar').toString(CryptoJS.enc.Utf8)
    );
    this.userRole = clientRole[0].role;
    if (isClientObj) {
      this.clientObj = this._commonCode.get_ConfidenceColor_Clientselection(
        'clientSelectionObject'
      );
      this.userRole = this.clientObj.workRole.role; // .toLowerCase();
      this.userCode = this.clientObj.workRole.code;
      const clientObj = JSON.parse(
        CryptoJS.AES.decrypt(isClientObj, 'oscar').toString(CryptoJS.enc.Utf8)
      );
      const role = clientObj.workRole.code;
      role === 'admin'
        ? (this.isAdmin = true)
        : role === 'manager'
        ? (this.isMgr = true)
        : role === 'coder'
        ? (this.isCoder = true)
        : role === 'auditor'
        ? (this.isAuditor = true)
        : role === 'tl'
        ? (this.isTl = true)
        : role === 'sme'
        ? (this.isSme = true)
        : (this.isSme = false);
    } else if (!isClientObj && this.userRole === 'SENIOR MANAGER') {
      this.isMgr = true;
    } else {
      clientRoleList = this.storage.getItem('Role');
      clientRole = JSON.parse(
        CryptoJS.AES.decrypt(clientRoleList, 'oscar').toString(
          CryptoJS.enc.Utf8
        )
      );
      this.isClient = true;
      /*       this.isMgr = false; */
      this.userRole = clientRole[0].role;
      this.userCode = clientRole[0].code;
    }
    this.navJson();
  }
  navJson() {
    this.navListHeader = [
      {
        icon: 'home',
        headerName: 'Dashboard',
        headerLink: '/index',
        isVisible: !this.isClient && !this.isMgr
      },
      // { icon: 'Admin', headerName: 'Admin Dashboard', headerLink: '/index/admin1', isVisible: !this.isClient },
      {
        icon: 'home',
        headerName: 'RAI Dashboard',
        headerLink: '/index/rai/raidashboard',
        isVisible: this.isClient
      },
      // { icon: 'insert_link', headerName: 'User Mapping', headerLink: '/index/userMapping', isVisible: !this.isClient }
      {
        icon: 'Admin',
        headerName: 'Manager Dashboard',
        headerLink: '/index/managerdashboard',
        isVisible: this.isMgr
      }
    ];
    this.navList = [
      {
        categoryName: 'Coders',
        icon: 'cui-user',
        dropDown: false,
        hideToggle: false,
        isVisible: this.isCoder || this.isAdmin,
        subCategory: [
          {
            subCategoryName: 'Coder Queue',
            subCategoryLink: '/index/coder/queue',
            visible: this.isCoder || this.isAdmin,
            icon: 'star'
          }
        ]
      },
      {
        categoryName: 'Auditors',
        icon: 'cui-speech',
        dropDown: false,
        hideToggle: false,
        isVisible: this.isAuditor || this.isAdmin,
        subCategory: [
          {
            subCategoryName: 'Auditor Queue',
            subCategoryLink: '/index/auditor/queue',
            visible: this.isAuditor || this.isAdmin,
            icon: 'star'
          },
          {
            subCategoryName: 'L2 Audit',
            subCategoryLink: '/index/L2auditor/queue',
            visible: this.isAuditor || this.isAdmin,
            icon: 'star'
          }
        ]
      },
      {
        categoryName: 'SME',
        icon: 'cui-user-follow',
        dropDown: false,
        hideToggle: false,
        isVisible: this.isSme || this.isAdmin,
        subCategory: [
          {
            subCategoryName: 'Adaptive Learning',
            subCategoryLink: '/index/sme/learning',
            visible: this.isSme || this.isAdmin,
            icon: 'star'
          },
          {
            subCategoryName: 'Inventory Tracking',
            subCategoryLink: '/index/teamlead/inventorytracking',
            visible: this.isSme || this.isAdmin,
            icon: 'star'
          },
          {
            subCategoryName: 'Work Allocation',
            subCategoryLink: '/index/workAllocation',
            visible: false || this.isAdmin,
            icon: 'star'
          },
          {
            subCategoryName: 'SME Queue',
            subCategoryLink: '/index/sme/queue',
            visible: this.isSme || this.isAdmin,
            icon: 'star'
          }
        ]
      },
      {
        categoryName: 'Team Lead',
        icon: 'cui-people',
        dropDown: false,
        hideToggle: false,
        isVisible: this.isTl || this.isAdmin,
        subCategory: [
          {
            subCategoryName: 'Rebuttal Review',
            subCategoryLink: '/index/teamlead/queue',
            visible: this.isTl || this.isAdmin,
            icon: 'star'
          },
          {
            subCategoryName: 'Inventory Tracker',
            subCategoryLink: '/index/teamlead/inventorytracking',
            visible: this.isTl || this.isAdmin,
            icon: 'star'
          },
          {
            subCategoryName: 'Inventory Upload',
            subCategoryLink: '/index/teamlead/inventoryupload',
            visible: this.isTl || this.isAdmin,
            icon: 'star'
          },
          {
            subCategoryName: 'Facility Onboarding',
            subCategoryLink: '/index/teamlead/facilityonboarding',
            visible: (!this.isClient && this.isTl) || this.isAdmin,
            icon: 'star'
          },
          {
            subCategoryName: 'User Mapping',
            subCategoryLink: '/index/teamlead/usermapping',
            visible: this.isTl || this.isAdmin,
            icon: 'star'
          }
        ]
      },
      {
        categoryName: 'RAI',
        icon: 'cui-user',
        dropDown: false,
        hideToggle: false,
        isVisible: this.isClient,
        subCategory: [
          {
            subCategoryName: 'Queue',
            subCategoryLink: '/index/rai/raiqueue',
            visible: true,
            icon: 'star'
          }
        ]
      },
      {
        categoryName: 'Reports',
        icon: 'cui-file',
        dropDown: false,
        hideToggle: false,
        isVisible:
          this.isCoder || this.isAuditor ? false : true || this.isAdmin,
        subCategory: [
          {
            subCategoryName: 'Reconciliation',
            subCategoryLink: '/index/reports/tatreconciliation',
            visible: !this.isClient || this.isAdmin,
            icon: 'star'
          },
          {
            subCategoryName: 'Daily Status',
            subCategoryLink: '/index/reports/dailyStatus',
            visible: !this.isClient || this.isAdmin,
            icon: 'star'
          },
          {
            subCategoryName: 'Aging',
            subCategoryLink: '/index/reports/aging',
            visible: !this.isClient || this.isAdmin,
            icon: 'star'
          },
          {
            subCategoryName: 'Productivity',
            subCategoryLink: '/index/reports/productivity',
            visible: !this.isClient || this.isAdmin,
            icon: 'star'
          },
          {
            subCategoryName: 'Quality',
            subCategoryLink: '/index/reports/qualityaccuracy',
            visible: !this.isClient || this.isAdmin,
            icon: 'star'
          },
          {
            subCategoryName: 'Duplicates Log',
            subCategoryLink: '/index/reports/duplicatesLog',
            visible: !this.isClient || this.isAdmin,
            icon: 'star'
          },
          {
            subCategoryName: 'Discard Log',
            subCategoryLink: '/index/reports/discardLog',
            visible: !this.isClient || this.isAdmin,
            icon: 'star'
          },
          {
            subCategoryName: 'Error Analysis',
            subCategoryLink: '/index/reports/errorAnalysis',
            visible: !this.isClient || this.isAdmin,
            icon: 'star'
          },
          {
            subCategoryName: 'RAI Log',
            subCategoryLink: '/index/reports/raiLog',
            visible: !this.isClient || this.isAdmin,
            icon: 'star'
          },
          {
            subCategoryName: 'Monthly Invoice',
            subCategoryLink: '/index/reports/monthlyInvoice',
            visible: !this.isClient || this.isAdmin,
            icon: 'star'
          },
          {
            subCategoryName: 'Reconciliation',
            subCategoryLink: '/index/reports/raiReports',
            visible: this.isClient || this.isAdmin,
            icon: 'star'
          }
        ]
      }
    ];
  }
  public sidenavClick() {
    if (!this.menuClicked) {
      this.sidenavContainer.open();
      this.menuClicked = !this.menuClicked;
    } else {
      this.sidenavContainer.close();
      this.menuClicked = !this.menuClicked;
    }
  }
  changeMode() {
    this.width = window.innerWidth;
    this.height = window.innerHeight;
    if (this.width <= 800) {
      this.mode = 'over';
      this.open = 'false';
    }
    if (this.width > 800) {
      this.mode = 'side';
      this.open = 'true';
    }
  }
  logout(tokenService) {
    this.ngProgress.start();
    this.isLogout = true;
    localStorage.clear();
    this.clearChats();
  }
  saveLogoutDetails() {
    const param = {
      userid: this.usernameLogged,
      updatedby: this.usernameLogged
    };
    this.homecomponentService.saveLogoutDetails(param).subscribe(success => {
      if (success === 1) {
        this.clearChats();
        this.idle.stop();
        this.idle.ngOnDestroy();
        this.storage.clear();
        localStorage.clear();
        this._router.navigate(['/login']);
      } else {
        this.toaster.info('Something went wrong.');
      }
    });
  }
  public clearChats() {
    const user = this.storage.getItem('UserName');
    const role = this.userRole;
    this.homecomponentService.clearCharts(user, role).subscribe(success => {
      const param = {
        userid: user,
        updatedby: user
      };
      this._userService.userForceLogout(param).subscribe(data => {
        this.idle.stop();
        this.idle.ngOnDestroy();
        this.storage.clear();
        location.reload();
        this.ngProgress.done();
      });
    });
  }
  public clientSwitch() {
    const user = this.storage.getItem('UserName');
    const role = this.userRole;
    this.homecomponentService.clearCharts(user, role).subscribe(success => {
      this._router.navigate(['login/clientSelection']);
    });
  }
}
export class NavList {
  categoryName: string;
  icon: string;
  dropDown: boolean;
  subCategory: NavListItem[];
  hideToggle: boolean;
  isVisible: boolean;
  constructor(
    _categoryName: string,
    _icon: string,
    _dropDown: boolean,
    _subCategory: NavListItem[]
  ) {
    this.categoryName = _categoryName;
    this.icon = _icon;
    this.dropDown = _dropDown;
    this.subCategory = _subCategory;
  }
}
export class NavDashboard {}
export class NavListItem {
  subCategoryName: string;
  subCategoryLink: string;
  subCategoryQuery?: any;
  visible: boolean;
  icon: string;
}
