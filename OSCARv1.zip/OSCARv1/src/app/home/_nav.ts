
export class NavList {
  categoryName: string;
  icon: string;
  dropDown: boolean;
  subCategory: NavListItem[];
  hideToggle: boolean;
  isVisible: boolean;
  constructor(_categoryName: string, _icon: string, _dropDown: boolean, _subCategory: NavListItem[]) {
    this.categoryName = _categoryName;
    this.icon = _icon;
    this.dropDown = _dropDown;
    this.subCategory = _subCategory;
  }
}

export class NavListItem {
  subCategoryName: string;
  subCategoryLink: string;
  subCategoryQuery?: any;
  visible: boolean;
}
export const navItems: NavList[] = [
  {
    categoryName: 'Coders',
    icon: 'face',
    dropDown: false,
    hideToggle: true,
    isVisible: this.isCoder,
    subCategory:
      [
        {
          subCategoryName: 'Coder Queue',
          subCategoryLink: '/index/coderQueue',
          visible: this.isCoder
        },
      ]
  },
  {
    categoryName: 'Auditors',
    icon: 'question_answer',
    dropDown: false,
    hideToggle: true,
    isVisible: this.isAuditor,
    subCategory:
      [
        {
          subCategoryName: 'Auditor Queue',
          subCategoryLink: '/index/auditorQueue',
          visible: this.isAuditor
        },
      ]
  },
  {
    categoryName: 'SME',
    icon: 'how_to_reg',
    dropDown: false,
    hideToggle: true,
    isVisible: this.isSme,
    subCategory:
      [
        {
          subCategoryName: 'Learning System',
          subCategoryLink: '/index/sme',
          visible: this.isSme
        },
        {
          subCategoryName: 'batchprocess',
          subCategoryLink: '/index/batchprocess',
          visible: this.isSme
        },
        {
          subCategoryName: 'Work Allocation',
          subCategoryLink: '/index/workAllocation',
          visible: this.isSme
        }
      ]
  },
  {
    categoryName: 'Team Lead',
    icon: 'supervisor_account',
    dropDown: false,
    hideToggle: true,
    isVisible: this.isTl,
    subCategory:
      [
        {
          subCategoryName: 'Rebuttal Review',
          subCategoryLink: '/index/tl',
          visible: this.isTl
        },
        {
          subCategoryName: 'Inventory Tracker',
          subCategoryLink: '/index/batchprocess',
          visible: this.isTl
        },
        {
          subCategoryName: 'Inventory Upload',
          subCategoryLink: '/index/invupload',
          visible: this.isTl
        }
      ]
  },
  {
    categoryName: 'Reports',
    icon: 'file_copy',
    dropDown: false,
    hideToggle: true,
    isVisible: true,
    subCategory:
      [
        {
          subCategoryName: 'Aging',
          subCategoryLink: '/index/aging',
          visible: true
        },
        {
          subCategoryName: 'Daily Status',
          subCategoryLink: '/index/dailyStatus',
          visible: true
        },
        {
          subCategoryName: 'Discard Log',
          subCategoryLink: '/index/discardLog',
          visible: false
        },
        {
          subCategoryName: 'Duplicates Log',
          subCategoryLink: '/index/duplicatesLog',
          visible: false
        },
        {
          subCategoryName: 'Quality',
          subCategoryLink: '/index/qualityaccuracy',
          visible: true
        },
        {
          subCategoryName: 'Productivity',
          subCategoryLink: '/index/productivity',
          visible: true
        },
        {
          subCategoryName: 'TAT vs Reconciliation',
          subCategoryLink: '/index/tatreconciliation',
          visible: true
        },
      ]
  }
];
