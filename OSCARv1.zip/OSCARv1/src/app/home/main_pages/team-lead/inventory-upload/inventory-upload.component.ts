import { Component, OnInit, ViewChild } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormGroupDirective
} from '@angular/forms';
import { environment } from '../../../../../environments/environment';
import { InventoryUploadService } from './inventory-upload.service';
import { ToastsManager } from 'ng2-toastr';
import { NgProgress } from 'ngx-progressbar';
import { CommonCodeService } from '../../../../_shared-services/common-code.services';

@Component({
  selector: 'app-inv-upl',
  templateUrl: './inventory-upload.component.html',
  styleUrls: ['./inventory-upload.component.scss'],
  providers: [InventoryUploadService]
})
export class InventoryUploadComponent implements OnInit {
  public userName: string;
  inventoryUploadFormGroup: FormGroup;
  clientList: any = [];
  specialtyList: any = [];
  locationList: any = [];
  fileTypeList: any = [];
  clientSessionObj: any;
  facilityOptionList: any;
  facilitySelectModel: any;
  public storage: Storage = environment.storage;
  fileToUpload: FileList = null;
  public facilityList = [];
  @ViewChild(FormGroupDirective) formDirective: FormGroupDirective;
  constructor(
    private formbuilder: FormBuilder,
    private inventoryUploadService: InventoryUploadService,
    public toaster: ToastsManager,
    public ngProgress: NgProgress,
    private _commonCode: CommonCodeService
  ) {
    this.userName = this.storage.getItem('UserName');
    this.clientSessionObj = this._commonCode.get_ConfidenceColor_Clientselection(
      'clientSelectionObject'
    );
    this.facilityOptionList = JSON.parse(this.storage.getItem('facilityList'));
  }

  public ngOnInit() {
    this.getClientList();
    this.getFiletype();
    this.initializeInventoryUploadForm();
    this.formOnChanges();
  }

  public getClientList() {
    try {
      this.clientList = this.clientSessionObj.clientConfiguration.client;
    } catch (error) {
      console.log(error);
    }
  }

  public getFiletype() {
    this.fileTypeList = [];
    this.fileTypeList.push({
      name: 'HL7'
    });
  }

  public initializeInventoryUploadForm() {
    this.inventoryUploadFormGroup = this.formbuilder.group({
      client: ['', Validators.required],
      specialty: ['', Validators.required],
      location: ['', Validators.required],
      fileType: ['', Validators.required],
      facility: ['', Validators.required],
      priority: [false, Validators.required],
      invenotryFile: [
        { value: undefined, disabled: false },
        Validators.required
      ]
    });
  }

  public getSelectedFacility(event): void {
    if (event) {
      this.facilitySelectModel = [];
      if (event[0] === -1) {
        this.facilitySelectModel = [];
      } else {
        this.facilitySelectModel = event;
      }
    }
    if (event === '') {
      this.facilitySelectModel = [];
    }
  }

  handleFileInput(files: FileList) {
    this.fileToUpload = files;
  }

  reset(event: any): void {
    this.inventoryUploadFormGroup.reset();
  }

  upload(): void {
    this.ngProgress.start();
    const param = this.inventoryUploadFormGroup.value;
    const formData = new FormData();
    if (this.fileToUpload && this.fileToUpload.length > 0) {
      for (let i = 0; i < this.fileToUpload.length; i++) {
        formData.append(
          'file',
          this.fileToUpload[i],
          this.fileToUpload[i].name
        );
      }
    } else {
      const myBlob = new Blob(['This is my blob content'], {
        type: 'text/plain'
      });
      formData.append('file', myBlob, null);
    }
    this.inventoryUploadService
      .uploadHl7File(param, formData)
      .subscribe(res => {
        if (res) {
          this.toaster.success(
            param.invenotryFile.fileNames + ' Uploaded Successfully '
          );
        }
        this.resetForm();
      });
  }

  resetForm() {
    this.formDirective.resetForm();
  }

  private formOnChanges() {
    this.inventoryUploadFormGroup.controls.client.valueChanges.subscribe(
      val => {
        this.getSpecialtyList(val);
      }
    );

    this.inventoryUploadFormGroup.controls.specialty.valueChanges.subscribe(
      val => {
        this.getLocationList(val);
      }
    );

    this.inventoryUploadFormGroup.controls.location.valueChanges.subscribe(
      val => {
        this.getFacilityList(val);
      }
    );
  }

  getSpecialtyList(value) {
    this.inventoryUploadFormGroup.controls.specialty.setValue('');
    this.specialtyList = [];
    if (value) {
      this.specialtyList = value.speciality;
    }
  }

  getLocationList(value) {
    this.inventoryUploadFormGroup.controls.location.setValue('');
    this.locationList = [];
    if (value) {
      this.locationList = value.location;
    }
  }

  getFacilityList(value) {
    this.inventoryUploadFormGroup.controls.facility.setValue([]);
    this.facilityList = [];
    if (value) {
      this.facilityList = value.facility;
    }
  }
}
