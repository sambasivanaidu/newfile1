import { Injectable } from '@angular/core';
import { HeaderAuthenticationToken } from '../../../../auth/authetication-header';
import { environment } from '../../../../../environments/environment';
import { map } from 'rxjs/operators';
import { ToastsManager } from 'ng2-toastr';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class InventoryUploadService {
  public httpOption;
  public httpFileOption;
  public httpFile2Option;
  public envURL = environment.URL;
  public httpHeaders;
  public userName: string;
  public storage: Storage = environment.storage;
  constructor(
    private httpClient: HttpClient,
    private httpHeader: HeaderAuthenticationToken,
    public toaster: ToastsManager
  ) {
    this.userName = this.storage.getItem('UserName');
  }

  uploadHl7File(param, formData) {
    const saveBatchParam = {
      batchName: param.invenotryFile ? param.invenotryFile.fileNames : null,
      specialityName: param.specialty ? param.specialty.name : '',
      locationName: param.location ? param.location.name : '',
      facilityName: param.facility ? param.facility.name : '',
      clientName: param.client.name,
      fileType: param.fileType,
      createdBy: this.userName,
      autoupload: false,
      priority: param.priority,
      archived: true
    };
    const uploadFileURL = this.envURL + 'batchupload/uploadFileInsert';
    this.httpOption = this.httpHeader.setFileHeader2Token();
    formData.append('inputParam', JSON.stringify(saveBatchParam));
    return this.httpClient.post(uploadFileURL, formData, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
}
