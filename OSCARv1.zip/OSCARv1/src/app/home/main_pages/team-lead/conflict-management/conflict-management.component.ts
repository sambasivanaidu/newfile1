import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  Input,
  OnChanges
} from '@angular/core';
import { GridOptions } from 'ag-grid';
import { environment } from '../../../../../environments/environment';
import { DateFormatter } from '../../../../imports/_utilities/date-formatter';
import * as CryptoJS from 'crypto-js';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
import { ToastsManager } from 'ng2-toastr';
import { LocationStrategy } from '@angular/common';
import { CommonCodeService } from '../../../../_shared-services/common-code.services';
import { Router } from '@angular/router';

@Component({
  selector: 'app-conflict-management',
  templateUrl: './conflict-management.component.html',
  providers: [DateFormatter]
})
export class ConflictManagementComponent implements OnInit, OnChanges {
  public GridOptions: GridOptions;
  public columnDefs;
  public rowData: any;
  public gridApi;
  public gridColumnApi;
  public components;
  public rowSelection;
  public editType;
  public paginationPageSize;
  public attrgridComponent;
  public getNodeChildDetails;
  public getRowNodeId;
  public tlPreparedData;
  public defaultColDef;
  public confidenceColorCode;
  @Input() tlInfoRequest: any;
  @Output() getSelectedLearningRow = new EventEmitter();
  @Output() approvedData = new EventEmitter();
  selectedCptNodeValue;
  public colResizeDefault;
  public storage: Storage = environment.storage;
  constructor(
    private errorService: ErrorHandlingServices,
    public _toastr: ToastsManager,
    private _dateFilter: DateFormatter,
    public location: LocationStrategy,
    private _commonCode: CommonCodeService,
    private router: Router
  ) {
    this.confidenceColorCode = this._commonCode.get_ConfidenceColor_Clientselection(
      'confidenceColorCode'
    );
    this.GridInit1();
    history.pushState(
      null,
      null,
      window.location.href
    ); /* preventing back button in browser implemented by 'Samba Siva'  */
    this.location.onPopState(() => {
      history.pushState(null, null, window.location.href);
      console.clear();
    }); /* preventing back button END */
  }

  ngOnInit() {}

  GridInit1() {
    this.GridOptions = <GridOptions>{
      context: {
        componentParent: this
      }
    };
    this.GridOptions.columnDefs = this.columnDefinition();
    this.attrgridComponent = {
      _cellCheckbox: gridCheckbox()
    };
    this.rowData = [];
    this.rowSelection = 'multiple';
    this.paginationPageSize = 50;
    this.components = {
      simpleCellRenderer: getSimpleCellRenderer()
    };
    this.defaultColDef = { resizable: true };
    this.colResizeDefault = 'shift';
  }

  ngOnChanges() {
    this.prepareRowData();
  }

  groupGrid() {
    this.getNodeChildDetails = function getNodeChildDetails(rowItem, i) {
      if (rowItem && rowItem.rowD) {
        return {
          group: true,
          expanded: true,
          children: rowItem.rowD,
          key: rowItem.count
        };
      } else {
        return null;
      }
    };
    this.getRowNodeId = function(data) {
      return data.count;
    };
  }

  onGridSizeChanged(params) {
    this.gridApi.sizeColumnsToFit();
  }

  public onCellValueChanged(event) {
    const username = this.storage.getItem('UserName');
    if (event) {
      const selectedRows = event.api.getSelectedRows();
      const approvedCptData = [];
      const approvedIcdData = [];
      const data = [];
      selectedRows.forEach(ele => {
        if (ele.correctCode !== '') {
          approvedCptData.push({
            approvedBy: username,
            approvedInfo: [
              {
                cptCode:
                  ele.correctCode === 'predicted code'
                    ? ele.predictedCptCode
                    : ele.correctCode === 'coder code'
                    ? ele.coderCptCode
                    : ele.tlCptCode,
                cptDescription:
                  ele.correctCode === 'predicted code'
                    ? ele.predictedCptDescngonchanges
                    : ele.correctCode === 'coder code'
                    ? ele.coderCptDesc
                    : ele.tlCptDesc,
                cptRole: ele.correctCode.toLowerCase()
              }
            ],
            uniqueId: ele.uniqueId
          });
          approvedIcdData.push({
            approvedBy: username,
            approvedInfo: [
              {
                cptCode:
                  ele.correctCode === 'predicted code'
                    ? ele.predictedIcdCode
                    : ele.correctCode === 'coder code'
                    ? ele.coderIcdCode
                    : ele.tlIcdCode,
                cptDescription:
                  ele.correctCode === 'predicted code'
                    ? ele.predictedIcdDesc
                    : ele.correctCode === 'coder code'
                    ? ele.coderIcdDesc
                    : ele.tlIcdDesc,
                cptRole: ele.correctCode.toLowerCase()
              }
            ],
            uniqueId: ele.uniqueId
          });
        }
      });
      data.push({
        cptData: approvedCptData,
        icdData: approvedIcdData
      });
      event.context.componentParent.approvedData.emit(data);
    }
  }

  GridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }

  changeSelectedRow(ev, event, data) {
    let param = {};
    let cellValue;
    let colHeaderName;

    const CPTelement = event.eGridCell.offsetParent.getElementsByClassName(
      'selectedCptCell'
    );
    const ICDelement = event.eGridCell.offsetParent.getElementsByClassName(
      'selectedIcdCell'
    );

    if (this.gridApi.getFocusedCell().column.colDef.id === 'CPT') {
      if (CPTelement.length > 0) {
        CPTelement[0].classList.remove('selectedCptCell');
      }
      param = {
        selectedCptCode: event.value,
        selectedCptDesc: event.eGridCell.title,
        selectedCptModifier: data.modifier,
        selectedCptRef: data.ref
      };
      cellValue = JSON.stringify(param);
      colHeaderName = 'selectedCptRowData';

      event.eGridCell.classList.add('selectedCptCell');
    } else {
      if (ICDelement.length > 0) {
        ICDelement[0].classList.remove('selectedIcdCell');
      }
      param = {
        selectedIcdCode: event.value,
        selectedIcdDesc: event.eGridCell.title
      };
      cellValue = JSON.stringify(param);
      colHeaderName = 'selectedIcdRowData';

      event.eGridCell.classList.add('selectedIcdCell');
    }
    event.node.setDataValue(colHeaderName, cellValue);
    event.context.componentParent.getSelectedLearningRow.emit(event);
  }

  OnBodyScroll(event) {
    this.gridApi.stopEditing();
  }

  columnDefinition() {
    return [
      {
        headerName: 'Unique ID',
        field: 'uniqueId',
        hide: true,
        tooltipField: 'uniqueId'
      },
      {
        headerName: 'MRN',
        showRowGroup: true,
        cellClass: 'hyper-link',
        field: 'mrn',
        width: 100,
        cellStyle: {
          fontSize: '14px'
        },
        onCellClicked(value): void {
          const uniqueID = value.data.uniqueId;
          const facility = value.data.facilityId;
          const param = {
            uniqueId: uniqueID, /* author: Samba SIva functionality: URL Sortening  Date: 01/07/2019 */
            facilityId: facility,
            auditorConflict: value.data.auditorConflict,
            l2AuditorConflict: value.data.l2auditorConflict,
            isProcessed: value.data.isProcessed === 'Active' ? false : true
          };
          const urlparameters = CryptoJS.AES.encrypt(
            JSON.stringify(param),
            'oscar'
          ).toString();
          localStorage.setItem(
            'urlParameters',
            urlparameters
          ); /* URL Sortening END*/
          value.context.componentParent.router.navigate([
            '/index/teamlead/platform'
          ]);
        }
      },
      {
        headerName: 'Accession Number',
        field: 'accessionNo',
        tooltipField: 'accessionNo',
        width: 100,
        cellClass: 'text-right',
        cellStyle: { fontSize: '14px' }
      },
      {
        headerName: 'Patient Name',
        field: 'patientName',
        tooltipField: 'patientName',
        width: 100,
        cellStyle: { fontSize: '14px' }
      },
      {
        headerName: 'Date of Service',
        field: 'dos',
        valueFormatter: this._dateFilter.dos,
        tooltipField: 'dos',
        width: 100,
        cellStyle: { fontSize: '14px' },
        cellClass: 'text-center'
      },
      {
        headerName: 'Physician Name',
        field: 'physicianName',
        tooltipField: 'physicianName',
        width: 150,
        cellStyle: { fontSize: '14px' }
      },
      {
        headerName: 'Facility',
        field: 'facilityId',
        tooltipField: 'facilityId',
        width: 100,
        cellStyle: { fontSize: '14px' }
      },
      {
        headerName: 'Coder Name',
        field: 'coderallocatedto',
        width: 150,
        tooltipField: 'coderallocatedto',
        hide: false
      },
      {
        headerName: 'Auditor Name',
        field: 'auditorallocatedto',
        width: 150,
        tooltipField: 'auditorallocatedto',
        hide: false
      },
      {
        field: 'auditorConflict',
        hide: true
      },
      {
        field: 'l2auditorConflict',
        hide: true
      },
      {
        headerName: 'Status',
        field: 'isProcessed',
        width: 150,
        tooltipField: 'isProcessed',
        hide: false
      }
    ];
  }

  prepareRowData() {
    this.tlPreparedData = [];
    if (this.tlInfoRequest) {
      if (!this.tlInfoRequest.apierror) {
        this.tlInfoRequest.forEach((data, data_index) => {
          this.tlPreparedData.push({
            auditorConflict: data.auditorConflict,
            l2auditorConflict: data.l2auditorConflict,
            uniqueId: data.uniqueId,
            mrn: data.mrn,
            confidencescore: data.confidencescore,
            accessionNo: data.accessionNo,
            patientName: data.patientName,
            dos: data.dos,
            physicianName: data.physicianName
              ? data.physicianName.toUpperCase()
              : data.physicianName,
            facilityId: data.facilityId,
            coderallocatedto: data.coderAllocatedTo
              ? data.coderAllocatedTo.toUpperCase()
              : data.coderAllocatedTo,
            auditorallocatedto: data.auditorAllocatedTo
              ? data.auditorAllocatedTo.toUpperCase()
              : data.auditorAllocatedTo,
            isProcessed: data.isProcessed ? 'Inactive' : 'Active'
          });
        });
        this.rowData = this.tlPreparedData;
      } else {
        this.errorService.throwInfo(this.tlInfoRequest.apierror.message);
      }
    }
  }
}

// confidencescore
function getSimpleCellRenderer() {
  function SimpleCellRenderer() {}
  SimpleCellRenderer.prototype.init = function(params) {
    let colorCode;
    const cellConfidenceScore = params.data.confidencescore;
    const confidenceColorCodeCheckList =
      params.context.componentParent.confidenceColorCode;
    confidenceColorCodeCheckList.forEach(ele => {
      const whichColorCode = between(
        cellConfidenceScore,
        ele.lowerLimit,
        ele.upperLimit
      );
      if (whichColorCode) {
        colorCode = ele.confidenceScore;
      }
    });
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML =
      '<span title="confidence Score: " '+
      colorCode +
      ' class="score scoreColor_' +
      colorCode +
      ' float-right">' +
      cellConfidenceScore +
      '</span>';
    this.eGui = tempDiv;
  };
  SimpleCellRenderer.prototype.getGui = function() {
    return this.eGui;
  };
  return SimpleCellRenderer;
}

function between(x, min, max) {
  return x >= min && x <= max;
}

function RowClickEventHandler(event) {
  event.node.setSelected(true);
  event.context.componentParent.getSelectedLearningRow.emit(event);
}

function gridCheckbox() {
  function agGridCellCheckbox() {}
  agGridCellCheckbox.prototype.getGui = function() {
    return this.eGui;
  };
  agGridCellCheckbox.prototype.getValue = function() {
    this.isChecked = this.eGui.childNodes[1].checked;
    return this.cellValue;
  };
  agGridCellCheckbox.prototype.isPopup = function() {
    return true;
  };
  agGridCellCheckbox.prototype.afterGuiAttached = function() {
    const changedWidth = this.colWidth + 'px';
    this.eGui.parentElement.style.width = changedWidth;
  };
  agGridCellCheckbox.prototype.init = function(param) {
    const _this = param;
    this.cellValue = _this.value;
    this.rowIndex = _this.rowIndex + '_' + _this.column.colDef.colId;
    this.colWidth = _this.column.actualWidth;
    let isCheckedValue;

    const eCelllabel = document.createElement('label');
    eCelllabel.setAttribute('class', 'grid-cell-checkbox-container');
    eCelllabel.setAttribute('for', this.cellValue + '_' + this.rowIndex);
    eCelllabel.innerText = this.cellValue ? this.cellValue : '';

    if (_this.column.colDef.id === 'CPT') {
      isCheckedValue = validateIsChecked(
        _this,
        _this.node.data.selectedCptRowData,
        'CPT'
      );
    } else {
      isCheckedValue = validateIsChecked(
        _this,
        _this.node.data.selectedIcdRowData,
        'ICD'
      );
    }

    const eCellIput = document.createElement('input');
    eCellIput.checked = isCheckedValue;
    eCellIput.type = 'radio';
    eCellIput.id = this.cellValue + '_' + this.rowIndex;
    eCellIput.name = this.rowIndex;
    eCellIput.value = this.cellValue;

    eCellIput.addEventListener('click', function(ev) {
      let cellData;
      ev.toElement.parentElement.classList.add('selectedCptCell'); // = '#165d1880' ;
      if (_this.column.colDef.id === 'CPT') {
        isCheckedValue = _this.node.data.selectedCptRowData;
        cellData = getRelatedCellData(_this);
      } else {
        isCheckedValue = _this.node.data.selectedIcdRowData;
        cellData = _this.value;
      }
      _this.context.componentParent.changeSelectedRow(ev, _this, cellData);
    });

    const eCellSpan = document.createElement('span');
    eCellSpan.setAttribute('class', 'checkmark');

    eCelllabel.appendChild(eCellIput);
    eCelllabel.appendChild(eCellSpan);

    this.eGui = eCelllabel;
  };
  return agGridCellCheckbox;
}

function validateIsChecked(obj, paramToValidate, colId) {
  if (obj && paramToValidate) {
    const param = getRelatedCellData(obj);
    const selectedOptionValue = JSON.parse(paramToValidate);
    if (colId === 'CPT') {
      if (
        obj.value === selectedOptionValue.selectedCptCode &&
        param.modifier === selectedOptionValue.selectedCptModifier &&
        param.ref === selectedOptionValue.selectedCptRef
      ) {
        return true;
      } else {
        return false;
      }
    } else {
      if (obj.value === selectedOptionValue.selectedIcdCode) {
        return true;
      } else {
        return false;
      }
    }
  }
}

function getRelatedCellData(obj) {
  let param;
  if (obj.column.colDef.colId === 'CCPT') {
    param = {
      modifier: obj.node.data.coderModifier,
      ref: obj.node.data.coderRef
    };
  } else if (obj.column.colDef.colId === 'ACPT') {
    param = {
      modifier: obj.node.data.auditorModifier,
      ref: obj.node.data.auditorRef
    };
  } else if (obj.column.colDef.colId === 'PCPT') {
    param = {
      modifier: obj.node.data.predictModifier,
      ref: obj.node.data.predictRef
    };
  } else if (obj.column.colDef.colId === 'TLCPT') {
    param = {
      modifier: obj.node.data.tlModifier,
      ref: obj.node.data.tlRef
    };
  }
  return param;
}
