import {
  Component,
  OnInit,
  AfterContentInit,
  ViewChild,
  ViewContainerRef,
  SecurityContext
} from '@angular/core';
import { BatchProcessSummaryService } from '../../../../_shared-services/batch-services/batch-process-summary.service';
import { BatchCheckboxRendererComponent } from '../../../../imports/ag-grid/batch-checkbox-renderer';
import { GridOptions } from 'ag-grid';
import { MediaChange, ObservableMedia } from '@angular/flex-layout';
import { MatGridList } from '@angular/material';
import { DatePipe } from '@angular/common';
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators
} from '@angular/forms';
import { DateFormatter } from '../../../../imports/_utilities/date-formatter';
import * as _moment from 'moment';
import { ValidationService } from '../../../../services/validation.service';
import { ToastsManager } from 'ng2-toastr';
import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter
} from '@angular/material-moment-adapter';
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE
} from '@angular/material/core';
import { DateService } from '../../../../_shared-services/date-service/date.service';
import { DomSanitizer } from '@angular/platform-browser';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';

@Component({
  selector: 'app-batch-process-summary',
  templateUrl: './batch-process-summary.component.html',
  styleUrls: ['./batch-process-summary.component.scss'],
  providers: [
    BatchProcessSummaryService,
    DateService,
    DatePipe,
    DateFormatter,
    ValidationService,
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS }
  ]
})
export class BatchProcessSummaryComponent implements OnInit, AfterContentInit {
  customCollapsedHeight = '40px';
  customExpandedHeight = '55px';

  breakpoint;
  @ViewChild('grid') grid: MatGridList;
  gridByBreakpoint = {
    xl: 5,
    lg: 5,
    md: 5,
    sm: 2,
    xs: 1
  };
  toDateModel: any;
  formDateModel: any;
  fileNameModel = '';
  processUpload: number;
  myGroup;
  batchDuplicates = 'Duplicates';
  batchFailed = 'Failed';
  public batchProcessgridOptions: GridOptions;
  public columnDefs;
  public rowData: any;
  public gridApi;
  public gridColumnApi;
  public bacthProcessframeworkComponents;
  public rowSelection;
  public icons;
  batchProcessFormGroup: FormGroup;
  maxDate = new Date();
  fromDateErrorMessage = 'Please enter valid date.';
  toDateErrorMessage = 'Please enter valid date.';
  @ViewChild('filters') filters;
  public height = 80;

  constructor(
    private observableMedia: ObservableMedia,
    private _batchProcessSummaryService: BatchProcessSummaryService,
    private _datePipe: DatePipe,
    private _dateFilter: DateFormatter,
    private formBuilder: FormBuilder,
    public _toastr: ToastsManager,
    private dateService: DateService,
    private errorService: ErrorHandlingServices,
    private _sanitizer: DomSanitizer
  ) {}

  ngAfterContentInit() {
    this.observableMedia.asObservable().subscribe((change: MediaChange) => {
      if (this.grid) {
        this.grid.cols = this.gridByBreakpoint[change.mqAlias];
      }
    });
  }

  ngOnInit() {
    this.processGridInit();
    this.processUpload = 1;
    this.intializedashboardForm();
    this.submitBatchMethod();
  }

  toggleFilter(event){
    if (event === 'block'){
      this.height = 69;
    } else{
      this.height = 80;
    }
  }

  processGridInit() {
    this.batchProcessgridOptions = <GridOptions>{
      context: {
        componentParent: this
      }
    };
    this.batchProcessgridOptions.columnDefs = [
      {
        width: 45,
        pinned: 'left',
        suppressSizeToFit: true,
        suppressFilter: true,
        headerCheckboxSelectionFilteredOnly: true,
        editable: false,
        checkboxSelection: function(params) {
          return params.columnApi.getRowGroupColumns().length === 0;
        },
        headerCheckboxSelection: function(params) {
          return params.columnApi.getRowGroupColumns().length === 0;
        }
      },

      {
        headerName: 'Batch Name',
        field: 'batchFileName',
        tooltipField: 'batchFileName'
      },
      {
        headerName: 'Facility',
        field: 'facility',
        tooltipField: 'facility'
      },
      {
        headerName: 'Location',
        field: 'location',
        tooltipField: 'location'
      },
      {
        headerName: 'Specialty',
        field: 'speciality',
        tooltipField: 'speciality'
      },
      {
        headerName: 'Received Date',
        field: 'batchReceived',
        cellClass: 'text-center',
        valueFormatter: this._dateFilter.dates,
        tooltipField: 'batchReceived'
      },
      {
        headerName: 'Total Charts',
        field: 'noOfCharts',
        tooltipField: 'noOfCharts',
        cellClass: 'text-right'
      },
      {
        headerName: 'Passed',
        field: 'noOfPass',
        tooltipField: 'noOfPass',
        cellClass: 'text-right text-hyperlink',
        cellRenderer: downloadIconCellRenderer,
        onCellClicked: this.downloadExcel
      },
      {
        headerName: 'Failed',
        field: 'noOfFails',
        tooltipField: 'noOfFails',
        cellClass: 'text-right text-hyperlink',
        cellRenderer: downloadIconCellRenderer,
        onCellClicked: this.downloadExcel
      },
      {
        headerName: 'Duplicates',
        field: 'noOfDuplicates',
        tooltipField: 'noOfDuplicates',
        cellClass: 'text-right text-hyperlink',
        cellRenderer: downloadIconCellRenderer,
        onCellClicked: this.downloadExcel
      },
      {
        headerName: 'Priority',
        field: 'priority',
        tooltipField: 'priority',
        cellRenderer: 'checkboxRenderer',
        cellClass: 'text-center'
      }
    ];

    this.bacthProcessframeworkComponents = {
      checkboxRenderer: BatchCheckboxRendererComponent
    };

    this.rowData = [];
    this.rowSelection = 'single';
  }

  autoSizeAll() {
    this.gridApi.sizeColumnsToFit();
  }

  onProcessGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.autoSizeAll();
  }

  downloadExcel(event) {
    const self = event.context.componentParent;
    const cellNodeData = {
      batchName: event.data.batchFileName
    };
    if (event.colDef.headerName === self.batchFailed) {
      self._batchProcessSummaryService
        .getBatchData(cellNodeData, 'errors')
        .subscribe(data => {
          if (data && data.length > 0) {
            self.errorService.throwSuccess('Download successful');
            self._batchProcessSummaryService.batchDownloadExcel(
              data,
              'inventory-tracking-error'
            );
          }
        });
    } else if (event.colDef.headerName === self.batchDuplicates) {
      self._batchProcessSummaryService
        .getBatchData(cellNodeData, 'duplicates')
        .subscribe(data => {
          if (data && data.length > 0) {
            self.errorService.throwSuccess('Download successful');
            self._batchProcessSummaryService.batchDownloadExcel(
              data,
              'inventory-tracking-duplicates'
            );
          }
        });
    } else {
      self._batchProcessSummaryService
        .getProcessedBatchData(cellNodeData, 'processed')
        .subscribe(data => {
          if (data && data.length > 0) {
            self.errorService.throwSuccess('Download successful');
            self._batchProcessSummaryService.batchDownloadExcel(
              data,
              'inventory-tracking-processed'
            );
          }
        });
    }
  }

  submitBatchMethod() {
    this.rowData = [];
    const sanitizedBatchFileName = this._sanitizer.sanitize(
      SecurityContext.HTML,
      this.batchProcessFormGroup.value.fileName
    );
    const params = {
      fromDate: this.batchProcessFormGroup.controls.fromDate.value.format(
        'YYYY-MM-DD'
      ),
      toDate: this.batchProcessFormGroup.controls.toDate.value.format(
        'YYYY-MM-DD'
      ),
      batchFileName: sanitizedBatchFileName,
      autoUpload:
        this.batchProcessFormGroup.value.uploadType === 1 ? true : false
    };

    this._batchProcessSummaryService
      .getBatchProcess(params)
      .subscribe((data: any) => {
        if (data && data.length > 0) {
          this.rowData = data;
        }
      });
  }

  getDatetime(date) {
    const d = new Date(date);
    return this._datePipe.transform(d, 'yyyy-MM-dd');
  }

  public intializedashboardForm() {
    this.batchProcessFormGroup = this.formBuilder.group({
      fromDate: new FormControl(_moment([])),
      toDate: new FormControl(_moment([])),
      fileName: new FormControl(null),
      uploadType: new FormControl(1)
    });
  }

  validateDate(event, field?: string): any {
    const toDateControl = this.batchProcessFormGroup.controls['toDate'];
    const fromDateControl = this.batchProcessFormGroup.controls['fromDate'];
    const validate = this.dateService.dateValidation(
      event,
      fromDateControl,
      toDateControl,
      field
    );
    this.fromDateErrorMessage = '';
    this.toDateErrorMessage = '';
    if (
      validate.toDateControl.status === 'INVALID' &&
      validate.fromDateControl.status === 'INVALID'
    ) {
      setTimeout(() => {
        toDateControl.setErrors({ invalid: true });
        fromDateControl.setErrors({ invalid: true });
        this.toDateErrorMessage = validate.toDateErrorMessage;
        this.fromDateErrorMessage = validate.fromDateErrorMessage;
      }, 100);
    } else if (validate.toDateControl.status === 'INVALID') {
      setTimeout(() => {
        toDateControl.setErrors({ invalid: true });
        this.toDateErrorMessage = validate.toDateErrorMessage;
      }, 100);
    } else if (validate.fromDateControl.status === 'INVALID') {
      setTimeout(() => {
        fromDateControl.setErrors({ invalid: true });
        this.fromDateErrorMessage = validate.fromDateErrorMessage;
      }, 100);
    } else if (
      validate.toDateControl.status === 'VALID' &&
      validate.fromDateControl.status === 'VALID'
    ) {
      setTimeout(() => {
        toDateControl.setErrors(null);
        fromDateControl.setErrors(null);
      }, 100);
    }
  }

  clearAll() {
    this.intializedashboardForm();
  }
}

function downloadIconCellRenderer(params) {
  const flag =
    '<img src="assets/images/download.png" class="cell-download-icon" style="margin-right: 50px">';
  return flag + ' ' + params.value;
}
