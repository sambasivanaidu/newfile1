import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TLPlatformComponent } from './teamLead-platform.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatIconModule,
  MatInputModule,
  MatFormFieldModule,
  MatAutocompleteModule,
  MatExpansionModule,
  MatDialogModule,
  MAT_DIALOG_DATA,
  MatDividerModule
} from '@angular/material';
import { DatePipe } from '@angular/common';
import { ToastsManager } from 'ng2-toastr';
import { ToastOptions } from 'ng2-toastr';
import { RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { FlexLayoutModule } from '@angular/flex-layout';
import { By } from '@angular/platform-browser';
import * as cptData from 'assets/testMockData/cptMockList.json';
import * as icdData from 'assets/testMockData/icdMockList.json';
import * as params from 'assets/testMockData/paramsCoderPlatform.json';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {
  ContextMenuComponent,
  ContextMenuService,
  ContextMenuModule
} from 'ngx-contextmenu';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { of } from 'rxjs/observable/of';
import { CUSTOM_ELEMENTS_SCHEMA, ViewContainerRef } from '@angular/core';
import { NgProgressModule } from 'ngx-progressbar';
import { RelatedVisitComponent } from '../../oscar-shared/related-visit/related-visit.component';
import { IcdInfoComponent } from '../../oscar-shared/icd-info/icd-info.component';
import { CptInfoComponent } from '../../oscar-shared/cpt-info/cpt-info.component';
import { PateintMedicalReportComponent } from '../../oscar-shared/pateint-medical-report/pateint-medical-report.component';
import { PateintInfoComponent } from '../../oscar-shared/pateint-info/pateint-info.component';
import { RecordInfoComponent } from '../../oscar-shared/record-info/record-info.component';
import { HighlightSearch } from '../../../../imports/pipes/highlights.pipe';
import { AuditAcknowledgeDialogComponent } from '../../../../imports/_utilities/mat-dialog-acknowledge/mat-dialog-acknowledge.component';
import { SpilitFilePathPipe } from '../../../../imports/pipes/splitFilePath.pipe';
import { HttpModule } from '@angular/http';
import { AgGridModule } from 'ag-grid-angular';
import { LookupDataService } from '../../../../_shared-services/unrelated-data-services/lookup-data.service';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
import { HeaderAuthenticationToken } from '../../../../auth/authetication-header';
import { DateFormatter } from '../../../../imports/_utilities/date-formatter';
import { CommonCodeService } from '../../../../_shared-services/common-code.services';
import { QueueService } from '../../../../services/main-pages/queue.service';
import { PlatformService } from '../../../../services/main-pages/paltform-services/platform-service.service';
import { MatDynamicDdModule } from '../../../../imports/_utilities/mat-dynamic-dd/mat-dynamic-dd.module';
describe('TLPlatformComponent', () => {
  let component: TLPlatformComponent;
  let fixture: ComponentFixture<TLPlatformComponent>;
  let elementRefference;
  let viewContainerRef;
  let originalTimeout;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        TLPlatformComponent,
        RelatedVisitComponent,
        IcdInfoComponent,
        CptInfoComponent,
        PateintMedicalReportComponent,
        PateintInfoComponent,
        RecordInfoComponent,
        HighlightSearch,
        AuditAcknowledgeDialogComponent,
        SpilitFilePathPipe
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        HttpModule,
        MatButtonModule,
        MatIconModule,
        MatInputModule,
        MatFormFieldModule,
        MatAutocompleteModule,
        FormsModule,
        ReactiveFormsModule,
        MatExpansionModule,
        AgGridModule.forRoot(),
        ContextMenuModule,
        RouterModule,
        RouterTestingModule,
        MatDialogModule,
        FlexLayoutModule,
        BrowserAnimationsModule,
        HttpClientTestingModule,
        MatDividerModule,
        NgProgressModule,
        MatDynamicDdModule
      ],
      providers: [
        PlatformService,
        LookupDataService,
        QueueService,
        ErrorHandlingServices,
        HeaderAuthenticationToken,
        DateFormatter,
        DatePipe,
        ToastsManager,
        ToastOptions,
        ContextMenuService,
        { provide: MAT_DIALOG_DATA, useValue: {} },
        ViewContainerRef,
        CommonCodeService
      ]
    }).compileComponents();
  }));
  beforeEach(() => {
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 5000;
    fixture = TestBed.createComponent(TLPlatformComponent);
    component = fixture.componentInstance;
    elementRefference = fixture.debugElement;
    viewContainerRef = TestBed.get(ViewContainerRef);
    fixture.detectChanges();
  });
  afterEach(() => {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = originalTimeout;
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should enable save button when icd list or cpt list is not empty', () => {
    component.fetchICDRowData = icdData;
    component.fetchCPTRowData = cptData;
    fixture.detectChanges();
    expect(
      elementRefference.nativeElement.querySelector('#saveBtn').disabled
    ).toBeTruthy();
  });
  it('#saveClick() should be called when save button is clicked', () => {
    spyOn(component, 'saveClick');
    component.saveClick();
    expect(component.saveClick).toHaveBeenCalled();
    component.icdIsPristines = false;
    component.cptIsPristines = false;
    component.fetchCPTRowData = cptData;
    component.fetchICDRowData = icdData;
    component.uniqueId = 'M001039969~4105747001~2016-02-06 00:00:00.0';
    component.selectedModality = 'US';
    fixture.detectChanges();
    spyOn(
      component._lookupDataService,
      'cptDxRefValidationCheck'
    ).and.returnValue({
      code: 1,
      msg: 'All dxRef value are correct'
    });
    expect(
      component._lookupDataService.cptDxRefValidationCheck(
        component.fetchCPTRowData
      )
    ).toEqual({
      code: 1,
      msg: 'All dxRef value are correct'
    });
    spyOn(
      component._lookupDataService,
      'validateBlankRecordCoder'
    ).and.returnValue({
      cptCodeIsEmpty: [],
      icdCodeIsEmpty: [],
      cptAccessionEmpty: []
    });
    expect(
      component._lookupDataService.validateBlankRecordCoder(
        component.fetchCPTRowData,
        component.fetchICDRowData
      )
    ).toEqual({
      cptCodeIsEmpty: [],
      icdCodeIsEmpty: [],
      cptAccessionEmpty: []
    });
    const conflict =
      component.icdIsPristines || component.cptIsPristines ? true : false;
    fixture.detectChanges();
    spyOn(component, 'checkForLcdCciMipsValidation');
    component.checkForLcdCciMipsValidation(
      // component.fetchCPTRowData,
      // component.fetchICDRowData,
      conflict
    );
    expect(component.checkForLcdCciMipsValidation).toHaveBeenCalled();
  });
  it('#checkForLcdCciMipsValidation() should be called when save button validations are done', () => {
    const lcdncd = params['lcdncd']; // {'uniqueId': 'M002049717~4105975001~2016-02-05 00:00:00.0', 'cptInput': '73700*1~10180*1', 'icdInput': 'S82.102A'};
    const cci = params['cci'];
    const mips = params['mips'];
    component.uniqueId = 'M001039969~4105747001~2016-02-06 00:00:00.0';
    component.selectedModality = 'US';
    component.icdIsPristines = false;
    component.cptIsPristines = false;
    component.fetchCPTRowData = cptData;
    component.fetchICDRowData = icdData;
    fixture.detectChanges();
    const lcdParam = params ? params['lcdparam'] : null;
    const cciParam = params ? params['cciparam'] : null;
    const mipsParam = params ? params['mipsparam'] : null;
    const param = params ? params['fetchlcdncdparam'] : null;
    expect(lcdParam.cptCodeEmpty).toBeFalsy();
    expect(lcdParam.icdCodeEmpty).toBeFalsy();
    expect(cciParam.cptCodeEmpty).toBeFalsy();
    expect(lcdParam.cptCodeEmpty).toBeFalsy();
    spyOn(component._platformService, 'fetchlcdmipsccicheck').and.returnValue(
      of({ response: params['fetchlcdparam'] })
    );
    const icdCheckStatus = true;
    component._platformService
      .fetchlcdmipsccicheck(param.cciInput, param.lcdInput, param.mipsInput)
      .subscribe(response => {
        expect(response).toEqual({
          response: { validDetails: { cci: null, mips: null, lcd: null } }
        });
        const val = response;
        expect(response.response.validDetails.mips).toEqual(null);
        expect(response.response.validDetails.cci).toEqual(null);
        expect(icdCheckStatus).toBeTruthy();
      });
  });
  it('#partialSave("DISCARD REASON", "Discard") should be called when discard is clicked', () => {
    fixture.detectChanges();
    elementRefference.nativeElement.querySelector('#discardBtn').click();
    spyOn(component, 'partialSave');
    expect(component.reason).toBe('Discard');
  });
  it('#partialSave("REROUTE REASON", "Reroute") should be called when reroute is clicked', () => {
    fixture.detectChanges();
    elementRefference.nativeElement.querySelector('#rerouteBtn').click();
    spyOn(component, 'partialSave');
    expect(component.reason).toBe('Reroute');
  });
  it('#partialSave("SUSPEND REASON", "Suspend") should be called when suspend is clicked', () => {
    fixture.detectChanges();
    elementRefference.nativeElement.querySelector('#suspendBtn').click();
    spyOn(component, 'partialSave');
    expect(component.reason).toBe('Suspend');
  });
  it('setheight', () => {
    fixture.detectChanges();
    elementRefference.nativeElement.querySelector('#feedbackbtn').click();
    spyOn(component, 'setHeight');
    expect(component.setHeight).toBeTruthy();
  });
  it('On #openDialogForAcknowledge1()', () => {
    // if errorFeedBack is true i.e. when there is acknowledgement
    component.uniqueId = 'M001039969~4105747001~2016-02-06 00:00:00.0';
    component.l2auditorConflict = false;
    const data = params['data_errorfeedback_false'];
    const icddata = data[1];
    const cptdata = data[0];
    const configuration = {
      hasBackdrop: true,
      width: '1200px',
      data: {
        codingRole: 'coder',
        uniqueId: component.uniqueId,
        platform: 'coder',
        status: 'agree',
        cptData: cptdata,
        icdData: icddata // data[1],
      },
      disableClose: true
    };
    const returnedVal = {
      afterClosed: () => of(true)
    };
    fixture.detectChanges();
    const data1 = { icddata: icdData, cptdata: cptdata };
    spyOn(component._platformService, 'getAcknowledge1').and.returnValue(
      of({ response: data1 })
    );
    spyOn(component._platformService, 'fetchdataOnCountSave').and.returnValue(
      of({})
    );
    component._platformService.fetchdataOnCountSave().subscribe(res => {});
    expect(component._platformService.fetchdataOnCountSave).toHaveBeenCalled();
  });
});
