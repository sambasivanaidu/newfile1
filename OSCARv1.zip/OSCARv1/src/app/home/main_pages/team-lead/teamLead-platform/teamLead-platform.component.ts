import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng2-toastr';
import { LookupDataService } from '../../../../_shared-services/unrelated-data-services/lookup-data.service';
import { TlService } from '../team-lead.component.service';
import { MatDialog, MatDialogRef } from '@angular/material';
import { MatDialogOverviewComponent } from '../../../../imports/_utilities/mat-dialog-overview/mat-dialog-overview.component';
import { FormControl } from '@angular/forms';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
import { MipsDialogComponent } from '../../../../imports/_utilities/mips-dialog/mips-dialog.component';
import { DomSanitizer } from '@angular/platform-browser';
import { environment } from '../../../../../environments/environment';
import * as CryptoJS from 'crypto-js';
import { PlatformOnloadCheckComponent } from '../../../../imports/_utilities/platform-onload-check/platform-onload-check.component';
import { LocationStrategy } from '@angular/common';
import { CommonCodeService } from '../../../../_shared-services/common-code.services';
import { CoderModalChildComponent } from '../../oscar-shared/coder-modal-child/coder-modal-child.component';
import { PlatformService } from '../../../../services/main-pages/paltform-services/platform-service.service';
@Component({
  selector: 'app-tl-platform',
  templateUrl: './teamLead-platform.component.html',
  styleUrls: ['./teamLead-platform.component.scss'],
  providers: [LookupDataService, TlService]
})
export class TLPlatformComponent implements OnInit {
  public uniqueId: string;
  public MRN: string;
  public patientInformation: any;
  public realtedVisit: any;
  public patientMedicalInfo: any;
  public recordInformation: any;
  public icdInformation: any;
  public cptInformation: any;
  public platform: string = 'tl';
  public selectedModality: any;
  public selectedFacility: any;
  public icdClickEvent: any;
  public cptClickEvent: any;
  public isDisabled: boolean = false;
  public fetchICDRowData: any = [];
  public fetchCPTRowData: any = [];
  public expanded: boolean = true;
  customCollapsedHeight: string = '25px';
  customExpandedHeight: string = '25px';
  public reason: string = '';
  public patientName;
  public dateOfService;
  public lcdCheckStatus: any;
  public disableMIPS: boolean;
  public facility: string;
  public searchTerm: any;
  lookUpOption: any;
  lookups: string;
  myControl = new FormControl();
  public disableLCD: boolean;
  public disableCCI: boolean;
  public validateCptInfo = [];
  public validateIcdInfo = [];
  dialogRefModal: MatDialogRef<any>;
  public display: boolean = false;
  public UID;
  public lcdNcdClicked = false;
  public cciClicked = false;
  public pqrsMipsClicked = false;
  public cciCheck: any;
  fileURL: any;
  displayPdf: any = 'none';
  public zoom: any = 1;
  public lineHeight: any = 1.5;
  public saveDeletedICDObj = [];
  public saveDeletedCPTObj = [];
  public storage: Storage = environment.storage;
  public username;
  public icdFeedbackJson = [];
  public cptFeedbackJson = [];
  public auditorConflict;
  public l2auditorConflict;
  public patientInfoGender: string;
  public patientInfoFacility: string;
  public dateOfBirth: any;
  icdIsPristines: boolean = false;
  cptIsPristines: boolean = false;
  lastCptDxVal: any;
  public lookupGuidePath = false;
  public isProcessed;
  lastAccessionVal: any;
  urlParameters: any;
  accesionNo: any;
  cptSectionHeight: any;
  icdSectionHeight: any;
  height: any = 750;
  related_visit: boolean = false;
  panelOpenState: boolean = true;
  constructor(
    private platformService: PlatformService,
    private lookupDataService: LookupDataService,
    private router: Router,
    private _tlService: TlService,
    private dialog: MatDialog,
    public _platformService: PlatformService,
    public _lookupDataService: LookupDataService,
    private errorService: ErrorHandlingServices,
    public _toastr: ToastsManager,
    public sanitzer: DomSanitizer,
    public location: LocationStrategy,
    private _commonCode: CommonCodeService
  ) {
    this.username = this.storage.getItem('TLId');
    this.router.routeReuseStrategy.shouldReuseRoute = function() {
      return false;
    };

    if (localStorage.getItem('urlParameters')) {
      this.urlParameters = JSON.parse(
        CryptoJS.AES.decrypt(
          localStorage.getItem('urlParameters'),
          'oscar'
        ).toString(CryptoJS.enc.Utf8)
      );
    }

    if (this.urlParameters !== undefined) {
      this.uniqueId = this.urlParameters.uniqueId;
      this.facility = this.urlParameters.facilityId
        ? this.urlParameters.facilityId
        : '';
      this.MRN = this.uniqueId.split('~')[0];
      this.l2auditorConflict = this.urlParameters.l2AuditorConflict;
      this.auditorConflict = this.urlParameters.auditorConflict;
      this.isProcessed =
        this.urlParameters.isProcessed === 'true' ? true : false;
    }
    history.pushState(
      null,
      null,
      window.location.href
    );
    this.location.onPopState(() => {
      history.pushState(null, null, window.location.href);
      setTimeout(() => {
        console.clear();
      }, 100);
      const previousChart: any = sessionStorage.getItem('previousChart');
      this.router.navigate(['index/coderPlatform', previousChart]);
      setTimeout(() => {
        console.clear();
      }, 100);
    });
  }
  getTlAcknowldege() {
    this._platformService.getTlAcknowledge(this.uniqueId).subscribe(res => {
      if (res) {
        const cptInfo = res[0];
        const icdInfo = res[1];
        this.onloadCheck(cptInfo, icdInfo);
      }
    });
  }
  public onloadCheck(cpt, icd) {
    const dialogRef = this.dialog.open(PlatformOnloadCheckComponent, {
      hasBackdrop: true,
      width: '1250px',
      data: {
        dataList: { cpt, icd },
        uniqueId: this.uniqueId
      },
      disableClose: false
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.saveOnLoadResponse(result);
      }
    });
  }
  getModalityData() {}
  saveOnLoadResponse(result) {
    this.cptInformation = !result[0].apierror
      ? result[0].cptResult
      : this.showErrorMsg(result[0].apierror);
    this.cptFeedbackJson = !result[0].apierror
      ? result[0].cptFeedbackJson
      : this.showErrorMsg(result[0].apierror);
    this.icdInformation = !result[1].apierror
      ? result[1].icdResult
      : this.showErrorMsg(result[1].apierror);
    this.icdFeedbackJson = !result[1].apierror
      ? result[1].icdFeedbackJson
      : this.showErrorMsg(result[1].apierror);
  }
  showErrorMsg(data) {
    this.errorService.throwInfo(data.message);
    return [];
  }
  feedback() {
    this.resetFeedbackAction();
    this.getTlAcknowldege();
  }
  public ngOnInit(): void {
    this.getPlatformParam();
    this.initPlatformFunction();
    this.getTlAcknowldege();
  }
  openpdf(): void {
    if (this.lookupGuidePath) {
      this._platformService
        .fetchPdfFileData(this.lookupGuidePath)
        .subscribe(res => {
          this.fileURL = URL.createObjectURL(res);
          this.fileURL = this.sanitzer.bypassSecurityTrustResourceUrl(
            this.fileURL
          );
        });
      this.displayPdf = 'block';
    }
  }
  private onCloseHandled(): void {
    this.displayPdf = 'none';
  }
  setHeight(functionName) {
    if (functionName === 'setCptHeight') {
      this.cptSectionHeight = this._commonCode.setCptHeight();
    } else if (functionName === 'setIcdHeight') {
      this.icdSectionHeight = this._commonCode.setIcdHeight();
    } else if (functionName === 'setMedicalReportHeight') {
      this.height = this._commonCode.setMedicalReportHeight(
        '',
        this.related_visit
      );
    } else if (functionName === 'pateintrecordinfoheight') {
      this.cptSectionHeight = this._commonCode.pateintRecordInfoHeight();
      this.icdSectionHeight = this.cptSectionHeight;
    }
  }
  ZoomIn(event) {
    event.stopPropagation();
    this.zoom = this.zoom + 0.1;
    this.lineHeight = this.lineHeight + 0.1;
  }
  zoomOut(event) {
    event.stopPropagation();
    this.zoom = this.zoom - 0.1;
    this.lineHeight = this.lineHeight - 0.1;
  }
  zoomReset(event) {
    event.stopPropagation();
    this.zoom = 'normal';
    this.zoom = 1;
    this.lineHeight = 'inherit';
    this.lineHeight = 1.5;
  }
  private getPlatformParam() {
    this.urlParameters = JSON.parse(
      /* author: Samba SIva functionality: URL Sortening Date: 01/07/2019 */
      CryptoJS.AES.decrypt(
        localStorage.getItem('urlParameters'),
        'oscar'
      ).toString(CryptoJS.enc.Utf8)
    );
    if (this.urlParameters !== undefined) {
      this.uniqueId = this.urlParameters.uniqueId;
      this.facility = this.urlParameters.facilityId
        ? this.urlParameters.facilityId
        : '';
      this.MRN = this.MRN = this.uniqueId.split('~')[0];
    } /* URL Sortening End */
    this.getMIPSDisableCheck();
  }
  private prepareTLRebuttalData(): void {
    const clientObject = this._commonCode.get_ConfidenceColor_Clientselection(
      'clientSelectionObject'
    );
    const role = clientObject.workRole.role;
    const param = {
      userId: this.storage.getItem('UserName'),
      role: role ? role : ''
    };
    this._tlService.fetchRebuttal(param).subscribe((data: any) => {
      this.myMethodChangingQueryParams(data[0]);
    });
  }
  private myMethodChangingQueryParams(param) {
    this.MRN = param.mrn;
    const params = {
      /* author: Samba SIva functionality: URL Sortening Date: 01/07/2019 */
      uniqueId: param.uniqueId,
      facilityId: param.facilityId,
      mrn: param.mrn,
      isProcessed: param.isProcessed,
      auditorConflict: param.auditorConflict,
      l2AuditorConflict: param.l2auditorConflict
    };
    this.urlParameters = CryptoJS.AES.encrypt(
      JSON.stringify(params),
      'oscar'
    ).toString();
    localStorage.setItem(
      'urlParameters',
      this.urlParameters
    ); /* URL Sortening END */
    this.router.navigate(
      [
        'index/teamlead/platform',
        {
          uniqueID: param.uniqueId,
          facility: param.facilityId,
          auditorConflict: param.auditorConflict,
          l2AuditorConflict: param.l2auditorConflict,
          isProcessed: param.isProcessed
        }
      ],
      { skipLocationChange: true }
    );
  }
  private initPlatformFunction() {
    this.preparePatientMedicalInformation();
    this.preparePatientInformation();
    this.prepareRecordInformation();
    this.prepareICDInformation();
    this.prepareCPTInformation();
  }
  resetFeedbackAction() {
    this.prepareICDInformation();
    this.prepareCPTInformation();
    this.icdFeedbackJson = [];
    this.cptFeedbackJson = [];
  }
  doFilter(param) {
    if (param) {
      this.lookupDataService.getLookUpData(param).subscribe(data => {
        if (data) {
          this.lookUpOption = data;
        }
      });
    }
  }
  private getMIPSDisableCheck() {
    this.platformService
      .fetchMIPSDisableCheck(this.facility)
      .subscribe(response => {
        if (response) {
          this.disableMIPS = response.pqrsMipsEnabled;
          this.disableCCI = response.ccienabled;
          this.disableLCD = response.lcdenabled;
          this.lookupGuidePath = response.lookupguidepath
            ? response.lookupguidepath
            : null;
        }
      });
  }
  // Related Visit
  private prepareRelatedVisit() {
    const myObj = {
      uniqueId: this.uniqueId,
      patientName: this.patientName,
      dos: this.dateOfService,
      modality: this.selectedModality,
      mrn: this.MRN
    };
    this.platformService.fetchRelatedChart(myObj).subscribe(response => {
      if (response) {
        this.realtedVisit = response;
        this.related_visit = true;
        this.height = 594;
      }
    });
  }
  private preparePatientMedicalInformation() {
    // Patient Medical Information
    this.patientMedicalInfo = [];
    this.platformService
      .fetchPatientChart(this.uniqueId)
      .subscribe((response: any) => {
        if (response) {
          this.patientMedicalInfo = response.observationValue;
        }
      });
  }
  private preparePatientInformation() {
    // Patient Information
    this.platformService.fetchPatientInfo(this.uniqueId).subscribe(response => {
      if (response) {
        this.patientInformation = response;
        let firstname = response['First name'];
        const lastChar = response['First name'].charAt(
          response['First name'].length - 1
        );
        firstname = lastChar === ' ' ? firstname.trim() : firstname;
        this.patientName = response['Last name'] + ' ' + firstname;
        this.dateOfService = response['DOS'];
        this.dateOfBirth = response['DOB'];
        this.patientInfoGender = response['Gender'];
      }
    });
  }
  private prepareRecordInformation() {
    // Record Information
    this.platformService
      .fetchPatientRecordInfo(this.uniqueId)
      .subscribe((response: any) => {
        if (response) {
          this.recordInformation = response;
          this.selectedModality = response.Modality;
          this.selectedFacility = response['Facility name'];
          this.patientInfoFacility = response['Facility name'];
          if (this.selectedModality && this.dateOfService) {
            this.prepareRelatedVisit();
          }
          if (response.Accession) {
            this.accesionNo = response.Accession;
          }
        }
      });
  }
  private prepareICDInformation() {
    // ICD Information
    this.icdInformation = [];
    this.platformService
      .fetchICDInfo(this.uniqueId, this.platform)
      .subscribe((response: any) => {
        if (response && response.length > 0) {
          this.icdInformation = response;
        }
      });
  }
  private prepareCPTInformation() {
    // CPT Information
    this.cptInformation = [];
    this.platformService
      .fetchCPTInfo(this.uniqueId, this.platform)
      .subscribe((response: any) => {
        if (response && response.length > 0) {
          this.cptInformation = response;
        }
      });
  }
  childEventClickedICD(event: any) {
    // Add ICD New Row on Click
    this.getSectionSplit(event, 'ICD');
  }
  childEventClickedCPT(event: any) {
    // Add ICD New Row on Click
    this.getSectionSplit(event, 'CPT');
  }
  highlightText(event: any) {
    if (event) {
      this.searchTerm = ' ';
      setTimeout(() => {
        this.searchTerm = event;
      }, 10);
    }
  }
  removeAttr(text) {
    const doc = new DOMParser().parseFromString(text, 'text/html');
    const docArr = doc.getElementsByClassName('highlighted');
    for (let i = 0; i < docArr.length; i++) {
      docArr[i].removeAttribute('data-timestamp');
      docArr[i].removeAttribute('style');
      docArr[i].removeAttribute('data-highlighted');
    }
    return doc;
  }
  private getSectionSplit(innerHtml, code) {
    const originalText = this.removeAttr(innerHtml.textInnerHtml);
    const param = {
      uniqueId: this.uniqueId,
      originalText: originalText.body.innerHTML
    };
    this._platformService.sectionSplitService(param).subscribe(res => {
      if (res) {
        let el: any = originalText.body.querySelectorAll('.highlighted');
        el.forEach(element => {
          element.classList.remove('highlighted');
          element.classList.add('htn');
        });
        if (code === 'ICD') {
          this.addICDrowData(
            res,
            innerHtml.highlightedText,
            originalText.body.innerHTML,
            res[0].sectionName
          );
        } else {
          this.addCPTrowData(
            res,
            innerHtml.highlightedText,
            originalText.body.innerHTML,
            res[0].sectionName
          );
        }
      }
    });
  }
  appendRationale(originalText, sectionArr) {
    sectionArr.forEach(element => {
      const html = '<span class="htb">$&</span>';
      const reg = new RegExp('\\b' + element.section + '\\b', 'i');
      originalText = originalText.replace(reg, html);
    });
    return originalText;
  }
  private addICDrowData(event, selectedWord, originalText, sectionName) {
    originalText = this.appendRationale(originalText, event);
    this.lcdNcdClicked = false;
    const newIcdRow = {
      id: null,
      icdCode: '',
      aapcDescription: '',
      isActive: true,
      accessionNo: '',
      icdDescription: selectedWord,
      rationaleData: originalText,
      rationaleSection: event,
      lcdStatus: '',
      comments: 'new row'
    };
    this.icdClickEvent = newIcdRow;
  }
  getDxval(event) {
    this.lastCptDxVal = event;
  }
  private addCPTrowData(event, selectedWord, originalText, sectionName) {
    originalText = this.appendRationale(originalText, event);
    this.cciClicked = false;
    this.pqrsMipsClicked = false;
    const newCptRow = {
      id: null,
      cptCode: '',
      modifier: '',
      units: '1',
      dxRef: this.lastCptDxVal === undefined ? '1' : this.lastCptDxVal,
      accessionNo: this.accesionNo.split(' ')[0],
      aapcDescription: '',
      cptDescription: selectedWord,
      rationaleData: originalText,
      rationaleSection: event,
      cptChart: event,
      isActive: true,
      comments: 'new row'
    };
    this.cptClickEvent = newCptRow;
  }
  ICDRowData(event) {
    this.fetchICDRowData = [];
    if (event && event.length > 0) {
      this.fetchICDRowData = event;
    }
  }
  CPTRowData(event) {
    this.fetchCPTRowData = [];
    if (event && event.length > 0) {
      this.fetchCPTRowData = event;
    }
  }
  saveClick() {
    this.isDisabled = true;
    const saveIcdInfo = this.fetchICDRowData;
    const saveCptInfo = this.fetchCPTRowData;
    this.validateCptInfo = [];
    this.validateIcdInfo = [];
    // get data for validations whose active state is true
    this.validateIcdInfo = this.fetchICDRowData.filter(
      element => element.isActive != false
    );
    this.validateCptInfo = this.fetchCPTRowData.filter(
      element => element.isActive != false
    );
    if (
      this.validateCptInfo.length === 0 ||
      this.validateIcdInfo.length === 0
    ) {
      this.errorService.throwWarning(
        '1 ICD and CPT is mandatory to save the chart'
      );
    } else {
      const dxIsEmpty = this._lookupDataService.cptDxRefValidationCheck(
        this.validateCptInfo
      );
      const isValidate = this._lookupDataService.validateBlankRecordCoder(
        this.validateCptInfo,
        this.validateIcdInfo
      );
      const conflictStatus =
        this.icdIsPristines || this.cptIsPristines ? true : false;
      // const cptDuplicate = this.checkCptDup(this.validateCptInfo);
      if (dxIsEmpty && dxIsEmpty.code === 1) {
        if (
          isValidate.cptCodeIsEmpty.length === 0 &&
          isValidate.icdCodeIsEmpty.length === 0 &&
          isValidate.cptAccessionEmpty.length === 0
        ) {
          this.checkForLcdCciMipsValidation(conflictStatus);
        } else {
          const msg = this.getValidationMessage(isValidate);
          this.errorService.throwWarning(msg);
        }
      } else if (dxIsEmpty) {
        this.errorService.throwWarning(dxIsEmpty.msg);
      } else {
        this.errorService.throwWarning(
          '1 ICD and CPT is mandatory to save the chart'
        );
      }
    }
  }
  // get deleted ICD
  deletedIcd(event) {
    if (event) {
      event.comments = 'wrongly coded ' + event.icdCode;
    }
    this.saveDeletedICDObj.push(event);
  }
  // get deleted CPT
  deletedCpt(event) {
    if (event) {
      event.comments = 'wrongly coded ' + event.cptCode;
    }
    this.saveDeletedCPTObj.push(event);
  }
  private saveCodedTlChart(cptInfo, icdInfo) {
    // this._toastr.setRootViewContainerRef(this.vcr);
    const saveIcdObj = [];
    const saveCptObj = [];
    icdInfo.forEach(element => {
      if (
        element['comments'] !== undefined &&
        element['comments'] === 'new row'
      ) {
        element.comments = 'missed coding ' + element.icdCode;
      }
      saveIcdObj.push(element);
    });
    if (this.saveDeletedICDObj && this.saveDeletedICDObj.length > 0) {
      this.saveDeletedICDObj.forEach(ele => {
        saveIcdObj.push(ele);
      });
    }
    cptInfo.forEach(element => {
      if (
        element['comments'] !== undefined &&
        element['comments'] === 'new row'
      ) {
        element.comments = 'missed coding ' + element.cptCode;
      }
      saveCptObj.push(element);
    });
    if (this.saveDeletedCPTObj && this.saveDeletedCPTObj.length > 0) {
      this.saveDeletedCPTObj.forEach(ele => {
        saveCptObj.push(ele);
      });
    }
    const codingRole =
      this.auditorConflict === 'true'
        ? 'auditor'
        : this.l2auditorConflict === 'true'
        ? 'l2auditor'
        : 'auditor';
    this._tlService
      .saveTLChart(
        saveCptObj,
        saveIcdObj,
        this.uniqueId,
        this.selectedModality,
        this.icdFeedbackJson,
        this.cptFeedbackJson,
        codingRole
      )
      .subscribe(responseList => {
        if (responseList) {
          if (responseList[1]) {
            this._platformService.fetchdataOnCountSave().subscribe(res => {});
            this.prepareTLRebuttalData();
            // this._toastr.setRootViewContainerRef(this.vcr);
            this.errorService.throwSuccess('Chart saved successfully!');
          }
        }
      });
  }
  private getValidationMessage(isValidate): string {
    let message: string;
    if (isValidate.icdCodeIsEmpty.length > 0) {
      message = 'Please enter ICD code.';
    } else if (isValidate.cptCodeIsEmpty.length > 0) {
      message = 'Please enter CPT code.';
    } else if (isValidate.cptAccessionEmpty.length > 0) {
      message = 'Please enter CPT Accession Number.';
    }
    return message;
  }
  public partialSave(event, reasonName) {
    const cptInfo = this.fetchCPTRowData;
    const icdInfo = this.fetchICDRowData;
    cptInfo.forEach((element, index) => {
      element.counter = index;
    });
    icdInfo.forEach((element, index) => {
      element.counter = index;
    });
    this.reason = reasonName;
    this._tlService.discardService(event).subscribe(responseList => {
      if (responseList) {
        this.openDialog(responseList, this.reason, cptInfo, icdInfo);
      }
    });
  }
  private openDialog(responseList, reasonName, cptInfo, icdInfo) {
    const dialogRef = this.dialog.open(MatDialogOverviewComponent, {
      hasBackdrop: true,
      width: '450px',
      data: {
        dataList: responseList,
        reason: reasonName,
        uniqueId: this.uniqueId,
        platform: 'tl',
        disableClose: true,
        cptInfo: cptInfo ? cptInfo : '',
        icdInfo: icdInfo ? icdInfo : '',
        isSaved: false,
        modality: this.selectedModality
      },
      disableClose: false
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this._platformService.fetchdataOnCountSave().subscribe(res => {});
        this.errorService.throwSuccess(
          'Chart ' + reasonName + 'ed' + ' successfully!'
        );
        this.prepareTLRebuttalData();
      }
    });
  }
  private openModalDialog(uniqueID, display, status) {
    this.dialogRefModal = this.dialog.open(CoderModalChildComponent, {
      hasBackdrop: true,
      disableClose: true,
      width: '1480px',
      panelClass: 'modal-dialog',
      data: {
        uniqueId: this.uniqueId,
        displayName: display,
        status: status
      }
    });
    this.dialogRefModal.afterClosed().subscribe(data => {
      console.log('The dialog was closed');
    });
  }
  showModal(event) {
    this.display = event;
    this.UID = event.api.getSelectedRows()[0].uniqueId;
    const status = event.api.getSelectedRows()[0].chartStatus;
    this.openModalDialog(this.UID, this.display, status);
  }
  private refresh() {
    this.patientInformation = [];
    this.recordInformation = [];
    this.icdInformation = [];
    this.selectedModality = [];
    this.selectedFacility = [];
    this.cptInformation = [];
    this.realtedVisit = [];
    this.patientMedicalInfo = [];
    this.searchTerm = null;
    this.recordInformation = null;
    this.fetchICDRowData = [];
    this.fetchCPTRowData = [];
    this.uniqueId = null;
    this.facility = null;
    this.MRN = null;
  }
  // CCI MIPS LCD Validation functions
  private prepareLCDParam(cptInfo, icdInfo) {
    let cptCodeEmpty = false;
    const icdCodeEmpty = false;
    let CPTCodes = '';
    let ICDCodes = '';
    const lcdInput = {
      uniqueId: this.uniqueId,
      cptInput: '',
      icdInput: ''
    };
    cptInfo.forEach((element, index) => {
      if (element.predictCptCode || element.cptCode) {
        if (index > 0) {
          CPTCodes = lcdInput.cptInput.concat(CPTCodes, '~');
        }
        const predictCptCode = element.predictCptCode + '*' + element.dxRef;
        const cptCode = element.cptCode + '*' + element.dxRef;
        CPTCodes = element.predictCptCode
          ? lcdInput.cptInput.concat(CPTCodes, predictCptCode.trim())
          : lcdInput.cptInput.concat(CPTCodes, cptCode.trim());
      } else {
        cptCodeEmpty = true;
        this.errorService.throwWarning(
          'Please enter CPT Code for LCD/NCD check'
        );
      }
    });
    icdInfo.forEach((element, index) => {
      if (element.predictIcdCode || element.icdCode) {
        if (index > 0) {
          ICDCodes = lcdInput.icdInput.concat(ICDCodes, '~');
        }
        ICDCodes = element.predictIcdCode
          ? lcdInput.icdInput.concat(ICDCodes, element.predictIcdCode.trim())
          : lcdInput.icdInput.concat(ICDCodes, element.icdCode.trim());
      } else {
        cptCodeEmpty = true;
        this.errorService.throwWarning(
          'Please enter ICD Code for LCD/NCD check'
        );
      }
    });
    lcdInput.cptInput = CPTCodes;
    lcdInput.icdInput = ICDCodes;
    return { lcdInput, cptCodeEmpty, icdCodeEmpty };
  }
  private preapreMIPSParam(cptInfo) {
    let cptCodeEmpty = false;
    const MIPSMeasureInput = {
      cptcode: '',
      uniqueId: this.uniqueId
    };
    let CPTCodes = '';
    if (cptInfo && cptInfo.length) {
      cptInfo.forEach((element, index) => {
        if (element.predictCptCode || element.cptCode) {
          if (index > 0) {
            CPTCodes = MIPSMeasureInput.cptcode.concat(CPTCodes, '~');
          }
          CPTCodes = element.predictCptCode
            ? MIPSMeasureInput.cptcode.concat(
                CPTCodes,
                element.predictCptCode.trim()
              )
            : MIPSMeasureInput.cptcode.concat(CPTCodes, element.cptCode.trim());
        } else {
          cptCodeEmpty = true;
          this.errorService.throwWarning(
            'Please enter CPT Code for MIPS Measure'
          );
        }
      });
    }
    MIPSMeasureInput.cptcode = CPTCodes;
    return { MIPSMeasureInput, cptCodeEmpty };
  }
  private prepareCCIParam(cptInfo) {
    let cptCodeEmpty = false;
    const CCIInputMeasure = {
      cptMod: '',
      currentChartID: this.uniqueId
    };
    let CPTCodes = '';
    if (cptInfo && cptInfo.length) {
      cptInfo.forEach((element, index) => {
        if (element.predictCptCode || element.cptCode) {
          if (index > 0) {
            CPTCodes = CCIInputMeasure.cptMod.concat(CPTCodes, '~');
          }
          CPTCodes = element.predictCptCode
            ? CCIInputMeasure.cptMod.concat(
                CPTCodes,
                element.predictCptCode.trim()
              )
            : CCIInputMeasure.cptMod.concat(CPTCodes, element.cptCode.trim());
          CPTCodes = CCIInputMeasure.cptMod.concat(CPTCodes, '*');
          CPTCodes = element.modifier
            ? CCIInputMeasure.cptMod.concat(CPTCodes, element.modifier)
            : CCIInputMeasure.cptMod.concat(CPTCodes, '');
        } else {
          cptCodeEmpty = true;
          this.errorService.throwWarning(
            'Please enter CPT Code for CCI Modifier'
          );
        }
      });
    }
    CCIInputMeasure.cptMod = CPTCodes;
    return { CCIInputMeasure, cptCodeEmpty };
  }
  private updateLCDNCDCol(lcdDetails) {
    const param = [];
    lcdDetails.forEach(element => {
      param.push({
        lcdStatus: element.icdCheckStatus,
        icdCode: element.icdCode
      });
    });
    const x = {
      status: param,
      colName: 'predictIcdCode'
    };
    this.lcdCheckStatus = x;
  }
  private updateMoidifierCol(response) {
    const param = [];
    let message = false;
    response.forEach(element => {
      param.push({
        modifier: element.cciModifier,
        cptcode: element.cpt
      });
      if (element.cciModifier === 'Not Applicable') {
        message = true;
      }
      const x = {
        modifier: param,
        colName: 'predictIcdCode'
      };
      this.cciCheck = x;
    });
    return message;
  }
  lcdCheck(event) {
    // this._toastr.setRootViewContainerRef(this.vcr);
    event.stopPropagation();
    this.lcdNcdClicked = true;
    const cptInfo = this.fetchCPTRowData;
    const icdInfo = this.fetchICDRowData;
    const isValidate = this._lookupDataService.validateBlankRecordCoder(
      cptInfo,
      icdInfo
    );
    if (isValidate.icdCodeIsEmpty.length === 0) {
      const inputParam = this.prepareLCDParam(cptInfo, icdInfo);
      if (
        inputParam.cptCodeEmpty === false &&
        inputParam.icdCodeEmpty === false
      ) {
        this._platformService
          .fetchlcdmipsccicheck(null, inputParam.lcdInput, null)
          .subscribe(res => {
            if (res) {
              if (res.validDetails && res.validDetails.lcd.length > 0) {
                this.updateLCDNCDCol(res.validDetails.lcd);
                this.errorService.throwSuccess('LCD status updated.');
              }
            }
          });
      }
    } else {
      const msg = this.getValidationMessage(isValidate);
      this.errorService.throwWarning(msg);
    }
  }
  getCCIModifier(event) {
    event.stopPropagation();
    this.cciClicked = true;
    const cptInfo = this.fetchCPTRowData;
    const inputParam = this.prepareCCIParam(cptInfo);
    if (!inputParam.cptCodeEmpty) {
      let msg;
      this._platformService
        .fetchlcdmipsccicheck(inputParam.CCIInputMeasure, null, null)
        .subscribe(response => {
          if (response) {
            if (
              response.validDetails &&
              response.validDetails.cci &&
              response.validDetails.cci.length > 0
            ) {
              msg = this.updateMoidifierCol(response.validDetails.cci);
              this.errorService.throwSuccess('Modifier updated.');
            } else {
              msg = true;
            }
          }
          if (msg) {
            this.errorService.throwInfo('CCI modifier is not applicable');
          }
        });
    }
  }
  getMIPSMeasure(event) {
    event.stopPropagation();
    this.pqrsMipsClicked = true;
    const cptInfo = this.fetchCPTRowData;
    const inputParam = this.preapreMIPSParam(cptInfo);
    if (!inputParam.cptCodeEmpty) {
      this._platformService
        .fetchlcdmipsccicheck(null, null, inputParam.MIPSMeasureInput)
        .subscribe(response => {
          if (response) {
            if (
              response.validDetails &&
              response.validDetails.mips &&
              response.validDetails.mips.length > 0
            ) {
              const dialogRef = this.dialog.open(MipsDialogComponent, {
                hasBackdrop: true,
                width: '950px',
                data: {
                  uniqueId: this.uniqueId,
                  mipsData: response.validDetails.mips
                },
                disableClose: true
              });
            } else {
              this.errorService.throwInfo('MIPS not applicable.');
            }
          }
        });
    }
  }
  checkForLcdCciMipsValidation(conflictStatus) {
    const cptInfo = this.fetchCPTRowData;
    const icdInfo = this.fetchICDRowData;
    const lcdParam = this.prepareLCDParam(cptInfo, icdInfo);
    const cciParam = this.prepareCCIParam(cptInfo);
    const mipsParam = this.preapreMIPSParam(cptInfo);
    let icdCheckStatus: boolean;
    const param = {
      cciInput: null,
      lcdInput: null,
      mipsInput: null
    };
    if (
      lcdParam.cptCodeEmpty === false &&
      lcdParam.icdCodeEmpty === false &&
      cciParam.cptCodeEmpty === false &&
      mipsParam.cptCodeEmpty === false
    ) {
      if (this.lcdNcdClicked === false) {
        param.lcdInput = lcdParam.lcdInput;
      }
      if (this.cciClicked === false) {
        param.cciInput = cciParam.CCIInputMeasure;
      }
      param.mipsInput = mipsParam.MIPSMeasureInput;
      this._platformService
        .fetchlcdmipsccicheck(param.cciInput, param.lcdInput, param.mipsInput)
        .subscribe(response => {
          if (response) {
            if (
              response.validDetails &&
              (response.validDetails.lcd ||
                response.validDetails.mips ||
                response.validDetails.cci)
            ) {
              if (this.lcdNcdClicked === false) {
                if (
                  response.validDetails &&
                  response.validDetails.lcd &&
                  response.validDetails.lcd.length > 0
                ) {
                  this.updateLCDNCDCol(response.validDetails.lcd);
                  this.lcdNcdClicked = true;
                }
              }
              if (this.cciClicked === false) {
                if (
                  response.validDetails &&
                  response.validDetails.cci &&
                  response.validDetails.cci.length > 0
                ) {
                  this.updateMoidifierCol(response.validDetails.cci);
                  this.cciClicked = true;
                }
              }
              if (response.validDetails.lcd !== null) {
                response.validDetails.lcd.every(function(element, index) {
                  if (
                    element.icdCheckStatus == 'Not Applicable' ||
                    element.icdCheckStatus == 'LCD Passed' ||
                    element.icdCheckStatus == 'NCD Passed'
                  ) {
                    icdCheckStatus = true;
                  } else {
                    icdCheckStatus = false;
                    return false;
                  }
                });
              }
              if (
                response.validDetails.mips === null &&
                response.validDetails.cci === null &&
                icdCheckStatus
              ) {
                setTimeout(() => {
                  this.saveCodedTlChart(cptInfo, icdInfo);
                }, 0); // Donot remove this as this will effect update lcdncd col bug
              } else {
                // this.showValueChangeDialog(cptInfo, icdInfo, conflictStatus);
                const dialogRef = this.dialog.open(MipsDialogComponent, {
                  hasBackdrop: true,
                  width: '950px',
                  data: {
                    uniqueId: this.uniqueId,
                    mipsData: response.validDetails.mips,
                    cciData: response.validDetails.cci,
                    lcdData: response.validDetails.lcd
                  },
                  disableClose: true
                });
              }
            } else {
              this.saveCodedTlChart(cptInfo, icdInfo);
            }
          }
        });
    }
  }
  checkIcdIsPrisitine(event) {
    if (event) {
      this.icdIsPristines = event;
    }
  }
  checkCptIsPrisitine(event) {
    if (event) {
      this.cptIsPristines = event;
    }
  }
}
