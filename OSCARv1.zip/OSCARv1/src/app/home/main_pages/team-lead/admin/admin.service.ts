import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '@angular/common/http';
import { Http } from '@angular/http';
import { environment } from '../../../../../environments/environment';
import { HeaderAuthenticationToken } from '../../../../auth/authetication-header';

@Injectable()
export class AdminService {
  public envURL = environment.URL;
  public httpOption;
  public httpFileOption;
  constructor(private httpClient: HttpClient, private http: Http, private __httpHeader: HeaderAuthenticationToken) {
    this.httpOption = this.__httpHeader.setHeaderToken();
    this.httpFileOption = this.__httpHeader.setFileHeaderToken();
  }

  getMeasures(): Observable<any> {
    return this.httpClient.get('http://localhost:3004/measures');
  }

  public getJSON() {
    return this.httpClient.get('./assets/measure.json');
  }

  public getMeasuresJSON() {
    return this.httpClient.get('./assets/facility-on-boarding/measure.json');
  }

  public postJSON(body): any {
    const url = './assets/measure.json';
    return this.httpClient.post(url, body);
  }

  public save(formData): Observable<any> {
    const URL = this.envURL + 'facilitymaster/facility/insertorupdate';
    return this.httpClient.post(URL, formData, this.httpFileOption);
  }

  public searchCustomization(params): Observable<any> {
    const URL = this.envURL + 'facilitymaster/facilityDetails/' + params;
    return this.httpClient.get(URL, this.httpOption);
  }

  public getFacility(): Observable<any> {
    const URL = this.envURL + 'facilitymaster/facility';

    return this.httpClient.get(URL, this.httpOption);
  }
}
