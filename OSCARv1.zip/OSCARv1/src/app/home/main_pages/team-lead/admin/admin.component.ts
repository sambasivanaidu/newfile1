import { Component, OnInit, SecurityContext } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  FormControl,
  FormArray,
  Validators,
  AbstractControl
} from '../../../../../../node_modules/@angular/forms';
import { environment } from '../../../../../environments/environment';
import { AdminService } from './admin.service';
import { DateFormatter } from '../../../../imports/_utilities/date-formatter';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
import { DomSanitizer } from '@angular/platform-browser';
import { NgProgress } from 'ngx-progressbar';
import { ToastsManager } from 'ng2-toastr';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss'],
  providers: [AdminService, DateFormatter]
})
export class AdminComponent implements OnInit {
  clientCustomizationFormGroup: FormGroup;
  public storage: Storage = environment.storage;
  specialtyList = [];
  facilityList = [];
  dataSource = [];
  displayedColumns: string[];
  stateLcdIdList = [];
  participatingProviders = [];
  public physicianList = [];
  clientConfiguration = JSON.parse(this.storage.getItem('clientConfiguration'));
  locationList = [];
  receivedData: any = null;
  hide: boolean = true;
  userName;
  jsonData;
  formArray: FormArray;

  validationMessages = {
    facility: ' Select Facility ',
    specialty: ' Enter Specialty ',
    location: ' Enter Location ',
    facilityGroup: ' Select Group ',
    lcdNcdDd: ' Select LCD NCD Dropdown Value ',
    lcdNcdFile: ' Choose LCD NCD File ',
    nopDd: ' Select NOP Dropdown Value ',
    nopFile: ' Choose NOP File ',
    locumFile: 'Choose Locum File',
    residentPhysicianFile: 'Choose Resident Physician File',
    clientSpecProDd: 'Select Client Excecution Dropdown',
    clientPathwaysFile: 'Choose Client Pathways File',
    clientSpecProInput: 'Enter CPT or ICD Codes',
    newfacility: 'Enter Facility Name',
    pqrslist: 'Enter age',
    base: 'Choose claim based or registry based'
  };
  constructor(
    private formBuilder: FormBuilder,
    private dateFormatter: DateFormatter,
    private adminService: AdminService,
    private ngProgress: NgProgress,
    private errorHandlingService: ErrorHandlingServices,
    public toaster: ToastsManager,
    // vcr: ViewContainerRef,
    private _sanitizer: DomSanitizer
  ) {
    // this.toaster.setRootViewContainerRef(vcr);
    this.userName = this.storage.getItem('UserName');
  }

  ngOnInit() {
    this.getFacilityList();
    this.initialiseForm();
    this.getInitialMeasures();
    this.onChanges();
  }
  public getFacilityList() {
    this.adminService.getFacility().subscribe(
      data => {
        if (!data.apierror) {
          this.facilityList = data;
        } else {
          this.errorHandlingService.throwInfo(data.apierror.message);
        }
      },
      error => {
        this.errorHandlingService.throwError(error);
      }
    );
  }

  initialiseForm() {
    this.clientCustomizationFormGroup = this.formBuilder.group({
      specialty: ['', Validators.required],
      location: ['', Validators.required],
      facilityGroup: ['', Validators.required],
      facility: ['', Validators.required],
      pqrs: [{ value: true, disabled: false }],
      pqrslist: this.formBuilder.array([]),
      globalBilling: [{ value: true, disabled: false }],
      lcdNcd: [{ value: true, disabled: false }],
      lcdNcdDd: [{ value: '', disabled: false }, Validators.required],
      lcdNcdFile: [{ value: undefined, disabled: false }, Validators.required],
      nop: [{ value: true, disabled: false }],
      nopDd: [{ value: 'OP', disabled: false }, Validators.required],
      nopFile: [{ value: '', disabled: false }, Validators.required],
      locum: [{ value: true, disabled: false }],
      locumFile: [{ value: '', disabled: false }, Validators.required],
      residentPhysician: [{ value: true, disabled: false }],
      residentPhysicianFile: [
        { value: '', disabled: false },
        Validators.required
      ],
      clientSpecPro: [{ value: true, disabled: false }],
      clientSpecProDd: [
        { value: 'CPT Code', disabled: false },
        Validators.required
      ],
      clientSpecProInput: this.formBuilder.group({
        cptCode: [{ value: '', disabled: false }],
        icdCode: [{ value: '', disabled: false }]
      }),
      clientPathways: [{ value: true, disabled: false }],
      clientPathwaysFile: [{ value: '', disabled: false }, Validators.required],
      base: [{ value: '', disabled: false }, Validators.required],
      // claimBased: [{ value: false, disabled: false }],
      // registryBased: [{ value: false, disabled: false }],
      locumFilePath: [{ value: '', disabled: true }],
      locumFileLastUpdated: [{ value: '', disabled: true }],
      clientPathwaysFilePath: [{ value: '', disabled: true }],
      nopFileLastUpdated: [{ value: '', disabled: true }],
      nopFilePath: [{ value: '', disabled: true }],
      newfacility: [{ value: '' }],
      residentPhysicianLastUpdated: [{ value: '', disabled: true }],
      residentPhysicianFilePath: [{ value: '', disabled: true }]
    });
  }

  onChanges(): void {
    this.clientCustomizationFormGroup.controls.pqrs.valueChanges.subscribe(
      val => {
        if (val) {
          this.enableInputs();
          this.clientCustomizationFormGroup.controls.base.enable();
          this.clientCustomizationFormGroup.controls.base.setValidators([
            Validators.required
          ]);
          // this.clientCustomizationFormGroup.controls.claimBased.enable();
          // this.clientCustomizationFormGroup.controls.registryBased.enable();
        } else {
          this.disableInputs();
          this.clientCustomizationFormGroup.controls.base.disable();
          this.clientCustomizationFormGroup.controls.base.clearValidators();
          // this.clientCustomizationFormGroup.controls.claimBased.disable();
          // this.clientCustomizationFormGroup.controls.registryBased.disable();
        }
        this.clientCustomizationFormGroup.controls.base.updateValueAndValidity();
      }
    );

    this.clientCustomizationFormGroup.controls.lcdNcd.valueChanges.subscribe(
      val => {
        if (val) {
          this.clientCustomizationFormGroup.controls.lcdNcdDd.enable();
          this.clientCustomizationFormGroup.controls.lcdNcdFile.enable();
          this.clientCustomizationFormGroup.controls.lcdNcdDd.setValidators([
            Validators.required
          ]);
          this.clientCustomizationFormGroup.controls.lcdNcdFile.setValidators([
            Validators.required
          ]);
        } else {
          this.clientCustomizationFormGroup.controls.lcdNcdDd.disable();
          this.clientCustomizationFormGroup.controls.lcdNcdFile.disable();
          this.clientCustomizationFormGroup.controls.lcdNcdDd.clearValidators();
          this.clientCustomizationFormGroup.controls.lcdNcdFile.clearValidators();
        }
        this.clientCustomizationFormGroup.controls.lcdNcdFile.updateValueAndValidity();
        this.clientCustomizationFormGroup.controls.lcdNcdDd.updateValueAndValidity();
      }
    );

    this.clientCustomizationFormGroup.controls.nop.valueChanges.subscribe(
      val => {
        if (val) {
          this.clientCustomizationFormGroup.controls.nopDd.enable();
          this.clientCustomizationFormGroup.controls.nopFile.enable();
          this.clientCustomizationFormGroup.controls.nopDd.setValidators([
            Validators.required
          ]);
          this.clientCustomizationFormGroup.controls.nopFile.setValidators([
            Validators.required
          ]);
        } else {
          this.clientCustomizationFormGroup.controls.nopDd.disable();
          this.clientCustomizationFormGroup.controls.nopFile.disable();
          this.clientCustomizationFormGroup.controls.nopDd.clearValidators();
          this.clientCustomizationFormGroup.controls.nopFile.clearValidators();
        }
        this.clientCustomizationFormGroup.controls.nopFile.updateValueAndValidity();
        this.clientCustomizationFormGroup.controls.nopDd.updateValueAndValidity();
      }
    );

    this.clientCustomizationFormGroup.controls.locum.valueChanges.subscribe(
      val => {
        if (val) {
          // this.clientCustomizationFormGroup.controls.locumDd.enable();
          this.clientCustomizationFormGroup.controls.locumFile.enable();
          this.clientCustomizationFormGroup.controls.locumFile.setValidators([
            Validators.required
          ]);
        } else {
          // this.clientCustomizationFormGroup.controls.locumDd.disable();
          this.clientCustomizationFormGroup.controls.locumFile.disable();
          this.clientCustomizationFormGroup.controls.locumFile.clearValidators();
        }
        this.clientCustomizationFormGroup.controls.locumFile.updateValueAndValidity();
      }
    );

    this.clientCustomizationFormGroup.controls.locumFilePath.valueChanges.subscribe(
      val => {
        if (val !== '') {
          this.clientCustomizationFormGroup.controls.locumFile.clearValidators();
        } else {
          this.clientCustomizationFormGroup.controls.locumFile.setValidators([
            Validators.required
          ]);
        }
        this.clientCustomizationFormGroup.controls.locumFile.updateValueAndValidity();
      }
    );

    this.clientCustomizationFormGroup.controls.nopFilePath.valueChanges.subscribe(
      val => {
        if (val !== '') {
          this.clientCustomizationFormGroup.controls.nopFile.clearValidators();
          this.clientCustomizationFormGroup.controls.nopDd.clearValidators();
        } else {
          this.clientCustomizationFormGroup.controls.nopDd.setValidators([
            Validators.required
          ]);
          this.clientCustomizationFormGroup.controls.nopFile.setValidators([
            Validators.required
          ]);
        }
        this.clientCustomizationFormGroup.controls.nopFile.updateValueAndValidity();
        this.clientCustomizationFormGroup.controls.nopDd.updateValueAndValidity();
      }
    );

    this.clientCustomizationFormGroup.controls.clientPathwaysFilePath.valueChanges.subscribe(
      val => {
        if (val !== '') {
          this.clientCustomizationFormGroup.controls.clientPathwaysFile.clearValidators();
        } else {
          this.clientCustomizationFormGroup.controls.clientPathwaysFile.setValidators(
            [Validators.required]
          );
        }
        this.clientCustomizationFormGroup.controls.clientPathwaysFile.updateValueAndValidity();
      }
    );

    this.clientCustomizationFormGroup.controls.residentPhysician.valueChanges.subscribe(
      val => {
        if (val) {
          // this.clientCustomizationFormGroup.controls.residentPhysicianDd.enable();
          this.clientCustomizationFormGroup.controls.residentPhysicianFile.enable();
          this.clientCustomizationFormGroup.controls.residentPhysicianFile.setValidators(
            [Validators.required]
          );
        } else {
          // this.clientCustomizationFormGroup.controls.residentPhysicianDd.disable();
          this.clientCustomizationFormGroup.controls.residentPhysicianFile.disable();
          this.clientCustomizationFormGroup.controls.residentPhysicianFile.clearValidators();
        }
        this.clientCustomizationFormGroup.controls.residentPhysicianFile.updateValueAndValidity();
      }
    );

    this.clientCustomizationFormGroup.controls.residentPhysicianFilePath.valueChanges.subscribe(
      val => {
        if (val !== '') {
          this.clientCustomizationFormGroup.controls.residentPhysicianFile.clearValidators();
        } else {
          this.clientCustomizationFormGroup.controls.residentPhysicianFile.setValidators(
            [Validators.required]
          );
        }
        this.clientCustomizationFormGroup.controls.residentPhysicianFile.updateValueAndValidity();
      }
    );

    this.clientCustomizationFormGroup.controls.clientSpecPro.valueChanges.subscribe(
      val => {
        if (val) {
          this.clientCustomizationFormGroup.controls.clientSpecProDd.enable();
          this.clientCustomizationFormGroup.controls.clientSpecProInput.enable();
          this.clientCustomizationFormGroup.controls.clientSpecProDd.setValidators(
            Validators.required
          );
          this.clientCustomizationFormGroup.controls.clientSpecProInput.setValidators(
            Validators.required
          );
        } else {
          this.clientCustomizationFormGroup.controls.clientSpecProDd.disable();
          this.clientCustomizationFormGroup.controls.clientSpecProInput.disable();
          this.clientCustomizationFormGroup.controls.clientSpecProDd.clearValidators();
          this.clientCustomizationFormGroup.controls.clientSpecProInput.clearValidators();
        }
        this.clientCustomizationFormGroup.controls.clientSpecProDd.updateValueAndValidity();
        this.clientCustomizationFormGroup.controls.clientSpecProInput.updateValueAndValidity();
      }
    );

    this.clientCustomizationFormGroup.controls.clientPathways.valueChanges.subscribe(
      val => {
        if (val) {
          // this.clientCustomizationFormGroup.controls.clientPathwaysDd.enable();
          this.clientCustomizationFormGroup.controls.clientPathwaysFile.enable();
          // this.clientCustomizationFormGroup.controls.clientPathwaysDd.setValidators([Validators.required]);
          this.clientCustomizationFormGroup.controls.clientPathwaysFile.setValidators(
            [Validators.required]
          );
        } else {
          // this.clientCustomizationFormGroup.controls.clientPathwaysDd.disable();
          this.clientCustomizationFormGroup.controls.clientPathwaysFile.disable();
          // this.clientCustomizationFormGroup.controls.clientPathwaysDd.clearValidators();
          this.clientCustomizationFormGroup.controls.clientPathwaysFile.clearValidators();
        }
        this.clientCustomizationFormGroup.controls.clientPathwaysFile.updateValueAndValidity();
      }
    );

    this.clientCustomizationFormGroup.controls.facility.valueChanges.subscribe(
      val => {
        if (val !== '') {
          this.search();
        }
      }
    );

    this.clientCustomizationFormGroup.updateValueAndValidity();
  }

  disableInputs() {
    (<FormArray>(
      this.clientCustomizationFormGroup.get('pqrslist')
    )).controls.forEach(control => {
      control.get('enabled').disable();
      control.get('enabled').patchValue(false);
      control.get('age').patchValue('');
      control.get('age').clearValidators();
      control.get('age').setErrors(null);
    });
  }

  enableInputs() {
    (<FormArray>(
      this.clientCustomizationFormGroup.get('pqrslist')
    )).controls.forEach(control => {
      control.get('enabled').enable();
      control.get('enabled').patchValue(true);
      control.get('age').setValidators([Validators.required]);
      // control.get('age').setErrors(null);
    });
  }

  public getMeasures() {
    this.dataSource = this.jsonData.map(m => ({
      measure: m.measure,
      enabled: m.enabled,
      age: m.age,
      blank: ''
    }));
    // this.clientCustomizationFormGroup.controls.pqrslist = this.jsonFormArray;
    this.dataSource.forEach(element => {
      (this.clientCustomizationFormGroup.controls.pqrslist as FormArray).push(
        this.setMeasuresFormArray(element)
      );
    });
    this.clientCustomizationFormGroup.controls.pqrslist.updateValueAndValidity();
  }

  public getInitialMeasures() {
    this.adminService.getJSON().subscribe((data: any) => {
      this.displayedColumns = ['measure', 'enabled', 'age', 'blank'];
      this.dataSource = data.measures;
      this.jsonData = data.measures.map(m => ({
        measure: m.measure,
        enabled: m.enabled,
        age: m.age
      }));
      this.dataSource.forEach(element => {
        (this.clientCustomizationFormGroup.controls.pqrslist as FormArray).push(
          this.setMeasuresFormArray(element)
        );
      });
    });
  }

  public clearFormArray() {
    while (
      (this.clientCustomizationFormGroup.controls.pqrslist as FormArray)
        .length !== 0
    ) {
      (this.clientCustomizationFormGroup.controls
        .pqrslist as FormArray).removeAt(0);
    }
  }

  setMeasuresFormArray(element) {
    const formBuilderGroup = this.formBuilder.group({
      measure: [element.measure],
      enabled: [
        {
          value: element.enabled,
          disabled: !this.clientCustomizationFormGroup.controls.pqrs.value
        }
      ],
      age: [
        { value: element.age, disabled: !element.enabled },
        element.enabled && this.clientCustomizationFormGroup.controls.pqrs.value
          ? Validators.required
          : null
      ],
      blank: [element.blank ? element.blank : null]
    });
    // if(element.enabled && this.clientCustomizationFormGroup.controls.pqrs.value){
    //   formBuilderGroup.controls.age.setValidators([Validators.required]);
    // }
    formBuilderGroup.controls.enabled.valueChanges.subscribe(val => {
      formBuilderGroup.controls.age.setErrors(null);
      if (val) {
        formBuilderGroup.controls.age.enable();
        if (this.clientCustomizationFormGroup.controls.pqrs.value) {
          formBuilderGroup.controls.age.setValidators([Validators.required]);
        }
      } else {
        formBuilderGroup.controls.age.disable();
        formBuilderGroup.controls.age.patchValue('');
        formBuilderGroup.controls.age.clearValidators();
      }

      formBuilderGroup.controls.age.updateValueAndValidity();
    });
    return formBuilderGroup;
  }

  public save() {
    if (this.clientCustomizationFormGroup.controls.locumFilePath.value !== '') {
      this.clientCustomizationFormGroup.controls.locumFile.clearValidators();
      this.clientCustomizationFormGroup.controls.locumFile.updateValueAndValidity();
    }
    if (
      this.clientCustomizationFormGroup.controls.residentPhysicianFilePath
        .value !== ''
    ) {
      this.clientCustomizationFormGroup.controls.residentPhysicianFile.clearValidators();
      this.clientCustomizationFormGroup.controls.residentPhysicianFile.updateValueAndValidity();
    }

    if (
      this.clientCustomizationFormGroup.controls.clientPathwaysFilePath
        .value !== ''
    ) {
      this.clientCustomizationFormGroup.controls.clientPathwaysFile.clearValidators();
      this.clientCustomizationFormGroup.controls.clientPathwaysFile.updateValueAndValidity();
    }

    if (this.clientCustomizationFormGroup.controls.nopFilePath.value !== '') {
      this.clientCustomizationFormGroup.controls.nopFile.clearValidators();
      this.clientCustomizationFormGroup.controls.nopFile.updateValueAndValidity();
      this.clientCustomizationFormGroup.controls.nopDd.clearValidators();
      this.clientCustomizationFormGroup.controls.nopDd.updateValueAndValidity();
    }
    if (this.clientCustomizationFormGroup.controls.clientSpecPro.value) {
      if (
        this.clientCustomizationFormGroup.controls.clientSpecProInput[
          'controls'
        ].icdCode.value === '' &&
        this.clientCustomizationFormGroup.controls.clientSpecProInput[
          'controls'
        ].cptCode.value === ''
      ) {
        // this.errorHandlingService.throwInfo(this.validationMessages.clientSpecProInput);
        this.clientCustomizationFormGroup.controls.clientSpecProInput.setErrors(
          { backend: { someProp: 'Backend message' } }
        );
      } else {
        this.clientCustomizationFormGroup.controls.clientSpecProInput.setErrors(
          null
        );
      }
    }
    if (this.clientCustomizationFormGroup.valid) {
      this.ngProgress.start();
      const formData: FormData = new FormData();
      // if(this.clientCustomizationFormGroup.controls.lcdNcd.value){
      //   formData.append('files',this.clientCustomizationFormGroup.controls.lcdNcdFile.value._files[0],'lcdncd_'+this.clientCustomizationFormGroup.controls.lcdNcdFile.value._fileNames);
      // }
      let checkFileFlag = false;
      if (
        this.clientCustomizationFormGroup.controls.nop.value &&
        this.clientCustomizationFormGroup.controls.nopFile.value !== ''
      ) {
        formData.append(
          'files',
          this.clientCustomizationFormGroup.controls.nopFile.value._files[0],
          'nop_' +
            this.clientCustomizationFormGroup.controls.nopFile.value._fileNames
        );
        checkFileFlag = true;
      }
      if (
        this.clientCustomizationFormGroup.controls.locum.value &&
        this.clientCustomizationFormGroup.controls.locumFile.value !== ''
      ) {
        formData.append(
          'files',
          this.clientCustomizationFormGroup.controls.locumFile.value._files[0],
          'locum_' +
            this.clientCustomizationFormGroup.controls.locumFile.value
              ._fileNames
        );
        checkFileFlag = true;
      }
      if (
        this.clientCustomizationFormGroup.controls.residentPhysician.value &&
        this.clientCustomizationFormGroup.controls.residentPhysicianFile
          .value !== ''
      ) {
        formData.append(
          'files',
          this.clientCustomizationFormGroup.controls.residentPhysicianFile.value
            ._files[0],
          'resident_' +
            this.clientCustomizationFormGroup.controls.residentPhysicianFile
              .value._fileNames
        );
        checkFileFlag = true;
      }
      if (
        this.clientCustomizationFormGroup.controls.clientPathways.value &&
        this.clientCustomizationFormGroup.controls.clientPathwaysFile.value !==
          ''
      ) {
        formData.append(
          'files',
          this.clientCustomizationFormGroup.controls.clientPathwaysFile.value
            ._files[0],
          this.clientCustomizationFormGroup.controls.clientPathwaysFile.value
            ._fileNames
        ); // no need to append since its pdf
        checkFileFlag = true;
      }
      if (!checkFileFlag) {
        formData.append('files', '');
      }

      this.receivedData.pqrsMips = this.receivedData.pqrsMips
        ? (<FormArray>(
            this.clientCustomizationFormGroup.get('pqrslist')
          )).controls.map(control => {
            // control.get('enabled').enable();
            return {
              measure: control.get('measure').value,
              age: control.get('age').value,
              enabled: control.get('enabled').value
            };
          })
        : this.receivedData.pqrsMips;

      this.receivedData.claimBased =
        this.clientCustomizationFormGroup.controls.base.value === 'claimBased'
          ? true
          : false;
      // this.receivedData.pqrsMips.registryBased = this.clientCustomizationFormGroup.controls.base.value === 'registryBased' ? true : false;

      this.receivedData.pqrsMipsEnabled = this.clientCustomizationFormGroup.controls.pqrs.value;
      this.receivedData.globalbilling = {
        globalBilling: this.clientCustomizationFormGroup.controls.globalBilling
          .value,
        contrast: this.clientCustomizationFormGroup.controls.globalBilling
          .value,
        hipcs: this.clientCustomizationFormGroup.controls.globalBilling.value,
        modifier_26: !this.clientCustomizationFormGroup.controls.globalBilling
          .value
      };

      if (this.clientCustomizationFormGroup.controls.nop.value) {
        this.receivedData.ourPhysician =
          this.clientCustomizationFormGroup.controls.nopDd.value === 'OP'
            ? 'OP'
            : 'NOP';
      }
      this.receivedData.groupname = this.clientCustomizationFormGroup.controls.facilityGroup.value;
      this.receivedData.pseudoCode = this.clientCustomizationFormGroup.controls
        .clientSpecPro.value
        ? {
            icdCode: this.clientCustomizationFormGroup.controls
              .clientSpecProInput['controls'].icdCode.value,
            cptCode: this.clientCustomizationFormGroup.controls
              .clientSpecProInput['controls'].cptCode.value
          }
        : null;
      this.receivedData.updatedby = this.userName;
      this.receivedData.updatedon = Date.now();
      const stri = JSON.stringify(this.receivedData);
      formData.append('facilityConfigRequest', stri);
      this.adminService.save(formData).subscribe(
        data => {
          if (!data.apierror) {
            this.assignValues(data);
            this.ngProgress.done();
            this.errorHandlingService.throwSuccess(
              'Facility Saved Successfully'
            );
          } else {
            this.ngProgress.done();
            this.errorHandlingService.throwInfo(data.apierror.message);
          }
        },
        error => {
          this.ngProgress.done();
          this.errorHandlingService.throwError(error);
        }
      );
    } else {
      const invalidControls = this.findInvalidControls();
      this.errorHandlingService.throwInfo(invalidControls.toString());
    }
  }

  public findInvalidControls() {
    const invalid = [];
    const controls = this.clientCustomizationFormGroup.controls;
    for (const name in controls) {
      if (controls[name].invalid) {
        // invalid.push(name);
        const message = this.validationMessages[name];
        invalid.push(message);
        break;
      }
    }
    return invalid;
  }

  reset() {
    // this.resetForm(this.clientCustomizationFormGroup);
    this.hide = true;
    this.resetControlValues();
    let control: AbstractControl = null;
    Object.keys(this.clientCustomizationFormGroup.controls).forEach(name => {
      control = this.clientCustomizationFormGroup.controls[name];
      control.setErrors(null);
    });
    this.clientCustomizationFormGroup.markAsUntouched();
  }

  partialReset() {
    this.resetForm(this.clientCustomizationFormGroup);
    this.clearFormArray();
  }

  resetForm(formGroup: FormGroup) {
    let control: AbstractControl = null;

    Object.keys(formGroup.controls).forEach(name => {
      control = formGroup.controls[name];
      control.setErrors(null);
    });
    formGroup.reset();
    formGroup.markAsUntouched();
  }

  search() {
    this.clearBeforeSearchCall();
    if (this.clientCustomizationFormGroup.controls.facility.value) {
      this.ngProgress.start();

      this.adminService
        .searchCustomization(
          this.clientCustomizationFormGroup.controls.facility
            ? this.clientCustomizationFormGroup.controls.facility.value
            : ''
        )
        .subscribe(
          data => {
            if (!data.apierror) {
              this.assignValues(data);
            } else {
              // this.hide = false;
              // this.AddNew();
              this.errorHandlingService.throwInfo(data.apierror.message);
            }
            this.ngProgress.done();
          },
          error => {
            // this.hide = false;
            // this.AddNew();
            this.ngProgress.done();
            this.errorHandlingService.throwError(error);
          }
        );
    }
  }

  resetControlValues() {
    this.clearFormArray();
    this.clientCustomizationFormGroup.patchValue({
      facility: '',
      newfacility: '',
      specialty: '',
      location: '',
      pqrs: true,
      base: '',
      // claimBased: false,
      // registryBased: false,
      globalBilling: true,
      lcdNcd: false,
      lcdNcdDd: '',
      lcdNcdFile: '',
      nop: true,
      nopDd: 'OP',
      nopFile: '',
      nopFileLastUpdated: '',
      nopFilePath: '',
      locum: true,
      locumFile: '',
      locumFileLastUpdated: '',
      locumFilePath: '',
      residentPhysician: true,
      residentPhysicianFile: '',
      residentPhysicianLastUpdated: '',
      residentPhysicianFilePath: '',
      clientSpecPro: true,
      clientSpecProDd: 'CPT Code',
      clientSpecProInput: {
        cptCode: '',
        icdCode: ''
      },
      clientPathways: true,
      clientPathwaysDd: '',
      clientPathwaysFile: '',
      clientPathwaysFilePath: '',
      facilityGroup: ''
    });
    this.getMeasures();
  }

  resetControlValuesSearch() {
    this.clearFormArray();
    this.clientCustomizationFormGroup.patchValue({
      newfacility: '',
      specialty: '',
      location: '',
      pqrs: true,
      base: '',
      // claimBased: false,
      // registryBased: false,
      globalBilling: true,
      lcdNcd: false,
      lcdNcdDd: '',
      lcdNcdFile: '',
      nop: true,
      nopDd: 'OP',
      nopFile: '',
      nopFileLastUpdated: '',
      nopFilePath: '',
      locum: true,
      locumFile: '',
      locumFileLastUpdated: '',
      locumFilePath: '',
      residentPhysician: true,
      residentPhysicianFile: '',
      residentPhysicianLastUpdated: '',
      residentPhysicianFilePath: '',
      clientSpecPro: true,
      clientSpecProDd: 'CPT Code',
      clientSpecProInput: {
        cptCode: '',
        icdCode: ''
      },
      clientPathways: true,
      clientPathwaysDd: '',
      clientPathwaysFile: '',
      clientPathwaysFilePath: '',
      facilityGroup: ''
    });
    this.getMeasures();
  }

  public assignValues(data) {
    this.receivedData = data;
    this.clearFormArray();
    this.clientCustomizationFormGroup.patchValue({
      specialty: data.clientspecialityname,
      location: data.clientlocationname,
      pqrs: data.pqrsMipsEnabled ? data.pqrsMipsEnabled : false,
      // pqrslist : data.pqrsMips ? (
      //   this.formBuilder.array(
      //     data.pqrsMips.map(element=> {return this.setMeasuresFormArray(element)})
      //   )
      // ) : this.getMeasures(),
      base:
        data.claimBased !== null
          ? data.claimBased === true
            ? 'claimBased'
            : 'registryBased'
          : null,
      // claimBased: data.claimBased ? data.claimBased : false,
      // registryBased: data.registryBased ? data.registryBased : false,
      globalBilling: data.globalbilling
        ? data.globalbilling.globalBilling
        : false,
      lcdNcd: false, // not given
      nop: data.nop
        ? data.nop.physicianDetails.length > 0
          ? true
          : false
        : false,
      nopDd: data.nop ? data.nop.ourPhysician : '',
      nopFile: '',
      nopFileLastUpdated: data.nop
        ? this.dateFormatter.getDatetime(data.nop.lastModifiedTime)
        : '',
      nopFilePath: data.nop
        ? data.nop.filePath.replace(/^.*[\\\/]/, '').replace('nop_', '')
        : '',
      locum: data.locum
        ? data.locum.physicianDetails.length > 0
          ? true
          : false
        : false,
      locumFile: '',
      locumFilePath: data.locum
        ? data.locum.filePath.replace(/^.*[\\\/]/, '').replace('locum_', '')
        : '',
      locumFileLastUpdated: data.locum
        ? this.dateFormatter.getDatetime(data.locum.lastModifiedTime)
        : '',
      residentPhysician: data.residentPhysician
        ? data.residentPhysician.physicianDetails.length > 0
          ? true
          : false
        : false,
      residentPhysicianFile: '',
      residentPhysicianLastUpdated: data.residentPhysician
        ? this.dateFormatter.getDatetime(
            data.residentPhysician.lastModifiedTime
          )
        : '',
      residentPhysicianFilePath: data.residentPhysician
        ? data.residentPhysician.filePath
            .replace(/^.*[\\\/]/, '')
            .replace('resident_', '')
        : '',
      clientSpecPro: data.pseudoCode ? true : false, // not given
      clientSpecProDd: 'CPT Code',
      clientSpecProInput: {
        cptCode: data.pseudoCode
          ? data.pseudoCode.cptCode
            ? data.pseudoCode.cptCode
            : ''
          : '',
        icdCode: data.pseudoCode
          ? data.pseudoCode.icdCode
            ? data.pseudoCode.icdCode
            : ''
          : ''
      },
      clientPathways: data.lookUpGuidePath
        ? data.lookUpGuidePath === ''
          ? false
          : true
        : false,
      clientPathwaysFile: '',
      clientPathwaysFilePath: data.lookUpGuidePath
        ? data.lookUpGuidePath.replace(/^.*[\\\/]/, '')
        : '',
      facilityGroup: data.groupname
    });

    // // removing existing data
    // while ((this.clientCustomizationFormGroup.controls.pqrslist as FormArray).length !== 0) {
    //   (this.clientCustomizationFormGroup.controls.pqrslist as FormArray).removeAt(0)
    // }

    if (data.pqrsMips) {
      this.dataSource = data.pqrsMips.map(data => ({
        measure: data.measure,
        age: data.age,
        enabled: data.enabled,
        blank: ''
      }));
      data.pqrsMips.forEach(element => {
        (this.clientCustomizationFormGroup.controls.pqrslist as FormArray).push(
          this.setMeasuresFormArray(element)
        );
      });
    } else {
      this.getMeasures();
    }

    if (data.pqrsMipsEnabled) {
      this.clientCustomizationFormGroup.controls.base.enable();
      // this.clientCustomizationFormGroup.controls.claimBased.enable();
      // this.clientCustomizationFormGroup.controls.registryBased.enable();
    } else {
      this.clientCustomizationFormGroup.controls.base.disable();
      // this.clientCustomizationFormGroup.controls.claimBased.disable();
      // this.clientCustomizationFormGroup.controls.registryBased.disable();
    }
  }
  public AddNew() {
    this.ngProgress.start();
    this.hide = !this.hide;
    Object.keys(this.clientCustomizationFormGroup.controls).forEach(name => {
      control = this.clientCustomizationFormGroup.controls[name];
      control.setErrors(null);
    });

    if (!this.hide) {
      this.clientCustomizationFormGroup.controls.newfacility.setErrors(null);
      this.clientCustomizationFormGroup.controls.newfacility.setValidators([
        Validators.required
      ]);
      this.clientCustomizationFormGroup.controls.facility.clearValidators();
      // this.clientCustomizationFormGroup.controls.nopDd.setValidators([Validators.required]);
      // this.clientCustomizationFormGroup.controls.nopFile.setValidators([Validators.required]);
      // this.clientCustomizationFormGroup.controls.locumFile.setValidators([Validators.required]);
      // this.clientCustomizationFormGroup.controls.residentPhysicianFile.setValidators([Validators.required]);
      // this.clientCustomizationFormGroup.controls.clientPathwaysFile.setValidators([Validators.required]);
    } else {
      this.getFacilityList();
      this.clientCustomizationFormGroup.controls.facility.setErrors(null);
      this.clientCustomizationFormGroup.controls.newfacility.clearValidators();
      this.clientCustomizationFormGroup.controls.facility.setValidators([
        Validators.required
      ]);
    }

    this.resetControlValues();

    let control: AbstractControl = null;
    this.clientCustomizationFormGroup.markAsPristine();
    this.clientCustomizationFormGroup.markAsUntouched();
    this.clientCustomizationFormGroup.updateValueAndValidity();
    this.ngProgress.done();
  }

  clearBeforeSearchCall() {
    this.ngProgress.start();
    this.resetControlValuesSearch();

    let control: AbstractControl = null;
    Object.keys(this.clientCustomizationFormGroup.controls).forEach(name => {
      control = this.clientCustomizationFormGroup.controls[name];
      control.setErrors(null);
    });
    this.clientCustomizationFormGroup.markAsUntouched();
    this.clientCustomizationFormGroup.updateValueAndValidity();
    this.ngProgress.done();
  }

  public saveNew() {
    if (this.clientCustomizationFormGroup.controls.locumFilePath.value !== '') {
      this.clientCustomizationFormGroup.controls.locumFile.clearValidators();
      this.clientCustomizationFormGroup.controls.locumFile.updateValueAndValidity();
    }

    if (
      this.clientCustomizationFormGroup.controls.clientPathwaysFilePath
        .value !== ''
    ) {
      this.clientCustomizationFormGroup.controls.clientPathwaysFile.clearValidators();
      this.clientCustomizationFormGroup.controls.clientPathwaysFile.updateValueAndValidity();
    }

    if (this.clientCustomizationFormGroup.controls.nopFilePath.value !== '') {
      this.clientCustomizationFormGroup.controls.nopFile.clearValidators();
      this.clientCustomizationFormGroup.controls.nopFile.updateValueAndValidity();
      this.clientCustomizationFormGroup.controls.nopDd.clearValidators();
      this.clientCustomizationFormGroup.controls.nopDd.updateValueAndValidity();
    }
    if (this.clientCustomizationFormGroup.controls.clientSpecPro.value) {
      if (
        this.clientCustomizationFormGroup.controls.clientSpecProInput[
          'controls'
        ].icdCode.value === '' &&
        this.clientCustomizationFormGroup.controls.clientSpecProInput[
          'controls'
        ].cptCode.value === ''
      ) {
        // this.errorHandlingService.throwInfo(this.validationMessages.clientSpecProInput);
        this.clientCustomizationFormGroup.controls.clientSpecProInput.setErrors(
          { backend: { someProp: 'Backend message' } }
        );
      } else {
        this.clientCustomizationFormGroup.controls.clientSpecProInput.setErrors(
          null
        );
      }
    }

    if (this.clientCustomizationFormGroup.valid) {
      const formData: FormData = new FormData();
      // if(this.clientCustomizationFormGroup.controls.lcdNcd.value){
      //   formData.append('files',this.clientCustomizationFormGroup.controls.lcdNcdFile.value._files[0],'lcdncd_'+this.clientCustomizationFormGroup.controls.lcdNcdFile.value._fileNames);
      // }
      let checkFileFlag = false;
      if (
        this.clientCustomizationFormGroup.controls.nop.value &&
        this.clientCustomizationFormGroup.controls.nopFile.value !== ''
      ) {
        formData.append(
          'files',
          this.clientCustomizationFormGroup.controls.nopFile.value._files[0],
          'nop_' +
            this.clientCustomizationFormGroup.controls.nopFile.value._fileNames
        );
        checkFileFlag = true;
      }
      if (
        this.clientCustomizationFormGroup.controls.locum.value &&
        this.clientCustomizationFormGroup.controls.locumFile.value !== ''
      ) {
        formData.append(
          'files',
          this.clientCustomizationFormGroup.controls.locumFile.value._files[0],
          'locum_' +
            this.clientCustomizationFormGroup.controls.locumFile.value
              ._fileNames
        );
        checkFileFlag = true;
      }
      if (
        this.clientCustomizationFormGroup.controls.residentPhysician.value &&
        this.clientCustomizationFormGroup.controls.residentPhysicianFile
          .value !== ''
      ) {
        formData.append(
          'files',
          this.clientCustomizationFormGroup.controls.residentPhysicianFile.value
            ._files[0],
          'resident_' +
            this.clientCustomizationFormGroup.controls.residentPhysicianFile
              .value._fileNames
        );
        checkFileFlag = true;
      }
      if (
        this.clientCustomizationFormGroup.controls.clientPathways.value &&
        this.clientCustomizationFormGroup.controls.clientPathwaysFile.value !==
          ''
      ) {
        formData.append(
          'files',
          this.clientCustomizationFormGroup.controls.clientPathwaysFile.value
            ._files[0],
          this.clientCustomizationFormGroup.controls.clientPathwaysFile.value
            ._fileNames
        ); // no need to append since its pdf
        checkFileFlag = true;
      }
      if (!checkFileFlag) {
        formData.append('files', '');
      }
      const sanitizedNewFacility = this._sanitizer.sanitize(
        SecurityContext.HTML,
        this.clientCustomizationFormGroup.controls.newfacility.value
      );
      const sanitizedSpecialty = this._sanitizer.sanitize(
        SecurityContext.HTML,
        this.clientCustomizationFormGroup.controls.specialty.value
      );
      const sanitizedLocation = this._sanitizer.sanitize(
        SecurityContext.HTML,
        this.clientCustomizationFormGroup.controls.location.value
      );
      const sanitizedCptCode = this._sanitizer.sanitize(
        SecurityContext.HTML,
        this.clientCustomizationFormGroup.controls.clientSpecProInput[
          'controls'
        ].cptCode.value
      );
      const sanitizedIcdCode = this._sanitizer.sanitize(
        SecurityContext.HTML,
        this.clientCustomizationFormGroup.controls.clientSpecProInput[
          'controls'
        ].icdCode.value
      );
      const data = {
        clientfacilityname: sanitizedNewFacility,
        clientfacilitylongname: sanitizedNewFacility,
        interfacename: sanitizedNewFacility,
        clientlocationname: sanitizedLocation,
        clientspecialityname: sanitizedSpecialty,
        isactive: true,
        createdby: this.userName,
        createdon: Date.now(),
        pqrsMipsEnabled: this.clientCustomizationFormGroup.controls.pqrs.value,
        pqrsMips: (<FormArray>(
          this.clientCustomizationFormGroup.get('pqrslist')
        )).controls.map(control => {
          control.get('enabled').enable();
          return {
            measure: control.get('measure').value,
            age: control.get('age').value,
            enabled: control.get('enabled').value
          };
        }),
        claimBased:
          this.clientCustomizationFormGroup.controls.base.value === 'claimBased'
            ? true
            : false,
        globalbilling: {
          globalBilling: this.clientCustomizationFormGroup.controls
            .globalBilling.value,
          contrast: this.clientCustomizationFormGroup.controls.globalBilling
            .value,
          hipcs: this.clientCustomizationFormGroup.controls.globalBilling.value,
          modifier_26: !this.clientCustomizationFormGroup.controls.globalBilling
            .value
        },
        groupname: this.clientCustomizationFormGroup.controls.facilityGroup
          .value,
        pseudoCode: this.clientCustomizationFormGroup.controls.clientSpecPro
          .value
          ? { icdCode: sanitizedIcdCode, cptCode: sanitizedCptCode }
          : null
      };

      if (this.clientCustomizationFormGroup.controls.nop.value) {
        data['ourPhysician'] =
          this.clientCustomizationFormGroup.controls.nopDd.value === 'OP'
            ? 'OP'
            : 'NOP';
      }
      const stri = JSON.stringify(data);

      formData.append('facilityConfigRequest', stri);
      this.ngProgress.start();
      this.adminService.save(formData).subscribe(
        data => {
          if (!data.apierror) {
            // this.assignValues(data);
            this.AddNew();
            this.errorHandlingService.throwSuccess(
              'Facility Saved Successfully'
            );
          } else {
            this.errorHandlingService.throwInfo(data.apierror.message);
          }
          this.ngProgress.done();
        },
        error => {
          this.ngProgress.done();
          this.errorHandlingService.throwError(error);
        }
      );
    } else {
      const invalidControls = this.findInvalidControls();
      this.errorHandlingService.throwInfo(invalidControls.toString());
    }
  }

  onKey(event: any) {
    if (event.target.value) {
      const age = event.target.value;
      if (age[0] === '>' || age[0] === '<' || age[0] === '=') {
        const val1 = age[0];
        if (age[1]) {
          const val2 = age[1];
          if (
            '0123456789'.indexOf(age[1]) !== -1 ||
            (age[1] === '>' || age[1] === '<' || age[1] === '=')
          ) {
            if (age[2]) {
              const val3 = age[2];
              if ('0123456789'.indexOf(age[2]) !== -1) {
                if (age[3]) {
                  const val4 = age[3];
                  if ('0123456789'.indexOf(age[3]) !== -1) {
                  } else {
                    event.target.value = val1 + val2 + val3;
                  }
                }
              } else {
                event.target.value = val1 + val2;
              }
            }
          } else {
            event.target.value = val1;
          }
        }
      } else {
        event.target.value = '';
      }
    }
    const x = +' | ';
  }
}
