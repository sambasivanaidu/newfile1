import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConflictManagementComponent } from './conflict-management/conflict-management.component';
import { InventoryUploadComponent } from './inventory-upload/inventory-upload.component';
import { TLPlatformComponent } from './teamLead-platform/teamLead-platform.component';
import { TlComponent } from './team-lead.component';
import { BreadCrumbModule } from '../reports/bread-crumb/bread-crumb.module';
import { MaterialModule } from '../../../imports/material.module';
import { RouterModule, Routes } from '@angular/router';
import { MatDynamicDdModule } from '../../../imports/_utilities/mat-dynamic-dd/mat-dynamic-dd.module';
import { AgGridModule } from 'ag-grid-angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  PasswordModule,
  InputTextModule,
  PanelModule,
  DialogModule,
  ConfirmDialogModule,
  SharedModule,
  ContextMenuModule
} from 'primeng/primeng';
import { ChartModule } from 'primeng/chart';
import { OscarSharedModule } from '../oscar-shared/oscar-shared.module';
import { PipesModule } from '../../../imports/pipes/pipes.module';
import { CoderModalChildComponent } from '../oscar-shared/coder-modal-child/coder-modal-child.component';
import { BatchProcessSummaryComponent } from './batch-process-summary/batch-process-summary.component';
import { BatchCheckboxRendererComponent } from '../../../imports/ag-grid/batch-checkbox-renderer';
import { ContextMenuService } from 'ngx-contextmenu';
import { AdminComponent } from './admin/admin.component';
import { AdminService } from './admin/admin.service';
import { UsrMappingComponent } from './usr-mapping/usr-mapping.component';
import { MatSearchDdModule } from '../../../imports/_utilities/mat-search-dd/mat-search-dd.module';
import { UsrMappingService } from './usr-mapping/usr-mapping.service';
import { QueueService } from '../../../services/main-pages/queue.service';
import { MipsDialogModule } from '../../../imports/_utilities/mips-dialog/mips-dialog.module';

const routes: Routes = [
  { path: 'queue', component: TlComponent },
  { path: 'platform', component: TLPlatformComponent },
  { path: 'inventoryupload', component: InventoryUploadComponent },
  { path: 'inventorytracking', component: BatchProcessSummaryComponent },
  { path: 'facilityonboarding', component: AdminComponent },
  { path: 'usermapping', component: UsrMappingComponent }
];

@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
    RouterModule.forChild(routes),
    MatDynamicDdModule,
    AgGridModule,
    FormsModule,
    ReactiveFormsModule,
    PasswordModule,
    InputTextModule,
    PanelModule,
    DialogModule,
    ConfirmDialogModule,
    SharedModule,
    ChartModule,
    OscarSharedModule,
    PipesModule,
    BreadCrumbModule,
    ContextMenuModule,
    MatSearchDdModule,
    MipsDialogModule
  ],
  declarations: [
    ConflictManagementComponent,
    InventoryUploadComponent,
    TLPlatformComponent,
    BatchProcessSummaryComponent,
    TlComponent,
    BatchCheckboxRendererComponent,
    AdminComponent,
    UsrMappingComponent
  ],
  providers: [
    ContextMenuService,
    AdminService,
    UsrMappingService,
    QueueService
  ],
  entryComponents: [CoderModalChildComponent, BatchCheckboxRendererComponent]
})
export class TeamLeadModule {}
