import { Component, OnInit } from '@angular/core';
import { TlService } from './team-lead.component.service';
import { ToastsManager } from 'ng2-toastr';
import { environment } from '../../../../environments/environment';
import { CommonCodeService } from '../../../_shared-services/common-code.services';
@Component({
  selector: 'app-tl',
  templateUrl: './team-lead.component.html',
  styleUrls: ['./team-lead.component.scss'],
  providers: [TlService]
})
export class TlComponent implements OnInit {
  customCollapsedHeight: string = '40px';
  customExpandedHeight: string = '55px';
  public tlData: any;
  public approvedCptData: any = [];
  public approvedIcdData: any = [];
  public saveSelectedRowdata;
  public username: string;
  public storage: Storage = environment.storage;
  public userRole;
  userSubRole = 'tl';
  constructor(
    private _tlService: TlService,
    public toaster: ToastsManager,
    private _commonCode: CommonCodeService
  ) {}

  ngOnInit() {
    this.username = this.storage.getItem('TLId');
    this.prepareTLRebuttalData();
  }

  public prepareTLRebuttalData(): void {
    const clientObject = this._commonCode.get_ConfidenceColor_Clientselection(
      'clientSelectionObject'
    );
    const role = clientObject.workRole.role;
    const param = {
      userId: this.storage.getItem('UserName'),
      adminSubRole: this.userSubRole,
      role: role ? role : ''
    };
    this._tlService.fetchRebuttal(param).subscribe((data: any) => {
      this.tlData = data;
    });
  }

  public selectedLearningRowData(event) {
    if (event) {
      this.saveSelectedRowdata = event.api.getSelectedRows();
    }
  }
}
