import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { environment } from '../../../../environments/environment';
import { HeaderAuthenticationToken } from '../../../auth/authetication-header';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ToastsManager } from 'ng2-toastr';

@Injectable()
export class TlService {
  public httpOption;
  public envURL = environment.URL;
  public httpHeaders;
  public userName: string;
  public storage: Storage = environment.storage;
  constructor(
    private http: Http,
    private httpClient: HttpClient,
    private httpHeader: HeaderAuthenticationToken,
    private toaster: ToastsManager
  ) {
    this.httpOption = this.httpHeader.setHeaderToken();
    this.userName = this.storage.getItem('UserName');
  }

  public fetchRebuttal(param): any {
    const url = this.envURL + 'chartinformation/searchchartinformation';
    return this.httpClient.post(url, param, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }

  // public saveTLData(cptdata, icddata): any {
  //   const cptAPIUrl = this.envURL + 'chartcptinfo/saveTlAuditing';
  //   const icdAPIUrl = this.envURL + 'charticdinfo/saveTlAuditing';

  //   return Observable.forkJoin(
  //     this.http
  //       .post(cptAPIUrl, cptdata, this.httpOption)
  //       .map(res => res.json()),
  //     this.http.post(icdAPIUrl, icddata, this.httpOption).map(res => res.json())
  //   );
  // }

  public discardService(event) {
    const _url = this.envURL + 'mastersdata/discardReason?masterType=' + event;
    return this.httpClient.get(_url, this.httpOption);
  }

  public saveTLChart(
    CPTInfo: any,
    ICDInfo: any,
    UniqueID: string,
    modality,
    icdFeedbackJson,
    cptFeedbackJson,
    codingRole
  ) {
    // const codingRole = 'auditor';
    const updatecoder: any = [];

    const newlyAddedIcd = ICDInfo.filter(n => !n.id).length > 0 ? true : false;
    const newlyAddedCpt = CPTInfo.filter(n => !n.id).length > 0 ? true : false;
    let coderError, auditorError;
    const CptArrParam = this.coderHandleCPT(
      CPTInfo,
      codingRole,
      UniqueID,
      this.userName,
      cptFeedbackJson
    );
    const IcdArrParam = this.coderHandleICD(
      ICDInfo,
      codingRole,
      UniqueID,
      this.userName,
      icdFeedbackJson
    );
    if (newlyAddedIcd || newlyAddedCpt) {
      coderError = true;
      auditorError = true;
    } else {
      const arrAck =
        cptFeedbackJson.length > 0
          ? cptFeedbackJson.concat(icdFeedbackJson)
          : icdFeedbackJson;

      const cc = arrAck.map(
        n => n.tlAck === 'Coder Correct' || n.tlAck === 'Both Incorrect'
      );
      const ac = arrAck.map(
        n => n.tlAck === 'Auditor Correct' || n.tlAck === 'Both Incorrect'
      );

      coderError = ac.find(n => n === true) ? true : false;
      auditorError = cc.find(n => n === true) ? true : false;
    }
    const saveParam = {
      tlReviewed: true,
      updatedBy: this.userName,
      updatedon: Date.now(),
      uniqueId: UniqueID,
      coderErrorFound: coderError,
      auditorErrorFound: auditorError,
      addToLearning : false // Since tl can only add rows adddtolearning will be false
    };

    // parvati Api Inputs and url
    return Observable.forkJoin(
      this.httpClient
        .post(
          this.envURL + 'charticdinfo/saveTlAuditing/',
          IcdArrParam,
          this.httpOption
        ),
      this.httpClient
        .post(
          this.envURL + 'chartcptinfo/saveTlAuditing/',
          CptArrParam,
          this.httpOption
        ),
      this.httpClient
        .post(
          this.envURL + 'chartinformation/tlSave',
          saveParam,
          this.httpOption
        )
    );
  }

  coderHandleCPT(CPTInfo, codingRole, UniqueID, userName, feedbackJson) {
    const CPTArr = [];
    for (let i = 0; i < CPTInfo.length; i++) {
      const CPTObj = {
        id: CPTInfo[i].id,
        uniqueId: UniqueID,
        counter: i,
        aapcDescription: CPTInfo[i].aapcDescription,
        accessionNo: CPTInfo[i].accessionNo,
        codingRole: codingRole,
        cptCode: CPTInfo[i].cptCode,
        cptDescription: CPTInfo[i].cptDescription,
        dxRef: CPTInfo[i].dxRef,
        modifier: CPTInfo[i].modifier,
        units: CPTInfo[i].units,
        approved: CPTInfo[i].approved,
        isDiscarded: CPTInfo[i].isDiscarded,
        addToLearningSystem: CPTInfo[i].addToLearningSystem,
        approvedBy: CPTInfo[i].approvedBy,
        approvedOn: CPTInfo[i].approvedOn,
        updatedBy: null,
        updatedOn: null,
        isActive: CPTInfo[i].isActive,
        createdBy: userName,
        createdOn: Date.now(),
        rationaleData: CPTInfo[i].rationaleData,
        rationaleSection: CPTInfo[i].rationaleSection
      };
      CPTArr.push(CPTObj);
    }
    const cptParam = {
      approvedBy: this.userName,
      approvedInfo: CPTArr,
      approvedOn: Date.now(),
      codingRole: codingRole,
      tlAcknowledgeJson: feedbackJson,
      uniqueId: UniqueID
    };
    return cptParam;
  }

  coderHandleICD(ICDInfo, codingRole, UniqueID, userName, feedbackJson) {
    const ICDArr = [];
    for (let i = 0; i < ICDInfo.length; i++) {
      const ICdObj = {
        id: ICDInfo[i].id,
        uniqueId: UniqueID,
        counter: i,
        aapcDescription: ICDInfo[i].aapcDescription,
        accessionNo: ICDInfo[i].accessionNo,
        codingRole: codingRole,
        icdCode: ICDInfo[i].icdCode,
        icdDescription: ICDInfo[i].icdDescription,
        isActive: ICDInfo[i].isActive,
        lcdStatus: ICDInfo[i].lcdStatus,
        addToLearningSystem: ICDInfo[i].addToLearningSystem,
        approved: ICDInfo[i].approved,
        discarded: ICDInfo[i].discarded,
        lcdPassed: ICDInfo[i].lcdPassed,
        approvedBy: ICDInfo[i].approvedBy,
        approvedOn: ICDInfo[i].approvedOn,
        updatedBy: null,
        updatedOn: null,
        createdBy: userName,
        createdOn: Date.now(),
        rationaleData: ICDInfo[i].rationaleData,
        rationaleSection: ICDInfo[i].rationaleSection
      };
      ICDArr.push(ICdObj);
    }
    const icdParam = {
      approvedBy: this.userName,
      approvedInfo: ICDArr,
      approvedOn: Date.now(),
      codingRole: codingRole,
      tlAcknowledgeJson: feedbackJson,
      uniqueId: UniqueID
    };
    return icdParam;
  }
}
