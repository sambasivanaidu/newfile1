import { Component, OnInit } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl,
  FormArray
} from '@angular/forms';
import * as _moment from 'moment';
import { ToastsManager } from 'ng2-toastr';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
import {
  MomentDateAdapter,
  MAT_MOMENT_DATE_FORMATS
} from '@angular/material-moment-adapter';
import {
  MAT_DATE_LOCALE,
  DateAdapter,
  MAT_DATE_FORMATS
} from '@angular/material';
import { DateService } from '../../../../_shared-services/date-service/date.service';
import { environment } from '../../../../../environments/environment';
import { UsrMappingService } from './usr-mapping.service';
import { UserMappingService } from '../../../../_shared-services/user-mapping/user-mapping.service';

@Component({
  selector: 'app-usr-mapping',
  templateUrl: './usr-mapping.component.html',
  styleUrls: ['./usr-mapping.component.scss'],
  providers: [
    DateService,
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS }
  ]
})
export class UsrMappingComponent implements OnInit {
  customCollapsedHeight: string = '30px';
  customExpandedHeight: string = '35px';
  fromDateErrorMessage = 'Please enter valid date.';
  toDateErrorMessage = 'Please enter valid date.';
  validationMessage = {
    username: [
      { type: 'required', message: 'Please enter the username.' },
      { type: 'minlength', message: 'Username must be at least 5 characters.' }
    ],
    password: [
      { type: 'required', message: 'Please enter the password.' },
      { type: 'minlength', message: 'Password must be at least 5 characters.' },
      { type: 'password', message: 'password don\'t match..............' }
    ],
    email: [
      { type: 'required', message: 'Please enter the email.' },
      { type: 'pattern', message: 'Please enter a valid email.' }
    ]
  };

  storage: Storage = environment.storage;
  loginInfoForm: FormGroup;
  teamMappingForm: FormGroup;
  clientMappingForm: FormGroup;
  profileMappingForm: FormGroup;
  samplingForm: FormGroup;
  targetForm: FormGroup;
  seniorMgrList = [];
  managerList = [];
  teamLeadList = [];
  userRoles = [];
  clientList = [];
  specialtyList = [];
  locationList = [];
  facilityList = [];
  workFlowList = [];
  modalityList = [];
  selectedFacilityList = [];
  selectedWorkFlowList = [];
  selectedModalityList = [];
  profileMappingFacilities = [];
  clientData: any;
  facilityPriority: any;
  targetArray = [];
  samplingArray = [];
  disableSave = false;
  errorMessage = false;
  selectedUserRole: any;
  public selectedUserConfiguration: any = {};
  multipleRole: string;

  constructor(
    public uMappingService: UserMappingService,
    private formBuilder: FormBuilder,
    private userMappingService: UsrMappingService,
    public toaster: ToastsManager,
    private errorService: ErrorHandlingServices,
    private dateService: DateService
  ) {}

  public ngOnInit() {
    this.initialiseUserMapping();
  }

  initialiseUserMapping() {
    this.initializeLoginInfoForm();
    this.initializeTeamLeadForm();
    this.initializeClientMappingForm();
    this.initializeProfileMappingForm();
    this.getUsersMapped();
    this.enablePriorityList();
  }

  enablePriorityList() {
    this.facilityPriority = [
      { key: 'primary', value: 'Primary', selected: false, disabled: false },
      {
        key: 'secondary',
        value: 'Secondary',
        selected: false,
        disabled: false
      },
      { key: 'tertiary', value: 'Tertiary', selected: false, disabled: false }
    ];
  }

  setTeamMappingData(data) {
    this.seniorMgrList.push({
      name: data.seniorManager
    });

    this.managerList.push({
      name: data.manager
    });

    data.teamleads.forEach(tl => {
      this.teamLeadList.push({
        name: tl
      });
    });

    this.teamMappingForm.controls['seniorManager'].setValue(
      this.seniorMgrList[0]
    );
    this.teamMappingForm.controls['manager'].setValue(this.managerList[0]);
    this.teamMappingForm.controls['teamLead'].setValue(this.teamLeadList[0]);
  }

  setClientMappingData(clientData) {
    this.clientData = clientData;
    this.clientList.push(clientData[0].name);
  }

  getUsersMapped() {
    this.clientData = [];
    this.userMappingService.fetchMappedUsers().subscribe(data => {
      if (data) {
        this.userRoles = data.userRole;
        this.setTeamMappingData(data);
        this.setClientMappingData(data.client);
      }
    });
  }

  initializeLoginInfoForm() {
    this.loginInfoForm = this.formBuilder.group({
      userName: new FormControl('', [
        Validators.required,
        Validators.minLength(5)
      ]),
      firstName: new FormControl('', [Validators.required]),
      middleName: new FormControl(''),
      lastName: new FormControl('', [Validators.required]),
      email: new FormControl('', [
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ]),
      password: new FormControl('', [
        Validators.required,
        Validators.minLength(5)
      ]),
      confirmPassword: new FormControl('', [
        Validators.required,
        Validators.minLength(5)
      ]),
      dateOfJoining: new FormControl(_moment([])),
      productionDate: new FormControl(_moment([])),
      userType: new FormControl('', [Validators.required]),
      opsLocation: new FormControl('', [Validators.required]),
      isActive: new FormControl(false),
      userRole: new FormControl([], [Validators.required])
    });
  }

  initializeTeamLeadForm() {
    this.teamMappingForm = this.formBuilder.group({
      seniorManager: new FormControl(''),
      manager: new FormControl(''),
      teamLead: new FormControl('')
    });
  }

  initializeClientMappingForm() {
    this.clientMappingForm = this.formBuilder.group({
      client: new FormControl('', [Validators.required]),
      specialty: new FormControl('', [Validators.required]),
      location: new FormControl('', [Validators.required]),
      facility: new FormControl('', [Validators.required]),
      workflow: new FormControl('', [Validators.required])
    });
  }

  intializeSamplingForm() {
    this.samplingForm = this.formBuilder.group({
      sampling: new FormControl('', [Validators.required])
      // fromDate: new FormControl(_moment([])),
      // toDate: new FormControl(_moment([])),
    });
  }

  initializeTargetForm() {
    this.targetForm = this.formBuilder.group({
      target: new FormControl('', [Validators.required])
      // fromDate: new FormControl(_moment([])),
      // toDate: new FormControl(_moment([])),
    });
  }

  createMappedFacilityArray(eve?: any) {
    return this.formBuilder.group({
      facility: new FormControl('', [Validators.required])
    });
  }

  initializeProfileMappingForm() {
    this.profileMappingForm = this.formBuilder.group({
      modality: new FormControl('', [Validators.required]),
      mappedFacilities: this.formBuilder.array([]),
      target: new FormControl(''),
      sampling: new FormControl('', [Validators.required])
    });
    // this.intializeSamplingForm();
    // this.initializeTargetForm();
  }

  updateLoginFormOnSearch(data) {
    this.loginInfoForm.controls['password'].disable();
    this.loginInfoForm.controls['confirmPassword'].disable();
    this.loginInfoForm.get('password').clearValidators();
    this.loginInfoForm.get('confirmPassword').clearValidators();
    this.loginInfoForm.controls['firstName'].setValue(data.userfirstname);
    this.loginInfoForm.controls['middleName'].setValue(data.usermiddlename);
    this.loginInfoForm.controls['lastName'].setValue(data.userlastname);
    this.loginInfoForm.controls['email'].setValue(data.email);
    this.loginInfoForm.controls['productionDate'].setValue(_moment(data.dop));
    this.loginInfoForm.controls['dateOfJoining'].setValue(_moment(data.doj));
    this.loginInfoForm.controls['userType'].setValue(data.userType);
    this.loginInfoForm.controls['opsLocation'].setValue(data.opsLocation);
    this.loginInfoForm.controls['isActive'].setValue(data.isActive);
    const userRole = [];
    data.userRole.forEach(element => {
      userRole.push(element.role);
    });
    this.loginInfoForm.controls['userRole'].setValue(userRole);
  }

  updateClientMappingFormOnSearch(userConfig) {
    // this.clientMappingForm.reset();
    let client, specialty, location;
    this.selectedFacilityList = [];
    this.selectedWorkFlowList = [];
    this.selectedModalityList = [];
    if (userConfig) {
      userConfig.client.forEach(c => {
        client = { value: c.name };
        if (client) {
          this.getSpecialtyList(client);
        }
        c.speciality.forEach(s => {
          specialty = { value: s.name };
          if (specialty) {
            this.getLocationList(specialty);
          }
          s.location.forEach(l => {
            location = { value: l.name };
            if (location) {
              this.getFacilityList(location);
            }
            l.facility.forEach(f => {
              this.selectedFacilityList.push(f.name);
              const facility = { value: f.name };
            });
            l.workflow.forEach(w => {
              this.selectedWorkFlowList.push(w.name);
            });
          });
        });
      });
      this.clientMappingForm.controls['client'].setValue(client.value);
      this.clientMappingForm.controls['specialty'].setValue(specialty.value);
      this.clientMappingForm.controls['location'].setValue(location.value);
      this.clientMappingForm.controls['facility'].setValue(
        this.selectedFacilityList
      );
      this.clientMappingForm.controls['workflow'].setValue(
        this.selectedWorkFlowList
      );
      this.profileMappingForm.controls['modality'].setValue(
        this.selectedModalityList
      );
      const eventValue = { value: this.selectedFacilityList };
      this.setProfileMappingFacilty(eventValue);
    }
  }
  // get target and sampling
  getTarget() {
    if (
      this.loginInfoForm.controls.productionDate &&
      this.loginInfoForm.controls.productionDate.value &&
      (this.loginInfoForm.controls.userRole &&
        this.loginInfoForm.controls.userRole.value)
    ) {
    }
  }

  resetForm() {
    this.initializeClientMappingForm();
    this.initializeLoginInfoForm();
    this.initializeProfileMappingForm();
  }

  bindUserConfigAll() {
    let modalityList = [];

    this.profileMappingForm.value.modality.forEach(element => {
      modalityList.push(element);
    });

    let facilityList = [];
    this.clientMappingForm.value.facility.forEach(element => {
      facilityList.push({
        locationId: this.clientMappingForm.value.location,
        name: element,
        modality: modalityList
      });
    });

    let workflowList = [];
    this.clientMappingForm.value.workflow.forEach(element => {
      workflowList.push({
        locationId: this.clientMappingForm.value.location,
        name: element
      });
    });

    let locationList = [];
    locationList.push({
      clientId: this.clientMappingForm.value.client,
      name: this.clientMappingForm.value.location,
      specialityId: this.clientMappingForm.value.specialty,
      facility: facilityList,
      workflow: workflowList
    });

    let specialityList = [];
    specialityList.push({
      clientId: this.clientMappingForm.value.client,
      name: this.clientMappingForm.value.specialty,
      location: locationList
    });

    let finalparam = [];
    finalparam.push({
      name: this.clientMappingForm.value.client,
      speciality: specialityList
    });

    this.selectedUserConfiguration.client = finalparam;
  }

  // on click of user search button
  getUserSearchData() {
    const userId = this.loginInfoForm.controls.userName.value;
    this.resetForm();
    this.loginInfoForm.controls['userName'].setValue(userId);
    this.userMappingService.fetchUserToUpdate(userId).subscribe(data => {
      if (data && data.userMaster) {
        this.disableSave = true;
        // this.multipleRole = 'multiple';
        this.profileMappingForm.controls['target'].setValue(data.userTarget);
        this.profileMappingForm.controls['sampling'].setValue(
          data.userMaster.samplingpercentage
            ? data.userMaster.samplingpercentage
            : ''
        );
        this.updateLoginFormOnSearch(data.userMaster);
        this.updateClientMappingFormOnSearch(data.userMaster.userconfiguration);
      } else {
        this.disableSave = false;
        // this.multipleRole = '';
      }
    });
  }

  getSpecialtyList(event) {
    this.specialtyList = [];
    this.clientData.forEach(client => {
      if (event.value === client.name) {
        client.speciality.forEach(spec => {
          this.specialtyList.push({
            name: spec.name
          });
        });
      }
    });
  }

  getLocationList(event) {
    this.locationList = [];
    this.clientData.forEach(client => {
      client.speciality.forEach(spec => {
        if (event.value === spec.name) {
          spec.location.forEach(loc => {
            this.locationList.push({
              name: loc.name
            });
          });
        }
      });
    });
  }

  getFacilityList(event) {
    this.facilityList = [];
    this.modalityList = [];
    this.workFlowList = [];
    this.clientData.forEach(client => {
      client.speciality.forEach(spec => {
        spec.location.forEach(loc => {
          if (event.value === loc.name) {
            loc.facility.forEach(fac => {
              this.facilityList.push(fac.name);
            });
            this.modalityList = loc.facility[0].modality;
            this.selectedModalityList = this.modalityList;
            loc.workflow.forEach(w => {
              this.workFlowList.push(w.name);
            });
          }
        });
      });
    });
    this.facilityList.sort();
  }

  clearFormArrayControls() {
    while (
      (this.profileMappingForm.controls.mappedFacilities as FormArray).controls
        .length
    ) {
      (this.profileMappingForm.controls.mappedFacilities as FormArray).removeAt(
        0
      );
    }
  }

  setProfileMappingFacilty(event) {
    this.profileMappingFacilities = [];
    this.clearFormArrayControls();
    this.profileMappingForm.updateValueAndValidity();
    event.value.forEach(element => {
      this.profileMappingFacilities.push(element);
    });
    if (
      this.profileMappingFacilities &&
      this.profileMappingFacilities.length > 0
    ) {
      this.profileMappingFacilities.forEach((f, i) => {
        (this.profileMappingForm.controls.mappedFacilities as FormArray).push(
          this.createMappedFacilityArray(f)
        );
      });
      this.enablePriorityList();
    } else {
      this.clearFormArrayControls();
    }
  }

  // on selection of priority of the facilities in team mapping
  onPrioritySelect(event) {
    const isError = false;
    const formArrayList: FormArray = this.profileMappingForm.controls
      .mappedFacilities as FormArray;
    const valueList: string[] = [];
    for (const formGroup of formArrayList.controls) {
      valueList.push(formGroup.get('facility').value);
    }

    const isPrimary = valueList.includes('primary');
    const isSecondary = valueList.includes('secondary');

    this.facilityPriority.find(obj => {
      if (obj.key === 'primary') {
        obj.disabled = isPrimary ? true : false;
      } else if (obj.key === 'secondary') {
        obj.disabled = isSecondary ? true : false;
      }
    });
  }

  // on change of modality drop down. If no modality disable the selected facility
  modalityChange(event) {
    if (event) {
      if (this.profileMappingForm.controls.modality.value.length === 0) {
        (this.profileMappingForm.controls
          .mappedFacilities as FormArray).controls.forEach((ele: any) => {
          ele.controls.facility.disable();
        });
      } else {
        (this.profileMappingForm.controls
          .mappedFacilities as FormArray).controls.forEach((ele: any) => {
          ele.controls.facility.enable();
        });
      }
    }
  }

  getuserRole() {
    let param = [];
    this.loginInfoForm.controls.userRole.value.forEach(element => {
      this.userRoles.forEach(usrRole => {
        usrRole.subRoles.forEach(subRole => {
          if (element === subRole.role) {
            param.push(subRole);
          }
        });
      });
    });
    return param;
  }

  // prepare the parameter for userMapping save API
  prepareSaveObject() {
    return {
      userId: this.loginInfoForm.controls.userName.value,
      defaultRole: this.loginInfoForm.controls.userRole.value[0],
      createdOn: Date.now(),
      createdBy: this.storage.getItem('UserName'),
      doj: this.loginInfoForm.controls.dateOfJoining
        ? this.loginInfoForm.get('dateOfJoining').value.format('YYYY-MM-DD')
        : '',
      dop: this.loginInfoForm.controls.productionDate
        ? this.loginInfoForm.get('productionDate').value.format('YYYY-MM-DD')
        : '',
      email: this.loginInfoForm.controls.email.value
        ? this.loginInfoForm.controls.email.value
        : '',
      internalUser: <boolean>false,
      userRole: this.getuserRole(),
      isActive: this.loginInfoForm.controls.isActive.value,
      manager: this.teamMappingForm.controls.manager.value.name
        ? this.teamMappingForm.controls.manager.value.name
        : '',
      opsLocation: this.loginInfoForm.controls.opsLocation.value,
      password: this.loginInfoForm.controls.confirmPassword.value
        ? this.loginInfoForm.controls.confirmPassword.value
        : '',
      teamlead: this.teamMappingForm.controls.teamLead.value.name
        ? this.teamMappingForm.controls.teamLead.value.name
        : '',
      userfirstname: this.loginInfoForm.controls.firstName.value
        ? this.loginInfoForm.controls.firstName.value
        : '',
      usermiddlename: this.loginInfoForm.controls.middleName.value
        ? this.loginInfoForm.controls.middleName.value
        : '',
      userlastname: this.loginInfoForm.controls.lastName.value
        ? this.loginInfoForm.controls.lastName.value
        : '',
      userType: this.loginInfoForm.controls.userType.value
        ? this.loginInfoForm.controls.userType.value
        : '',
      userconfiguration: this.selectedUserConfiguration,
      samplingpercentage: this.profileMappingForm.controls.sampling.value,
      tlsmemapping: null,
      usertarget: [],
      targetsampling: null,
      updatedOn: null,
      updatedBy: null
    };
  }

  // on click of save/update button
  saveUserMapping() {
    this.bindUserConfigAll();
    const param = this.prepareSaveObject();
    this.uMappingService.saveMappedUsers(param).subscribe((data: any) => {
      if (data) {
        this.toaster.success('User Created successfully!');
        this.resetForm();
        this.disableSave = false;
      }
    });
  }

  checkPassword() {
    this.errorMessage = false;
    if (
      this.loginInfoForm.controls.password &&
      this.loginInfoForm.controls.confirmPassword
    ) {
      if (this.loginInfoForm.controls.password.value === '') {
        this.errorMessage = false;
        this.loginInfoForm.controls.confirmPassword.setErrors(null);
      } else if (this.loginInfoForm.controls.confirmPassword.value === '') {
        this.errorMessage = false;
        this.loginInfoForm.controls.password.setErrors(null);
      } else if (
        this.loginInfoForm.controls.password.value !==
        this.loginInfoForm.controls.confirmPassword.value
      ) {
        this.errorMessage = true;
        this.loginInfoForm.controls.password.setErrors({ invalid: true });
        this.loginInfoForm.controls.confirmPassword.setErrors({
          invalid: true
        });
      } else {
        this.errorMessage = false;
        this.loginInfoForm.controls.password.setErrors(null);
        this.loginInfoForm.controls.confirmPassword.setErrors(null);
      }
    }
  }

  validateDate(event, field?: string): any {
    const toDateControl = this.loginInfoForm.controls['productionDate'];
    const fromDateControl = this.loginInfoForm.controls['dateOfJoining'];
    const validate = this.dateService.dateValidation(
      event,
      fromDateControl,
      toDateControl,
      field,
      'userMapping'
    );
    this.fromDateErrorMessage = '';
    this.toDateErrorMessage = '';
    if (
      validate.toDateControl.status === 'INVALID' &&
      validate.fromDateControl.status === 'INVALID'
    ) {
      setTimeout(() => {
        toDateControl.setErrors({ invalid: true });
        fromDateControl.setErrors({ invalid: true });
        this.toDateErrorMessage = validate.toDateErrorMessage;
        this.fromDateErrorMessage = validate.fromDateErrorMessage;
      }, 100);
    } else if (validate.toDateControl.status === 'INVALID') {
      setTimeout(() => {
        toDateControl.setErrors({ invalid: true });
        this.toDateErrorMessage = validate.toDateErrorMessage;
      }, 100);
    } else if (validate.fromDateControl.status === 'INVALID') {
      setTimeout(() => {
        fromDateControl.setErrors({ invalid: true });
        this.fromDateErrorMessage = validate.fromDateErrorMessage;
      }, 100);
    } else if (
      validate.toDateControl.status === 'VALID' &&
      validate.fromDateControl.status === 'VALID'
    ) {
      setTimeout(() => {
        toDateControl.setErrors(null);
        fromDateControl.setErrors(null);
      }, 100);
    }
    this.getTarget();
  }
}
