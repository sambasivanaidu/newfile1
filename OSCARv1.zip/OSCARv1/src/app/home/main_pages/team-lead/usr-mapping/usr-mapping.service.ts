import { Injectable } from '@angular/core';
import { environment } from '../../../../../environments/environment';
import { HeaderAuthenticationToken } from '../../../../auth/authetication-header';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class UsrMappingService {
  public userName: any;
  public storage: any = environment.storage;
  public httpOptions: any;
  public envUrl: any = environment.URL;

  constructor(
    private httpClient: HttpClient,
    private __httpHeader: HeaderAuthenticationToken
  ) {
    this.httpOptions = this.__httpHeader.setHeaderToken();
    this.userName = this.storage.getItem('UserName');
  }

  public fetchMappedUsers(): Observable<any> {
    const _url =
      this.envUrl + 'facilitymaster/usermapping?teamLeadId=' + this.userName;
    return this.httpClient.get(_url, this.httpOptions);
  }

  public fetchUserToUpdate(userId): Observable<any> {
    const _url = this.envUrl + 'usermaster/userId?userId=' + userId;
    return this.httpClient.get(_url, this.httpOptions).pipe(map(res => res));
  }

  public saveMappedUsers(params): Observable<any> {
    const _url = this.envUrl + 'usermaster/save';
    return this.httpClient
      .post(_url, params, this.httpOptions);
  }
}
