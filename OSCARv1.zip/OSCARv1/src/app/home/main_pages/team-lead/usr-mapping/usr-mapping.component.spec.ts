// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { UsrMappingComponent } from './usr-mapping.component';

// describe('UsrMappingComponent', () => {
//   let component: UsrMappingComponent;
//   let fixture: ComponentFixture<UsrMappingComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ UsrMappingComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(UsrMappingComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
