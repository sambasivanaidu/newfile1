import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog, MatDialogRef } from '@angular/material';
import 'rxjs/add/operator/map';
import { MatDialogOverviewComponent } from '../../../../imports/_utilities/mat-dialog-overview/mat-dialog-overview.component';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { MatDialogCheckDuplicateComponent } from '../../../../imports/_utilities/mat-dialog-check-duplicate/mat-dialog-check-duplicate.component';
import { LookupDataService } from '../../../../_shared-services/unrelated-data-services/lookup-data.service';
import { environment } from '../../../../../environments/environment';
import { MipsDialogComponent } from '../../../../imports/_utilities/mips-dialog/mips-dialog.component';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
import { TlService } from '../../team-lead/team-lead.component.service';
import * as CryptoJS from 'crypto-js';
import { DomSanitizer } from '@angular/platform-browser';
import { AuditAcknowledgeDialogComponent } from '../../../../imports/_utilities/mat-dialog-acknowledge/mat-dialog-acknowledge.component';
import { LocationStrategy } from '@angular/common';
import { CommonCodeService } from '../../../../_shared-services/common-code.services';
import { CoderModalChildComponent } from '../../oscar-shared/coder-modal-child/coder-modal-child.component';
import { QueueService } from '../../../../services/main-pages/queue.service';
import { PlatformService } from '../../../../services/main-pages/paltform-services/platform-service.service';
@Component({
  selector: 'app-auditor-platform',
  templateUrl: './auditor-platform.component.html',
  styleUrls: ['./auditor-platform.component.scss'],
  providers: [
    LookupDataService,
    TlService
  ]
})
export class AuditorPlatformComponent implements OnInit {
  uniqueID = '';
  customCollapsedHeight: string = '25px';
  customExpandedHeight: string = '25px';
  platform: string = 'auditor';
  patientChart: any;
  patientInfoParent: any;
  patientRecordInfoParent: any;
  ICDInfoRequest: any;
  CPTInfoRequest: any;
  icdIsPristines: boolean = false;
  cptIsPristines: boolean = false;
  // lookups;
  userSubRole = 'auditor';
  public storage: Storage = environment.storage;
  public clickedEventICD: any;
  public clickedEventCPT: any;
  public patientName;
  public dateOfService;
  public isDisabled: boolean;
  public isIcdValidated: boolean;
  public isCptValidated: boolean;
  public reason = '';
  // public lookUpOption;
  public relatedVisitParentData: any;
  public MRN;
  public fetchICDRowData: any = [];
  public fetchCPTRowData: any = [];
  dialogRefModal: MatDialogRef<any>;
  public display: boolean = false;
  public UID;
  public selectedModality;
  public selectedFacility;
  public searchTerm: any;
  public lcdCheckStatus;
  public disableMIPS: boolean;
  public facility: string;
  public disableLCD: boolean;
  public disableCCI: boolean;
  public cciCheck: any;
  public validateCptInfo = [];
  public validateIcdInfo = [];
  public chartInfoParam: any;
  public serviceFor: any;
  public lcdNcdClicked = false;
  public cciClicked = false;
  public pqrsMipsClicked = false;
  public chartRemarks = '';
  public height = 750;
  public zoom: any = 1;
  public lineHeight: any = 1.5;
  priorityQueueRequest: any[];
  AuditorWorkQueueRequest: any[];
  username: string;
  clientSelectionObj: any;
  facilityOptionList: any;
  public auditorFeedback: any;
  public priorityQueue: any;
  fileURL: any;
  displayPdf: any = 'none';
  public isProccessed: boolean;
  public hideAckAuditor: boolean;
  public auditorConflict: boolean;
  public l2auditorConflict: boolean;
  public saveDeletedICDObj = [];
  public saveDeletedCPTObj = [];
  public errorFeedBack: boolean;
  public patientInfoGender: string;
  public patientInfoFacility: string;
  public dateOfBirth: any;
  lastCptDxVal: any;
  public lookupGuidePath = null;
  lastAccessionVal: any;
  urlParameters: any;
  public auditorAllocated = null;
  public coderAllocated = null;
  public raiComment: string;
  cptlength = 0;
  icdlength = 0;
  public relatedVisitHeaderClickCount: number = 0;
  accesionNo: any;
  public isDiscarded = false;
  icdHeaderClickCount: number = 0;
  cptSectionHeight: number;
  cptHeaderClickCount: number = 0;
  icdSectionHeight: number;
  relatedVisit: boolean = false;
  raiResponse: any;
  public panelOpenState: boolean = true;
  constructor(
    public _platformService: PlatformService,
    private _router: Router,
    public _toastr: ToastsManager,
    public dialog: MatDialog,
    public _lookupDataService: LookupDataService,
    public coderQueueService: QueueService,
    private errorService: ErrorHandlingServices,
    public sanitzer: DomSanitizer,
    public location: LocationStrategy,
    private CommonCodeService: CommonCodeService
  ) {
    this.getPlatformParam();
    this._router.routeReuseStrategy.shouldReuseRoute = function() {
      return false;
    };
    history.pushState(null, null, window.location.href);
    this.location.onPopState(() => {
      history.pushState(null, null, window.location.href);
      setTimeout(() => {
        console.clear();
      }, 100);
      const previousChart: any = sessionStorage.getItem('previousChart');
      this._router.navigate(['index/coderPlatform', previousChart]);
      setTimeout(() => {
        console.clear();
      }, 100);
    });
  }
  ngOnInit() {
    if (localStorage.getItem('urlParameters')) {
      this.urlParameters = JSON.parse(
        CryptoJS.AES.decrypt(
          localStorage.getItem('urlParameters'),
          'oscar'
        ).toString(CryptoJS.enc.Utf8)
      );
    }
    if (this.urlParameters !== undefined) {
      this.uniqueID = this.urlParameters.uniqueId;
    }
    /* URL Sortening END*/
    this.initPlatformFunction();
  }
  setHeight(functionName) {
    if (functionName === 'setCptHeight') {
      this.cptSectionHeight = this.CommonCodeService.setCptHeight();
    } else if (functionName === 'setIcdHeight') {
      this.icdSectionHeight = this.CommonCodeService.setIcdHeight();
    } else if (functionName === 'setMedicalReportHeight') {
      this.height = this.CommonCodeService.setMedicalReportHeight(
        this.chartRemarks,
        this.relatedVisit
      );
    } else if (functionName === 'pateintrecordinfoheight') {
      this.cptSectionHeight = this.CommonCodeService.pateintRecordInfoHeight();
      this.icdSectionHeight = this.cptSectionHeight;
    }
  }
  openpdf(): void {
    if (this.lookupGuidePath) {
      this._platformService
        .fetchPdfFileData(this.lookupGuidePath)
        .subscribe(res => {
          this.fileURL = URL.createObjectURL(res);
          this.fileURL = this.sanitzer.bypassSecurityTrustResourceUrl(
            this.fileURL
          );
        });
      this.displayPdf = 'block';
    }
  }
  openRaiDocument(val) {
    if (this.raiResponse) {
      this._platformService.downloadRaiFiles(val).subscribe(res => {
        this.fileURL = URL.createObjectURL(res);
        const link = document.createElement('a');
        link.href = this.fileURL;
        const filename = val.split('/RAI/');
        link.download = filename[1];
        link.click();
      });
    }
  }

  private getPlatformParam() {
    if (localStorage.getItem('urlParameters')) {
      this.urlParameters = JSON.parse(
        CryptoJS.AES.decrypt(
          localStorage.getItem('urlParameters'),
          'oscar'
        ).toString(CryptoJS.enc.Utf8)
      );
    }
    if (this.urlParameters !== undefined) {
      this.uniqueID = this.urlParameters.uniqueId;
      this.facility = this.urlParameters.facilityId
        ? this.urlParameters.facilityId
        : '';
      this.MRN = this.urlParameters.mrn;
    }
    /* URL Sortening END*/
    this.auditorFeedback = JSON.parse(this.storage.getItem('osc-aud-ack'));
    this.priorityQueue = JSON.parse(this.storage.getItem('osc-coder-pri'));
    const clientSelectionObj = this.storage.getItem('clientSelectionObject');
    if (clientSelectionObj) {
      this.clientSelectionObj = JSON.parse(
        CryptoJS.AES.decrypt(clientSelectionObj, 'oscar').toString(
          CryptoJS.enc.Utf8
        )
      );
    }
    this.getMIPSDisableCheck();
  }
  private initPlatformFunction() {
    this.fetchPatientChart();
    this.fetchPatientInfo();
    this.fetchPatientRecordInfo();
    this.fetchRemarks();
  }
  public myMethodChangingQueryParams(param) {
    if (this.auditorFeedback) {
      this.MRN = param.mrn;
      const params = {
        uniqueId: param.uniqueId,
        facilityId: param.facilityId,
        mrn: param.mrn
      };
      if (params) {
        this.urlParameters = CryptoJS.AES.encrypt(
          JSON.stringify(params),
          'oscar'
        ).toString();
      }
      localStorage.setItem('urlParameters', this.urlParameters);
      /* URL Sortening END */
      this._router.navigate(
        [
          'index/auditor/platform',
          { uniqueID: param.uniqueId, facility: param.facilityId }
        ],
        { skipLocationChange: true }
      );
    } else {
      this.coderQueueService
        .updateStartTimeforCoder(param.uniqueId, 'updateauditorstartedon')
        .subscribe(responseList => {
          if ( responseList && responseList == '1') {
            setTimeout(() => {
              this.MRN = param.mrn;
              const params = {
                uniqueId: param.uniqueId,
                facilityId: param.facilityId,
                mrn: param.mrn
              };
              if (params) {
                this.urlParameters = CryptoJS.AES.encrypt(
                  JSON.stringify(params),
                  'oscar'
                ).toString();
              }
              localStorage.setItem('urlParameters', this.urlParameters);
              /* URL Sortening END */
              this._router.navigate(
                [
                  'index/auditor/platform',
                  { uniqueID: param.uniqueId, facility: param.facilityId }
                ],
                { skipLocationChange: true }
              );
            }, 100);
          }
        });
    }
  }
  public prepareParamAuditorQueue(
    facilityList,
    modalityList,
    auditorConflict,
    priority
  ) {
    return {
      facility: [],
      modality: [],
      role: this.clientSelectionObj.workRole.role
        ? this.clientSelectionObj.workRole.role
        : '',
      userId: this.storage.getItem('UserName'),
      teamLeadId: this.storage.getItem('TLId'),
      location: this.clientSelectionObj.location,
      userConfiguration: this.clientSelectionObj.clientConfiguration,
      userType: this.clientSelectionObj.clientType,
      doj: this.clientSelectionObj.clientDOJ,
      speciality: this.clientSelectionObj.specialty,
      client: this.clientSelectionObj.client,
      auditorConflict: auditorConflict,
      adminSubRole: this.userSubRole,
      targetsampling:
        this.storage.getItem('targetSampling') === 'null'
          ? null
          : JSON.parse(this.storage.getItem('targetSampling'))
    };
  }
  public loadNextChart(): void {
    const params = this.prepareParamAuditorQueue(
      [],
      [],
      this.auditorFeedback,
      this.priorityQueue
    );
    this.getNextPlatformData(params);
  }
  private navigateToQueue() {
    this._router.navigate(['/index/auditor/queue']);
  }
  private getNextPlatformData(params) {
    let priorityData = [];
    this.coderQueueService.fetchCoderQueue(params).subscribe((data: any) => {
      if (data && data.length > 0) {
        if (this.auditorFeedback) {
          const audData = data.filter(element => element.isAck == true);
          if (audData.length > 0) {
            this.myMethodChangingQueryParams(audData[0]);
          } else {
            this.navigateQueue();
          }
        } else if (this.priorityQueue) {
          priorityData = data.filter(element => element.priority == true);
          if (priorityData && priorityData.length > 0) {
            this.myMethodChangingQueryParams(data[0]);
          } else {
            this.navigateToQueue();
          }
        } else {
          const workQue = data.filter(
            element => element.priority == false && element.isAck == false
          );
          if (workQue.length > 0) {
            this.myMethodChangingQueryParams(workQue[0]);
          } else {
            this.navigateQueue();
          }
        }
      } else {
        // this.errorService.throwInfo(data.apierror.message);
        this.navigateQueue();
      }
    });
  }
  ZoomIn(event) {
    event.stopPropagation();
    this.zoom = this.zoom + 0.1;
    this.lineHeight = this.lineHeight + 0.1;
  }
  zoomOut(event) {
    event.stopPropagation();
    this.zoom = this.zoom - 0.1;
    this.lineHeight = this.lineHeight - 0.1;
  }
  zoomReset(event) {
    event.stopPropagation();
    this.zoom = 'normal';
    this.zoom = 1;
    this.lineHeight = 'inherit';
    this.lineHeight = 1.5;
  }
  fetchRemarks() {
    this._platformService
      .searchByUniqueID(this.uniqueID)
      .subscribe(response => {
        if (response) {
          this.isDiscarded = response.chartReasonCode ? true : false;
          this.chartRemarks = response.chartRemarks;
          this.auditorAllocated = response.auditorAllocatedTo;
          this.coderAllocated = response.coderAllocatedTo;
          if (this.auditorFeedback) {
            this.chartRemarks = response.auditorComments;
            this.isProccessed = response.isProcessed
              ? response.isProcessed
              : false;
            this.hideAckAuditor = response.auditorAllocatedTo ? false : true;
            this.auditorConflict = response.auditorConflict
              ? response.auditorConflict
              : false;
            this.l2auditorConflict = response.l2auditorConflict
              ? response.l2auditorConflict
              : false;
            this.errorFeedBack = response.auditorErrorfound
              ? response.auditorErrorfound
              : false;
            if (this.errorFeedBack) {
              this.fetchFeedBackCPTInfo();
              this.fetchFeedBackICDInfo();
            } else if (this.l2auditorConflict) {
              this.fetchAucitorConflicICDInfo();
              this.fetchAuditorConflictCPTInfo();
            }
          } else {
            this.fetchPredictedICDInfo();
            this.fetchPredictedCPTInfo();
          }
          if (response.raiDetails) {
            this.raiResponse = response.raiDetails.responses;
          }
          if (response.accessionNo) {
            this.accesionNo = response.accessionNo;
          }
        }
      });
  }
  private getMIPSDisableCheck() {
    this._platformService
      .fetchMIPSDisableCheck(this.facility)
      .subscribe(response => {
        if (response) {
          this.disableMIPS = response.pqrsMipsEnabled;
          this.disableCCI = response.ccienabled;
          this.disableLCD = response.lcdenabled;
          this.lookupGuidePath = response.lookupguidepath
            ? response.lookupguidepath
            : null;
        }
      });
  }
  // doFilter(param) {
  //   if (param) {
  //     this._lookupDataService.getLookUpData(param).subscribe(data => {
  //       if (data) {
  //         this.lookUpOption = data;
  //       }
  //     });
  //   }
  // }
  // For Patient Medical Report
  fetchPatientChart() {
    this.patientChart = [];
    this._platformService
      .fetchPatientChart(this.uniqueID)
      .subscribe((data: any) => {
        if (data) {
          this.patientChart = data.observationValue;
        }
      });
  }
  fetchFeedBackICDInfo() {
    this.ICDInfoRequest = [];
    const params = {
      codedBy: '',
      coderAuditorFeedback: true,
      uniqueId: this.uniqueID
    };
    this._platformService.fetchFeedBackICDInfo(params).subscribe(response => {
      if (response && response.length > 0) {
        this.ICDInfoRequest = response;
      }
    });
  }
  clearSelection(event) {
    event.stopPropagation();
    const selectedText = document.querySelectorAll(
      '.highlighted, .ht, .htb, .htn, .hted'
    );
    let parent;
    for (let i = 0; i < selectedText.length; i++) {
      parent = selectedText[i].parentNode;
      if (selectedText[i].firstChild) {
        parent.insertBefore(selectedText[i].firstChild, selectedText[i]);
      }
      parent.removeChild(selectedText[i]);
    }
  }
  fetchFeedBackCPTInfo() {
    this.CPTInfoRequest = [];
    const params = {
      codedBy: '',
      coderAuditorFeedback: true,
      uniqueId: this.uniqueID
    };
    this._platformService.fetchFeedBackCPTInfo(params).subscribe(response => {
      if (response && response.length > 0) {
        this.CPTInfoRequest = response;
      }
    });
  }
  // For Pateint Informtation
  fetchPatientInfo() {
    this._platformService.fetchPatientInfo(this.uniqueID).subscribe(data => {
      if (data) {
        this.patientInfoParent = data;
        let firstname = data['First name'];
        const lastChar = data['First name'].charAt(
          data['First name'].length - 1
        );
        firstname = lastChar === ' ' ? firstname.trim() : firstname;
        this.patientName = data['Last name'] + ' ' + firstname;
        this.dateOfService = data['DOS'];
        this.dateOfBirth = data['DOB'];
        this.patientInfoGender = data['Gender'];
      }
    });
  }
  // For Record Information
  fetchPatientRecordInfo() {
    this._platformService
      .fetchPatientRecordInfo(this.uniqueID)
      .subscribe((data: any) => {
        if (data) {
          this.patientRecordInfoParent = data;
          this.selectedModality = data.Modality;
          this.selectedFacility = data['Facility name'];
          this.patientInfoFacility = data['Facility name'];
          if (this.selectedModality && this.dateOfService) {
            this.fetchRelatedVisit();
          }
        }
      });
  }
  // For ICD 10 - CM
  fetchPredictedICDInfo() {
    this.ICDInfoRequest = [];
    this._platformService
      .fetchICDInfo(this.uniqueID, this.platform)
      .subscribe((data: any) => {
        if (data && data.length > 0) {
          this.ICDInfoRequest = data;
        }
      });
  }
  // For CPT - CM
  fetchPredictedCPTInfo() {
    this.CPTInfoRequest = [];
    this._platformService
      .fetchCPTInfo(this.uniqueID, this.platform)
      .subscribe((data: any) => {
        if (data && data.length > 0) {
          this.CPTInfoRequest = data;
        }
      });
  }
  // For ICD 10 - CM
  fetchAucitorConflicICDInfo() {
    this.ICDInfoRequest = [];
    const params = {
      l2Auditor: this.l2auditorConflict,
      uniqueId: this.uniqueID
    };
    this._platformService.getFeebackICDInfo(params).subscribe(data => {
      if (data && data.length > 0) {
        this.ICDInfoRequest = data;
      }
    });
  }
  // For CPT - CM
  fetchAuditorConflictCPTInfo() {
    this.CPTInfoRequest = [];
    const params = {
      l2Auditor: this.l2auditorConflict,
      uniqueId: this.uniqueID
    };
    this._platformService.getFeedbackCPTInfo(params).subscribe(data => {
      if (data) {
        this.CPTInfoRequest = data;
      }
    });
  }
  // For related Visit
  fetchRelatedVisit() {
    const myObj = {
      uniqueId: this.uniqueID,
      patientName: this.patientName,
      dos: this.dateOfService,
      modality: this.selectedModality,
      mrn: this.MRN
    };
    this.relatedVisitParentData = [];
    this._platformService.fetchRelatedChart(myObj).subscribe(data => {
      if (data && data.length > 0) {
        this.relatedVisitParentData = data;
        this.relatedVisit = true;
        this.height = this.chartRemarks === '' ? 594 : 536;
      }
    });
  }
  checkIcdIsPrisitine(event) {
    if (event) {
      this.icdIsPristines = event;
    }
  }
  checkCptIsPrisitine(event) {
    if (event) {
      this.cptIsPristines = event;
    }
  }
  ICDRowData(event) {
    this.fetchICDRowData = [];
    if (event && event.length > 0) {
      this.fetchICDRowData = event;
    }
  }
  CPTRowData(event) {
    this.fetchCPTRowData = [];
    if (event && event.length > 0) {
      this.fetchCPTRowData = event;
    }
  }
  highlightText(event: any) {
    if (event) {
      this.searchTerm = ' ';
      setTimeout(() => {
        this.searchTerm = event;
      }, 10);
    }
  }
  saveClick() {
    const saveIcdInfo = this.fetchICDRowData;
    const saveCptInfo = this.fetchCPTRowData;
    this.validateCptInfo = [];
    this.validateIcdInfo = [];
    // get data for validations whose active state is true
    this.validateIcdInfo = this.fetchICDRowData.filter(
      element => element.isActive != false
    );
    this.validateCptInfo = this.fetchCPTRowData.filter(
      element => element.isActive != false
    );
    if (
      this.validateCptInfo.length === 0 ||
      this.validateIcdInfo.length === 0
    ) {
      this.errorService.throwWarning(
        '1 ICD and CPT is mandatory to save the chart'
      );
    } else {
      const dxIsEmpty = this._lookupDataService.cptDxRefValidationCheck(
        this.validateCptInfo
      );
      const isValidate = this._lookupDataService.validateBlankRecordCoder(
        this.validateCptInfo,
        this.validateIcdInfo
      );
      const conflictStatus =
        this.icdIsPristines || this.cptIsPristines ? true : false;
      if (dxIsEmpty && dxIsEmpty.code === 1) {
        if (
          isValidate.cptCodeIsEmpty.length === 0 &&
          isValidate.icdCodeIsEmpty.length === 0 &&
          isValidate.cptAccessionEmpty.length === 0
        ) {
          this.checkForLcdCciMipsValidation(conflictStatus);
        } else {
          const msg = this.getValidationMessage(isValidate);
          this.errorService.throwWarning(msg);
        }
      } else if (dxIsEmpty) {
        this.errorService.throwWarning(dxIsEmpty.msg);
      } else {
        this.errorService.throwWarning(
          '1 ICD and CPT is mandatory to save the chart'
        );
      }
    }
  }
  checkForLcdCciMipsValidation(conflictStatus) {
    const cptInfo = this.fetchCPTRowData;
    const icdInfo = this.fetchICDRowData;
    const lcdParam = this.prepareLCDParam(cptInfo, icdInfo);
    const cciParam = this.prepareCCIParam(cptInfo);
    const mipsParam = this.preapreMIPSParam(cptInfo);
    let icdCheckStatus: boolean;
    const param = {
      cciInput: null,
      lcdInput: null,
      mipsInput: null
    };
    if (
      lcdParam.cptCodeEmpty === false &&
      lcdParam.icdCodeEmpty === false &&
      cciParam.cptCodeEmpty === false &&
      mipsParam.cptCodeEmpty === false
    ) {
      if (this.lcdNcdClicked === false) {
        param.lcdInput = lcdParam.lcdInput;
      }
      if (this.cciClicked === false) {
        param.cciInput = cciParam.CCIInputMeasure;
      }
      param.mipsInput = mipsParam.MIPSMeasureInput;
      this._platformService
        .fetchlcdmipsccicheck(param.cciInput, param.lcdInput, param.mipsInput)
        .subscribe(response => {
          if (response) {
            if (
              response.validDetails &&
              (response.validDetails.lcd ||
                response.validDetails.mips ||
                response.validDetails.cci)
            ) {
              if (this.lcdNcdClicked === false) {
                if (
                  response.validDetails &&
                  response.validDetails.lcd &&
                  response.validDetails.lcd.length > 0
                ) {
                  this.updateLCDNCDCol(response.validDetails.lcd);
                  this.lcdNcdClicked = true;
                }
              }
              if (this.cciClicked === false) {
                if (
                  response.validDetails &&
                  response.validDetails.cci &&
                  response.validDetails.cci.length > 0
                ) {
                  this.updateMoidifierCol(response.validDetails.cci);
                  this.cciClicked = true;
                }
              }
              if (response.validDetails.lcd !== null) {
                response.validDetails.lcd.every(function(element, index) {
                  if (
                    element.icdCheckStatus == 'Not Applicable' ||
                    element.icdCheckStatus == 'LCD Passed' ||
                    element.icdCheckStatus == 'NCD Passed'
                  ) {
                    icdCheckStatus = true;
                  } else {
                    icdCheckStatus = false;
                    return false;
                  }
                });
              }
              if (
                response.validDetails.mips === null &&
                response.validDetails.cci === null &&
                icdCheckStatus
              ) {
                setTimeout(() => {
                  this.saveAuditorPlatformData(
                    cptInfo,
                    icdInfo,
                    conflictStatus
                  );
                }, 10); // Donot remove this as this will effect update lcdncd col bug
              } else {
                const dialogRef = this.dialog.open(MipsDialogComponent, {
                  hasBackdrop: true,
                  width: '950px',
                  data: {
                    uniqueId: this.uniqueID,
                    mipsData: response.validDetails.mips,
                    cciData: response.validDetails.cci,
                    lcdData: response.validDetails.lcd
                  },
                  disableClose: true
                });
              }
            } else {
              this.saveAuditorPlatformData(cptInfo, icdInfo, conflictStatus);
            }
          }
        });
    }
  }
  private getValidationMessage(isValidate): string {
    let message: string;
    if (isValidate.icdCodeIsEmpty.length > 0) {
      message = 'Please enter ICD code.';
    } else if (isValidate.cptCodeIsEmpty.length > 0) {
      message = 'Please enter CPT code.';
    } else if (isValidate.cptAccessionEmpty.length > 0) {
      message = 'Please enter CPT Accession Number.';
    }
    return message;
  }
  // get deleted ICD
  public deletedIcd(event) {
    if (event) {
      event.comments = 'wrongly coded ' + event.icdCode;
    }
    let param = this.checkDupDeletedIcd(event);
    if (!param) {
      this.saveDeletedICDObj.push(event);
    }
  }
  checkDupDeletedIcd(event) {
    const data = this.saveDeletedICDObj.filter(res => res.id === event.id);
    if (data.length > 0) {
      return true;
    } else {
      return false;
    }
  }
  public deletedCpt(event) {
    if (event) {
      event.comments = 'wrongly coded ' + event.cptCode;
    }
    this.saveDeletedCPTObj.push(event);
  }
  getDeletedCPTICD(cptInfo, icdInfo) {
    const saveIcdObj = [];
    const saveCptObj = [];
    icdInfo.forEach(element => {
      if (
        element['comments'] !== undefined &&
        element['comments'] === 'new row'
      ) {
        element.comments = 'missed coding ' + element.icdCode;
      }
      saveIcdObj.push(element);
    });
    if (this.saveDeletedICDObj && this.saveDeletedICDObj.length > 0) {
      this.saveDeletedICDObj.forEach(ele => {
        saveIcdObj.push(ele);
      });
    }
    cptInfo.forEach(element => {
      if (
        element['comments'] !== undefined &&
        element['comments'] === 'new row'
      ) {
        element.comments = 'missed coding ' + element.cptCode;
      }
      saveCptObj.push(element);
    });
    if (this.saveDeletedCPTObj && this.saveDeletedCPTObj.length > 0) {
      this.saveDeletedCPTObj.forEach(ele => {
        saveCptObj.push(ele);
      });
    }
    return { saveCpt: saveCptObj, saveIcd: saveIcdObj };
  }
  saveAuditorPlatformData(cptInfo, icdInfo, conflictStatus) {
    const chartData = this.getDeletedCPTICD(cptInfo, icdInfo);
    if (conflictStatus || this.isDiscarded) {
      this.showCommentsDialog(
        chartData['saveCpt'],
        chartData['saveIcd'],
        conflictStatus
      );
    } else {
      const param: any = {
        CPTInfo: chartData['saveCpt'],
        ICDInfo: chartData['saveIcd'],
        UniqueID: this.uniqueID,
        comments: null,
        conflicts: this.icdIsPristines || this.cptIsPristines ? true : false,
        chartStatus: 'audited',
        modality: this.selectedModality
      };
      this._platformService.saveAuditorChartInfo(param).subscribe(
        responseList => {
          if (responseList) {
            // this._toastr.setRootViewContainerRef(this.vcr);
            this.errorService.throwSuccess('Chart saved successfully!');
            this.loadNextChart();
          } else {
            this._toastr.info('Charts not Saved. Try Later');
          }
        },
        error => {
          this.errorService.throwError(error);
        }
      );
    }
  }
  showCommentsDialog(cptInfo, icdInfo, conflictStatus) {
    const dialogRef = this.dialog.open(MatDialogCheckDuplicateComponent, {
      hasBackdrop: true,
      disableClose: true,
      width: '450px',
      data: {
        cptInfo: cptInfo,
        icdInfo: icdInfo,
        UniqueID: this.uniqueID,
        conflict: conflictStatus,
        modality: this.selectedModality,
        chartStatus: 'audited'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        // this._toastr.setRootViewContainerRef(this.vcr);
        this.errorService.throwSuccess('Chart saved successfully!');
        this.loadNextChart();
      }
    });
  }
  partialSave(event, reasonName) {
    const cptInfo = this.fetchCPTRowData;
    const icdInfo = this.fetchICDRowData;
    this.reason = reasonName;
    this._platformService
      .auditorChartService(event, cptInfo, icdInfo, this.platform)
      .subscribe(data => {
        if (data) {
          this.openDialog(data, this.reason, cptInfo, icdInfo);
        }
      });
  }
  openDialog(responseList, reasonName, cptInfo, icdInfo) {
    const dialogRef = this.dialog.open(MatDialogOverviewComponent, {
      hasBackdrop: true,
      disableClose: false,
      width: '450px',
      data: {
        dataList: responseList,
        reason: reasonName,
        uniqueId: this.uniqueID,
        platform: 'auditor',
        cptInfo: cptInfo ? cptInfo : '',
        icdInfo: icdInfo ? icdInfo : '',
        isSaved: false,
        modality: this.selectedModality
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.errorService.throwSuccess(
          'Chart ' + reasonName + 'ed' + ' successfully!'
        );
        this._platformService.fetchdataOnCountSave().subscribe(res => {});
        this.loadNextChart();
      }
    });
  }
  public openDialogForAcknowledge1() {
    if (this.errorFeedBack) {
      this._platformService.getTLFeedBack(this.uniqueID).subscribe(data => {
        if (data) {
          const dialogRef = this.dialog.open(AuditAcknowledgeDialogComponent, {
            hasBackdrop: true,
            width: '1200px',
            data: {
              codingRole: 'auditor',
              uniqueId: this.uniqueID,
              platform: 'auditor',
              status: 'agree',
              cptData: data[0],
              icdData: data[1],
              remarks: this.chartRemarks,
              isProcessed: this.isProccessed,
              hideAckAuditor: this.hideAckAuditor,
              auditorConflict: this.auditorConflict,
              l2auditorConflict: this.l2auditorConflict,
              errorFeedBack: this.errorFeedBack
            },
            disableClose: true
          });
          dialogRef.afterClosed().subscribe(result => {
            if (result) {
              this.errorService.throwSuccess(
                'Chart Acknowledged successfully.'
              );
              this._platformService.fetchdataOnCountSave().subscribe(res => {});
              this.loadNextChart();
            }
          });
        }
      });
    } else {
      this._platformService
        .getAcknowledge1(
          this.uniqueID,
          this.l2auditorConflict,
          this.isDiscarded
        )
        .subscribe(data => {
          if (data) {
            const dialogRef = this.dialog.open(
              AuditAcknowledgeDialogComponent,
              {
                hasBackdrop: true,
                width: '1200px',
                data: {
                  codingRole: 'auditor',
                  uniqueId: this.uniqueID,
                  platform: 'auditor',
                  status: 'agree',
                  cptData: data[0],
                  icdData: data[1], // data[1],
                  remarks: this.chartRemarks,
                  isProcessed: this.isProccessed,
                  hideAckAuditor: this.hideAckAuditor,
                  auditorConflict: this.auditorConflict,
                  l2auditorConflict: this.l2auditorConflict,
                  errorFeedBack: this.errorFeedBack,
                  isDiscarded: this.isDiscarded
                },
                disableClose: true
              }
            );
            dialogRef.afterClosed().subscribe(result => {
              if (result) {
                this._platformService
                  .fetchdataOnCountSave()
                  .subscribe(res => {});
                this.loadNextChart();
              }
            });
          }
        });
    }
  }
  navigateQueue() {
    this._router.navigate(['/index/auditor/queue']);
  }
  // Add ICD New Row on Click
  childEventClickedICD(event: any) {
    this.getSectionSplit(event, 'ICD');
  }
  // Add ICD New Row on Click
  childEventClickedCPT(event: any) {
    this.getSectionSplit(event, 'CPT');
  }
  removeAttr(text) {
    const doc = new DOMParser().parseFromString(text, 'text/html');
    const docArr = doc.getElementsByClassName('highlighted');
    for (let i = 0; i < docArr.length; i++) {
      docArr[i].removeAttribute('data-timestamp');
      docArr[i].removeAttribute('style');
      docArr[i].removeAttribute('data-highlighted');
    }
    return doc;
  }
  getSectionSplit(innerHtml, code) {
    const originalText = this.removeAttr(innerHtml.textInnerHtml);
    const param = {
      uniqueId: this.uniqueID,
      originalText: originalText.body.innerHTML
    };
    this._platformService.sectionSplitService(param).subscribe(data => {
      if (data) {
        let el: any = originalText.body.querySelectorAll('.highlighted');
        el.forEach(element => {
          element.classList.remove('highlighted');
          element.classList.add('htn');
        });
        if (code === 'ICD') {
          this.addICDrowData(
            data,
            innerHtml.highlightedText,
            originalText.body.innerHTML,
            code
          );
        } else {
          this.addCPTrowData(
            data,
            innerHtml.highlightedText,
            originalText.body.innerHTML,
            code
          );
        }
      }
    });
  }
  appendRationale(originalText, sectionArr) {
    sectionArr.forEach(element => {
      const html = '<span class="htb">$&</span>';
      const reg = new RegExp('\\b' + element.section + '\\b', 'i');
      originalText = originalText.replace(reg, html);
    });
    return originalText;
  }
  addICDrowData(event, selectedWord, originalText, code) {
    originalText = this.appendRationale(originalText, event);
    this.isDisabled = true;
    const newIcdRow = {
      id: null,
      icdCode: '',
      aapcDescription: '',
      accessionNo: '',
      icdDescription: selectedWord,
      rationaleData: originalText,
      rationaleSection: event,
      isActive: true,
      lcdStatus: '',
      comments: 'new row'
    };
    this.clickedEventICD = newIcdRow;
  }
  getDxval(event) {
    this.lastCptDxVal = event;
  }
  // Add ICD New Row on Click
  addCPTrowData(event, selectedWord, originalText, code) {
    originalText = this.appendRationale(originalText, event);
    this.isDisabled = true;
    const newCptRow = {
      id: null,
      cptCode: '',
      modifier: '',
      units: '1',
      dxRef: this.lastCptDxVal === undefined ? '1' : this.lastCptDxVal,
      accessionNo: this.accesionNo.split(' ')[0],
      aapcDescription: '',
      cptDescription: selectedWord,
      rationaleData: originalText,
      rationaleSection: event,
      isActive: true,
      comments: 'new row'
    };
    this.clickedEventCPT = newCptRow;
  }
  openModalDialog(uniqueID, display, status) {
    this.dialogRefModal = this.dialog.open(CoderModalChildComponent, {
      hasBackdrop: false,
      width: '1480px',
      panelClass: 'modal-dialog',
      data: {
        uniqueId: this.uniqueID,
        displayName: display,
        disableClose: true,
        status: status
      }
    });
    this.dialogRefModal.afterClosed().subscribe(data => {
    });
  }
  showModal(event) {
    this.display = event;
    this.UID = event.api.getSelectedRows()[0].uniqueId;
    const status = event.api.getSelectedRows()[0].chartStatus;
    this.openModalDialog(this.UID, this.display, status);
  }
  getModalityData(event) {
    this.selectedModality = event;
  }
  // CCI MIPS LCD Validation functions
  public prepareLCDParam(cptInfo, icdInfo) {
    let cptCodeEmpty = false;
    let icdCodeEmpty = false;
    let CPTCodes = '';
    let ICDCodes = '';
    const lcdInput = {
      uniqueId: this.uniqueID,
      cptInput: '',
      icdInput: ''
    };
    cptInfo.forEach((element, index) => {
      if (element.cptCode) {
        if (index > 0) {
          CPTCodes = lcdInput.cptInput.concat(CPTCodes, '~');
        }
        const cptCode = element.cptCode + '*' + element.dxRef;
        CPTCodes = lcdInput.cptInput.concat(CPTCodes, cptCode.trim());
      } else {
        cptCodeEmpty = true;
        this._toastr.warning('Please enter CPT Code for LCD/NCD check');
      }
    });
    icdInfo.forEach((element, index) => {
      if (element.icdCode) {
        if (index > 0) {
          ICDCodes = lcdInput.icdInput.concat(ICDCodes, '~');
        }
        ICDCodes = lcdInput.icdInput.concat(ICDCodes, element.icdCode.trim());
      } else {
        icdCodeEmpty = true;
        this._toastr.warning('Please enter ICD Code for LCD/NCD check');
      }
    });
    lcdInput.cptInput = CPTCodes;
    lcdInput.icdInput = ICDCodes;
    return { lcdInput, cptCodeEmpty, icdCodeEmpty };
  }
  public preapreMIPSParam(cptInfo) {
    let cptCodeEmpty = false;
    const MIPSMeasureInput = {
      cptcode: '',
      uniqueId: this.uniqueID
    };
    let CPTCodes = '';
    if (cptInfo && cptInfo.length) {
      cptInfo.forEach((element, index) => {
        if (element.cptCode) {
          if (index > 0) {
            CPTCodes = MIPSMeasureInput.cptcode.concat(CPTCodes, '~');
          }
          CPTCodes = MIPSMeasureInput.cptcode.concat(
            CPTCodes,
            element.cptCode.trim()
          );
        } else {
          cptCodeEmpty = true;
          this._toastr.warning('Please enter CPT Code for MIPS Measure');
        }
      });
    }
    MIPSMeasureInput.cptcode = CPTCodes;
    return { MIPSMeasureInput, cptCodeEmpty };
  }
  public prepareCCIParam(cptInfo) {
    let cptCodeEmpty = false;
    const CCIInputMeasure = {
      cptMod: '',
      currentChartID: this.uniqueID
    };
    let CPTCodes = '';
    if (cptInfo && cptInfo.length) {
      cptInfo.forEach((element, index) => {
        if (element.cptCode) {
          if (index > 0) {
            CPTCodes = CCIInputMeasure.cptMod.concat(CPTCodes, '~');
          }
          CPTCodes = CCIInputMeasure.cptMod.concat(
            CPTCodes,
            element.cptCode.trim()
          );
          CPTCodes = CCIInputMeasure.cptMod.concat(CPTCodes, '*');
          CPTCodes = element.modifier
            ? CCIInputMeasure.cptMod.concat(CPTCodes, element.modifier)
            : CCIInputMeasure.cptMod.concat(CPTCodes, '');
        } else {
          cptCodeEmpty = true;
          this._toastr.warning('Please enter CPT Code for CCI Modifier');
        }
      });
    }
    CCIInputMeasure.cptMod = CPTCodes;
    return { CCIInputMeasure, cptCodeEmpty };
  }
  private updateLCDNCDCol(lcdDetails) {
    const param = [];
    lcdDetails.forEach(element => {
      param.push({
        lcdStatus: element.icdCheckStatus,
        icdCode: element.icdCode
      });
    });
    const x = {
      status: param,
      colName: 'predictIcdCode'
    };
    this.lcdCheckStatus = x;
  }
  private updateMoidifierCol(response) {
    const param = [];
    let message = false;
    response.forEach(element => {
      param.push({
        modifier: element.cciModifier,
        cptcode: element.cpt
      });
      if (element.cciModifier === 'Not Applicable') {
        message = true;
      }
      const x = {
        modifier: param,
        colName: 'predictIcdCode'
      };
      this.cciCheck = x;
    });
    return message;
  }
  public lcdCheck(event) {
    event.stopPropagation();
    this.lcdNcdClicked = true;
    const cptInfo = this.fetchCPTRowData;
    const icdInfo = this.fetchICDRowData;
    const isValidate = this._lookupDataService.validateBlankRecordCoder(
      cptInfo,
      icdInfo
    );
    if (
      isValidate.icdCodeIsEmpty.length === 0 &&
      isValidate.cptCodeIsEmpty.length === 0
    ) {
      const inputParam = this.prepareLCDParam(cptInfo, icdInfo);
      if (
        inputParam.cptCodeEmpty === false &&
        inputParam.icdCodeEmpty === false
      ) {
        this._platformService
          .fetchlcdmipsccicheck(null, inputParam.lcdInput, null)
          .subscribe(res => {
            if (res) {
              if (res.validDetails && res.validDetails.lcd.length > 0) {
                this.updateLCDNCDCol(res.validDetails.lcd);
                this._toastr.success('LCD status updated.');
              }
            }
          });
      }
    } else {
      const msg = this.getValidationMessage(isValidate);
      this._toastr.warning(msg);
    }
  }
  public getCCIModifier(event) {
    event.stopPropagation();
    this.cciClicked = true;
    const cptInfo = this.fetchCPTRowData;
    const inputParam = this.prepareCCIParam(cptInfo);
    if (!inputParam.cptCodeEmpty) {
      let msg;
      this._platformService
        .fetchlcdmipsccicheck(inputParam.CCIInputMeasure, null, null)
        .subscribe(response => {
          if (response) {
            if (
              response.validDetails &&
              response.validDetails.cci &&
              response.validDetails.cci.length > 0
            ) {
              msg = this.updateMoidifierCol(response.validDetails.cci);
              this._toastr.success('Modifier updated.');
            } else {
              msg = true;
            }
          }
          if (msg) {
            this._toastr.info('CCI modifier is not applicable');
          }
        });
    }
  }
  public getMIPSMeasure(event) {
    event.stopPropagation();
    this.pqrsMipsClicked = true;
    const cptInfo = this.fetchCPTRowData;
    const inputParam = this.preapreMIPSParam(cptInfo);
    if (!inputParam.cptCodeEmpty) {
      this._platformService
        .fetchlcdmipsccicheck(null, null, inputParam.MIPSMeasureInput)
        .subscribe(response => {
          if (response) {
            if (
              response.validDetails &&
              response.validDetails.mips &&
              response.validDetails.mips.length > 0
            ) {
              const dialogRef = this.dialog.open(MipsDialogComponent, {
                hasBackdrop: true,
                width: '950px',
                data: {
                  uniqueId: this.uniqueID,
                  mipsData: response.validDetails.mips
                },
                disableClose: true
              });
            } else {
              this._toastr.info('MIPS not applicable.');
            }
          }
        });
    }
  }
}
