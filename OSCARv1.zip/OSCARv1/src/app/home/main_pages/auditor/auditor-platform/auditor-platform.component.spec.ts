import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AuditorPlatformComponent } from './auditor-platform.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatIconModule,
  MatInputModule,
  MatFormFieldModule,
  MatAutocompleteModule,
  MatExpansionModule,
  MatDialogModule
} from '@angular/material';
import { AgGridModule, BaseComponentFactory } from 'ag-grid-angular';
import { ContextMenuModule, ContextMenuService } from 'ngx-contextmenu';
import { HttpModule, Http } from '@angular/http';
import { DatePipe } from '@angular/common';
import { ToastsManager } from 'ng2-toastr';
import { ToastOptions } from 'ng2-toastr';
import { RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { FlexLayoutModule } from '@angular/flex-layout';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA, ViewContainerRef } from '@angular/core';
import * as params from 'assets/testMockData/paramsAuditorPlatform.json';
import { of } from 'rxjs/observable/of';
import { NgProgressModule } from 'ngx-progressbar';
import { RelatedVisitComponent } from '../../oscar-shared/related-visit/related-visit.component';
import { IcdInfoComponent } from '../../oscar-shared/icd-info/icd-info.component';
import { CptInfoComponent } from '../../oscar-shared/cpt-info/cpt-info.component';
import { PateintMedicalReportComponent } from '../../oscar-shared/pateint-medical-report/pateint-medical-report.component';
import { PateintInfoComponent } from '../../oscar-shared/pateint-info/pateint-info.component';
import { RecordInfoComponent } from '../../oscar-shared/record-info/record-info.component';
import { HighlightSearch } from '../../../../imports/pipes/highlights.pipe';
import { LookupDataService } from '../../../../_shared-services/unrelated-data-services/lookup-data.service';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
import { HeaderAuthenticationToken } from '../../../../auth/authetication-header';
import { DateFormatter } from '../../../../imports/_utilities/date-formatter';
import { TlService } from '../../team-lead/team-lead.component.service';
import { CommonCodeService } from '../../../../_shared-services/common-code.services';
import { SpilitFilePathPipe } from '../../../../imports/pipes/splitFilePath.pipe';
import { QueueService } from '../../../../services/main-pages/queue.service';
import { PlatformService } from '../../../../services/main-pages/paltform-services/platform-service.service';

describe('AuditorPlatformComponent', () => {
  let component: AuditorPlatformComponent;
  let fixture: ComponentFixture<AuditorPlatformComponent>;
  let elementRefference;
  let toastsManager;
  let viewContainerRef;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AuditorPlatformComponent,
        RelatedVisitComponent,
        IcdInfoComponent,
        CptInfoComponent,
        PateintMedicalReportComponent,
        PateintInfoComponent,
        RecordInfoComponent,
        HighlightSearch,
        SpilitFilePathPipe
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        HttpModule,
        MatButtonModule,
        MatIconModule,
        MatInputModule,
        MatFormFieldModule,
        MatAutocompleteModule,
        FormsModule,
        ReactiveFormsModule,
        MatExpansionModule,
        AgGridModule,
        ContextMenuModule,
        RouterModule,
        RouterTestingModule,
        MatDialogModule,
        FlexLayoutModule,
        HttpClientTestingModule,
        BrowserAnimationsModule,
        NgProgressModule
      ],
      providers: [
        PlatformService,
        LookupDataService,
        QueueService,
        ErrorHandlingServices,
        HeaderAuthenticationToken,
        DateFormatter,
        DatePipe,
        ToastsManager,
        ToastOptions,
        BaseComponentFactory,
        ContextMenuService,
        HeaderAuthenticationToken,
        TlService,
        ViewContainerRef,
        CommonCodeService
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AuditorPlatformComponent);
    component = fixture.componentInstance;
    elementRefference = fixture.debugElement;
    toastsManager = TestBed.get(ToastsManager);
    viewContainerRef = TestBed.get(ViewContainerRef);
    // fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('hide #saveBtn on FeedBack Chart', () => {
    component.auditorFeedback = true;
    fixture.detectChanges();
    expect(
      elementRefference.nativeElement.querySelector('#saveBtn')
    ).toBeNull();
  });

  it('visible #saveBtn on FeedBack Chart', () => {
    component.auditorFeedback = false;
    fixture.detectChanges();
    expect(
      elementRefference.nativeElement.querySelector('#saveBtn').hidden
    ).toBeFalsy();
  });

  // it('disable #saveBtn on fetchICDRowData or fetchCPTRowData with no data', () => {
  //   component.fetchCPTRowData = [];
  //   component.fetchICDRowData = [];
  //   component.auditorFeedback = false;
  //   fixture.detectChanges();
  //   expect(
  //     elementRefference.nativeElement.querySelector('#saveBtn').disabled
  //   ).toBeTruthy();
  // });

  it('On #saveAuditorChart() function call', () => {
    component.isDisabled = true;
    component.icdIsPristines = false;
    component.cptIsPristines = false;
    component.fetchCPTRowData = params['fetchCPTRowData'];
    component.fetchICDRowData = params['fetchICDRowData'];
    component.uniqueID = params['uniqueID'];
    component.selectedModality = 'XR';
    fixture.detectChanges();
    spyOn(
      component._lookupDataService,
      'cptDxRefValidationCheck'
    ).and.returnValue({
      code: 1,
      msg: 'All dxRef value are correct'
    });
    expect(
      component._lookupDataService.cptDxRefValidationCheck(
        component.fetchCPTRowData
      )
    ).toEqual({
      code: 1,
      msg: 'All dxRef value are correct'
    });

    spyOn(
      component._lookupDataService,
      'validateBlankRecordCoder'
    ).and.returnValue({
      cptCodeIsEmpty: [],
      icdCodeIsEmpty: [],
      cptAccessionEmpty: []
    });
    expect(
      component._lookupDataService.validateBlankRecordCoder(
        component.fetchCPTRowData,
        component.fetchICDRowData
      )
    ).toEqual({
      cptCodeIsEmpty: [],
      icdCodeIsEmpty: [],
      cptAccessionEmpty: []
    });

    const conflict =
      component.icdIsPristines || component.cptIsPristines ? true : false;
    fixture.detectChanges();

    spyOn(component, 'checkForLcdCciMipsValidation');
    component.checkForLcdCciMipsValidation(
      conflict
    );
    expect(component.checkForLcdCciMipsValidation).toHaveBeenCalled();
  });

  it('#checkForLcdCciMipsValidation() function', () => {
    const lcdncd = params['lcdParam']; // {'uniqueId': 'M002049717~4105975001~2016-02-05 00:00:00.0', 'cptInput': '73700*1~10180*1', 'icdInput': 'S82.102A'};
    const cci = params['cciParam'];
    const mips = params['mipsParam'];
    component.uniqueID = params['uniqueID'];
    component.selectedModality = 'XR';
    component.icdIsPristines = false;
    component.cptIsPristines = false;
    component.fetchCPTRowData = params['fetchCPTRowData'];
    component.fetchICDRowData = params['fetchICDRowData'];
    const conflictStatus = false;
    fixture.detectChanges();

    spyOn(component, 'prepareLCDParam').and.returnValue(lcdncd);
    expect(
      component.prepareLCDParam(
        component.fetchCPTRowData,
        component.fetchICDRowData
      )
    ).toEqual(lcdncd);

    spyOn(component, 'prepareCCIParam').and.returnValue(cci);
    expect(component.prepareCCIParam(component.fetchCPTRowData)).toEqual(cci);

    spyOn(component, 'preapreMIPSParam').and.returnValue(mips);
    expect(component.preapreMIPSParam(component.fetchCPTRowData)).toEqual(mips);

    const param = params['param'];
    const lcdParam = param['lcdInput'];
    const cciParam = param['cciInput'];
    const mipsParam = param['mipsInput'];

    expect(lcdParam.cptCodeEmpty).toBeFalsy();
    expect(lcdParam.icdCodeEmpty).toBeFalsy();
    expect(cciParam.cptCodeEmpty).toBeFalsy();
    expect(lcdParam.cptCodeEmpty).toBeFalsy();

    spyOn(component._platformService, 'fetchlcdmipsccicheck').and.returnValue(
      of({ response: params['fetchlcdparam'] })
    );
    const icdCheckStatus = true;
    component._platformService
      .fetchlcdmipsccicheck(param.cciInput, param.lcdInput, param.mipsInput)
      .subscribe(response => {
        expect(response).toEqual({
          response: { validDetails: { cci: null, mips: null, lcd: null } }
        });
        const val = response;
        expect(response.response.validDetails.mips).toEqual(null);
        expect(response.response.validDetails.cci).toEqual(null);
        expect(icdCheckStatus).toBeTruthy();

        spyOn(component, 'saveAuditorPlatformData');
        component.saveAuditorPlatformData(
          component.fetchCPTRowData,
          component.fetchICDRowData,
          conflictStatus
        );
        expect(component.saveAuditorPlatformData).toHaveBeenCalled();
      });
  });

  it('#saveAuditorPlatformData() should be called when checkForlcdCciMipsValidation validations are done', () => {
    component.uniqueID = params['uniqueID'];
    component.selectedModality = 'XR';
    component.icdIsPristines = false;
    component.cptIsPristines = false;
    component.fetchCPTRowData = params['fetchCPTRowData'];
    component.fetchICDRowData = params['fetchICDRowData'];

    fixture.detectChanges();

    const param: any = {
      CPTInfo: component.fetchCPTRowData,
      ICDInfo: component.fetchICDRowData,
      UniqueID: component.uniqueID,
      comments: null,
      conflicts:
        component.icdIsPristines || component.cptIsPristines ? true : false,
      chartStatus: 'audited',
      modality: 'XR'
    };
    spyOn(component._platformService, 'saveAuditorChartInfo').and.returnValue(
      of({ response: 1 })
    );
    component._platformService
      .saveAuditorChartInfo(param)
      .subscribe(responseList => {
        expect(responseList).toEqual({ response: 1 });
        spyOn(component, 'loadNextChart');
        component.loadNextChart();
        expect(component.loadNextChart).toHaveBeenCalled();
      });
  });
});
