import { Component, OnInit, ViewChild } from '@angular/core';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import * as CryptoJS from 'crypto-js';
import { environment } from '../../../../../environments/environment';
import { LocationStrategy } from '@angular/common';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
import { QueueService } from '../../../../services/main-pages/queue.service';

@Component({
  selector: 'app-auditor-queue',
  templateUrl: './auditor-queue.component.html',
  styleUrls: ['./auditor-queue.component.scss']
})
export class AuditorQueueComponent implements OnInit {
  public panelOpenState: boolean = true;
  public platformType: string = '';
  public customCollapsedHeight: string = '40px';
  public customExpandedHeight: string = '55px';
  public username: string;
  userRole: any;
  facilityOptionList: any;
  public storage: Storage = environment.storage;
  modalityOptionList: string[] = [];
  clientSelectionObj: any;
  auditorPriority = false;
  auditorRegular = false;
  auditorFeedback = false;
  auditorWorkQueueRequest: any = [];
  priorityQueueRequest: any;
  feedbackQueueRequest: any;
  activetab = '';
  tabSelecetdIndex: number;
  userSubRole = 'auditor';
  public auditorQueueForm: FormGroup;
  @ViewChild('filters') filters;
  public height = 77;
  constructor(
    private _coderQueueService: QueueService,
    public _toastr: ToastsManager,
    private errorService: ErrorHandlingServices,
    private location: LocationStrategy,
    private formBuilder: FormBuilder
  ) {
    this.intializeAuditorQueueForm();
    this.username = this.storage.getItem('UserName');
    const clientSelectionObj = this.storage.getItem('clientSelectionObject');
    this.clientSelectionObj = JSON.parse(
      CryptoJS.AES.decrypt(clientSelectionObj, 'oscar').toString(
        CryptoJS.enc.Utf8
      )
    );
    this.facilityOptionList = JSON.parse(this.storage.getItem('facilityList'));
    /* preventing back button in browser implemented by 'Samba Siva'  */
    history.pushState(null, null, window.location.href);
    this.location.onPopState(() => {
      history.pushState(null, null, window.location.href);
      console.clear();
    });
    /* preventing back button END */
    this.formControlChanges();
  }
  toggleFilter(event){
    if (event === 'block'){
      this.height = 68;
    } else{
      this.height = 77;
    }
  }
  formControlChanges() {
    this.auditorQueueForm.controls.facility.valueChanges.subscribe(val => {
      this.selectedFacilityModalityList(val);
    });
  }
  public selectedFacilityModalityList(data) {
    data = data.filter(function(element) {
      return element !== undefined;
    });
    if (data.length === 0) {
      this.auditorQueueForm.controls.modality.setValue([]);
      this.modalityOptionList = [];
    } else {
      this.modalityOptionList.length = 0;
      const selectedModalityList = this.auditorQueueForm.controls.modality.value
        ? this.auditorQueueForm.controls.modality.value
        : [];
      const list = [];
      data.forEach(function(value) {
        if (value.modality !== 'undefined') {
          value.modality.forEach(function(value1) {
            const dataexists = list.filter(eleme => eleme.name === value1);
            if (dataexists.length === 0) {
              const elem = { name: value1, value: value1 };
              list.push(elem);
            }
          });
        }
      });
      this.modalityOptionList = list;
      this.auditorQueueForm.controls.modality.patchValue(list);
    }
  }
  public intializeAuditorQueueForm() {
    this.auditorQueueForm = this.formBuilder.group({
      facility: new FormControl([]),
      modality: new FormControl([]),
      icdCode: new FormControl(''),
      cptCode: new FormControl('')
    });
  }
  prepareParams() {
    return {
      facility: this.auditorQueueForm.controls.facility.value
        ? this.auditorQueueForm.controls.facility.value.map(eleme => {
            return eleme.name;
          })
        : [],
      modality: this.auditorQueueForm.controls.modality.value
        ? this.auditorQueueForm.controls.modality.value.map(eleme => {
            return eleme.name;
          })
        : [],
      role: this.clientSelectionObj.workRole.role
        ? this.clientSelectionObj.workRole.role
        : '',
      icdCode: this.auditorQueueForm.controls.icdCode.value,
      cptCode: this.auditorQueueForm.controls.cptCode.value,
      userId: this.storage.getItem('UserName'),
      teamLeadId: this.storage.getItem('TLId'),
      location: this.clientSelectionObj.location,
      userConfiguration: this.clientSelectionObj.clientConfiguration,
      userType: this.clientSelectionObj.clientType,
      doj: this.clientSelectionObj.clientDOJ,
      speciality: this.clientSelectionObj.specialty,
      client: this.clientSelectionObj.client,
      adminSubRole: this.userSubRole,
      targetsampling:
        this.storage.getItem('targetSampling') === 'null'
          ? null
          : JSON.parse(this.storage.getItem('targetSampling'))
    };
  }
  public getQueue() {
    const params = this.prepareParams();
    const serviceType =
      this.auditorQueueForm.controls.icdCode.value ||
      this.auditorQueueForm.controls.cptCode.value
        ? 'APIComposition'
        : 'searchChartInfo';
    this.feedbackQueueRequest = [];
    this._coderQueueService
      .fetchAuditorQueue(params, serviceType, 'feedback')
      .subscribe(response => {
        if (response && response.length > 0) {
          const audAckData = response.filter(element => element.isAck == true);
          if (audAckData.length > 0) {
            this.platformType = 'updateauditorstartedon';
            this.storage.setItem('osc-aud-ack', 'true');
            this.storage.setItem('osc-coder-pri', 'false');
            this.storage.setItem('osc-aud-reg', 'false');
            this.auditorFeedback = true;
            this.auditorPriority = false;
            this.auditorRegular = false;
            this.tabSelecetdIndex = 0;
            this.feedbackQueueRequest = audAckData;
          } else {
            const priorityData = response.filter(
              element => element.priority == true
            );
            if (priorityData.length > 0) {
              this.platformType = 'updateauditorstartedon';
              this.storage.setItem('osc-aud-ack', 'false');
              this.storage.setItem('osc-coder-pri', 'true');
              this.storage.setItem('osc-aud-reg', 'false');
              this.auditorFeedback = false;
              this.auditorPriority = true;
              this.auditorRegular = false;
              this.tabSelecetdIndex = 1;
              this.priorityQueueRequest = priorityData;
            } else {
              const workQueueData = response.filter(
                element => element.isAck == false && element.priority == false
              );
              if (workQueueData.length > 0) {
                this.storage.setItem('osc-aud-ack', 'false');
                this.storage.setItem('osc-coder-pri', 'false');
                this.storage.setItem('osc-aud-reg', 'true');
                this.auditorPriority = false;
                this.auditorFeedback = false;
                this.auditorRegular = true;
                this.tabSelecetdIndex = 2;
                this.auditorWorkQueueRequest = response;
                this.platformType = 'updateauditorstartedon';
              } else {
                this.auditorPriority = false;
                this.auditorFeedback = false;
                this.auditorRegular = true;
                this.tabSelecetdIndex = 2;
              }
            }
          }
        } else {
          this.auditorPriority = false;
          this.auditorFeedback = false;
          this.auditorRegular = true;
          this.tabSelecetdIndex = 2;
        }
      });
  }
  public ngOnInit(): void {
    this.getQueue();
  }
  tabClick(event): void {
    if (event) {
      this.activetab = event.tab.textLabel;
      window.dispatchEvent(new Event('resize'));
    }
  }
}
