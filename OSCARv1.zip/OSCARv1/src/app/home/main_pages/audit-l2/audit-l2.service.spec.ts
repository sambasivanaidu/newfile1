// import { TestBed, inject } from '@angular/core/testing';

// import { AuditL2Service } from './audit-l2.service';

// describe('AuditL2Service', () => {
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       providers: [AuditL2Service]
//     });
//   });

//   it('should be created', inject([AuditL2Service], (service: AuditL2Service) => {
//     expect(service).toBeTruthy();
//   }));
// });
