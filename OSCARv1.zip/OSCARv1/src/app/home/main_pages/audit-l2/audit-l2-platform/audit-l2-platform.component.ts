import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog, MatDialogRef } from '@angular/material';
import 'rxjs/add/operator/map';
import { MatDialogOverviewComponent } from '../../../../imports/_utilities/mat-dialog-overview/mat-dialog-overview.component';
import { MatDialogFeedbackComponent } from '../../../../imports/_utilities/mat-dialog-feedback/mat-dialog-feedback.component';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { MatDialogCheckDuplicateComponent } from '../../../../imports/_utilities/mat-dialog-check-duplicate/mat-dialog-check-duplicate.component';
import { LookupDataService } from '../../../../_shared-services/unrelated-data-services/lookup-data.service';
import { environment } from '../../../../../environments/environment';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
import { MipsDialogComponent } from '../../../../imports/_utilities/mips-dialog/mips-dialog.component';
import * as CryptoJS from 'crypto-js';
import { AuditL2Service } from '../audit-l2.service';
import { DateFormatter } from '../../../../imports/_utilities/date-formatter';
import { DomSanitizer } from '@angular/platform-browser';
import { LocationStrategy } from '@angular/common';
import { NgProgress } from 'ngx-progressbar';
import { CoderModalChildComponent } from '../../oscar-shared/coder-modal-child/coder-modal-child.component';
import { CommonCodeService } from '../../../../_shared-services/common-code.services';
import { PlatformService } from '../../../../services/main-pages/paltform-services/platform-service.service';
@Component({
  selector: 'app-audit-l2-platform',
  templateUrl: './audit-l2-platform.component.html',
  styleUrls: ['./audit-l2-platform.component.scss'],
  providers: [
    LookupDataService,
    AuditL2Service,
    DateFormatter
  ]
})
export class AuditL2PlatformComponent implements OnInit {
  uniqueID = '';
  customCollapsedHeight: string = '35px';
  customExpandedHeight: string = '30px';
  platform: string = 'auditor';
  patientChart: any;
  patientInfoParent: any;
  patientRecordInfoParent: any;
  ICDInfoRequest: any;
  CPTInfoRequest: any;
  icdIsPristines: boolean = false;
  cptIsPristines: boolean = false;
  public storage: Storage = environment.storage;
  public clickedEventICD: any;
  public clickedEventCPT: any;
  public patientName;
  public dateOfService;
  public isDisabled: boolean;
  public isIcdValidated: boolean;
  public isCptValidated: boolean;
  public reason = '';
  public lookUpOption;
  public relatedVisitParentData: any;
  public MRN;
  public fetchICDRowData: any = [];
  public fetchCPTRowData: any = [];
  dialogRefModal: MatDialogRef<any>;
  public display: boolean = false;
  public UID;
  public selectedModality;
  public selectedFacility;
  public searchTerm: any;
  public lcdCheckStatus;
  disableMIPS: boolean;
  facility: string;
  disableLCD: boolean;
  disableCCI: boolean;
  public cciCheck: any;
  public validateCptInfo = [];
  public validateIcdInfo = [];
  public chartInfoParam: any;
  public serviceFor: any;
  isProcessed: boolean;
  lcdNcdClicked = false;
  cciClicked = false;
  pqrsMipsClicked = false;
  auditorAllocatedTo = '';
  fileURL: any;
  displayPdf: any = 'none';
  zoom: any = 1;
  lineHeight: any = 1.5;
  public patientInfoGender: string;
  public patientInfoFacility: string;
  public dateOfBirth: any;
  public saveDeletedICDObj = [];
  public saveDeletedCPTObj = [];
  lastCptDxVal: any;
  public lookupGuidePath = null;
  lastAccessionVal: any;
  urlParameters: any;
  public auditorAllocated = null;
  public coderAllocated = null;
  accesionNo: any;
  public getAccessionval: any;
  public isDiscarded = false;
  cptSectionHeight: any;
  icdSectionHeight: any;
  height: number = 750;
  relatedVisit: boolean = false;
  panelOpenState: boolean = true;
  constructor(
    private _platformService: PlatformService,
    private _router: Router,
    public _toastr: ToastsManager,
    public dialog: MatDialog,
    private ngProgress: NgProgress,
    private _lookupDataService: LookupDataService,
    private errorService: ErrorHandlingServices,
    private audiorL2Service: AuditL2Service,
    private _dateFormatter: DateFormatter,
    public sanitzer: DomSanitizer,
    public location: LocationStrategy,
    private _commonCode: CommonCodeService
  ) {
    this.getPlatformParam();
    this._router.routeReuseStrategy.shouldReuseRoute = function() {
      return false;
    };
    /* preventing back button in browser implemented by 'Samba Siva'  */
    history.pushState(null, null, window.location.href);
    this.location.onPopState(() => {
      history.pushState(null, null, window.location.href);
      setTimeout(() => {
        console.clear();
      }, 100);
      const previousChart: any = sessionStorage.getItem('previousChart');
      this._router.navigate(['index/coderPlatform', previousChart]);
      setTimeout(() => {
        console.clear();
      }, 100);
    });
    /* preventing back button END */
  }
  ZoomIn(event) {
    event.stopPropagation();
    this.zoom = this.zoom + 0.1;
    this.lineHeight = this.lineHeight + 0.1;
  }
  zoomOut(event) {
    event.stopPropagation();
    this.zoom = this.zoom - 0.1;
    this.lineHeight = this.lineHeight - 0.1;
  }
  zoomReset(event) {
    event.stopPropagation();
    this.zoom = 'normal';
    this.zoom = 1;
    this.lineHeight = 'inherit';
    this.lineHeight = 1.5;
  }
  getPlatformParam() {
    this.urlParameters = JSON.parse(
      CryptoJS.AES.decrypt(
        localStorage.getItem('urlParameters'),
        'oscar'
      ).toString(CryptoJS.enc.Utf8)
    );
    if (this.urlParameters !== undefined) {
      this.uniqueID = this.urlParameters.uniqueId;
      this.facility = this.urlParameters.facilityId
        ? this.urlParameters.facilityId
        : '';
      this.MRN = this.urlParameters.mrn;
      this.isProcessed = this.urlParameters.isProcessed;
      this.auditorAllocatedTo = this.urlParameters.auditorAllocatedTo;
    }
    /* URL Sortening END*/
    this.getMIPSDisableCheck();
  }
  ngOnInit() {
    this.urlParameters = JSON.parse(
      CryptoJS.AES.decrypt(
        localStorage.getItem('urlParameters'),
        'oscar'
      ).toString(CryptoJS.enc.Utf8)
    );
    if (this.urlParameters !== undefined) {
      this.uniqueID = this.urlParameters.uniqueId;
    }
    this.initPlatformFunction();
  }
  openpdf(): void {
    if (this.lookupGuidePath) {
      this._platformService
        .fetchPdfFileData(this.lookupGuidePath)
        .subscribe(res => {
          this.fileURL = URL.createObjectURL(res);
          this.fileURL = this.sanitzer.bypassSecurityTrustResourceUrl(
            this.fileURL
          );
        });
      this.displayPdf = 'block';
    }
  }
  onCloseHandled(): void {
    this.displayPdf = 'none';
  }
  setHeight(functionName) {
    if (functionName === 'setCptHeight') {
      this.cptSectionHeight = this._commonCode.setCptHeight();
    } else if (functionName === 'setIcdHeight') {
      this.icdSectionHeight = this._commonCode.setIcdHeight();
    } else if (functionName === 'setMedicalReportHeight') {
      this.height = this._commonCode.setMedicalReportHeight(
        '',
        this.relatedVisit
      );
    } else if (functionName === 'pateintrecordinfoheight') {
      this.cptSectionHeight = this._commonCode.pateintRecordInfoHeight();
      this.icdSectionHeight = this.cptSectionHeight;
    }
  }
  public myMethodChangingQueryParams(param) {
    this.MRN = param.mrn;
    const params = {
      uniqueId: param.uniqueId,
      facilityId: param.facilityId,
      mrn: param.mrn,
      isProcessed: param.isProcessed,
      auditorAllocatedTo: param.auditorAllocatedTo
    };
    this.urlParameters = CryptoJS.AES.encrypt(
      JSON.stringify(params),
      'oscar'
    ).toString();
    localStorage.setItem('urlParameters', this.urlParameters);
    /* URL Sortening END*/
    this._router.navigate(
      [
        'index/L2auditor/platform',
        {
          uniqueID: param.uniqueId,
          facility: param.facilityId,
          isProcessed: param.isProcessed,
          auditorAllocatedTo: param.auditorAllocatedTo
        }
      ],
      { skipLocationChange: true }
    );
  }
  getNextChart() {
    const clientObj = this._commonCode.get_ConfidenceColor_Clientselection(
      'clientSelectionObject'
    );
    const param = {
      role: clientObj.workRole.role,
      l2AllocationInput: {
        fromDate: this._dateFormatter.getDatetime(Date.now()),
        toDate: this._dateFormatter.getDatetime(Date.now()),
        facilityName: [],
        batchId: '',
        modality: [],
        patientName: '',
        physicianName: '',
        mrn: '',
        accessionNo: '',
        icdCode: '',
        cptCode: '',
        location: []
      }
    };
    this.audiorL2Service.fetchAudtorL2Queue(param).subscribe(
      response => {
        if (response && !response.apierror && response.length > 0) {
          this.myMethodChangingQueryParams(response[0]);
        } else {
          this._router.navigate(['/index/L2auditor/queue']); //
        }
      },
      error => {
        this.errorService.throwError(error);
      }
    );
  }
  initPlatformFunction() {
    this.fetchPatientChart();
    this.fetchPatientInfo();
    this.fetchPatientRecordInfo();
    this.fetchRemarks();
  }
  fetchRemarks() {
    this._platformService
      .searchByUniqueID(this.uniqueID)
      .subscribe(response => {
        if (response) {
          this.isDiscarded = response.chartReasonCode ? true : false;
          this.auditorAllocated = response.auditorAllocatedTo;
          this.coderAllocated = response.coderAllocatedTo;
          this.fetchPredictedICDInfo();
          this.fetchPredictedCPTInfo();
          if (response.accessionNo) {
            this.accesionNo = response.accessionNo;
          }
        }
      });
  }
  getMIPSDisableCheck() {
    this._platformService
      .fetchMIPSDisableCheck(this.facility)
      .subscribe(response => {
        this.disableMIPS = response.pqrsMipsEnabled;
        this.disableCCI = response.ccienabled;
        this.disableLCD = response.lcdenabled;
        this.lookupGuidePath = response.lookupguidepath
          ? response.lookupguidepath
          : null;
      });
  }
  doFilter(param) {
    if (param) {
      this._lookupDataService.getLookUpData(param).subscribe(data => {
        if (data) {
          this.lookUpOption = data;
        }
      });
    }
  }
  // For Patient Medical Report
  fetchPatientChart() {
    this.patientChart = [];
    this._platformService
      .fetchPatientChart(this.uniqueID)
      .subscribe((data: any) => {
        if (data) {
          this.patientChart = data.observationValue;
        }
      });
  }
  // For Pateint Informtation
  fetchPatientInfo() {
    this._platformService.fetchPatientInfo(this.uniqueID).subscribe(data => {
      if (data) {
        this.patientInfoParent = data;
        let firstname = data['First name'];
        const lastChar = data['First name'].charAt(
          data['First name'].length - 1
        );
        firstname = lastChar === ' ' ? firstname.trim() : firstname;
        this.patientName = data['Last name'] + ' ' + firstname;
        this.dateOfService = data['DOS'];
        this.dateOfBirth = data['DOB'];
        this.patientInfoGender = data['Gender'];
      }
    });
  }
  // For Record Information
  fetchPatientRecordInfo() {
    this._platformService
      .fetchPatientRecordInfo(this.uniqueID)
      .subscribe((data: any) => {
        if (data) {
          this.patientRecordInfoParent = data;
          this.selectedModality = data.Modality;
          this.selectedFacility = data['Facility name'];
          this.patientInfoFacility = data['Facility name'];
          if (this.selectedModality && this.dateOfService) {
            this.fetchRelatedVisit();
          }
        }
      });
  }
  // For ICD 10 - CM
  fetchPredictedICDInfo() {
    this.ICDInfoRequest = [];
    const params = {
      uniqueId: this.uniqueID,
      codedBy: this.auditorAllocated
        ? 'auditor'
        : this.coderAllocated
        ? 'coder'
        : null
    };
    this._platformService
      .auditL2fetchICDInfo(params, this.platform)
      .subscribe((data: any) => {
        if (data && data.length > 0) {
          this.ICDInfoRequest = data;
        }
      });
  }
  // For CPT - CM
  fetchPredictedCPTInfo() {
    this.CPTInfoRequest = [];
    const params = {
      uniqueId: this.uniqueID,
      codedBy: this.auditorAllocated
        ? 'auditor'
        : this.coderAllocated
        ? 'coder'
        : null
    };
    this._platformService
      .auditL2fetchCPTInfo(params, this.platform)
      .subscribe((data: any) => {
        if (data && data.length > 0) {
          this.CPTInfoRequest = data;
        }
      });
  }
  // For related Visit
  fetchRelatedVisit() {
    const myObj = {
      uniqueId: this.uniqueID,
      patientName: this.patientName,
      dos: this.dateOfService,
      modality: this.selectedModality,
      mrn: this.MRN
    };
    this.relatedVisitParentData = [];
    this._platformService.fetchRelatedChart(myObj).subscribe(data => {
      if (data && data.length > 0) {
        this.relatedVisitParentData = data;
        this.relatedVisit = true;
        this.height = 594;
      }
    });
  }
  checkIcdIsPrisitine(event) {
    if (event) {
      this.icdIsPristines = event;
    }
  }
  checkCptIsPrisitine(event) {
    if (event) {
      this.cptIsPristines = event;
    }
  }
  ICDRowData(event) {
    this.fetchICDRowData = [];
    if (event && event.length > 0) {
      this.fetchICDRowData = event;
    }
  }
  CPTRowData(event) {
    this.fetchCPTRowData = [];
    if (event && event.length > 0) {
      this.fetchCPTRowData = event;
    }
  }
  highlightText(event: any) {
    if (event) {
      this.searchTerm = ' ';
      setTimeout(() => {
        this.searchTerm = event;
      }, 10);
    }
  }
  getValidationMessage(isValidate): string {
    let message: string;
    if (isValidate.icdCodeIsEmpty.length > 0) {
      message = 'Please enter ICD code.';
    } else if (isValidate.cptCodeIsEmpty.length > 0) {
      message = 'Please enter CPT code.';
    } else if (isValidate.cptAccessionEmpty.length > 0) {
      message = 'Please enter CPT Accession Number.';
    }
    return message;
  }
  showCommentsDialog(cptInfo, icdInfo, conflictStatus) {
    const dialogRef = this.dialog.open(MatDialogCheckDuplicateComponent, {
      hasBackdrop: true,
      disableClose: true,
      width: '450px',
      data: {
        cptInfo: cptInfo,
        icdInfo: icdInfo,
        UniqueID: this.uniqueID,
        conflict: conflictStatus,
        modality: this.selectedModality,
        chartStatus: 'retroed',
        conflicts: this.icdIsPristines || this.cptIsPristines ? true : false,
        auditorAllocatedTo: this.auditorAllocatedTo,
        platform: 'L2Auditor'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.errorService.throwSuccess('Chart saved successfully!');
        this.getNextChart();
      }
    });
  }
  partialSave(event, reasonName) {
    const cptInfo = this.fetchCPTRowData;
    const icdInfo = this.fetchICDRowData;
    this.reason = reasonName;
    this._platformService
      .auditorChartService(event, cptInfo, icdInfo, this.platform)
      .subscribe(data => {
        if (data) {
          this.openDialog(data, this.reason, cptInfo, icdInfo);
        }
      });
  }
  openDialog(responseList, reasonName, cptInfo, icdInfo) {
    const dialogRef = this.dialog.open(MatDialogOverviewComponent, {
      hasBackdrop: true,
      disableClose: false,
      width: '450px',
      data: {
        dataList: responseList,
        reason: reasonName,
        uniqueId: this.uniqueID,
        platform: 'auditor',
        cptInfo: cptInfo ? cptInfo : '',
        icdInfo: icdInfo ? icdInfo : '',
        isSaved: false,
        modality: this.selectedModality,
        userRole: 'l2auditor'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        // this._toastr.setRootViewContainerRef(this.vcr);
        this._platformService.fetchdataOnCountSave().subscribe(res => {});
        this.getNextChart();
      } else {
        // this._toastr.setRootViewContainerRef(this.vcr);
      }
    });
  }
  // Add ICD New Row on Click
  childEventClickedICD(event: any) {
    this.getSectionSplit(event, 'ICD');
  }
  // Add ICD New Row on Click
  childEventClickedCPT(event: any) {
    this.getSectionSplit(event, 'CPT');
  }
  removeAttr(text) {
    const doc = new DOMParser().parseFromString(text, 'text/html');
    const docArr = doc.getElementsByClassName('highlighted');
    for (let i = 0; i < docArr.length; i++) {
      docArr[i].removeAttribute('data-timestamp');
      docArr[i].removeAttribute('style');
      docArr[i].removeAttribute('data-highlighted');
    }
    return doc;
  }
  getSectionSplit(innerHtml, code) {
    const originalText = this.removeAttr(innerHtml.textInnerHtml);
    const param = {
      uniqueId: this.uniqueID,
      originalText: originalText.body.innerHTML
    };
    this._platformService.sectionSplitService(param).subscribe(data => {
      if (data) {
        let el: any = originalText.body.querySelectorAll('.highlighted');
        el.forEach(element => {
          element.classList.remove('highlighted');
          element.classList.add('htn');
        });
        if (code === 'ICD') {
          this.addICDrowData(
            data,
            innerHtml.highlightedText,
            originalText.body.innerHTML,
            data[0].sectionName
          );
        } else {
          this.addCPTrowData(
            data,
            innerHtml.highlightedText,
            originalText.body.innerHTML,
            data[0].sectionName
          );
        }
      }
    });
  }
  appendRationale(originalText, sectionArr) {
    sectionArr.forEach(element => {
      const html = '<span class="htb">$&</span>';
      const reg = new RegExp('\\b' + element.section + '\\b', 'i');
      originalText = originalText.replace(reg, html);
    });
    return originalText;
  }
  addICDrowData(event, selectedWord, originalText, sectionName) {
    originalText = this.appendRationale(originalText, event);
    this.isDisabled = true;
    const newIcdRow = {
      id: null,
      icdCode: '',
      aapcDescription: '',
      accessionNo: '',
      icdDescription: selectedWord,
      rationaleData: originalText,
      rationaleSection: event,
      isActive: true,
      lcdStatus: '',
      comments: 'new row'
    };
    this.clickedEventICD = newIcdRow;
  }
  getDxval(event) {
    this.lastCptDxVal = event;
  }
  // Add ICD New Row on Click
  addCPTrowData(event, selectedWord, originalText, sectionName) {
    originalText = this.appendRationale(originalText, event);
    this.isDisabled = true;
    const newCptRow = {
      id: null,
      cptCode: '',
      modifier: '',
      units: '1',
      dxRef: this.lastCptDxVal === undefined ? '1' : this.lastCptDxVal,
      accessionNo: this.accesionNo.split(' ')[0],
      aapcDescription: '',
      cptDescription: selectedWord,
      rationaleData: originalText,
      rationaleSection: event,
      isActive: true,
      comments: 'new row'
    };
    this.clickedEventCPT = newCptRow;
  }
  openModalDialog(uniqueID, display, status) {
    this.dialogRefModal = this.dialog.open(CoderModalChildComponent, {
      hasBackdrop: false,
      width: '1480px',
      panelClass: 'modal-dialog',
      data: {
        uniqueId: this.uniqueID,
        displayName: display,
        disableClose: true,
        status: status
      }
    });
    this.dialogRefModal.afterClosed().subscribe(data => { });
  }
  showModal(event) {
    this.display = event;
    this.UID = event.api.getSelectedRows()[0].uniqueId;
    const status = event.api.getSelectedRows()[0].chartStatus;
    this.openModalDialog(this.UID, this.display, status);
  }
  getModalityData(event) {
    this.selectedModality = event;
  }
  public openDialogForFeedBack() {
    const dialogRef = this.dialog.open(MatDialogFeedbackComponent, {
      hasBackdrop: true,
      width: '450px',
      data: {
        CPTInfo: this.fetchCPTRowData,
        ICDInfo: this.fetchICDRowData,
        UniqueID: this.uniqueID,
        comments: null,
        conflicts: this.icdIsPristines || this.cptIsPristines ? true : false,
        chartStatus: 'retroed',
        modality: this.selectedModality,
        auditorAllocatedTo: this.auditorAllocatedTo,
        isRetroed: true
      },
      disableClose: true
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.getNextChart();
      }
    });
  }
  // CCI MIPS LCD Validation functions
  prepareLCDParam(cptInfo, icdInfo) {
    let cptCodeEmpty = false;
    let icdCodeEmpty = false;
    let CPTCodes = '';
    let ICDCodes = '';
    const lcdInput = {
      uniqueId: this.uniqueID,
      cptInput: '',
      icdInput: ''
    };
    cptInfo.forEach((element, index) => {
      if (element.cptCode) {
        if (index > 0) {
          CPTCodes = lcdInput.cptInput.concat(CPTCodes, '~');
        }
        const cptCode = element.cptCode + '*' + element.dxRef;
        CPTCodes = lcdInput.cptInput.concat(CPTCodes, cptCode.trim());
      } else {
        cptCodeEmpty = true;
        this.errorService.throwWarning(
          'Please enter CPT Code for LCD/NCD check'
        );
      }
    });
    icdInfo.forEach((element, index) => {
      if (element.icdCode) {
        if (index > 0) {
          ICDCodes = lcdInput.icdInput.concat(ICDCodes, '~');
        }
        ICDCodes = lcdInput.icdInput.concat(ICDCodes, element.icdCode.trim());
      } else {
        icdCodeEmpty = true;
        this.errorService.throwWarning(
          'Please enter ICD Code for LCD/NCD check'
        );
      }
    });
    lcdInput.cptInput = CPTCodes;
    lcdInput.icdInput = ICDCodes;
    return { lcdInput, cptCodeEmpty, icdCodeEmpty };
  }
  preapreMIPSParam(cptInfo) {
    let cptCodeEmpty = false;
    const MIPSMeasureInput = {
      cptcode: '',
      uniqueId: this.uniqueID
    };
    let CPTCodes = '';
    if (cptInfo && cptInfo.length) {
      cptInfo.forEach((element, index) => {
        if (element.cptCode) {
          if (index > 0) {
            CPTCodes = MIPSMeasureInput.cptcode.concat(CPTCodes, '~');
          }
          CPTCodes = MIPSMeasureInput.cptcode.concat(
            CPTCodes,
            element.cptCode.trim()
          );
        } else {
          cptCodeEmpty = true;
          this.errorService.throwWarning(
            'Please enter CPT Code for MIPS Measure'
          );
        }
      });
    }
    MIPSMeasureInput.cptcode = CPTCodes;
    return { MIPSMeasureInput, cptCodeEmpty };
  }
  prepareCCIParam(cptInfo) {
    let cptCodeEmpty = false;
    const CCIInputMeasure = {
      cptMod: '',
      currentChartID: this.uniqueID
    };
    let CPTCodes = '';
    if (cptInfo && cptInfo.length) {
      cptInfo.forEach((element, index) => {
        if (element.cptCode) {
          if (index > 0) {
            CPTCodes = CCIInputMeasure.cptMod.concat(CPTCodes, '~');
          }
          CPTCodes = CCIInputMeasure.cptMod.concat(
            CPTCodes,
            element.cptCode.trim()
          );
          CPTCodes = CCIInputMeasure.cptMod.concat(CPTCodes, '*');
          CPTCodes = element.modifier
            ? CCIInputMeasure.cptMod.concat(CPTCodes, element.modifier)
            : CCIInputMeasure.cptMod.concat(CPTCodes, '');
        } else {
          cptCodeEmpty = true;
          this.errorService.throwWarning(
            'Please enter CPT Code for CCI Modifier'
          );
        }
      });
    }
    CCIInputMeasure.cptMod = CPTCodes;
    return { CCIInputMeasure, cptCodeEmpty };
  }
  updateLCDNCDCol(lcdDetails) {
    const param = [];
    lcdDetails.forEach(element => {
      param.push({
        lcdStatus: element.icdCheckStatus,
        icdCode: element.icdCode
      });
    });
    const x = {
      status: param,
      colName: 'predictIcdCode'
    };
    this.lcdCheckStatus = x;
  }
  updateMoidifierCol(response) {
    const param = [];
    let message = false;
    response.forEach(element => {
      param.push({
        modifier: element.cciModifier,
        cptcode: element.cpt
      });
      if (element.cciModifier === 'Not Applicable') {
        message = true;
      }
      const x = {
        modifier: param,
        colName: 'predictIcdCode'
      };
      this.cciCheck = x;
    });
    return message;
  }
  lcdCheck(event) {
    event.stopPropagation();
    this.lcdNcdClicked = true;
    const cptInfo = this.fetchCPTRowData;
    const icdInfo = this.fetchICDRowData;
    const isValidate = this._lookupDataService.validateBlankRecordCoder(
      cptInfo,
      icdInfo
    );
    if (
      isValidate.icdCodeIsEmpty.length === 0 &&
      isValidate.cptCodeIsEmpty.length === 0
    ) {
      const inputParam = this.prepareLCDParam(cptInfo, icdInfo);
      if (
        inputParam.cptCodeEmpty === false &&
        inputParam.icdCodeEmpty === false
      ) {
        this._platformService
          .fetchlcdmipsccicheck(null, inputParam.lcdInput, null)
          .subscribe(res => {
            if (res) {
              if (res.validDetails && res.validDetails.lcd.length > 0) {
                this.updateLCDNCDCol(res.validDetails.lcd);
                this.errorService.throwSuccess('LCD status updated.');
              }
            }
          });
      }
    } else {
      const msg = this.getValidationMessage(isValidate);
      this.errorService.throwWarning(msg);
    }
  }
  getMIPSMeasure(event) {
    event.stopPropagation();
    this.pqrsMipsClicked = true;
    const cptInfo = this.fetchCPTRowData;
    const inputParam = this.preapreMIPSParam(cptInfo);
    if (!inputParam.cptCodeEmpty) {
      this._platformService
        .fetchlcdmipsccicheck(null, null, inputParam.MIPSMeasureInput)
        .subscribe(response => {
          if (response) {
            if (
              response.validDetails &&
              response.validDetails.mips &&
              response.validDetails.mips.length > 0
            ) {
              const dialogRef = this.dialog.open(MipsDialogComponent, {
                hasBackdrop: true,
                width: '950px',
                data: {
                  uniqueId: this.uniqueID,
                  mipsData: response.validDetails.mips
                },
                disableClose: true
              });
            }
          }
        });
    }
  }
  getCCIModifier(event) {
    event.stopPropagation();
    this.cciClicked = true;
    const cptInfo = this.fetchCPTRowData;
    const inputParam = this.prepareCCIParam(cptInfo);
    if (!inputParam.cptCodeEmpty) {
      let msg;
      this._platformService
        .fetchlcdmipsccicheck(inputParam.CCIInputMeasure, null, null)
        .subscribe(response => {
          if (response) {
            if (
              response.validDetails &&
              response.validDetails.cci &&
              response.validDetails.cci.length > 0
            ) {
              msg = this.updateMoidifierCol(response.validDetails.cci);
              this.errorService.throwSuccess('Modifier updated.');
            } else {
              msg = true;
            }
          }
          if (msg) {
            this.errorService.throwInfo('CCI modifier is not applicable');
          }
        });
    }
  }
  // get deleted ICD
  public deletedIcd(event) {
    if (event) {
      event.comments = 'wrongly coded ' + event.icdCode;
    }
    this.saveDeletedICDObj.push(event);
  }
  // get deleted CPT
  public deletedCpt(event) {
    if (event) {
      event.comments = 'wrongly coded ' + event.cptCode;
    }
    this.saveDeletedCPTObj.push(event);
  }
  saveClick() {
    const saveIcdInfo = this.fetchICDRowData;
    const saveCptInfo = this.fetchCPTRowData;
    this.validateCptInfo = [];
    this.validateIcdInfo = [];
    // get data for validations whose active state is true
    this.validateIcdInfo = this.fetchICDRowData.filter(
      element => element.isActive != false
    );
    this.validateCptInfo = this.fetchCPTRowData.filter(
      element => element.isActive != false
    );
    if (
      this.validateCptInfo.length === 0 ||
      this.validateIcdInfo.length === 0
    ) {
      this.errorService.throwWarning(
        '1 ICD and CPT is mandatory to save the chart'
      );
    } else {
      const dxIsEmpty = this._lookupDataService.cptDxRefValidationCheck(
        this.validateCptInfo
      );
      const isValidate = this._lookupDataService.validateBlankRecordCoder(
        this.validateCptInfo,
        this.validateIcdInfo
      );
      const conflictStatus =
        this.icdIsPristines || this.cptIsPristines ? true : false;
      if (dxIsEmpty && dxIsEmpty.code === 1) {
        if (
          isValidate.cptCodeIsEmpty.length === 0 &&
          isValidate.icdCodeIsEmpty.length === 0 &&
          isValidate.cptAccessionEmpty.length === 0
        ) {
          this.checkForLcdCciMipsValidation(conflictStatus);
        } else {
          const msg = this.getValidationMessage(isValidate);
          this.errorService.throwWarning(msg);
        }
      } else if (dxIsEmpty) {
        this.errorService.throwWarning(dxIsEmpty.msg);
      } else {
        this.errorService.throwWarning(
          '1 ICD and CPT is mandatory to save the chart'
        );
      }
    }
  }
  checkForLcdCciMipsValidation(conflictStatus) {
    let setValidationError = false;
    const cptInfo = this.fetchCPTRowData;
    const icdInfo = this.fetchICDRowData;
    const lcdParam = this.prepareLCDParam(cptInfo, icdInfo);
    const cciParam = this.prepareCCIParam(cptInfo);
    const mipsParam = this.preapreMIPSParam(cptInfo);
    let icdCheckStatus: boolean;
    const param = {
      cciInput: null,
      lcdInput: null,
      mipsInput: null
    };
    if (
      lcdParam.cptCodeEmpty === false &&
      lcdParam.icdCodeEmpty === false &&
      cciParam.cptCodeEmpty === false &&
      mipsParam.cptCodeEmpty === false
    ) {
      if (this.lcdNcdClicked === false) {
        param.lcdInput = lcdParam.lcdInput;
      }
      if (this.cciClicked === false) {
        param.cciInput = cciParam.CCIInputMeasure;
      }
      param.mipsInput = mipsParam.MIPSMeasureInput;
      this._platformService
        .fetchlcdmipsccicheck(param.cciInput, param.lcdInput, param.mipsInput)
        .subscribe(response => {
          if (response) {
            if (
              response.validDetails &&
              (response.validDetails.lcd ||
                response.validDetails.mips ||
                response.validDetails.cci)
            ) {
              setValidationError = true;
              if (this.lcdNcdClicked === false) {
                if (
                  response.validDetails &&
                  response.validDetails.lcd &&
                  response.validDetails.lcd.length > 0
                ) {
                  this.updateLCDNCDCol(response.validDetails.lcd);
                  this.lcdNcdClicked = true;
                }
              }
              if (this.cciClicked === false) {
                if (
                  response.validDetails &&
                  response.validDetails.cci &&
                  response.validDetails.cci.length > 0
                ) {
                  this.updateMoidifierCol(response.validDetails.cci);
                  this.cciClicked = true;
                }
              }
              if (response.validDetails.lcd !== null) {
                response.validDetails.lcd.every(function(element, index) {
                  if (
                    element.icdCheckStatus == 'Not Applicable' ||
                    element.icdCheckStatus == 'LCD Passed'
                  ) {
                    icdCheckStatus = true;
                  } else {
                    icdCheckStatus = false;
                    return false;
                  }
                });
              }
              if (
                response.validDetails.mips === null &&
                response.validDetails.cci === null &&
                icdCheckStatus
              ) {
                setTimeout(() => {
                  this.saveAuditorPlatformData(
                    cptInfo,
                    icdInfo,
                    conflictStatus
                  );
                }, 10); // Donot remove this as this will effect update lcdncd col bug
              } else {
                const dialogRef = this.dialog.open(MipsDialogComponent, {
                  hasBackdrop: true,
                  width: '950px',
                  data: {
                    uniqueId: this.uniqueID,
                    mipsData: response.validDetails.mips,
                    cciData: response.validDetails.cci,
                    lcdData: response.validDetails.lcd
                  },
                  disableClose: true
                });
              }
            } else {
              this.saveAuditorPlatformData(cptInfo, icdInfo, conflictStatus);
            }
          }
        });
    }
  }
  getDeletedCPTICD(cptInfo, icdInfo) {
    const saveIcdObj = [];
    const saveCptObj = [];
    icdInfo.forEach(element => {
      if (
        element['comments'] !== undefined &&
        element['comments'] === 'new row'
      ) {
        element.comments = 'missed coding ' + element.icdCode;
      }
      saveIcdObj.push(element);
    });
    if (this.saveDeletedICDObj && this.saveDeletedICDObj.length > 0) {
      this.saveDeletedICDObj.forEach(ele => {
        saveIcdObj.push(ele);
      });
    }
    cptInfo.forEach(element => {
      if (
        element['comments'] !== undefined &&
        element['comments'] === 'new row'
      ) {
        element.comments = 'missed coding ' + element.cptCode;
      }
      saveCptObj.push(element);
    });
    if (this.saveDeletedCPTObj && this.saveDeletedCPTObj.length > 0) {
      this.saveDeletedCPTObj.forEach(ele => {
        saveCptObj.push(ele);
      });
    }
    return { saveCpt: saveCptObj, saveIcd: saveIcdObj };
  }
  saveAuditorPlatformData(cptInfo, icdInfo, conflictStatus) {
    const chartData = this.getDeletedCPTICD(cptInfo, icdInfo);
    if (conflictStatus || this.isDiscarded) {
      this.showCommentsDialog(
        chartData['saveCpt'],
        chartData['saveIcd'],
        conflictStatus
      );
    } else {
      const param: any = {
        CPTInfo: chartData['saveCpt'],
        ICDInfo: chartData['saveIcd'],
        UniqueID: this.uniqueID,
        comments: null,
        conflicts: this.icdIsPristines || this.cptIsPristines ? true : false,
        chartStatus: 'retroed',
        modality: this.selectedModality,
        auditorAllocatedTo: this.auditorAllocatedTo,
        isRetroed: true
      };
      this._platformService
        .saveL2AuditorChartInfo(param)
        .subscribe(responseList => {
          if (responseList) {
            this.ngProgress.start();
            // this._toastr.setRootViewContainerRef(this.vcr);
            this._toastr.success('Chart Saved Successfully');
            setTimeout(() => {
              this.ngProgress.done();
              this._platformService.fetchdataOnCountSave().subscribe(res => {});
              this.getNextChart();
            }, 1000);
          }
        });
    }
  }
}
