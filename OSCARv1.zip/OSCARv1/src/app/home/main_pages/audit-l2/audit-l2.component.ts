import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import {
  MatGridList,
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE
} from '@angular/material';
import { GridOptions } from 'ag-grid';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { ObservableMedia } from '@angular/flex-layout';
import { ToastsManager } from 'ng2-toastr';
import * as _moment from 'moment';
import {
  MomentDateAdapter,
  MAT_MOMENT_DATE_FORMATS
} from '@angular/material-moment-adapter';
import { DateFormatter } from '../../../imports/_utilities/date-formatter';
import { ValidationService } from '../../../services/validation.service';
import { ClientSelectionService } from '../../../users/client-selection/client-selection.service';
import { ReportService } from '../reports/report.service';
import { environment } from '../../../../environments/environment';
import { AuditL2Service } from './audit-l2.service';
import { DateService } from '../../../_shared-services/date-service/date.service';
import { ErrorHandlingServices } from '../../../services/error-handling.services';
import { CommonCodeService } from '../../../_shared-services/common-code.services';
@Component({
  selector: 'app-audit-l2',
  templateUrl: './audit-l2.component.html',
  styleUrls: ['./audit-l2.component.scss'],
  providers: [
    AuditL2Service,
    DateService,
    DateFormatter,
    ValidationService,
    ClientSelectionService,
    ReportService,
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS }
  ]
})
export class AuditL2Component implements OnInit {
  clientName;
  location;
  batchId;
  modality;
  patientName;
  physicianName;
  MRN;
  accession;
  account;
  cpt;
  icd;
  modifier;
  userId;
  selectedLocationModel: any;
  @ViewChild('grid') grid: MatGridList;
  @ViewChild('filters') filters;
  public facility;
  public gridOptions: GridOptions;
  public columnDefs;
  public rowData: any;
  public gridApi;
  public gridColumnApi;
  public frameworkComponents;
  public rowSelection;
  public paginationPageSize;
  fromDateErrorMessage = 'Please enter valid date.';
  toDateErrorMessage = 'Please enter valid date.';
  auditorL2FormGroup: FormGroup;
  excelExportBtn: boolean = false;
  facilityOptionList: any = [];
  modalityOptionList: any = [];
  public facilitySelectModel: any = [];
  locationOptionList: any = [];
  public locationSelectModel: any = [];
  public modalitySelectModel: any = [];
  maxDate = new Date();
  public storage: Storage = environment.storage;
  clientObj;
  height = 56;
  constructor(
    private auditL2Service: AuditL2Service,
    private _dateFormatter: DateFormatter,
    private formBuilder: FormBuilder,
    public toaster: ToastsManager,
    private dateService: DateService,
    private errorHandlingService: ErrorHandlingServices,
    private _commonCode: CommonCodeService
  ) {
    this.getLocationList();
    this.getModalityList();
  }
  public ngOnInit(): void {
    this.gridInit();
    this.intializeAgingForm();
    this.onChanges();
  }
  toggleFilter(event){
    if (event === 'block'){
      this.height = 56;
    } else{
      this.height = 80;
    }
  }
  fetchParams() {
    this.clientObj = this._commonCode.get_ConfidenceColor_Clientselection(
      'clientSelectionObject'
    );
    return {
      role: this.clientObj.workRole.role,
      l2AllocationInput: {
        fromDate: this.auditorL2FormGroup.controls.fromDate.value.format(
          'YYYY-MM-DD'
        ),
        toDate: this.auditorL2FormGroup.controls.toDate.value.format(
          'YYYY-MM-DD'
        ),
        facilityName: this.auditorL2FormGroup.controls.facility.value
          ? this.auditorL2FormGroup.controls.facility.value.map(
              data => data.name
            )
          : [],
        batchId: this.auditorL2FormGroup.controls.batchId
          ? this.auditorL2FormGroup.controls.batchId.value
          : '',
        modality: this.auditorL2FormGroup.controls.modality.value
          ? this.auditorL2FormGroup.controls.modality.value.map(
              data => data.name
            )
          : [], // this.modalitySelectModel ? this.modalitySelectModel : [],
        patientName: this.auditorL2FormGroup.controls.patientName
          ? this.auditorL2FormGroup.controls.patientName.value
          : '',
        physicianName: this.auditorL2FormGroup.controls.physicianName
          ? this.auditorL2FormGroup.controls.physicianName.value
          : '',
        mrn: this.auditorL2FormGroup.controls.MRN
          ? this.auditorL2FormGroup.controls.MRN.value
          : '',
        accessionNo: this.auditorL2FormGroup.controls.accession
          ? this.auditorL2FormGroup.controls.accession.value
          : '',
        icdCode: this.auditorL2FormGroup.controls.icd
          ? this.auditorL2FormGroup.controls.icd.value
          : '',
        cptCode: this.auditorL2FormGroup.controls.cpt
          ? this.auditorL2FormGroup.controls.cpt.value
          : '',
        location: this.auditorL2FormGroup.controls.location.value
          ? this.auditorL2FormGroup.controls.location.value.map(
              data => data.name
            )
          : []
      }
    };
  }
  getAuditorL2Queue() {
    const params = this.fetchParams();
    this.rowData = [];
    this.auditL2Service.fetchAudtorL2Queue(params).subscribe((data: any) => {
      if (data) {
        if (data && data.length > 0) {
          this.rowData = data;
        } else {
          this.rowData = [];
        }
      }
    });
  }
  public getLocationList() {
    this.auditL2Service.getLocationFacility().subscribe(
      data => {
        if (!data.apierror) {
          this.locationOptionList = data;
        } else {
          this.errorHandlingService.throwInfo(data.apierror.message);
        }
      },
      error => {
        this.errorHandlingService.throwError(error);
      }
    );
  }
  public getModalityList() {
    this.modalityOptionList = [];
    this.auditL2Service.getModality().subscribe(data => {
      if (data) {
        this.modalityOptionList = data.map(m => {
          return {
            name: m.modlaityid,
            modalityname: m.modalityname,
            highvalue: m.highvalue
          };
        });
      }
    });
  }
  selectedLocation() {
    this.facilityOptionList.length = 0;
    const facilityListData = this.auditorL2FormGroup.controls.facility.value
      ? this.auditorL2FormGroup.controls.facility.value
      : null;
    const list = [];
    if (this.auditorL2FormGroup.controls.location.value) {
      this.auditorL2FormGroup.controls.location.value.forEach(
        locationElement => {
          if (locationElement) {
            locationElement.facility.forEach(element => {
              list.push(element);
            });
          }
        }
      );
    }
    this.facilityOptionList = list;
    const facilityFilterList = this.facilityOptionList.includes(
      facilityListData
    )
      ? facilityListData
      : null;
    this.auditorL2FormGroup.controls.facility.patchValue(facilityFilterList);
  }
  gridInit(): void {
    this.gridOptions = <GridOptions>{
      context: {
        componentParent: this
      }
    };
    this.gridOptions.columnDefs = [
      {
        width: 45,
        pinned: 'left',
        suppressSizeToFit: true,
        suppressFilter: true,
        headerCheckboxSelectionFilteredOnly: true,
        editable: false,
        checkboxSelection: function(params) {
          return params.columnApi.getRowGroupColumns().length === 0;
        },
        headerCheckboxSelection: function(params) {
          return params.columnApi.getRowGroupColumns().length === 0;
        }
      },
      {
        headerName: 'SL.No.',
        field: 'serialNo',
        valueGetter: 'node.rowIndex + 1',
        suppressNavigable: true,
        width: 100,
        cellClass: 'text-right'
      },
      {
        headerName: 'Location',
        field: 'location',
        tooltipField: 'location'
      },
      {
        headerName: 'Specialty',
        field: 'specialty',
        tooltipField: 'specialty'
      },
      {
        headerName: 'Facility',
        field: 'facility',
        tooltipField: 'facility'
      },
      {
        headerName: 'Batch Name',
        field: 'batchName',
        tooltipField: 'batchName'
      },
      {
        headerName: 'Received Date',
        field: 'date',
        tooltipField: 'date',
        valueFormatter: this._dateFormatter.reportDate,
        cellClass: 'text-center'
      },
      {
        headerName: 'Aged Reports',
        field: 'agedReports',
        tooltipField: 'agedReports',
        cellClass: 'text-right'
      },
      {
        headerName: '24 Hrs.',
        field: 'charts24',
        tooltipField: 'charts24',
        cellClass: 'text-right'
      },
      {
        headerName: '48 Hrs.',
        field: 'charts48',
        tooltipField: 'charts48',
        cellClass: 'text-right'
      },
      {
        headerName: '72 Hrs.',
        field: 'charts72',
        tooltipField: 'charts72',
        cellClass: 'text-right'
      },
      {
        headerName: '72 Hrs. and above',
        field: 'chartso72',
        tooltipField: 'chartso72',
        cellClass: 'text-right'
      },
      {
        headerName: 'Remarks',
        field: 'remarks',
        tooltipField: 'remarks',
        editable: true
      }
    ];
    this.rowData = [];
    this.rowSelection = 'multiple';
    this.paginationPageSize = 30;
  }
  autoSizeAll() {
    this.gridApi.sizeColumnsToFit();
  }
  public gridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.autoSizeAll();
  }
  public intializeAgingForm() {
    this.auditorL2FormGroup = this.formBuilder.group({
      fromDate: new FormControl(_moment([])),
      toDate: new FormControl(_moment([])),
      clientName: '',
      location: new FormControl([]),
      facility: new FormControl([]),
      batchId: '',
      modality: new FormControl([]),
      patientName: '',
      physicianName: '',
      MRN: '',
      accession: '',
      account: '',
      cpt: '',
      icd: '',
      modifier: '',
      userId: ''
    });
  }
  onChanges() {
    this.auditorL2FormGroup.controls.location.valueChanges.subscribe(val => {
      this.selectedLocation();
    });
  }
  onSelectionChanged(event) {
    const selectedRows = event.api.getSelectedRows();
    if (selectedRows.length > 0) {
      this.excelExportBtn = true;
    } else {
      this.excelExportBtn = false;
    }
  }
  validateDate(event, field?: string): any {
    const toDateControl = this.auditorL2FormGroup.controls['toDate'];
    const fromDateControl = this.auditorL2FormGroup.controls['fromDate'];
    const validate = this.dateService.dateValidation(
      event,
      fromDateControl,
      toDateControl,
      field
    );
    this.fromDateErrorMessage = '';
    this.toDateErrorMessage = '';
    if (
      validate.toDateControl.status === 'INVALID' &&
      validate.fromDateControl.status === 'INVALID'
    ) {
      setTimeout(() => {
        toDateControl.setErrors({ invalid: true });
        fromDateControl.setErrors({ invalid: true });
        this.toDateErrorMessage = validate.toDateErrorMessage;
        this.fromDateErrorMessage = validate.fromDateErrorMessage;
      }, 100);
    } else if (validate.toDateControl.status === 'INVALID') {
      setTimeout(() => {
        toDateControl.setErrors({ invalid: true });
        this.toDateErrorMessage = validate.toDateErrorMessage;
      }, 100);
    } else if (validate.fromDateControl.status === 'INVALID') {
      setTimeout(() => {
        fromDateControl.setErrors({ invalid: true });
        this.fromDateErrorMessage = validate.fromDateErrorMessage;
      }, 100);
    } else if (
      validate.toDateControl.status === 'VALID' &&
      validate.fromDateControl.status === 'VALID'
    ) {
      setTimeout(() => {
        toDateControl.setErrors(null);
        fromDateControl.setErrors(null);
      }, 100);
    }
  }
}
