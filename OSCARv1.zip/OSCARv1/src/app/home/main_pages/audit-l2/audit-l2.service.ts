import { Injectable } from '@angular/core';
import { HeaderAuthenticationToken } from '../../../auth/authetication-header';
import { environment } from '../../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
@Injectable()
export class AuditL2Service {
  public httpOption;
  public envURL = environment.URL;
  public storage: Storage = environment.storage;
  constructor(
    private httpClient: HttpClient,
    private __httpHeader: HeaderAuthenticationToken
  ) {
    this.httpOption = this.__httpHeader.setHeaderToken();
  }
  public getLocationFacility() {
    const URL = this.envURL + 'facilitymaster/locationfacility';
    return this.httpClient.get(URL, this.httpOption).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
  public getLocations() {
    const URL = this.envURL + 'facilitymaster/location';
    return this.httpClient.get(URL, this.httpOption).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
  public getFacility() {
    const URL = this.envURL + 'facilitymaster/facility';
    return this.httpClient.get(URL, this.httpOption).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
  public getModality() {
    const URL = this.envURL + 'facilitymaster/modality';
    return this.httpClient.get(URL, this.httpOption).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
  public fetchAudtorL2Queue(params): any {
    const URL = this.envURL + 'chartinformation/searchchartinformation';
    return this.httpClient.post(URL, params, this.httpOption).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
}
