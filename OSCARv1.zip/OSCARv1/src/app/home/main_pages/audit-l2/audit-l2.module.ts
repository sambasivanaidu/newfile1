import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuditL2PlatformComponent } from './audit-l2-platform/audit-l2-platform.component';
import { AuditL2Component } from './audit-l2.component';
import { BreadCrumbModule } from '../reports/bread-crumb/bread-crumb.module';
import { MaterialModule } from '../../../imports/material.module';
import { RouterModule, Routes } from '@angular/router';
import { MatDynamicDdModule } from '../../../imports/_utilities/mat-dynamic-dd/mat-dynamic-dd.module';
import { AgGridModule } from 'ag-grid-angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  PasswordModule,
  InputTextModule,
  PanelModule,
  DialogModule,
  ConfirmDialogModule,
  SharedModule,
  ContextMenuModule
} from 'primeng/primeng';
import { ChartModule } from 'primeng/chart';
import { OscarSharedModule } from '../oscar-shared/oscar-shared.module';
import { PipesModule } from '../../../imports/pipes/pipes.module';
import { CoderModalChildComponent } from '../oscar-shared/coder-modal-child/coder-modal-child.component';
import { ContextMenuService } from 'ngx-contextmenu';
import { MipsDialogModule } from '../../../imports/_utilities/mips-dialog/mips-dialog.module';

const routes: Routes = [
  { path: 'queue', component: AuditL2Component },
  { path: 'platform', component: AuditL2PlatformComponent }
];
@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
    RouterModule.forChild(routes),
    MatDynamicDdModule,
    AgGridModule,
    FormsModule,
    ReactiveFormsModule,
    PasswordModule,
    InputTextModule,
    PanelModule,
    DialogModule,
    ConfirmDialogModule,
    SharedModule,
    ChartModule,
    OscarSharedModule,
    PipesModule,
    BreadCrumbModule,
    ContextMenuModule,
    MipsDialogModule
  ],
  declarations: [AuditL2PlatformComponent, AuditL2Component],
  providers: [
    ContextMenuService
  ],
  entryComponents: [CoderModalChildComponent]
})
export class AuditL2Module {}
