import { ContextMenuModule, ContextMenuService } from 'ngx-contextmenu';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CoderQueueComponent } from './coder-queue/coder-queue.component';
import { CoderPlatformComponent } from './coder-platform/coder-platform.component';
import { MaterialModule } from '../../../imports/material.module';
import { RouterModule, Routes } from '@angular/router';
import { MatDynamicDdModule } from '../../../imports/_utilities/mat-dynamic-dd/mat-dynamic-dd.module';
import { AgGridModule } from 'ag-grid-angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
    PasswordModule,
    InputTextModule,
    PanelModule,
    DialogModule,
    ConfirmDialogModule,
    SharedModule

} from 'primeng/primeng';
import { ChartModule } from 'primeng/chart';
import { OscarSharedModule } from '../oscar-shared/oscar-shared.module';
import { PipesModule } from '../../../imports/pipes/pipes.module';
import { CoderModalChildComponent } from '../oscar-shared/coder-modal-child/coder-modal-child.component';
import { BreadCrumbModule } from '../reports/bread-crumb/bread-crumb.module';
import { QueueService } from '../../../services/main-pages/queue.service';
import { MipsDialogModule } from '../../../imports/_utilities/mips-dialog/mips-dialog.module';

const routes: Routes = [
  { path: 'queue', component: CoderQueueComponent},
  { path: 'platform', component: CoderPlatformComponent}
]

@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
    RouterModule.forChild(routes),
    MatDynamicDdModule,
    AgGridModule,
    FormsModule,
    ReactiveFormsModule,
    PasswordModule,
    InputTextModule,
    PanelModule,
    DialogModule,
    ConfirmDialogModule,
    SharedModule,
    ChartModule,
    OscarSharedModule,
    PipesModule,
    ContextMenuModule,
    BreadCrumbModule,
    MipsDialogModule
  ],
  declarations: [
    CoderQueueComponent,
    CoderPlatformComponent
  ],
  providers: [
    ContextMenuService,
    QueueService
  ],
  entryComponents: [CoderModalChildComponent]
})
export class CoderModule { }
