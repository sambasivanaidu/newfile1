import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import 'rxjs/add/operator/map';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { MatDialog, MatDialogRef } from '@angular/material';
import { FormControl, FormBuilder } from '@angular/forms';
import { LookupDataService } from '../../../../_shared-services/unrelated-data-services/lookup-data.service';
import { ObservableMedia } from '@angular/flex-layout';
import { environment } from '../../../../../environments/environment';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
import * as CryptoJS from 'crypto-js';
import { DomSanitizer } from '@angular/platform-browser';
import { LocationStrategy } from '@angular/common';
import { CommonCodeService } from '../../../../_shared-services/common-code.services';
import { MatDialogOverviewComponent } from '../../../../imports/_utilities/mat-dialog-overview/mat-dialog-overview.component';
import { CoderModalChildComponent } from '../../oscar-shared/coder-modal-child/coder-modal-child.component';
import { AuditAcknowledgeDialogComponent } from '../../../../imports/_utilities/mat-dialog-acknowledge/mat-dialog-acknowledge.component';
import { MipsDialogComponent } from '../../../../imports/_utilities/mips-dialog/mips-dialog.component';
import { QueueService } from '../../../../services/main-pages/queue.service';
import { PlatformService } from '../../../../services/main-pages/paltform-services/platform-service.service';

@Component({
  selector: 'app-coder-platform',
  templateUrl: './coder-platform.component.html',
  styleUrls: ['./coder-platform.component.scss'],
  providers: [
    LookupDataService
  ]
})
export class CoderPlatformComponent implements OnInit {
  uniqueID = '';
  customCollapsedHeight: string = '25px';
  customExpandedHeight: string = '25px';
  platform: string = 'coder';
  errorMsg = 'Something went wrong, please try again later';

  patientChart: any;
  patientInfoParent: any;
  patientRecordInfoParent: any;
  relatedVisitParentData: any;
  ICDInfoRequest: any;
  CPTInfoRequest: any;
  ICDInfoRequestOld: any;
  expanded: boolean = true;
  isL2Auditor: boolean = false;
  public MRN: string = '';
  public patientName;
  public dateOfService;
  public isDisabled: boolean;
  public isIcdValidated: boolean;
  public isCptValidated: boolean;
  public reason = '';
  public clickedEventICD: any;
  public searchTerm: any;
  public clickedEventCPT: any;

  public fetchICDRowData: any = [];
  public fetchCPTRowData: any = [];
  public validateCptInfo = [];
  public validateIcdInfo = [];

  myControl = new FormControl();
  lookups: string;
  lookUpOption: any;
  dialogRefModal: MatDialogRef<any>;

  public display: boolean = false;
  public UID;
  public selectedModality;
  public lcdCheckStatus;
  public selectedFacility;
  autocompleteFormGroup: boolean = false;
  public auditAck: any;
  public suppressRowEdit: boolean = false;
  public facility: string;
  public disableMIPS: boolean;
  public disableLCD: boolean;
  public disableCCI: boolean;
  public cciCheck: any;
  public storage: Storage = environment.storage;
  public lcdNcdClicked = false;
  public cciClicked = false;
  public pqrsMipsClicked = false;

  public chartInfoParam: any;
  public queueType: string;
  public auditorRemarks = '';
  public height = 750;
  public disp: any = 'none';
  public iframeUrl;
  public zoom: any = 1;
  public lineHeight: any = 1.5;
  public priorityQueue;
  urlpdf: any;
  fileURL: any;
  displayPdf: any = 'none';
  countsave: any;
  public isProccessed: boolean;
  public hideAckAuditor: boolean;
  public saveDeletedICDObj = [];
  public saveDeletedCPTObj = [];
  public auditorConflict: boolean;
  public l2auditorConflict: boolean;
  public errorFeedBack: boolean;
  public patientInfoGender: string;
  public dateOfBirth: any;
  public patientInfoforCodeLookUp = [];
  public lastCptDxVal: any;
  public lookupGuidePath = null;
  closeTest;
  public icdIsPristines: boolean = false;
  public cptIsPristines: boolean = false;
  lastAccessionVal: any;
  urlParameters: any;
  public isSaved: boolean;
  public codedBy;
  public raiComment: any;
  cptlength = 0;
  icdlength = 0;
  raiResponse: any;
  accesionNo: any;
  accessionNumber: any;
  cptSectionHeight: any;
  icdSectionHeight: any;
  public isDiscarded: boolean; // for acknowledge charts to send for cptinfo
  relatedVisit: boolean = false;
  public panelOpenState: boolean = true;
  addclass: boolean;
  constructor(
    public _platformService: PlatformService,
    private _router: Router,
    public _toastr: ToastsManager,
    public dialog: MatDialog,
    public _lookupDataService: LookupDataService,
    private coderQueueService: QueueService,
    private errorService: ErrorHandlingServices,
    public sanitzer: DomSanitizer,
    public location: LocationStrategy,
    private _commonCode: CommonCodeService
  ) {
    this.setCoderParam();
    this._router.routeReuseStrategy.shouldReuseRoute = function() {
      return false;
    };
    /* preventing back button in browser implemented by 'Samba Siva'  */

    history.pushState(null, null, window.location.href);
    this.location.onPopState(() => {
      history.pushState(null, null, window.location.href);
      setTimeout(() => {
        console.clear();
      }, 100);
      const previousChart: any = sessionStorage.getItem('previousChart');
      this._router.navigate(['index/coder/platform', previousChart]);
      setTimeout(() => {
        console.clear();
      }, 100);
    });
    /* preventing back button END */
  }

  setHeight(functionName) {
       if (functionName === 'setCptHeight') {
      this.cptSectionHeight = this._commonCode.setCptHeight();
    } else if (functionName === 'setIcdHeight') {
      this.icdSectionHeight = this._commonCode.setIcdHeight();
    } else if (functionName === 'setMedicalReportHeight') {
      this.height = this._commonCode.setMedicalReportHeight(
        this.auditorRemarks,
        this.relatedVisit
      );
    } else if (functionName === 'pateintrecordinfoheight') {
      this.cptSectionHeight = this._commonCode.pateintRecordInfoHeight();
      this.icdSectionHeight = this.cptSectionHeight;
    }
  }

  openpdf(): void {
    if (this.lookupGuidePath) {
      this._platformService
        .fetchPdfFileData(this.lookupGuidePath)
        .subscribe(res => {
          this.fileURL = URL.createObjectURL(res);
          this.fileURL = this.sanitzer.bypassSecurityTrustResourceUrl(
            this.fileURL
          );
        });
      this.displayPdf = 'block';
    }
  }

  openRaiDocument(val) {
    if (this.raiResponse) {
      this._platformService.downloadRaiFiles(val).subscribe(res => {
        this.fileURL = URL.createObjectURL(res);
        const link = document.createElement('a');
        link.href = this.fileURL;
        const filename = val.split('/RAI/');
        link.download = filename[1];
        link.click();
      });
    }
  }

  onCloseHandled(): void {
    this.displayPdf = 'none';
  }

  public myMethodChangingQueryParams(param) {
    if (this.auditAck) {
      this.MRN = param.mrn;
      const params = {
        uniqueId: param.uniqueId,
        facilityId: param.facilityId,
        mrn: param.mrn
      };
      this.urlParameters = CryptoJS.AES.encrypt(
        JSON.stringify(params),
        'oscar'
      ).toString();
      localStorage.setItem('urlParameters', this.urlParameters);
      /* URL Sortening END*/
      this._router.navigate(
        [
          'index/coder/platform',
          { uniqueID: param.uniqueId, facilityId: param.facilityId }
        ],
        { skipLocationChange: true }
      );
    } else {
      this.coderQueueService
        .updateStartTimeforCoder(param.uniqueId, 'updatecoderstartedon')
        .subscribe(responseList => {
          if (responseList && responseList === 1) {
            setTimeout(() => {
              this.MRN = param.mrn;
              const params = {
                uniqueId: param.uniqueId,
                facilityId: param.facilityId,
                mrn: param.mrn
              };
              this.urlParameters = CryptoJS.AES.encrypt(
                JSON.stringify(params),
                'oscar'
              ).toString();
              localStorage.setItem('urlParameters', this.urlParameters);
              /* URL Sortening END*/
              this._router.navigate(
                [
                  'index/coder/platform',
                  { uniqueID: param.uniqueId, facilityId: param.facilityId }
                ],
                { skipLocationChange: true }
              );
            }, 100);
          }
        });
    }
  }

  setCoderParam() {
    if (localStorage.getItem('urlParameters')) {
      this.urlParameters = JSON.parse(
        CryptoJS.AES.decrypt(
          localStorage.getItem('urlParameters'),
          'oscar'
        ).toString(CryptoJS.enc.Utf8)
      );
    }

    if (this.urlParameters !== undefined) {
      this.uniqueID = this.urlParameters.uniqueId;
      this.facility = this.urlParameters.facilityId
        ? this.urlParameters.facilityId
        : '';
      this.MRN = this.urlParameters.mrn;
    }

    /* URL Sortening END*/
    this.auditAck = JSON.parse(this.storage.getItem('osc-aud-ack'));
    this.priorityQueue = JSON.parse(this.storage.getItem('osc-coder-pri'));
    this.getMIPSDisableCheck();
  }

  ZoomIn($event) {
    event.stopPropagation();
    this.zoom = this.zoom + 0.1;
    this.lineHeight = this.lineHeight + 0.1;
  }
  zoomOut($event) {
    event.stopPropagation();
    this.zoom = this.zoom - 0.1;
    this.lineHeight = this.lineHeight - 0.1;
  }

  zoomReset(event) {
    event.stopPropagation();
    this.zoom = 'normal';
    this.zoom = 1;
    this.lineHeight = 'inherit';
    this.lineHeight = 1.5;
  }

  ngOnInit() {
    this.initPlatformFunction();
    this.onFilterChanges();
  }

  initPlatformFunction() {
    this.fetchPatientInfo();
    this.fetchPatientRecordInfo();
    this.fetchPatientChart();
    this.fetchRemarks1();
  }

  // Feedback queue fetch
  public getAuditAcknowledgeQueue(): void {
    const params = this.prepareParams(
      [],
      [],
      this.auditAck,
      this.priorityQueue
    );
    this.getAuditAcknowledgeData(params);
  }

  // get audit acknowledge data else goto priority queue fetch
  public getAuditAcknowledgeData(params) {
    this.coderQueueService.fetchCoderQueue(params).subscribe((data: any) => {
      if (data && data.length > 0) {
        if (this.auditAck) {
          const audData = data.filter(element => element.isAck == true);
          if (audData.length > 0) {
            this.myMethodChangingQueryParams(audData[0]);
          } else {
            this.navigateQueue();
          }
        } else if (this.priorityQueue) {
          const priData = data.filter(element => element.priority == true);
          if (priData.length > 0) {
            this.myMethodChangingQueryParams(priData[0]);
          } else {
            this.navigateQueue();
          }
        } else {
          const workQue = data.filter(
            element => element.priority == false && element.isAck == false
          );
          if (workQue.length > 0) {
            this.myMethodChangingQueryParams(workQue[0]);
          } else {
            this.navigateQueue();
          }
        }
      } else {
        this.navigateQueue();
      }
    });
  }

  navigateQueue() {
    this._router.navigate(['/index/coder/queue']);
  }

  // Prepare parameters for search Information API service call
  private prepareParams(facilityList, modalityList, auditorConflict, priority) {
    const clientObject = this._commonCode.get_ConfidenceColor_Clientselection('clientSelectionObject');
    const role = clientObject.workRole.role;
    const params = {
      facility: [],
      modality: [],
      userId: this.storage.getItem('UserName'),
      teamLeadId: this.storage.getItem('TLId'),
      role: role ? role : '',
      auditorConflict: auditorConflict,
      priority: priority,
      location: clientObject.location,
      userConfiguration: clientObject.clientConfiguration,
      userType: clientObject.clientType,
      doj: clientObject.clientDOJ,
      speciality: clientObject.specialty,
      client: clientObject.client,
      targetsampling:
        this.storage.getItem('targetSampling') === 'null'
          ? null
          : JSON.parse(this.storage.getItem('targetSampling'))
    };
    return params;
  }

  fetchRemarks1() {
    this._platformService
      .searchByUniqueID(this.uniqueID)
      .subscribe(response => {
        if (response) {
          this.codedBy = response.codedBy;
          if (this.auditAck) {
            this.isDiscarded = response.chartReasonCode ? true : false;
            this.isL2Auditor = response.isRetroed ? response.isRetroed : false;
            this.isProccessed = response.isProcessed
              ? response.isProcessed
              : false;
            this.auditorRemarks = response.auditorComments;
            this.hideAckAuditor = response.auditorAllocatedTo ? false : true;
            this.auditorConflict = response.auditorConflict
              ? response.auditorConflict
              : false;
            this.l2auditorConflict = response.l2auditorConflict
              ? response.l2auditorConflict
              : false;
            this.errorFeedBack = response.coderErrorfound
              ? response.coderErrorfound
              : false;
            if (this.errorFeedBack) {
              this.fetchFeedBackCPTInfo();
              this.fetchFeedBackICDInfo();
            } else if (this.l2auditorConflict || this.auditorConflict) {
              this.fetchAucitorConflictICDInfo();
              this.fetchAucitorConflictCPTInfo();
            }
            this.suppressRowEdit = true;
            //  this.height = this.auditorRemarks === '' ? 603 : 548;
          } else {
            this.isSaved = response.isSaved ? response.isSaved : false;
            if (this.isSaved) {
              this.fetchRerouteCPTInfo();
              this.fetchRerouteICDInfo();
            } else {
              this.fetchPredictedICDInfo();
              this.fetchPredictedCPTInfo();
            }
          }
          if (response.raiDetails) {
            this.raiResponse = response.raiDetails.responses;
          }
          if (response.accessionNo) {
            this.accesionNo = response.accessionNo;
          }
        }
      });
  }

  private getMIPSDisableCheck() {
    this._platformService
      .fetchMIPSDisableCheck(this.facility)
      .subscribe(response => {
        if (response) {
          this.disableMIPS = response.pqrsMipsEnabled;
          this.disableCCI = response.ccienabled;
          this.disableLCD = response.lcdenabled;
          this.lookupGuidePath = response.lookupguidepath ? response.lookupguidepath : null;
        }
      });
  }

  doFilter(param) {
    if (param) {
      this._lookupDataService.getLookUpData(param).subscribe(data => {
        if (data) {
          this.lookUpOption = data;
        }
      });
    }
  }

  // For related Visit
  fetchRelatedVisit() {
    const myObj = {
      uniqueId: this.uniqueID,
      patientName: this.patientName,
      dos: this.dateOfService,
      modality: this.selectedModality,
      mrn: this.MRN
    };
    this.relatedVisitParentData = [];
    this._platformService.fetchRelatedChart(myObj).subscribe(data => {
      if (data) {
        this.relatedVisitParentData = data;
        this.relatedVisit = true;
        this.height = this.height = this.auditorRemarks === '' ? 584 : 536;
      }
    });
  }

  // For Patient Medical Report
  fetchPatientChart() {
    this.patientChart = [];
    this._platformService
      .fetchPatientChart(this.uniqueID)
      .subscribe((data: any) => {
        if (data) {
          this.patientChart = data.observationValue;
        }
      });
  }

  // For Pateint Informtation
  fetchPatientInfo() {
    this._platformService
      .fetchPatientInfo(this.uniqueID)
      .subscribe(response => {
        if (response) {
          this.patientInfoParent = response;
          let firstname = response['First name'];
          const lastChar = response['First name'].charAt(
            response['First name'].length - 1
          );
          firstname = lastChar === ' ' ? firstname.trim() : firstname;
          this.patientName = response['Last name'] + ' ' + firstname;
          this.dateOfService = response['DOS'];
          this.dateOfBirth = response['DOB'];
          this.patientInfoGender = response['Gender'];
        }
      });
  }

  // For Record Information
  fetchPatientRecordInfo() {
    this._platformService
      .fetchPatientRecordInfo(this.uniqueID)
      .subscribe((response: any) => {
        if (response) {
          this.patientRecordInfoParent = response;
          this.selectedModality = response.Modality;
          this.selectedFacility = response['Facility name'];
          if (this.selectedModality && this.dateOfService) {
            this.fetchRelatedVisit();
          }
        }
      });
  }

  // For ICD 10 - CM
  fetchPredictedICDInfo() {
    this.ICDInfoRequest = [];
    this.platform = 'coder';
    this._platformService
      .fetchPredictedICDInfo(this.uniqueID)
      .subscribe(response => {
        if (response && response.length > 0) {
          const predictedData = response;
          predictedData.forEach((ele, i) => {
            ele.counter = i++;
            ele.icdDescription = ele.icdChart;
          });
          this.ICDInfoRequest = predictedData;
        }
      });
  }

  // For CPT - CM
  fetchPredictedCPTInfo() {
    this.CPTInfoRequest = [];
    this.platform = 'coder';
    this._platformService
      .fetchPredictedCPTInfo(this.uniqueID)
      .subscribe(response => {
        if (response && response.length > 0) {
          const predictedData = response;
          predictedData.forEach((ele, i) => {
            ele.counter = i++;
            ele.cptDescription = ele.cptChart;
          });
          this.CPTInfoRequest = predictedData;
        }
      });
  }
  fetchAucitorConflictICDInfo() {
    this.ICDInfoRequest = [];
    const param = {
      l2Auditor: this.l2auditorConflict,
      uniqueId: this.uniqueID
    };
    this._platformService
      .getFeebackICDInfo(param)
      .subscribe((response: any) => {
        if (response && response.length > 0) {
          // to get auditor colDef's for coder Audit Acknowledge
          this.platform = 'auditor';
          this.ICDInfoRequest = response;
        }
      });
  }

  fetchAucitorConflictCPTInfo() {
    this.CPTInfoRequest = [];
    const param = {
      l2Auditor: this.l2auditorConflict,
      uniqueId: this.uniqueID
    };
    this._platformService
      .getFeedbackCPTInfo(param)
      .subscribe((response: any) => {
        if (response && response.length > 0) {
          this.platform = 'auditor';
          this.CPTInfoRequest = response;
        }
      });
  }

  fetchFeedBackICDInfo() {
    this.ICDInfoRequest = [];
    const params = {
      codedBy: '',
      coderAuditorFeedback: true,
      uniqueId: this.uniqueID
    };

    this._platformService.fetchFeedBackICDInfo(params).subscribe(response => {
      if (response && response.length > 0) {
        this.platform = 'auditor';
        this.ICDInfoRequest = response;
      }
    });
  }

  fetchFeedBackCPTInfo() {
    this.CPTInfoRequest = [];
    const params = {
      codedBy: '',
      coderAuditorFeedback: true,
      uniqueId: this.uniqueID
    };

    this._platformService.fetchFeedBackCPTInfo(params).subscribe(response => {
      if (response && response.length > 0) {
        this.platform = 'auditor';
        this.CPTInfoRequest = response;
      }
    });
  }

  fetchRerouteICDInfo() {
    this.ICDInfoRequest = [];
    const params = {
      codedBy: this.codedBy,
      coderAuditorFeedback: false,
      uniqueId: this.uniqueID,
      isPartial: true
    };

    this._platformService.fetchFeedBackICDInfo(params).subscribe(response => {
      if (response && response.length > 0) {
        this.platform = 'coder';
        this.ICDInfoRequest = response;
      }
    });
  }

  fetchRerouteCPTInfo() {
    this.CPTInfoRequest = [];
    const params = {
      codedBy: this.codedBy,
      coderAuditorFeedback: false,
      uniqueId: this.uniqueID,
      isPartial: true
    };

    this._platformService.fetchFeedBackCPTInfo(params).subscribe(response => {
      if (response && response.length > 0) {
        this.platform = 'coder';
        this.CPTInfoRequest = response;
      }
    });
  }

  ICDRowData(event) {
    this.fetchICDRowData = [];
    if (event) {
      this.fetchICDRowData = event;
    }
  }

  CPTRowData(event) {
    this.fetchCPTRowData = [];
    if (event) {
      this.fetchCPTRowData = event;
    }
  }

  hasEmptyElement(array) {
    if (!array.includes(array.dxRef)) {
      return false;
    }
  }

  saveClick() {
    const saveIcdInfo = this.fetchICDRowData;
    const saveCptInfo = this.fetchCPTRowData;

    this.validateCptInfo = [];
    this.validateIcdInfo = [];
    // get data for validations whose active state is true
    this.validateIcdInfo = this.fetchICDRowData.filter(
      element => element.isActive !== false
    );
    this.validateCptInfo = this.fetchCPTRowData.filter(
      element => element.isActive !== false
    );

    if (
      this.validateCptInfo.length === 0 ||
      this.validateIcdInfo.length === 0
    ) {
      this.errorService.throwWarning(
        '1 ICD and CPT is mandatory to save the chart'
      );
    } else {
      const dxIsEmpty = this._lookupDataService.cptDxRefValidationCheck(
        this.validateCptInfo
      );
      const isValidate = this._lookupDataService.validateBlankRecordCoder(
        this.validateCptInfo,
        this.validateIcdInfo
      );
      const conflictStatus =
        this.icdIsPristines || this.cptIsPristines ? true : false;
      const cptDuplicate = this.checkCptDup(this.validateCptInfo);
      if (dxIsEmpty && dxIsEmpty.code === 1) {
        if (
          isValidate.cptCodeIsEmpty.length === 0 &&
          isValidate.icdCodeIsEmpty.length === 0 &&
          isValidate.cptAccessionEmpty.length === 0
        ) {
          this.checkForLcdCciMipsValidation(conflictStatus);
        } else {
          const msg = this.getValidationMessage(isValidate);
          this.errorService.throwWarning(msg);
        }
      } else if (dxIsEmpty) {
        this.errorService.throwWarning(dxIsEmpty.msg);
      } else if (cptDuplicate) {
        this.errorService.throwWarning(dxIsEmpty.msg);
      } else {
        this.errorService.throwWarning(
          '1 ICD and CPT is mandatory to save the chart'
        );
      }
    }
  }

  checkForLcdCciMipsValidation(conflictStatus) {
    let setValidationError = false;
    let icdCheckStatus: boolean;
    const cptInfo = this.fetchCPTRowData;
    const icdInfo = this.fetchICDRowData;
    const lcdParam = this.prepareLCDParam(cptInfo, icdInfo);
    const cciParam = this.prepareCCIParam(cptInfo);
    const mipsParam = this.preapreMIPSParam(cptInfo);
    if (
      lcdParam.cptCodeEmpty === false &&
      lcdParam.icdCodeEmpty === false &&
      cciParam.cptCodeEmpty === false &&
      mipsParam.cptCodeEmpty === false
    ) {
      const param = {
        cciInput: null,
        lcdInput: null,
        mipsInput: null
      };
      if (this.lcdNcdClicked === false) {
        param.lcdInput = lcdParam.lcdInput;
      }
      if (this.cciClicked === false) {
        param.cciInput = cciParam.CCIInputMeasure;
      }
      // if (this.pqrsMipsClicked === false) {
      param.mipsInput = mipsParam.MIPSMeasureInput;
      this._platformService
        .fetchlcdmipsccicheck(param.cciInput, param.lcdInput, param.mipsInput)
        .subscribe(response => {
          if (response) {
            if (
              response.validDetails &&
              (response.validDetails.lcd ||
                response.validDetails.mips ||
                response.validDetails.cci)
            ) {
              setValidationError = true;
              if (this.lcdNcdClicked === false) {
                if (
                  response.validDetails &&
                  response.validDetails.lcd &&
                  response.validDetails.lcd.length > 0
                ) {
                  this.updateLCDNCDCol(response.validDetails.lcd);
                  this.lcdNcdClicked = true;
                }
              }
              if (this.cciClicked === false) {
                if (
                  response.validDetails &&
                  response.validDetails.cci &&
                  response.validDetails.cci.length > 0
                ) {
                  this.updateMoidifierCol(response.validDetails.cci);
                  this.cciClicked = true;
                }
              }
              if (response.validDetails.lcd !== null) {
                response.validDetails.lcd.every(function(element, index) {
                  if (
                    element.icdCheckStatus === 'Not Applicable' ||
                    element.icdCheckStatus === 'LCD Passed' ||
                    element.icdCheckStatus === 'NCD Passed'
                  ) {
                    icdCheckStatus = true;
                  } else {
                    icdCheckStatus = false;
                    return false;
                  }
                });
              }
              if (
                response.validDetails.mips === null &&
                response.validDetails.cci === null &&
                icdCheckStatus
              ) {
                setTimeout(() => {
                  this.saveCoderChart(cptInfo, icdInfo);
                }, 10); // Donot remove this as this will effect update lcdncd col bug
              } else {
                const dialogRef = this.dialog.open(MipsDialogComponent, {
                  hasBackdrop: true,
                  width: '950px',
                  data: {
                    uniqueId: this.uniqueID,
                    mipsData: response.validDetails.mips,
                    cciData: response.validDetails.cci,
                    lcdData: response.validDetails.lcd
                  },
                  disableClose: true
                });
              }
            } else {
              this.saveCoderChart(cptInfo, icdInfo);
            }
          }
        });
    }
  }

  checkCptDup(cptRow) {
    const valueArr = cptRow.map(function(item) {
      return item.name;
    });
    const isDuplicate = valueArr.some(function(item, idx) {
      return valueArr.indexOf(item) !== idx;
    });
    return true;
  }

  private getValidationMessage(isValidate): string {
    let message: string;
    if (isValidate.icdCodeIsEmpty.length > 0) {
      message = 'Please enter ICD code.';
    } else if (isValidate.cptCodeIsEmpty.length > 0) {
      message = 'Please enter CPT code.';
    } else if (isValidate.cptAccessionEmpty.length > 0) {
      message = 'Please enter CPT Accession Number.';
    }
    return message;
  }

  public saveCoderChart(cptInfo, icdInfo) {
    // this.btnOpts.active = true;
    const saveIcdObj = [];
    const saveCptObj = [];

    icdInfo.forEach((element, index) => {
      saveIcdObj.push(element);
    });

    if (this.saveDeletedICDObj && this.saveDeletedICDObj.length > 0) {
      this.saveDeletedICDObj.forEach(ele => {
        saveIcdObj.push(ele);
      });
    }

    cptInfo.forEach((element, index) => {
      saveCptObj.push(element);
    });

    if (this.saveDeletedCPTObj && this.saveDeletedCPTObj.length > 0) {
      this.saveDeletedCPTObj.forEach(ele => {
        saveCptObj.push(ele);
      });
    }

    if (this.isSaved) {
      this._platformService
        .saveCodedChartReroute(
          saveCptObj,
          saveIcdObj,
          this.uniqueID,
          this.selectedModality,
          this.icdIsPristines || this.cptIsPristines ? true : false
        )
        .subscribe(
          responseList => {
            // this.btnOpts.active = false;
            if (responseList) {
              // this._toastr.setRootViewContainerRef(this.vcr);
              this.errorService.throwSuccess('Chart saved successfully!');
              this.getAuditAcknowledgeQueue();
            } else {
              if (responseList[0].apierror) {
                this.errorService.throwInfo(responseList[0].apierror.message);
              } else if (responseList[1].apierror) {
                this.errorService.throwInfo(responseList[0].apierror.message);
              }
            }
          },
          error => {
            // this.btnOpts.active = false;
            this.errorService.throwError(error);
          }
        );
    } else {
      this._platformService
        .saveCodedChart(
          saveCptObj,
          saveIcdObj,
          this.uniqueID,
          this.selectedModality,
          this.icdIsPristines || this.cptIsPristines ? true : false
        )
        .subscribe(
          responseList => {
            if (responseList) {
              // this._toastr.setRootViewContainerRef(this.vcr);
              this.errorService.throwSuccess('Chart saved successfully!');
              this.getAuditAcknowledgeQueue();
            }
          },
          error => {
            let err = error.json();
            if (err && err.apierror) {
              // this._toastr.setRootViewContainerRef(this.vcr);
              this._toastr.error(err.apierror.message);
              // this.btnOpts.active = false;
            }
          }
        );
    }
  }

  partialSave(event, reasonName) {
    const cptInfo = this.fetchCPTRowData;
    const icdInfo = this.fetchICDRowData;
    this.reason = reasonName;
    this._platformService
      .auditorChartService(event, cptInfo, icdInfo, this.platform)
      .subscribe(responseList => {
        if (responseList) {
          this.openDialog(responseList, this.reason, cptInfo, icdInfo);
        }
      });
  }

  openDialog(responseList, reasonName, cptInfo, icdInfo) {
    const dialogRef = this.dialog.open(MatDialogOverviewComponent, {
      hasBackdrop: true,
      disableClose: false,
      width: '500px',
      data: {
        dataList: responseList,
        reason: reasonName,
        uniqueId: this.uniqueID,
        platform: 'coder',
        cptInfo: cptInfo ? cptInfo : '',
        icdInfo: icdInfo ? icdInfo : '',
        isSaved: this.isSaved,
        modality: this.selectedModality
      }
    });
    dialogRef.backdropClick().subscribe(event => {
      event.preventDefault();
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        // this._toastr.setRootViewContainerRef(this.vcr);
        this.errorService.throwSuccess(
          'Chart ' + reasonName + 'ed' + ' successfully!'
        );
        this._platformService.fetchdataOnCountSave().subscribe(res => {});
        this.getAuditAcknowledgeQueue();
      } else {
        // this._toastr.setRootViewContainerRef(this.vcr);
      }
    });
  }

  highlightText(event: any) {
    if (event) {
      this.searchTerm = ' ';
      setTimeout(() => {
        this.searchTerm = event;
      }, 10);
    }
  }

  // Add ICD New Row on Click
  childEventClickedICD(event: any) {
    this.getSectionSplit(event, 'ICD');
  }

  // Add ICD New Row on Click
  childEventClickedCPT(event: any) {
    this.getSectionSplit(event, 'CPT');
  }

  removeAttr(textValue) {
    const doc = new DOMParser().parseFromString(textValue, 'text/html');
    const docArr = doc.getElementsByClassName('highlighted');
    for (let i = 0; i < docArr.length; i++) {
      docArr[i].removeAttribute('data-timestamp');
      docArr[i].removeAttribute('style');
      docArr[i].removeAttribute('data-highlighted');
    }
    return doc;
  }

  getSectionSplit(innerHtml, code) {
    const originalText = this.removeAttr(innerHtml.textInnerHtml);
    const param = {
      uniqueId: this.uniqueID,
      originalText: originalText.body.innerHTML
    };
    this._platformService.sectionSplitService(param).subscribe(res => {
      if (res) {
        let el: any = originalText.body.querySelectorAll('.highlighted');
        el.forEach(element => {
          element.classList.remove('highlighted');
          element.classList.add('htn');
        });
        if (code === 'ICD') {
          this.addICDrowData(
            res,
            innerHtml.highlightedText,
            originalText.body.innerHTML,
            code
          );
        } else {
          this.addCPTrowData(
            res,
            innerHtml.highlightedText,
            originalText.body.innerHTML,
            code
          );
        }
      }
    });
  }

  appendRationale(originalText, sectionArr) {
    sectionArr.forEach(element => {
      const html = '<span class="htb">$&</span>';
      const reg = new RegExp('\\b' + element.section + '\\b', 'i');
      originalText = originalText.replace(reg, html);
    });
    return originalText;
  }

  addICDrowData(event, selectedWord, originalText, code) {
    originalText = this.appendRationale(originalText, event);
    this.lcdNcdClicked = false;
    const newIcdRow = {
      id: null,
      predictIcdCode: '',
      aapcIcdDescription: '',
      icdDescription: selectedWord,
      rationaleData: originalText,
      rationaleSection: event,
      isActive: true,
      comments: ''
    };
    this.clickedEventICD = newIcdRow;
  }

  getDxval(event) {
    this.lastCptDxVal = event;
  }

  addCPTrowData(event, selectedWord, originalText, code) {
    originalText = this.appendRationale(originalText, event);
    this.cciClicked = false;
    this.pqrsMipsClicked = false;
    const newCptRow = {
      id: null,
      predictCptCode: '',
      modifier: '',
      units: '1',
      dxRef: this.lastCptDxVal === undefined ? '1' : this.lastCptDxVal,
      accession: this.accesionNo.split(' ')[0],
      aapcCptDescription: '',
      cptDescription: selectedWord,
      rationaleData: originalText,
      rationaleSection: event,
      isActive: true,
      comments: ''
    };
    this.clickedEventCPT = newCptRow;
  }

  openModalDialog(uniqueID, display, status) {
    this.dialogRefModal = this.dialog.open(CoderModalChildComponent, {
      hasBackdrop: true,
      disableClose: true,
      width: '1480px',
      panelClass: 'modal-dialog',
      data: {
        uniqueId: this.uniqueID,
        displayName: display,
        status: status
      }
    });

    this.dialogRefModal.afterClosed().subscribe(data => {
      if (data) {
        this.fetchRelatedVisit();
      }
    });
  }

  showModal(event) {
    this.display = event;
    this.UID = event.api.getSelectedRows()[0].uniqueId;
    const status = event.api.getSelectedRows()[0].chartStatus;
    this.openModalDialog(this.UID, this.display, status);
  }

  getModalityData(event) {
    this.selectedModality = event;
  }

  public openDialogForAcknowledge1() {
    if (this.errorFeedBack) {
      this._platformService.getTLFeedBack(this.uniqueID).subscribe(data => {
        if (data) {
          const dialogRef = this.dialog.open(AuditAcknowledgeDialogComponent, {
            hasBackdrop: true,
            width: '1200px',
            data: {
              codingRole: 'coder',
              uniqueId: this.uniqueID,
              platform: 'coder',
              status: 'agree',
              cptData: data[0],
              icdData: data[1], // data[1],
              remarks: this.auditorRemarks,
              isProcessed: this.isProccessed,
              hideAckAuditor: this.hideAckAuditor,
              auditorConflict: this.auditorConflict,
              l2auditorConflict: this.l2auditorConflict,
              errorFeedBack: this.errorFeedBack
            },
            disableClose: true
          });
          dialogRef.afterClosed().subscribe(result => {
            if (result) {
              // this._toastr.setRootViewContainerRef(this.vcr);
              this.errorService.throwSuccess(
                'Chart Acknowledged Successfully.'
              );
              this._platformService.fetchdataOnCountSave().subscribe(res => {});
              this.getAuditAcknowledgeQueue();
            }
          });
        }
      });
    } else {
      this._platformService
        .getAcknowledge1(
          this.uniqueID,
          this.l2auditorConflict,
          this.isDiscarded
        )
        .subscribe(data => {
          if (data) {
            const dialogRef = this.dialog.open(
              AuditAcknowledgeDialogComponent,
              {
                hasBackdrop: true,
                width: '1200px',
                data: {
                  codingRole: 'coder',
                  uniqueId: this.uniqueID,
                  platform: 'coder',
                  status: 'agree',
                  cptData: data[0],
                  icdData: data[1], // data[1],
                  remarks: this.auditorRemarks,
                  isProcessed: this.isProccessed,
                  hideAckAuditor: this.hideAckAuditor,
                  auditorConflict: this.auditorConflict,
                  l2auditorConflict: this.l2auditorConflict,
                  errorFeedBack: this.errorFeedBack,
                  isDiscarded: this.isDiscarded
                },
                disableClose: true
              }
            );
            dialogRef.afterClosed().subscribe(result => {
              if (result) {
                this._platformService
                  .fetchdataOnCountSave()
                  .subscribe(res => {});
                this.getAuditAcknowledgeQueue();
              }
            });
          }
        });
    }
  }
  // public openDialogForAcknowledge() {
  //   const isFromL2Auditor = false;
  //   this._platformService
  //     .getAcknowledge(this.uniqueID, isFromL2Auditor)
  //     .subscribe(acknowledge => {
  //       if (acknowledge) {
  //         const dialogRef = this.dialog.open(AuditAcknowledgeDialogComponent, {
  //           hasBackdrop: true,
  //           width: '1200px',
  //           data: {
  //             codingRole: 'coder',
  //             uniqueId: this.uniqueID,
  //             platform: 'coder',
  //             status: 'agree',
  //             cptData: acknowledge[0],
  //             icdData: acknowledge[1],
  //             remarks: this.auditorRemarks,
  //             isProcessed: this.isProccessed,
  //             hideAckAuditor: this.hideAckAuditor
  //           },
  //           disableClose: true
  //         });
  //         dialogRef.afterClosed().subscribe(result => {
  //           if (result) {
  //             this.getAuditAcknowledgeQueue();
  //           }
  //         });
  //       }
  //     });
  // }

  // get deleted ICD
  public deletedIcd(event) {
    let param = this.checkDupDeletedIcd(event);
    if (!param) {
      this.saveDeletedICDObj.push(event);
    }
  }

  checkDupDeletedIcd(event) {
    const data = this.saveDeletedICDObj.filter(res => res.id === event.id);
    if (data.length > 0) {
      return true;
    } else {
      return false;
    }
  }

  public deletedCpt(event) {
    this.saveDeletedCPTObj.push(event);
  }

  // CCI MIPS LCD Validation functions
  public prepareLCDParam(cptInfo, icdInfo) {
    let cptCodeEmpty = false;
    let icdCodeEmpty = false;
    let CPTCodes = '';
    let ICDCodes = '';
    const lcdInput = {
      uniqueId: this.uniqueID,
      cptInput: '',
      icdInput: ''
    };

    cptInfo.forEach((element, index) => {
      if (element.predictCptCode || element.cptCode) {
        if (index > 0) {
          CPTCodes = CPTCodes + '~';
        }
        const predictCptCode = element.predictCptCode + '*' + element.dxRef;
        const cptCode = element.cptCode + '*' + element.dxRef;
        CPTCodes = element.predictCptCode
          ? CPTCodes + predictCptCode
          : CPTCodes + cptCode;
      } else {
        cptCodeEmpty = true;
        this.errorService.throwWarning(
          'Please enter CPT Code for LCD/NCD check'
        );
      }
    });

    icdInfo.forEach((element, index) => {
      if (element.predictIcdCode || element.icdCode) {
        if (index > 0) {
          ICDCodes = ICDCodes + '~';
        }
        ICDCodes = element.predictIcdCode
          ? ICDCodes + element.predictIcdCode
          : ICDCodes + element.icdCode;
      } else {
        icdCodeEmpty = true;
        this.errorService.throwWarning(
          'Please enter ICD Code for LCD/NCD check'
        );
      }
    });

    lcdInput.cptInput = CPTCodes;
    lcdInput.icdInput = ICDCodes;

    return { lcdInput, cptCodeEmpty, icdCodeEmpty };
  }

  preapreMIPSParam(cptInfo) {
    let cptCodeEmpty = false;
    const MIPSMeasureInput = {
      cptcode: '',
      uniqueId: this.uniqueID
    };
    let CPTCodes = '';
    if (cptInfo && cptInfo.length) {
      cptInfo.forEach((element, index) => {
        if (element.predictCptCode || element.cptCode) {
          if (index > 0) {
            CPTCodes = CPTCodes + '~';
          }
          CPTCodes = element.predictCptCode
            ? CPTCodes + element.predictCptCode
            : CPTCodes + element.cptCode;
        } else {
          cptCodeEmpty = true;
          this.errorService.throwWarning(
            'Please enter CPT Code for MIPS Measure'
          );
        }
      });
    }
    MIPSMeasureInput.cptcode = CPTCodes;

    return { MIPSMeasureInput, cptCodeEmpty };
  }

  prepareCCIParam(cptInfo) {
    let cptCodeEmpty = false;
    const CCIInputMeasure = {
      cptMod: '',
      currentChartID: this.uniqueID
    };
    let CPTCodes = '';

    if (cptInfo && cptInfo.length) {
      cptInfo.forEach((element, index) => {
        if (element.predictCptCode || element.cptCode) {
          if (index > 0) {
            CPTCodes = CPTCodes + '~';
          }
          CPTCodes = element.predictCptCode
            ? CPTCodes + element.predictCptCode
            : CPTCodes + element.cptCode;
          CPTCodes = CPTCodes + '*';
          CPTCodes = element.modifier
            ? CPTCodes + element.modifier
            : CPTCodes + '';
        } else {
          cptCodeEmpty = true;
          this.errorService.throwWarning(
            'Please enter CPT Code for CCI Modifier'
          );
        }
      });
    }
    CCIInputMeasure.cptMod = CPTCodes;
    return { CCIInputMeasure, cptCodeEmpty };
  }

  public updateLCDNCDCol(lcdDetails) {
    const param = [];
    lcdDetails.forEach(element => {
      param.push({
        lcdStatus: element.icdCheckStatus,
        icdCode: element.icdCode
      });
    });
    const x = {
      status: param,
      colName: 'predictIcdCode'
    };
    this.lcdCheckStatus = x;
  }

  public updateMoidifierCol(response) {
    const param = [];
    let message = false;
    response.forEach(element => {
      param.push({
        modifier: element.cciModifier,
        cptcode: element.cpt
      });
      if (element.cciModifier === 'Not Applicable') {
        message = true;
      }
      const x = {
        modifier: param,
        colName: 'predictIcdCode'
      };
      this.cciCheck = x;
    });
    return message;
  }

  public lcdCheck(event) {
    event.stopPropagation();
    this.lcdNcdClicked = true;
    const cptInfo = this.fetchCPTRowData;
    const icdInfo = this.fetchICDRowData;
    const isValidate = this._lookupDataService.validateBlankRecordCoder(
      cptInfo,
      icdInfo
    );
    if (isValidate.icdCodeIsEmpty.length === 0) {
      const inputParam = this.prepareLCDParam(cptInfo, icdInfo);
      if (
        inputParam.cptCodeEmpty === false &&
        inputParam.icdCodeEmpty === false
      ) {
        this._platformService
          .fetchlcdmipsccicheck(null, inputParam.lcdInput, null)
          .subscribe(res => {
            if (res) {
              if (res.validDetails && res.validDetails.lcd.length > 0) {
                this.updateLCDNCDCol(res.validDetails.lcd);
                this.errorService.throwSuccess('LCD status updated.');
              }
            }
          });
      }
    } else {
      const msg = this.getValidationMessage(isValidate);
      this.errorService.throwWarning(msg);
    }
  }

  public getCCIModifier(event) {
    event.stopPropagation();
    this.cciClicked = true;
    const cptInfo = this.fetchCPTRowData;
    const inputParam = this.prepareCCIParam(cptInfo);

    if (!inputParam.cptCodeEmpty) {
      let msg;
      this._platformService
        .fetchlcdmipsccicheck(inputParam.CCIInputMeasure, null, null)
        .subscribe(response => {
          if (response) {
            if (
              response.validDetails &&
              response.validDetails.cci &&
              response.validDetails.cci.length > 0
            ) {
              msg = this.updateMoidifierCol(response.validDetails.cci);
              this.errorService.throwSuccess('Modifier updated.');
            } else {
              msg = true;
            }
          }
          if (msg) {
            this.errorService.throwInfo('CCI modifier is not applicable');
          }
        });
    }
  }

  public getMIPSMeasure(event) {
    event.stopPropagation();
    this.pqrsMipsClicked = true;
    const cptInfo = this.fetchCPTRowData;
    const inputParam = this.preapreMIPSParam(cptInfo);

    if (!inputParam.cptCodeEmpty) {
      this._platformService
        .fetchlcdmipsccicheck(null, null, inputParam.MIPSMeasureInput)
        .subscribe(response => {
          if (response) {
            if (
              response.validDetails &&
              response.validDetails.mips &&
              response.validDetails.mips.length > 0
            ) {
              const dialogRef = this.dialog.open(MipsDialogComponent, {
                hasBackdrop: true,
                width: '950px',
                data: {
                  uniqueId: this.uniqueID,
                  mipsData: response.validDetails.mips
                },
                disableClose: true
              });
            } else {
              this.errorService.throwInfo('MIPS not applicable.');
            }
          }
        });
    }
  }

  onFilterChanges(): void {
    this.myControl.valueChanges.subscribe(val => {
      this.doFilter(val);
    });
  }

  checkIcdIsPrisitine(event) {
    if (event) {
      this.icdIsPristines = event;
    }
  }

  checkCptIsPrisitine(event) {
    if (event) {
      this.cptIsPristines = event;
    }
  }
}
