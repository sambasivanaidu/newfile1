import { Component, OnInit, ViewChild } from '@angular/core';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { environment } from '../../../../../environments/environment';
import { LocationStrategy } from '@angular/common';
import { CommonCodeService } from '../../../../_shared-services/common-code.services';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { QueueService } from '../../../../services/main-pages/queue.service';

@Component({
  selector: 'app-coder-queue',
  templateUrl: './coder-queue.component.html',
  styleUrls: ['./coder-queue.component.scss']
})
export class CoderQueueComponent implements OnInit {
  panelOpenState = true;
  CoderWorkQueueRequest: any = [];
  PriorityQueueRequest: any = [];
  CoderAuditAcknowledgeRequest: any = [];
  username: string;
  platformType = '';
  customCollapsedHeight = '40px';
  customExpandedHeight = '45px';
  priorityQueueLabel = 'Priority Queue';
  workQueueLabel = 'Work Queue';
  auditAckLabel = 'Coder Audit Acknowledge';
  activetab = '';
  facilitySelectModel: any = [];
  modalitySelectModel: any = [];
  expanded = true;
  chartInfoParam: any;
  priorityQueueData: any = [];
  isPriorityData: boolean;
  isAuditAck: boolean;
  isWorkQueue: boolean;
  tabSelectedIndex: number;
  userRole: any;
  facilityOptionList: any;
  public coderQueueForm: FormGroup;
  public storage: Storage = environment.storage;
  modalityOptionList: string[] = [];
  userSubRole = 'coder';
  @ViewChild('filters') filters;
  public height = 77;

  constructor(
    public _coderQueueService: QueueService,
    public _toastr: ToastsManager,
    private location: LocationStrategy,
    private _commonCode: CommonCodeService,
    private formBuilder: FormBuilder
  ) {
    this.intializeCoderQueueForm();
    this.username = this.storage.getItem('UserName');
    if (this.storage.getItem('clientSelectionObject')) {
      this.userRole = this._commonCode.get_ConfidenceColor_Clientselection('clientSelectionObject');
    }
    this.facilityOptionList = JSON.parse(this.storage.getItem('facilityList')); // this.storage.getItem('osc-fac-lis') ?JSON.parse(CryptoJS.AES.decrypt(this.storage.getItem('osc-fac-lis'), 'oscar').toString(CryptoJS.enc.Utf8)) : [];
    this.modalityOptionList = [];
    history.pushState(null, null, window.location.href);
    this.location.onPopState(() => {
      history.pushState(null, null, window.location.href);
      console.clear();
    });
    this.formControlChanges();
  }

  public ngOnInit(): void {
    this.getQueue();
  }

  public tabClick(event): void {
    if (event) {
      this.activetab = event.tab.textLabel;
      window.dispatchEvent(new Event('resize'));
    }
  }

  // Prepare parameters for search Information API service call
  prepareParams(facilityList, modalityList, auditorConflict, priority) {
    if (this.storage.getItem('clientSelectionObject')) {
      const clientObject = this._commonCode.get_ConfidenceColor_Clientselection('clientSelectionObject');
      const role = clientObject.workRole.role;
      const params = {
        facility: this.facilitySelectModel ? facilityList : [],
        modality: this.modalitySelectModel ? modalityList : [],
        userId: this.storage.getItem('UserName'),
        teamLeadId: this.storage.getItem('TLId'),
        role: role ? role : '',
        auditorConflict: auditorConflict,
        priority: priority,
        location: clientObject.location,
        userConfiguration: clientObject.clientConfiguration,
        userType: clientObject.clientType,
        doj: clientObject.clientDOJ,
        speciality: clientObject.specialty,
        client: clientObject.client,
        adminSubRole: this.userSubRole,
        targetsampling:
          this.storage.getItem('targetSampling') === 'null'
            ? null
            : JSON.parse(this.storage.getItem('targetSampling'))
      };
      return params;
    }
  }

  public intializeCoderQueueForm() {
    this.coderQueueForm = this.formBuilder.group({
      facility: new FormControl([]),
      modality: new FormControl([])
    });
  }

  formControlChanges() {
    this.coderQueueForm.controls.facility.valueChanges.subscribe(val => {
      this.selectedFacilityModalityList(val);
    });
  }

  public selectedFacilityModalityList(data) {
    data = data.filter(function(element) {
      return element !== undefined;
    });
    if (data.length === 0) {
      this.coderQueueForm.controls.modality.setValue([]);
      this.modalityOptionList = [];
    } else {
      this.modalityOptionList.length = 0;
      const selectedModalityList = this.coderQueueForm.controls.modality.value
        ? this.coderQueueForm.controls.modality.value
        : [];
      const list = [];
      data.forEach(function(value) {
        if (value.modality !== 'undefined') {
          value.modality.forEach(function(value1) {
            const dataexists = list.filter(eleme => eleme.name === value1);
            if (dataexists.length === 0) {
              const elem = { name: value1, value: value1 };
              list.push(elem);
            }
          });
        }
      });
      this.modalityOptionList = list;
      this.coderQueueForm.controls.modality.patchValue(list);
    }
  }

  public createParams() {
    return this.prepareParams(
      this.coderQueueForm.controls.facility.value
        ? this.coderQueueForm.controls.facility.value.map(eleme => {
            return eleme.name;
          })
        : [],
      this.coderQueueForm.controls.modality.value
        ? this.coderQueueForm.controls.modality.value.map(eleme => {
            return eleme.name;
          })
        : [],
      false,
      false
    );
  }

  public getQueue() {
    const params = this.createParams();
    this.resetData();
    this._coderQueueService.fetchCoderQueue(params).subscribe((data: any) => {
      if (data && data.length > 0) {
        const audAckData = data.filter(element => element.isAck == true);
        if (audAckData.length > 0) {
          this.platformType = 'updatecoderstartedon';
          this.isPriorityData = false;
          this.isAuditAck = true;
          this.isWorkQueue = false;
          this.tabSelectedIndex = 0;
          this.CoderAuditAcknowledgeRequest = audAckData;
          this.activetab = this.auditAckLabel;
          this.storage.setItem('osc-aud-ack', 'true');
          this.storage.setItem('osc-coder-pri', 'false');
        } else {
          const priorityData = data.filter(element => element.priority == true);
          if (priorityData.length > 0) {
            this.platformType = 'updatecoderstartedon';
            this.storage.setItem('osc-coder-pri', 'true');
            this.storage.setItem('osc-aud-ack', 'false');
            this.isPriorityData = true;
            this.isAuditAck = false;
            this.isWorkQueue = false;
            this.activetab = this.priorityQueueLabel;
            this.tabSelectedIndex = 1;
            this.PriorityQueueRequest = priorityData;
          } else {
            const workQueueData = data.filter(
              element => element.isAck == false && element.priority == false
            );
            if (workQueueData.length > 0) {
              this.platformType = 'updatecoderstartedon';
              this.CoderWorkQueueRequest = workQueueData;
              this.storage.setItem('osc-coder-pri', 'false');
              this.storage.setItem('osc-aud-ack', 'false');
              this.isPriorityData = false;
              this.isAuditAck = false;
              this.isWorkQueue = true;
              this.tabSelectedIndex = 2;
              this.activetab = this.workQueueLabel;
            } else {
              this.isAuditAck = false;
              this.isWorkQueue = true;
              this.tabSelectedIndex = 2;
              this.activetab = this.workQueueLabel;
            }
          }
        }
      } else{
        this.isAuditAck = false;
        this.isWorkQueue = true;
        this.tabSelectedIndex = 2;
        this.activetab = this.workQueueLabel;
      }
    });
  }

  public resetData() {
    this.CoderAuditAcknowledgeRequest = [];
    this.PriorityQueueRequest = [];
    this.CoderWorkQueueRequest = [];
    this.isAuditAck = false;
    this.isWorkQueue = true;
    this.tabSelectedIndex = 2;
    this.activetab = this.workQueueLabel;
  }
}
