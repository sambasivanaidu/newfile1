import { async, ComponentFixture, TestBed, tick } from '@angular/core/testing';
import { CoderQueueComponent } from './coder-queue.component';
import { ToastsManager, ToastOptions } from 'ng2-toastr';
import { ContextMenuService, ContextMenuModule } from 'ngx-contextmenu';
import {
  MatButtonModule,
  MatIconModule,
  MatInputModule,
  MatFormFieldModule,
  MatAutocompleteModule,
  MatExpansionModule,
  MatDialogModule
} from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AgGridModule } from 'ag-grid-angular';
import { RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { FlexLayoutModule } from '@angular/flex-layout';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DatePipe } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import {
  HttpModule
} from '@angular/http';
import { APP_BASE_HREF } from '@angular/common';
import * as params from 'assets/testMockData/coderQueue.json';
import { of } from 'rxjs/observable/of';
// import { MatFacilityDdComponent } from '../../../../imports/_utilities/mat-facility-dd/mat-facility-dd.component';
// import { MatModalityDd1Component } from '../../../../imports/_utilities/mat-modality-dd1/mat-modality-dd1.component';
import { WorkQueueComponent } from '../../oscar-shared/work-queue/work-queue.component';
// import { MaterialModule } from '../../../../imports/material.module';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
// import { PlatformService } from '../../../../_shared-services/paltform-services/platform-service.service';
import { LookupDataService } from '../../../../_shared-services/unrelated-data-services/lookup-data.service';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
import { HeaderAuthenticationToken } from '../../../../auth/authetication-header';
import { DateFormatter } from '../../../../imports/_utilities/date-formatter';
import { SMEService } from '../../sme/sme.component.service';
import { CommonCodeService } from '../../../../_shared-services/common-code.services';
import { PlatformService } from '../../../../services/main-pages/paltform-services/platform-service.service';
import { QueueService } from '../../../../services/main-pages/queue.service';
describe('CoderQueueComponent', () => {
  let component: CoderQueueComponent;
  let fixture: ComponentFixture<CoderQueueComponent>;
  let elementRefference;
  let originalTimeout;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        CoderQueueComponent,
        // MatFacilityDdComponent,
        // MatModalityDd1Component,
        WorkQueueComponent
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        HttpModule,
        MatButtonModule,
        MatIconModule,
        MatInputModule,
        MatFormFieldModule,
        MatAutocompleteModule,
        FormsModule,
        // MaterialModule,
        ReactiveFormsModule,
        MatExpansionModule,
        AgGridModule.withComponents([
          CoderQueueComponent,
          // MatFacilityDdComponent,
          // MatModalityDd1Component,
          WorkQueueComponent
        ]),
        ContextMenuModule,
        RouterTestingModule,
        MatDialogModule,
        FlexLayoutModule,
        BrowserAnimationsModule,
        HttpClientTestingModule,
        PerfectScrollbarModule
      ],
      providers: [
        { provide: APP_BASE_HREF, useValue: '/' },
        PlatformService,
        LookupDataService,
        // ErrorHandlingServices,
        HeaderAuthenticationToken,
        ToastsManager,
        ToastOptions,
        ContextMenuService,
        DateFormatter,
        DatePipe,
        SMEService,
        CommonCodeService,
        QueueService
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
    fixture = TestBed.createComponent(CoderQueueComponent);
    component = fixture.componentInstance;
    elementRefference = fixture.debugElement;
    fixture.detectChanges();
  });

  afterEach(() => {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = originalTimeout;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('#getQueue() should be called on #search is clicked', () => {
    spyOn(component, 'getQueue');
    elementRefference.nativeElement.querySelector('#search').click();
    expect(component.getQueue).toHaveBeenCalled();
  });

  it('#getQueue function execution for feedback queue', () => {
    spyOn(component._coderQueueService, 'fetchCoderQueue').and.returnValue(
      of(params['data'])
    );
    component._coderQueueService
      .fetchCoderQueue(params['data'])
      .subscribe((data: any) => {
        expect(data).not.toBeNull;
        const audAckData = data.filter(element => element.isAck == true);
        expect(audAckData).not.toBeNull();
        component.platformType = 'updatecoderstartedon';
        component.isPriorityData = false;
        component.isAuditAck = true;
        component.isWorkQueue = false;
        component.tabSelectedIndex = 0;
        component.CoderAuditAcknowledgeRequest = audAckData;
        component.activetab = this.auditAckLabel;
        fixture.detectChanges();
      });
  });

  it('#getQueue function execution for priority queue', () => {
    spyOn(component._coderQueueService, 'fetchCoderQueue').and.returnValue(
      of(params['data'])
    );
    component._coderQueueService
      .fetchCoderQueue(params['data'])
      .subscribe((data: any) => {
        const audAckData = null;
        expect(audAckData).toBeNull();

        const priorityData = data.filter(element => element.priority == true);
        expect(priorityData).not.toBeNull();
        component.platformType = 'updatecoderstartedon';
        component.isPriorityData = true;
        component.isAuditAck = false;
        component.isWorkQueue = false;
        component.activetab = this.priorityQueueLabel;
        component.tabSelectedIndex = 1;
        component.PriorityQueueRequest = priorityData;
        fixture.detectChanges();
      });
  });

  it('#getQueue function execution for work queue', () => {
    // tick(100);
    spyOn(component._coderQueueService, 'fetchCoderQueue').and.returnValue(
      of(params['data'])
    );
    component._coderQueueService
      .fetchCoderQueue(params['data'])
      .subscribe((data: any) => {
        const audAckData = null;
        expect(audAckData).toBeNull();

        const priorityData = null;
        expect(priorityData).toBeNull();

        const workQueueData = data.filter(
          element => element.isAck == false && element.priority == false
        );
        expect(workQueueData).not.toBeNull();
        component.platformType = 'updatecoderstartedon';
        component.CoderWorkQueueRequest = workQueueData;
        component.isPriorityData = false;
        component.isAuditAck = false;
        component.isWorkQueue = true;
        component.tabSelectedIndex = 2;
        component.activetab = this.workQueueLabel;
        fixture.detectChanges();
      });
  });

  it('#getQueue function execution for no data', () => {
    spyOn(component._coderQueueService, 'fetchCoderQueue').and.returnValue(
      of(params['data'])
    );
    component._coderQueueService
      .fetchCoderQueue(params['data'])
      .subscribe((data: any) => {
        const audAckData = null;
        expect(audAckData).toBeNull();

        const priorityData = null;
        expect(priorityData).toBeNull();

        const workQueueData = null;
        expect(workQueueData).toBeNull();

        component.isAuditAck = false;
        component.isWorkQueue = true;
        component.tabSelectedIndex = 2;
        component.activetab = this.workQueueLabel;
        fixture.detectChanges();
      });
  });
});
