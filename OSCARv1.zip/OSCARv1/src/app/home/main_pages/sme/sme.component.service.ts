import { Injectable } from '@angular/core';
import { environment } from '../../../../environments/environment';
import { HeaderAuthenticationToken } from '../../../auth/authetication-header';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators/map';
@Injectable()
export class SMEService {
  public httpOption;
  public envURL = environment.URL;
  public httpHeaders;
  constructor(
    private httpClient: HttpClient,
    private httpHeader: HeaderAuthenticationToken
  ) {
    this.httpOption = this.httpHeader.setHeaderToken();
  }
  public fetchSMEData(): any {
    const APIUrl = this.envURL + 'tlsmesummary/smeTlAllocation';
    return this.httpClient.get(APIUrl, this.httpOption);
  }
  public fetchSMEQueueData(params) {
    const APIUrl = this.envURL + 'chartinformation/searchchartinformation';
    return this.httpClient.post(APIUrl, params, this.httpOption).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
  public startTimerForSME(params) {
    const myObj = {
      currentTime: Date.now(),
      openCoderPlatform: true,
      uniqueId: params
    };
    const url = this.envURL + 'chartinformation/updatesmestartedon';
    return this.httpClient.post(url, myObj, this.httpOption);
  }
}
