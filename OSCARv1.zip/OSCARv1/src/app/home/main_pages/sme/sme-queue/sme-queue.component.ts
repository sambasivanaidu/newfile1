import {
  Component,
  OnInit
} from '@angular/core';
import { ToastsManager } from 'ng2-toastr';
import * as CryptoJS from 'crypto-js';
import { SMEService } from '../sme.component.service';
import { environment } from '../../../../../environments/environment';
import { LocationStrategy } from '@angular/common';
import {
  FormGroup,
  FormControl,
  FormBuilder
} from '../../../../../../node_modules/@angular/forms';
import { CommonCodeService } from '../../../../_shared-services/common-code.services';
@Component({
  selector: 'app-sme-queue',
  templateUrl: './sme-queue.component.html',
  providers: [SMEService]
})
export class SMEQueueComponent implements OnInit {
  public panelOpenState: boolean = true;
  public SMEQueueRequest: any = [];
  public platformType: string = '';
  public username: string;
  public storage: Storage = environment.storage;
  userRole: any;
  facilityOptionList: any = [];
  modalityOptionList: any = [];
  public smeQueueForm: FormGroup;
  public userSubRole = 'sme';
  public height = 80;
  constructor(
    private smeService: SMEService,
    public _toastr: ToastsManager,
    public location: LocationStrategy,
    private formBuilder: FormBuilder,
    private _commonCode: CommonCodeService
  ) {
    this.intializedashboardForm();
    this.username = this.storage.getItem('UserName');
    const clientSelectionObj = this.storage.getItem('clientSelectionObject');
    this.userRole = JSON.parse(
      CryptoJS.AES.decrypt(clientSelectionObj, 'oscar').toString(
        CryptoJS.enc.Utf8
      )
    );
    this.facilityOptionList = JSON.parse(this.storage.getItem('facilityList'));
    this.modalityOptionList = [];
    history.pushState(null, null, window.location.href); /* preventing back button in browser implemented by 'Samba Siva'  */
    this.location.onPopState(() => {
      history.pushState(null, null, window.location.href);
      console.clear();
    }); /* preventing back button END */
    this.onChnages();
  }
  public ngOnInit(): void {
    this.getQueue();
  }
  public intializedashboardForm() {
    this.smeQueueForm = this.formBuilder.group({
      facility: new FormControl([]),
      modality: new FormControl([])
    });
  }
  toggleFilter(event){
    if (event === 'block'){
      this.height = 71;
    } else{
      this.height = 80;
    }
  }
  onChnages() {
    this.smeQueueForm.controls.facility.valueChanges.subscribe(val => {
      this.selectedFacilityModalityList(val);
    });
  }
  public selectedFacilityModalityList(data) {
    data = data.filter(function(element) {
      return element !== undefined;
    });
    if (data.length === 0) {
      this.smeQueueForm.controls.modality.setValue([]);
      this.modalityOptionList = [];
    } else {
      this.modalityOptionList.length = 0;
      const selectedModalityList = this.smeQueueForm.controls.modality.value
        ? this.smeQueueForm.controls.modality.value
        : [];
      const list = [];
      data.forEach(function(value) {
        if (value.modality !== 'undefined') {
          value.modality.forEach(function(value1) {
            const dataexists = list.filter(eleme => eleme.name === value1);
            if (dataexists.length === 0) {
              const elem = { name: value1, value: value1 };
              list.push(elem);
            }
          });
        }
      });
      this.modalityOptionList = list;
      this.smeQueueForm.controls.modality.patchValue(list);
    }
  }
  public createParams() {
    const role = this._commonCode.get_ConfidenceColor_Clientselection('clientSelectionObject');
    return {
      facility: this.smeQueueForm.controls.facility.value
        ? this.smeQueueForm.controls.facility.value.map(eleme => {
            return eleme.name;
          })
        : [],
      modality: this.smeQueueForm.controls.modality.value
        ? this.smeQueueForm.controls.modality.value.map(eleme => {
            return eleme.name;
          })
        : [],
      role: role.workRole.role,
      userId: this.storage.getItem('UserName'),
      adminSubRole: this.userSubRole,
      teamLeadId: this.storage.getItem('TLId')
    };
  }
  public getQueue() {
    const params = this.createParams();
    this.SMEQueueRequest = [];
    this.smeService.fetchSMEQueueData(params).subscribe((data: any) => {
      if (data) {
        this.SMEQueueRequest = data;
        this.platformType = 'sme';
      }
    });
  }
}
