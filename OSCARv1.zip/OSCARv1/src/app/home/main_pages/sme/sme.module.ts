import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SMEQueueComponent } from './sme-queue/sme-queue.component';
import { SMEPlatformComponent } from './sme-platform/sme-platform.component';
import { LearningSystemComponent } from './learning-system/learning-system.component';
import { BreadCrumbModule } from '../reports/bread-crumb/bread-crumb.module';
import { MaterialModule } from '../../../imports/material.module';
import { RouterModule, Routes } from '@angular/router';
import { MatDynamicDdModule } from '../../../imports/_utilities/mat-dynamic-dd/mat-dynamic-dd.module';
import { AgGridModule } from 'ag-grid-angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  PasswordModule,
  InputTextModule,
  PanelModule,
  DialogModule,
  ConfirmDialogModule,
  SharedModule,
  ContextMenuModule
} from 'primeng/primeng';
import { ChartModule } from 'primeng/chart';
import { OscarSharedModule } from '../oscar-shared/oscar-shared.module';
import { PipesModule } from '../../../imports/pipes/pipes.module';
import { CheckBoxSelectorComponent } from './learning-system/check-box-selector/check-box-selector.component';
import { CoderModalChildComponent } from '../oscar-shared/coder-modal-child/coder-modal-child.component';
import { ContextMenuService } from 'ngx-contextmenu';
import { MipsDialogModule } from '../../../imports/_utilities/mips-dialog/mips-dialog.module';

const routes: Routes = [
  { path: 'queue', component: SMEQueueComponent },
  { path: 'platform', component: SMEPlatformComponent },
  { path: 'learning', component: LearningSystemComponent }
];

@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
    RouterModule.forChild(routes),
    MatDynamicDdModule,
    AgGridModule,
    FormsModule,
    ReactiveFormsModule,
    PasswordModule,
    InputTextModule,
    PanelModule,
    DialogModule,
    ConfirmDialogModule,
    SharedModule,
    ChartModule,
    OscarSharedModule,
    PipesModule,
    BreadCrumbModule,
    ContextMenuModule,
    MipsDialogModule
  ],
  declarations: [
    SMEQueueComponent,
    SMEPlatformComponent,
    LearningSystemComponent,
    CheckBoxSelectorComponent
  ],
  providers: [
    ContextMenuService
  ],
  entryComponents: [CoderModalChildComponent]
})
export class SmeModule {}
