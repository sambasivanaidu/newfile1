import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  Input,
  OnChanges,
  ViewChild
} from '@angular/core';
import { GridOptions } from 'ag-grid';
import { FormControl } from '@angular/forms';
import { environment } from '../../../../../environments/environment';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
import { MatDialog, MatDialogRef } from '@angular/material';
import { CoderModalChildComponent } from '../../oscar-shared/coder-modal-child/coder-modal-child.component';
import { PlatformService } from '../../../../services/main-pages/paltform-services/platform-service.service';
@Component({
  selector: 'app-learning-system',
  templateUrl: './learning-system.component.html',
  styleUrls: ['./learning-system.component.scss']
})
export class LearningSystemComponent implements OnInit {
  public storage = environment.storage;
  public GridOptions: GridOptions;
  public columnDefs;
  public rowData: any;
  public gridApi;
  public gridColumnApi;
  public frameworkComponents;
  public rowSelection;
  public editType;
  public paginationPageSize;
  public attrgridComponent;
  public getNodeChildDetails;
  smeLearningData: any;
  accessionNoLength: any = 0;
  isRowSelectable;
  public dataScience: any;
  public selectedList: any = [];
  public filteredData: any = [];
  public count: any;
  public getFilerValue: any;
  public username: any;
  public filterCountData: any;
  public filterlist: any = [];
  public filterListGettingCount: any = 0;
  public apicount: number = 0;
  dialogRefModal: MatDialogRef<any>;
  @ViewChild('filters') filters;
  public correctCodeList = [
    {
      key: 'predicted',
      value: 'Predicted'
    },
    {
      key: 'coder',
      value: 'Coder'
    },
    {
      key: 'auditor',
      value: 'Auditor'
    },
    {
      key: 'tl',
      value: 'TL'
    }
  ];
  @Input() smeInfoRequest: any;
  @Output() getSelectedLearningRow = new EventEmitter();
  @Output() approvedData = new EventEmitter();
  @ViewChild('matCheck') matCheck;
  @ViewChild('matUnCheck') matUnCheck;
  selectedCptNodeValue;
  formFilters: FormControl;
  colfield: any;
  public height = 75;
  constructor(
    public _platformService: PlatformService,
    private errorService: ErrorHandlingServices,
    public dialog: MatDialog
  ) {
    this.formFilters = new FormControl([]);
  }
  toggleFilter(event){
    if (event === 'block'){
      this.height = 66;
    } else{
      this.height = 75;
    }
  }
  ngOnInit() {
    // initially load all records on page load
    const obj = { category: ['cpt', 'icd', 'modifier'] };
    this.GridInit();
    this.rowData = [];
    this.smeLearningData = [];
    this._platformService.fetchsmelearning(obj).subscribe((data: any) => {
      if (data && data.length > 0) {
        this.smeLearningData = data;
        this.prepareRowData();
      } else {
        this.rowData = [];
      }
    });
    this.username = this.storage.getItem('UserName');
    this.updateFilterListCount();
    // initially load lookup data on page load
  }
  // update lookup data on  approved and discard action
  updateFilterListCount() {
    this.filterlist = [];
    this._platformService.countCptIcdModSmeLearning().subscribe(data => {
      if (data) {
        this.filterlist = data.map(element => {
          return {
            name: element[0] + '(' + element[1] + ')',
            value: element[1],
            category: element[0]
          };
        });
      }
    });
  }
  updateDataOnApprovedDiscard() {
    this.rowData = [];
    this.smeLearningData = [];
    const obj = { category: ['cpt', 'icd', 'modifier'] };
    this._platformService.fetchsmelearning(obj).subscribe((data: any) => {
      if (data && data.length > 0) {
        this.smeLearningData = data;
        this.prepareRowData();
      } else {
        this.rowData = [];
      }
    });
  }
  // getting data from lookup  then calling api for getting relative records beased on lookup selection
  searchQueue() {
    const obj = {
      category: this.formFilters.value
        ? this.formFilters.value.map(element => {
            return element.category.toLowerCase();
          })
        : []
    };
    this.rowData = [];
    this.smeLearningData = [];
    this._platformService.fetchsmelearning(obj).subscribe((data: any) => {
      if (data && data.length > 0) {
        this.smeLearningData = data;
        this.prepareRowData();
      } else {
        this.rowData = [];
      }
    });
  }
  // prepare ag grid data
  prepareRowData() {
    const tlPreparedData = [];
    if (this.smeLearningData) {
      this.smeLearningData.forEach((data, Index) => {
        tlPreparedData.push({
          checkbox: false,
          code: data.code,
          aapcdescription: data.aapcdescription,
          phrase: data.chartphrase,
          uniqueId: data.uniqueid,
          category: data.category.toUpperCase(),
          id: data.id
        });
      });
      this.rowData = tlPreparedData;
    }
  }
  // open chart on click on  code value
  onCellClicked(params) {
    this.colfield = params.colDef.field;
    if (params.colDef.field === 'code') {
      this.dialogRefModal = this.dialog.open(CoderModalChildComponent, {
        hasBackdrop: true,
        disableClose: true,
        width: '1480px',
        panelClass: 'modal-dialog',
        data: {
          uniqueId: params.data.uniqueId,
          displayName: params,
          status: '',
          reference: 'sme'
        }
      });
      this.dialogRefModal.afterClosed().subscribe(data => {
        if (data) {
        }
      });
    }
  }
  // approved data when click on Send To Learning Button
  sendToLearning() {
    const list = this.gridApi.getSelectedRows();
    const saveList = [];
    if (list.length !== 0) {
      list.forEach(element => {
        this.rowData.forEach(rowData => {
          if (element.id === rowData.id) {
            rowData.checkbox = true;
          }
        });
        const obj = {
          chartInformationInput: {
            category: element.category.toLowerCase(),
            status: 'approved',
            uniqueid: element.uniqueId,
            updatedby: this.username,
            updatedon: Date.now()
          },
          cptIcdInfo: {
            aapcdescription: element.aapcdescription,
            category: element.category,
            code: element.code,
            createdby: this.username,
            createdon: Date.now(),
            id: element.id,
            phrase: element.phrase,
            uniqueid: element.uniqueId
          }
        };
        saveList.push(obj);
      });
      this._platformService.updateSmeLearning(saveList).subscribe(
        data => {
          if (data) {
            this.errorService.throwSuccess('Data Approved Successfully!');
            this.updateFilterListCount();
            this.updateDataOnApprovedDiscard();
          }
        },
        error => {
          this.errorService.throwError(error);
        }
      );
    } else {
      this.errorService.throwStringError('Please Select the Data!');
    }
  }
  // discard data when click on Send To Learning Button
  discard() {
    const list = this.gridApi.getSelectedRows();
    const saveList = [];
    if (list.length !== 0) {
      list.forEach(element => {
        this.rowData.forEach(rowData => {
          if (element.id === rowData.id) {
            rowData.checkbox = true;
          }
        });
        const obj = {
          chartInformationInput: {
            category: element.category.toLowerCase(),
            status: 'discard',
            uniqueid: element.uniqueId,
            updatedby: this.username,
            updatedon: Date.now()
          },
          cptIcdInfo: {
            aapcdescription: element.aapcdescription,
            category: element.category,
            code: element.code,
            createdby: this.username,
            createdon: Date.now(),
            id: element.id,
            phrase: element.phrase,
            uniqueid: element.uniqueId
          }
        };
        saveList.push(obj);
      });
      this._platformService.updateSmeLearning(saveList).subscribe(
        data => {
          if (data) {
            this.errorService.throwSuccess('Data Discard Successfully!');
            this.updateFilterListCount();
            this.updateDataOnApprovedDiscard();
          }
        },
        error => {
          this.errorService.throwError(error);
        }
      );
    } else {
      this.errorService.throwStringError('Please select the data');
    }
  }
  GridInit() {
    this.GridOptions = <GridOptions>{
      context: {
        componentParent: this
      },
      onRowClicked: RowClickEventHandler,
      suppressRowClickSelection: true
    };
    this.GridOptions.columnDefs = [
      {
        width: 45,
        pinned: 'left',
        suppressSizeToFit: true,
        suppressFilter: true,
        headerCheckboxSelectionFilteredOnly: true,
        editable: false,
        checkboxSelection: function(params) {
          return params.columnApi.getRowGroupColumns().length === 0;
        },
        headerCheckboxSelection: function(params) {
          return params.columnApi.getRowGroupColumns().length === 0;
        }
      },
      {
        headerName: 'checkbox',
        field: 'checkbox',
        width: 170,
        hide: true
      },
      {
        headerName: 'id',
        field: 'id',
        width: 170,
        hide: true
      },
      {
        headerName: 'uniqueid',
        field: 'uniqueId',
        width: 170,
        tooltipField: 'uniquid',
        hide: true
      },
      {
        headerName: 'Category',
        field: 'category',
        width: 170,
        tooltipField: 'catagory'
      },
      {
        headerName: 'Code',
        field: 'code',
        width: 170,
        tooltipField: 'code',
        cellClass: 'hyper-link',
        cellStyle: {
          fontSize: '14px'
        }
      },
      {
        headerName: 'AAPC Description',
        field: 'aapcdescription',
        width: 170,
        tooltipField: 'aapcdescription'
      },
      {
        headerName: 'Phrase',
        field: 'phrase',
        width: 500,
        tooltipField: 'Phase'
      }
    ];
    this.attrgridComponent = {
      _cellCheckbox: gridCheckbox()
    };
    this.rowData = [];
    this.rowSelection = 'multiple';
    this.paginationPageSize = 50;
  }

  private fetchValue(data, key) {
    let value;
    if (data) {
      data.forEach(element => {
        value = element[key];
      });
    }
    return value;
  }
  GridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }
  changeSelectedRow(ev, event, data) {
    let param = {};
    let cellValue;
    let colHeaderName;
    const CPTelement = event.eGridCell.offsetParent.getElementsByClassName(
      'selectedCptCell'
    );
    const ICDelement = event.eGridCell.offsetParent.getElementsByClassName(
      'selectedIcdCell'
    );
    if (this.gridApi.getFocusedCell().column.colDef.id === 'CPT') {
      if (CPTelement.length > 0) {
        CPTelement[0].classList.remove('selectedCptCell');
      }
      param = {
        selectedCptCode: event.value,
        selectedCptDesc: event.eGridCell.title,
        selectedCptModifier: data.modifier,
        selectedCptRef: data.ref
      };
      cellValue = JSON.stringify(param);
      colHeaderName = 'selectedCptRowData';
      event.eGridCell.classList.add('selectedCptCell');
    } else {
      if (ICDelement.length > 0) {
        ICDelement[0].classList.remove('selectedIcdCell');
      }
      param = {
        selectedIcdCode: event.value,
        selectedIcdDesc: event.eGridCell.title
      };
      cellValue = JSON.stringify(param);
      colHeaderName = 'selectedIcdRowData';
      event.eGridCell.classList.add('selectedIcdCell');
    }
    event.node.setDataValue(colHeaderName, cellValue);
    event.context.componentParent.getSelectedLearningRow.emit(event);
  }
  OnBodyScroll(event) {
    this.gridApi.stopEditing();
  }
}
function RowClickEventHandler(event) {
  event.node.setSelected(true);
  event.context.componentParent.getSelectedLearningRow.emit(event);
}
export class SmeGridModel {
  chartId: string;
  desc: string;
  coderName: string;
  predictedCptCode: boolean;
  predictedIcdCode: boolean;
  coderCorrectedCptCode: boolean;
  coderCorrectedIcdCode: boolean;
  auditorName: string;
  auditorCorrectedCptCode: boolean;
  auditorCorrectedIcdCode: boolean;
  accepted: boolean;
  rejected: boolean;
  updatedOn: string;
  updatedBy: string;
}
function gridCheckbox() {
  function agGridCellCheckbox() {}
  agGridCellCheckbox.prototype.getGui = function() {
    return this.eGui;
  };
  agGridCellCheckbox.prototype.getValue = function() {
    this.isChecked = this.eGui.childNodes[1].checked;
    return this.cellValue;
  };
  agGridCellCheckbox.prototype.isPopup = function() {
    return true;
  };
  agGridCellCheckbox.prototype.afterGuiAttached = function() {
    const changedWidth = this.colWidth + 'px';
    this.eGui.parentElement.style.width = changedWidth;
  };
  agGridCellCheckbox.prototype.init = function(param) {
    const _this = param;
    this.cellValue = _this.value;
    this.rowIndex = _this.rowIndex + '_' + _this.column.colDef.colId;
    this.colWidth = _this.column.actualWidth;
    let isCheckedValue;
    const eCelllabel = document.createElement('label');
    eCelllabel.setAttribute('class', 'grid-cell-checkbox-container');
    eCelllabel.setAttribute('for', this.cellValue + '_' + this.rowIndex);
    eCelllabel.innerText = this.cellValue;
    if (_this.column.colDef.id === 'CPT') {
      isCheckedValue = validateIsChecked(
        _this,
        _this.node.data.selectedCptRowData,
        'CPT'
      );
    } else {
      isCheckedValue = validateIsChecked(
        _this,
        _this.node.data.selectedIcdRowData,
        'ICD'
      );
    }
    const eCellIput = document.createElement('input');
    eCellIput.checked = isCheckedValue;
    eCellIput.type = 'radio';
    eCellIput.id = this.cellValue + '_' + this.rowIndex;
    eCellIput.name = this.rowIndex;
    eCellIput.value = this.cellValue;
    eCellIput.addEventListener('click', function(ev) {
      let cellData;
      ev.toElement.parentElement.classList.add('selectedCptCell'); // = '#165d1880';
      if (_this.column.colDef.id === 'CPT') {
        isCheckedValue = _this.node.data.selectedCptRowData;
        cellData = getRelatedCellData(_this);
      } else {
        isCheckedValue = _this.node.data.selectedIcdRowData;
        cellData = _this.value;
      }
      _this.context.componentParent.changeSelectedRow(ev, _this, cellData);
    });
    const eCellSpan = document.createElement('span');
    eCellSpan.setAttribute('class', 'checkmark');
    eCelllabel.appendChild(eCellIput);
    eCelllabel.appendChild(eCellSpan);
    this.eGui = eCelllabel;
  };
  return agGridCellCheckbox;
}
function validateIsChecked(obj, paramToValidate, colId) {
  if (obj && paramToValidate) {
    const param = getRelatedCellData(obj);
    const selectedOptionValue = JSON.parse(paramToValidate);
    if (colId === 'CPT') {
      if (
        obj.value === selectedOptionValue.selectedCptCode &&
        param.modifier === selectedOptionValue.selectedCptModifier &&
        param.ref === selectedOptionValue.selectedCptRef
      ) {
        return true;
      } else {
        return false;
      }
    } else {
      if (obj.value === selectedOptionValue.selectedIcdCode) {
        return true;
      } else {
        return false;
      }
    }
  }
}
function getRelatedCellData(obj) {
  let param;
  if (obj.column.colDef.colId === 'CCPT') {
    param = {
      modifier: obj.node.data.coderModifier,
      ref: obj.node.data.coderRef
    };
  } else if (obj.column.colDef.colId === 'ACPT') {
    param = {
      modifier: obj.node.data.auditorModifier,
      ref: obj.node.data.auditorRef
    };
  } else if (obj.column.colDef.colId === 'PCPT') {
    param = {
      modifier: obj.node.data.predictModifier,
      ref: obj.node.data.predictRef
    };
  } else if (obj.column.colDef.colId === 'TLCPT') {
    param = {
      modifier: obj.node.data.tlModifier,
      ref: obj.node.data.tlRef
    };
  } else {
  }
  return param;
}
