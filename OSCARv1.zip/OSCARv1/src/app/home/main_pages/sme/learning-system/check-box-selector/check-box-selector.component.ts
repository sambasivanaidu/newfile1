import { Component, OnInit } from '@angular/core';
import { AfterViewInit, ViewChild, ViewContainerRef } from '@angular/core';

import { ICellRendererAngularComp } from 'ag-grid-angular';
@Component({
  selector: 'app-check-box-selector',
  templateUrl: './check-box-selector.component.html',
  styleUrls: ['./check-box-selector.component.scss']
})
export class CheckBoxSelectorComponent implements ICellRendererAngularComp {
  public params: any;
  constructor() { }
  agInit(params: any): void {
    this.params = params;
  }

  refresh(params): boolean {
    params.data.checkbox = params.value;
    params.api.refreshCells(params);
    return false;
  }

}
