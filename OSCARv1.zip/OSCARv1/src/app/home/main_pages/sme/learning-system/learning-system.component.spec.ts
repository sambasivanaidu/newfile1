import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LearningSystemComponent } from './learning-system.component';
// import { FormControl } from "./oscar_new/OSCARv1/node_modules/@angular/forms";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatAutocompleteModule,
    MatExpansionModule,
    MatDialogModule
} from '@angular/material';
import { AgGridModule } from 'ag-grid-angular';
import { ToastsManager } from 'ng2-toastr';
import { ToastOptions } from 'ng2-toastr';
import { RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { FlexLayoutModule } from '@angular/flex-layout';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MatDynamicDdComponent } from '../../../../imports/_utilities/mat-dynamic-dd/mat-dynamic-dd.component';
import { CUSTOM_ELEMENTS_SCHEMA, ViewContainerRef } from '@angular/core';
// import { CoderQueueService } from '../../coder-queue/coder-queue.service';
import { HeaderAuthenticationToken } from '../../../../auth/authetication-header';
import { APP_BASE_HREF } from '@angular/common';
import { HttpModule } from '@angular/http';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
import { of } from 'rxjs/observable/of';
import { NgProgress } from 'ngx-progressbar';
import { QueueService } from '../../../../services/main-pages/queue.service';
import { PlatformService } from '../../../../services/main-pages/paltform-services/platform-service.service';
describe('LearningSystemComponent', () => {
    let component: LearningSystemComponent;
    let fixture: ComponentFixture<LearningSystemComponent>;
    let elementRefference;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [
                LearningSystemComponent,
                MatDynamicDdComponent
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
            imports: [
                HttpModule,
                MatButtonModule,
                MatIconModule,
                MatInputModule,
                MatFormFieldModule,
                MatAutocompleteModule,
                FormsModule,
                ReactiveFormsModule,
                MatExpansionModule,
                AgGridModule.forRoot(),
                RouterModule,
                RouterTestingModule,
                MatDialogModule,
                FlexLayoutModule,
                BrowserAnimationsModule,
                HttpClientTestingModule,
            ],
            providers: [
                { provide: APP_BASE_HREF, useValue: '/' },
                PlatformService,
                ToastsManager,
                ToastOptions,
                QueueService,
                HeaderAuthenticationToken,
                // ErrorHandlingServices,
                ViewContainerRef,
                NgProgress,
                ErrorHandlingServices
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(LearningSystemComponent);
        component = fixture.componentInstance;
        elementRefference = fixture.debugElement;
    });

    it('Component Successfully Created', () => {
        expect(component).toBeTruthy();
    });

    it('initiating filters', () => {
        expect(component.formFilters.touched).toBe(false);
    });

    it('#onCellClicked() checking columndef field on component initaiting', () => {
        spyOn(component, 'onCellClicked');
        expect(component.colfield).toBe(undefined);
    });

    it('#updateFilterListCount() checking initial length of filterlist array ', () => {
        spyOn(component, 'updateFilterListCount');
        const length = component.filterlist.length;
        expect(length).toEqual(0);
    });

    it('#updateFilterListCount updating Lookup data for calling api', () => {
        spyOn(component._platformService, 'countCptIcdModSmeLearning').
            and.returnValue(of({ response: 1 }));

        component._platformService
            .countCptIcdModSmeLearning().subscribe(responseList => {
                expect(responseList).toEqual({ response: 1 });
            });
    });

    it('#ngOnInit initially updating AgGrid Rows', () => {
        const obj = {
            category: ['cpt', 'icd', 'modifier']
        };
        spyOn(component._platformService, 'fetchsmelearning').
            and.returnValue(of({ response: 1 }));
        component._platformService
            .fetchsmelearning(obj).subscribe(responseList => {
                expect(responseList).toEqual({ response: 1 });
            });
    });

});
