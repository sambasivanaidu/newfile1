import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CheckBoxSelectorComponent } from './check-box-selector.component';
import { FormsModule } from '@angular/forms';

describe('CheckBoxSelectorComponent', () => {
  let component: CheckBoxSelectorComponent;
  let fixture: ComponentFixture<CheckBoxSelectorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule],
      declarations: [CheckBoxSelectorComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckBoxSelectorComponent);
    component = fixture.componentInstance;
    component.params = 'any param';
    fixture.detectChanges();
  });

  it('should create', () => {
    const fixtures = TestBed.createComponent(CheckBoxSelectorComponent);
    const app = fixtures.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });
});

// describe('Adder', () => {
//   // A jasmine spec
//   it('should be able to add two whole numbers', () => {
//     expect(4).toEqual(4);
//   });

//   it('should be able to add a whole number and a negative number', () => {
//     expect(2-1).toEqual(1);
//   });

//   it('should be able to add a whole number and a zero', () => {
//     expect(2).toEqual(2);
//   });
// });
