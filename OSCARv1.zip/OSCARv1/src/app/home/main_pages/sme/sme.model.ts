interface PredictedCodesModel {
    predictref: string;
    predictcptdesc: string;
    predicticdcode: string;
    predictmodi: string;
    predicticddesc: string;
    predictcptcode: string;
}

interface CoderCodesModel {
    codercptdesc: string;
    codercptcode: string;
    codericddesc: string;
    codericdcode: string;
    codermodi: string;
    coderref: string;
}

interface AuditorCodesModel {
    auditoricddesc: string;
    auditorcptcode: string;
    auditorcptdesc: string;
    auditoricdcode: string;
    auditorref: string;
    auditormodi: string;
}

interface TlCodesModel {
    tlicdcode: string;
    tlref: string;
    tlmodi: string;
    tlcptcode: string;
    tlicddesc: string;
    tlcptdesc: string;
}

interface SMEResponseModel {
    uniqueid: string;
    predictedCodes: PredictedCodesModel[];
    coderid: string;
    coderCodes: CoderCodesModel[];
    auditorid: string;
    auditorCodes: AuditorCodesModel[];
    tlId: string;
    tlCodes: TlCodesModel[];
}

export {
    SMEResponseModel
};
