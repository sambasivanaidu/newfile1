import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  AfterContentInit
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DateFormatter } from '../../../imports/_utilities/date-formatter';
import { MatGridList } from '@angular/material';
import { MediaChange, ObservableMedia } from '@angular/flex-layout';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { ValidationService } from '../../../services/validation.service';
import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter
} from '@angular/material-moment-adapter';
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE
} from '@angular/material/core';
import * as _moment from 'moment';
import * as CryptoJS from 'crypto-js';
import { ClientSelectionService } from '../../../users/client-selection/client-selection.service';
import { DashboardService } from './dashboard.service';
import { environment } from '../../../../environments/environment';
import { DateService } from '../../../_shared-services/date-service/date.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  providers: [
    DashboardService,
    DateFormatter,
    ValidationService,
    ClientSelectionService,
    DateService,
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS }
  ]
})
export class DashboardComponent implements OnInit, AfterContentInit {
  @ViewChild('grid') grid: MatGridList;
  @ViewChild('filters') filters;
  public dashboardName;
  public serviceRole: string;
  public clientObj;
  public UserName: string;
  public teamLeadname: string;
  public toDateModel: any = new Date();
  public formDateModel: any = new Date();
  public facilitySelectModel: any;
  public QACoderSelectModel: any;
  public title = 'dashboard page';
  public panelOpenState = true;
  public customCollapsedHeight = '40px';
  public customExpandedHeight = '45px';
  public breakpoint: number;
  public barchartData: any;
  public dougnutCharts: any;
  public linechartsData: any;
  public chartResponsive = true;
  public dashboardFormGroup: FormGroup;
  public fromDateErrorMessage = 'Please enter valid date.';
  public toDateErrorMessage = 'Please enter valid date.';
  public maxDate = new Date();
  dashboardSummary;
  public isTLVisible = false;
  public isSDHVisible = false;
  public isMgrVisible = false;
  public userRole;
  public userCode;
  public facilityOptionList: any = [];
  public roleOptionList: any = [];
  public teamLeadOptionList: any = [];
  public clientList = [];
  public specialtyList = [];
  public locationList = [];
  public elementRef: ElementRef;
  public facilityChartData: any;
  public totalSuspended = 0;
  public storage: Storage = environment.storage;
  public clientSessionObject;
  @ViewChild('btnLgFullWidth') btnLgFullWidth: any;
  dataSource: Object;
  public myQueueVal: number = 0;
  public acknowledgedVal: number = 0;
  public gridByBreakpoint = {
    xl: 4,
    lg: 4,
    md: 4,
    sm: 2,
    xs: 1
  };
  public clientLocation;
  public clientSpecialty;
  public donutChartOptions = {
    plugins: {
      datalabels: {
        align: 'middle',
        anchor: 'middle',
        borderRadius: 4,
        // backgroundColor: '#fffff',
        padding: 4,
        color: 'black',
        font: {
          weight: 'bold',
          size: 12
        }
      }
    },
    lineOnHover: {
      enabled: true,
      lineColor: '#bbb',
      lineWidth: 1
    },
    pointRadius: 0,
    pointHoverRadius: 5,
    pointHoverBackgroundColor: 'white',
    legend: {
      position: 'left'
    }
  };
  public stackBarOptions = {
    responsive: false,
    maintainAspectRatio: false,
    scales: {
      yAxes: [
        {
          stacked: true,
          barThickness: 50
        }
      ],
      xAxes: [
        {
          stacked: true,
          barThickness: 50
        }
      ]
    },
    plugins: {
      datalabels: {
        align: 'middle',
        anchor: 'middle',
        borderRadius: 4,
        // backgroundColor: '#2d2d2d',
        padding: 4,
        color: 'black',
        font: {
          weight: 'bold',
          size: 12
        }
      }
    }
  };
  public lineChartOptions = {
    plugins: {
      datalabels: {
        align: 'top',
        anchor: 'middle',
        borderRadius: 4,
        // backgroundColor: '#27bc56',
        margin: 4,
        color: 'black',
        font: {
          weight: 'bold',
          size: 12
        }
      }
    }
  };
  public nameOptionList: any = [];
  constructor(
    private route: ActivatedRoute,
    private dashboardService: DashboardService,
    private observableMedia: ObservableMedia,
    private formBuilder: FormBuilder,
    private _clientSelectionService: ClientSelectionService,
    elementRef: ElementRef,
    private dateService: DateService
  ) {
    this.elementRef = elementRef;
    this.UserName = this.storage.getItem('UserName');
    this.teamLeadname = this.storage.getItem('TLId');
    this.clientObj = JSON.parse(
      CryptoJS.AES.decrypt(
        this.storage.getItem('clientSelectionObject'),
        'oscar'
      ).toString(CryptoJS.enc.Utf8)
    );
    this.userRole = this.clientObj.workRole.role; // .toLowerCase();
    this.userCode = this.clientObj.workRole.code;
    this.getFacilityList();
    this.clientObj = JSON.parse(
      CryptoJS.AES.decrypt(
        this.storage.getItem('clientSelectionObject'),
        'oscar'
      ).toString(CryptoJS.enc.Utf8)
    );
    this.clientLocation = this.clientObj.location;
    this.clientSpecialty = this.clientObj.specialty;
  }
  public ngOnInit(): void {
    this.getDashboardName();
    this.dashboardPageOnInit();
    this.intializedashboardForm();
    this.onChnages();
    if (this.clientObj.workRole.category.toUpperCase() === 'TEAM LEAD') {
      this.getCoderQAList();
    } else if (this.clientObj.workRole.category.toUpperCase() === 'MANAGER') {
      this.getTeamLeadList();
    }
    this.getdashboardData();
  }
  public getFacilityList() {
    this.facilityOptionList = JSON.parse(this.storage.getItem('facilityList'));
  }
  public getCoderQAList() {
    this.roleOptionList = [
      { id: 'CODER', name: 'Production' },
      { id: 'AUDITOR', name: 'Quality Control Analyst' }
      // {id: 'SME', name: 'Process Coach'}
    ];
    this.dashboardFormGroup.controls.role.setValue(this.roleOptionList[0]);
    this.dashboardFormGroup.updateValueAndValidity();
  }
  public getSpecialtyList(event): void {
    if (event.value) {
      this._clientSelectionService
        .specialtyService(event.value)
        .subscribe(data => {
          if (data) {
            this.specialtyList = data;
          }
        });
    }
  }
  public getTeamLeadList() {
    const param = {
      manager: 'manager',
      userId: this.storage.getItem('UserName')
    };
    this.dashboardService.getTeamLeadService(param).subscribe((data: any) => {
      const tempData = [];
      data.forEach(element => {
        tempData.push({
          id: element,
          name: element
        });
      });
      this.teamLeadOptionList = tempData;
    });
  }
  public getLocationList(event) {
    if (event.value) {
      this._clientSelectionService
        .locationService(event.value.name)
        .subscribe(data => {
          if (data) {
            this.locationList = data;
          }
        });
    }
  }
  public getDashboardName(): void {
    this.dashboardName = this.clientObj.workRole.category.toUpperCase();
    this.serviceRole =
      this.clientObj.workRole.code === 'admin'
        ? 'tl'
        : this.clientObj.workRole.code;
    if (this.clientObj.workRole.category === 'TEAM LEAD') {
      this.isTLVisible = true;
      this.getRoles();
      this.facilityOptionList.length = [];
    } else if (this.clientObj.workRole.category === 'SDH') {
      this.isSDHVisible = true;
      this.getTeamLeadList();
    }
  }
  public ngAfterContentInit(): void {
    this.observableMedia.asObservable().subscribe((change: MediaChange) => {
      if (this.grid) {
        this.grid.cols = this.gridByBreakpoint[change.mqAlias];
      }
    });
  }
  public dashboardPageOnInit() {
    this.route.queryParams.subscribe(params => {
      if (params.title) {
        this.title = params.title;
      }
    });
    if (this.route.snapshot.routeConfig.path === '404') {
      this.title = '404 unknown link';
    }
    this.breakpoint = window.innerWidth <= 400 ? 6 : 2;
  }
  public intializedashboardForm() {
    this.dashboardFormGroup = this.formBuilder.group({
      fromDate: new FormControl(_moment([])),
      toDate: new FormControl(_moment([])),
      specialty: new FormControl(null),
      location: new FormControl(null),
      client: new FormControl(null),
      facility: new FormControl([]),
      role: new FormControl(null),
      name: new FormControl([])
    });
  }
  public dashboardParam(role) {
    let param;
    const facility = this.dashboardFormGroup.controls.facility.value
      ? this.dashboardFormGroup.controls.facility.value.map(data => data.name)
      : [];
    const coderUsername = this.dashboardFormGroup.controls.name.value
      ? this.dashboardFormGroup.controls.name.value.map(data => data.name)
      : [];
    param =
      role === 'tl'
        ? {
            facility: facility && facility.length > 0 ? facility : [],
            fromDate: this.dashboardFormGroup.controls.fromDate.value.format(
              'YYYY-MM-DD'
            ),
            location: this.dashboardFormGroup.controls.location.value
              ? [this.dashboardFormGroup.controls.location.value.name]
              : [],
            role: role,
            specialty: this.dashboardFormGroup.controls.specialty.value
              ? [this.dashboardFormGroup.controls.specialty.value.name]
              : [],
            tlNtlg: this.UserName,
            toDate: this.dashboardFormGroup.controls.toDate.value.format(
              'YYYY-MM-DD'
            ),
            userRole: this.dashboardFormGroup.controls.role.value
              ? this.dashboardFormGroup.controls.role.value.id
              : '',
            userNames:
              coderUsername && coderUsername.length > 0 ? coderUsername : []
          }
        : role === 'sme'
        ? {
            sme: this.UserName,
            facilities: facility && facility.length > 0 ? facility : [],
            fromDate: this.dashboardFormGroup.controls.fromDate.value.format(
              'YYYY-MM-DD'
            ),
            toDate: this.dashboardFormGroup.controls.toDate.value.format(
              'YYYY-MM-DD'
            )
          }
        : {
            coder: this.UserName,
            facilities: facility && facility.length > 0 ? facility : [],
            fromDate: this.dashboardFormGroup.controls.fromDate.value.format(
              'YYYY-MM-DD'
            ),
            toDate: this.dashboardFormGroup.controls.toDate.value.format(
              'YYYY-MM-DD'
            ),
            location: this.clientLocation,
            specialty: this.clientSpecialty
          };
    return param;
  }
  public getdashboardData(): void {
    this.dashboardSummary = null;
    this.dougnutCharts = null;
    this.barchartData = null;
    this.linechartsData = null;
    const param = this.dashboardParam(this.serviceRole);
    if (this.serviceRole === 'sme') {
      this.getSmeChartData(param);
    } else {
      this.getChartData(param);
    }
  }
  public getSmeChartData(param): void {
    let doughnutChartData = [];
    let barChartDatavalues = [];
    this.dashboardService.getSmeChartServices(param).subscribe((data: any) => {
      if (data) {
        this.dashboardSummary = data.targetSummary;
        doughnutChartData = [
          data.noOfChartsPending ? data.noOfChartsPending : 0,
          data.noOfChartsClarified ? data.noOfChartsClarified : 0
        ];
        this.totalSuspended = data.totalCharts ? data.totalCharts : 0;
        this.getSmeDonutChartsData(doughnutChartData);
        const barChartDataLabel = [
          'Suspended By Coder',
          'Suspended By Auditor',
          'Clarified By Coder',
          'Clarified By Auditor'
        ];
        barChartDatavalues = [];
        barChartDatavalues.push(data.noOfChartsSuspendedByCoder);
        barChartDatavalues.push(data.noOfChartsSuspendedByAuditor);
        barChartDatavalues.push(data.smeClarifiedChartsForCoder);
        barChartDatavalues.push(data.smeClarifiedChartsForAuditor);
        const barChartData = [];
        let barChartLabels;
        barChartDatavalues.forEach(ele => {
          barChartData.push(ele);
        });
        barChartLabels = barChartDataLabel;
        this.getBarChartsData(barChartDatavalues, barChartDataLabel);
      }
    });
  }
  public getChartData(param): void {
    const barChartLabels = [];
    let barChartDatavalues = [];
    const lineChartLabels = [];
    const chartsCountData = [];
    const accuracyData = [];
    let doughnutChartData = [];
    const facilityChartLabels = [];
    const facilityChartData = [];
    this.dashboardService
      .getChartServices(param, this.serviceRole)
      .subscribe((data: any) => {
        if (
          data &&
          (data.statistics ||
            data.modality ||
            data.hourlyAccuracy ||
            data.hourlyCounts)
        ) {
          this.dashboardSummary = data.targetSummary;
          // doughnut Chart
          this.myQueueVal = data.myQueue ? data.myQueue : 0;
          this.acknowledgedVal = data.acknowledged ? data.acknowledged : 0;
          if (this.serviceRole === 'coder') {
            doughnutChartData = [
              data.coderCmp ? data.coderCmp : 0,
              data.coderPen ? data.coderPen : 0,
              data.chartDiscard ? data.chartDiscard : 0,
              data.chartRai ? data.chartRai : 0,
              data.chartSuspend ? data.chartSuspend : 0,
              data.errors ? data.errors : 0
            ];
            this.getCoderDonutChartsData(doughnutChartData);
          } else if (this.serviceRole === 'auditor') {
            doughnutChartData = [
              data.auditorCmp ? data.auditorCmp : 0,
              data.auditorPen ? data.auditorPen : 0,
              data.chartDiscard ? data.chartDiscard : 0,
              data.chartRai ? data.chartRai : 0,
              data.chartSuspend ? data.chartSuspend : 0,
              data.errors ? data.errors : 0
            ];
            this.getAuditorDonutChartData(doughnutChartData);
          } else if (this.serviceRole === 'tl') {
            doughnutChartData = [
              data.auditorCmp ? data.auditorCmp : 0,
              data.coderCmp ? data.coderCmp : 0,
              data.auditorPen ? data.auditorPen : 0,
              data.coderPen ? data.coderPen : 0,
              data.chartDiscard ? data.chartDiscard : 0,
              data.chartRai ? data.chartRai : 0,
              data.chartSuspend ? data.chartSuspend : 0,
              data.errors ? data.errors : 0
            ];
            this.getDonutChartsData(doughnutChartData);
          }
          // Bar Chart
          if (data.modality) {
            const barChartDataLabel = Object.keys(data.modality);
            barChartDatavalues = Object.values(data.modality);
            const barChartDataPending = [];
            const barChartDataCompleted = [];
            barChartDatavalues.forEach(ele => {
              barChartDataPending.push(ele.pending);
              barChartDataCompleted.push(ele.completed);
            });
            this.getStackedBarChartsData(
              barChartDataPending,
              barChartDataCompleted,
              barChartDataLabel
            );
          }
          // line charts
          if (data.hourlyAccuracy || data.hourlyCounts) {
            const lineChartHourlyAccuracyData: any[] = Object.values(
              data.hourlyAccuracy
            );
            const lineChartHourlyCountsData: any[] = Object.values(
              data.hourlyCounts
            );
            lineChartHourlyAccuracyData.forEach(hours => {
              lineChartLabels.push(hours.hour);
              accuracyData.push(hours.counts);
            });
            lineChartHourlyCountsData.forEach(defect => {
              chartsCountData.push(defect.counts);
            });
            this.getLineChartsData(
              lineChartLabels,
              chartsCountData,
              accuracyData
            );
          }
        } else {
          const rec = [];
          const completed = [];
          const backlog = [];
          const pending = [];
          this.serviceRole === 'coder'
            ? this.getCoderDonutChartsData(doughnutChartData)
            : this.serviceRole === 'auditor'
            ? this.getAuditorDonutChartData(doughnutChartData)
            : this.getDonutChartsData(doughnutChartData);
          this.getLineChartsData(
            lineChartLabels,
            chartsCountData,
            accuracyData
          );
          this.getStackedBarChartsData(pending, completed, barChartLabels);
        }
      });
  }
  public getStackedBarChartsData(pending, completed, label): void {
    this.barchartData = {
      labels: label,
      datasets: [
        {
          label: 'Pending',
          backgroundColor: '#F39C12',
          data: pending
        },
        {
          label: 'Completed',
          backgroundColor: '#117a63',
          data: completed
        }
      ]
    };
  }
  public getBarChartsData(data, label): void {
    this.barchartData = {
      labels: label,
      datasets: [
        {
          label: '',
          backgroundColor: '#537aef',
          data: data
        }
      ]
    };
  }
  // coder donut chart
  private getCoderDonutChartsData(data): void {
    this.dougnutCharts = {
      labels: ['Coded', 'Pending', 'Discarded', 'RAI', 'Suspended', 'Errors'],
      datasets: [
        {
          data: data,
          backgroundColor: [
            '#117a63', // coder completed
            '#e04d26', // coder pending
            '#edbe25', // discard
            '#660c8c', // rai
            '#5DADE2', // suspend
            '#bc1407' // errors
          ],
          borderWidth: 1
        }
      ]
    };
  }
  // auditor donut chart
  public getAuditorDonutChartData(data): void {
    this.dougnutCharts = {
      labels: ['Audited', 'Pending', 'Discarded', 'RAI', 'Suspended', 'Errors'],
      datasets: [
        {
          data: data,
          backgroundColor: [
            '#27bc56', // auditor completed
            '#2659f2', // auditor pending
            '#edbe25', // discard
            '#ed7f31', // rai
            '#f45053', // suspend
            '#a6a6a6' // errors
          ],
          borderWidth: 2
        }
      ]
    };
  }
  public getDonutChartsData(data): void {
    this.dougnutCharts = {
      labels: [
        'Auditor Completed',
        'Coder Completed',
        'Auditor Pending',
        'Coder Pending',
        'Discarded',
        'RAI',
        'Suspended',
        'Errors'
      ],
      datasets: [
        {
          data: data,
          backgroundColor: [
            '#27bc56', // auditor completed
            '#68e890', // coder completed
            '#2659f2', // auditor pending
            '#4968c6', // coder pending
            '#edbe25', // discard
            '#ed7f31', // rai
            '#f45053', // suspend
            '#a6a6a6' // errors
          ],
          borderWidth: 2
        }
      ]
    };
  }
  public getSmeDonutChartsData(data): void {
    this.dougnutCharts = {
      labels: ['Pending', 'Clarified'],
      datasets: [
        {
          data: data,
          backgroundColor: ['#2659f2', '#27bc56'],
          borderWidth: 2
        }
      ]
    };
  }
  public getLineChartsData(labels, chartCountData, accuracyData): void {
    const sortedLabel = labels.sort(function(a, b) {
      return a - b;
    });
    this.linechartsData = {
      labels: sortedLabel,
      datasets: [
        {
          label: 'Productivity %',
          data: chartCountData,
          fill: false,
          borderColor: '#4d4d4d'
        },
        {
          label: 'Accuracy %',
          data: accuracyData,
          fill: false,
          borderColor: '#27bc56'
        }
      ]
    };
  }
  public validateDate(event, field?: string): any {
    const toDateControl = this.dashboardFormGroup.controls['toDate'];
    const fromDateControl = this.dashboardFormGroup.controls['fromDate'];
    const validate = this.dateService.dateValidation(
      event,
      fromDateControl,
      toDateControl,
      field
    );
    this.fromDateErrorMessage = '';
    this.toDateErrorMessage = '';
    if (
      validate.toDateControl.status === 'INVALID' &&
      validate.fromDateControl.status === 'INVALID'
    ) {
      setTimeout(() => {
        toDateControl.setErrors({ invalid: true });
        fromDateControl.setErrors({ invalid: true });
        this.toDateErrorMessage = validate.toDateErrorMessage;
        this.fromDateErrorMessage = validate.fromDateErrorMessage;
      }, 100);
    } else if (validate.toDateControl.status === 'INVALID') {
      setTimeout(() => {
        toDateControl.setErrors({ invalid: true });
        this.toDateErrorMessage = validate.toDateErrorMessage;
      }, 100);
    } else if (validate.fromDateControl.status === 'INVALID') {
      setTimeout(() => {
        fromDateControl.setErrors({ invalid: true });
        this.fromDateErrorMessage = validate.fromDateErrorMessage;
      }, 100);
    } else if (
      validate.toDateControl.status === 'VALID' &&
      validate.fromDateControl.status === 'VALID'
    ) {
      setTimeout(() => {
        toDateControl.setErrors(null);
        fromDateControl.setErrors(null);
      }, 100);
    }
  }
  public getRoles() {
    const data = JSON.parse(this.storage.getItem('clientConfiguration'));
    if (data) {
      this.clientList = data.userconfiguration.client;
    }
  }
  private onChnages() {
    this.dashboardFormGroup.controls.client.valueChanges.subscribe(val => {
      this.selectedClientControl();
    });
    this.dashboardFormGroup.controls.specialty.valueChanges.subscribe(val => {
      this.selectedSpecialtyControl();
    });
    this.dashboardFormGroup.controls.location.valueChanges.subscribe(val => {
      this.selectedLocationControl();
    });
    this.dashboardFormGroup.controls.role.valueChanges.subscribe(val => {
      if (val) {
        this.getNamesControl(val);
      }
    });
  }
  private selectedClientControl() {
    this.specialtyList.length = 0;
    const specialtyListData = this.dashboardFormGroup.controls.specialty.value
      ? this.dashboardFormGroup.controls.specialty.value
      : null;
    const list = [];
    if (
      this.dashboardFormGroup.controls.client.value &&
      this.dashboardFormGroup.controls.client.value.speciality
    ) {
      this.dashboardFormGroup.controls.client.value.speciality.forEach(
        specialityElement => {
          list.push(specialityElement);
        }
      );
    }
    this.specialtyList = list;
    const specialityFilterList = this.specialtyList.includes(specialtyListData)
      ? specialtyListData
      : null;
    this.dashboardFormGroup.controls.specialty.patchValue(specialityFilterList);
  }
  private selectedSpecialtyControl() {
    this.locationList.length = 0;
    const locationListData = this.dashboardFormGroup.controls.location.value
      ? this.dashboardFormGroup.controls.location.value
      : null;
    const list = [];
    if (
      this.dashboardFormGroup.controls.specialty.value &&
      this.dashboardFormGroup.controls.specialty.value.location
    ) {
      this.dashboardFormGroup.controls.specialty.value.location.forEach(
        locationElement => {
          list.push(locationElement);
        }
      );
    }
    this.locationList = list;
    const locationFilterList = this.locationList.includes(locationListData)
      ? locationListData
      : null;
    this.dashboardFormGroup.controls.location.patchValue(locationFilterList);
  }
  private selectedLocationControl() {
    this.facilityOptionList.length = 0;
    const facilityListData = this.dashboardFormGroup.controls.facility.value
      ? this.dashboardFormGroup.controls.facility.value
      : null;
    const listOptions = [];
    if (
      this.dashboardFormGroup.controls.location.value &&
      this.dashboardFormGroup.controls.location.value.facility
    ) {
      this.dashboardFormGroup.controls.location.value.facility.forEach(
        facilityElement => {
          listOptions.push(facilityElement);
        }
      );
    }
    this.facilityOptionList = listOptions;
    const facilityFilterList = this.facilityOptionList.includes(
      facilityListData
    )
      ? facilityListData
      : null;
    this.dashboardFormGroup.controls.facility.patchValue(facilityFilterList);
  }
  public getNamesControl(val) {
    this.dashboardFormGroup.controls.name.setValue([]);
    this.dashboardFormGroup.updateValueAndValidity();
    const param = {
      userId: this.UserName,
      userRole: val.id
    };
    this.nameOptionList.length = 0;
    this.dashboardService.getCoderQaService(param).subscribe((data: any) => {
      if (data && data.length) {
        const tempData = [];
        data.forEach(element => {
          tempData.push({
            id: element.id,
            name: element.id
          });
        });
        this.nameOptionList = tempData;
      }
    });
  }
}
