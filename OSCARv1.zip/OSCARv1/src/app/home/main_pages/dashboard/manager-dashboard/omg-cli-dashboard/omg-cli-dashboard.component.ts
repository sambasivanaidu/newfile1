import {
  Component,
  OnInit,
  Input,
  ChangeDetectorRef,
  AfterViewChecked
} from '@angular/core';
import { DashboardService } from '../../../dashboard/dashboard.service';
import { DateFormatter } from '../../../../../imports/_utilities/date-formatter';
import { ValidationService } from '../../../../../services/validation.service';
import { ClientSelectionService } from '../../../../../users/client-selection/client-selection.service';
import {
  DateAdapter,
  MAT_DATE_LOCALE,
  MAT_DATE_FORMATS
} from '@angular/material';
import {
  MomentDateAdapter,
  MAT_MOMENT_DATE_FORMATS
} from '@angular/material-moment-adapter';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { environment } from '../../../../../../environments/environment';
import * as _moment from 'moment';
import { ManagerDashboardService } from '../manager-dashboard.service';
import { Subscription } from 'rxjs';
import { DateService } from '../../../../../_shared-services/date-service/date.service';
import { CommonCodeService } from '../../../../../_shared-services/common-code.services';
@Component({
  selector: 'app-omg-cli-dashboard',
  templateUrl: './omg-cli-dashboard.component.html',
  styleUrls: ['./omg-cli-dashboard.component.scss'],
  providers: [
    DateService,
    DashboardService,
    DateFormatter,
    ValidationService,
    ClientSelectionService,
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS }
  ]
})
export class OmgCliDashboardComponent implements OnInit, AfterViewChecked {
  public lineChartOptions: any;
  public productionOptions: any;
  public proAccLineChartOptions: any;
  public selectedFacility: any[];
  public selectedSpecialty: any[];
  public selectedLocation: any[];
  public selectedTL: any = [];
  public omegaLocationFacilities: any = [];
  public tabLabel: any;
  public subscribeTabLabel: Subscription;
  public dashboardName;
  public clientObj;
  public serviceRole: string = 'clientManager';
  public isClient = true;
  public isOmega = false;
  userRole;
  userCode;
  myQueueVal: number = 0;
  acknowledgedVal: number = 0;
  public facilityChartData: any;
  facilityOptionList: any = [];
  teamLeadOptionList: any;
  clientList: any = [];
  specialtyList: any = [];
  locationList: any = [];
  public dougnutCharts: any;
  public barchartData: any;
  public linechartsData: any;
  dashboardFormGroup: FormGroup;
  fromDateErrorMessage = 'Please enter valid date.';
  toDateErrorMessage = 'Please enter valid date.';
  maxDate = new Date();
  public UserName: string;
  public facilitySelectModel: any = [];
  public storage: Storage = environment.storage;
  public selectedIndex: any;
  public chartResponsive = true;
  facilityList = [];
  @Input() tabVal: string;
  @Input() set isClientTab(val: boolean) {
    this.isClient = val;
    this.isOmega = !val;
    this.serviceRole = this.isClient ? 'clientManager' : 'omegaManager';
  }
  public BarChartOptions = {
    responsive: false,
    maintainAspectRatio: false,
    plugins: {
      datalabels: {
        align: 'middle',
        anchor: 'middle',
        borderRadius: 4,
        backgroundColor: '#2d2d2d',
        padding: 4,
        color: 'white',
        font: {
          weight: 'normal',
          size: 9
        }
      }
    },
    scales: {
      yAxes: [
        {
          stacked: true,
          barThickness: 50
        }
      ],
      xAxes: [
        {
          stacked: true,
          barThickness: 50
        }
      ]
    }
  };
  constructor(
    private changeDetector: ChangeDetectorRef,
    private dashboardService: DashboardService,
    private formBuilder: FormBuilder,
    private _commonCode: CommonCodeService,
    private dateService: DateService
  ) {
    this.UserName = this.storage.getItem('UserName');
    this.clientObj = this._commonCode.get_ConfidenceColor_Clientselection(
      'clientSelectionObject'
    );
    this.userRole = this.clientObj.workRole.role; // .toLowerCase();
    this.userCode = this.clientObj.workRole.code;
    this.getTeamLeadList();
    this.getClientList();
    this.intializedashboardForm();
    this.selectionChange();
  }
  ngOnInit() {
    this.getdashboardData();
  }
  public intializedashboardForm() {
    this.dashboardFormGroup = this.formBuilder.group({
      fromDate: new FormControl(_moment([])),
      toDate: new FormControl(_moment([])),
      client: new FormControl(''),
      specialty: new FormControl(''),
      location: new FormControl(''),
      clientfacility: new FormControl([]),
      omegafacility: new FormControl([]),
      teamLead: new FormControl([])
    });
  }
  public getDashboardName(): void {
    this.dashboardName = this.clientObj.workRole.category.toUpperCase();
    this.serviceRole = this.clientObj.workRole.code;
    this.serviceRole =
      this.tabLabel === 'omegaManager' ? 'omegaManager' : 'clientManager';
    if (this.serviceRole === 'clientManager') {
      this.isClient = true;
      this.isOmega = false;
    } else {
      this.isClient = false;
      this.isOmega = true;
    }
  }
  public getFacilitiesByOmegaLocation() {
    const userId = this.storage.getItem('UserName');
    this.dashboardService
      .getOmegaFacilityByManager(userId)
      .subscribe((data: any) => {
        if (data && data.length > 0) {
          this.omegaLocationFacilities = data.map(element => {
            return { name: element };
          });
        }
      });
  }
  public getClientList(): void {
    try {
      this.clientList = this.clientObj.clientConfiguration.client;
    } catch (error) {
    }
  }
  public getSpecialtyList(event): void {
    if (event.value) {
      this.specialtyList = [this.clientObj.specialty];
    }
    if (this.serviceRole === 'omegaManager') {
      this.getFacilitiesByOmegaLocation();
    }
  }
  public getTeamLeadList() {
    // hardCoded
    const param = {
      manager: 'manager',
      userId: this.storage.getItem('UserName')
    };
    this.dashboardService.getTeamLeadService(param).subscribe((data: any) => {
      if (data && data.length > 0) {
        this.teamLeadOptionList = data.map(element => {
          return { name: element };
        }); // tempData;
      }
    });
  }
  public getSelectedFacility(event): void {
    if (event) {
      this.facilitySelectModel = [];
      if (event[0] === -1) {
        this.facilitySelectModel = [];
      } else {
        this.facilitySelectModel = event.value;
      }
    }
  }
  public getTeamLeadOptionList(evt) {
    this.selectedTL = [];
    evt.map(obj => {
      this.selectedTL.push(obj.name);
    });
  }
  public getdashboardData(): void {
    const param = this.dashBoardParam();
    this.getChartData(param);
  }
  public dashBoardParam() {
    const param = {
      specialty: this.dashboardFormGroup.controls.specialty.value
        ? [this.dashboardFormGroup.controls.specialty.value.name]
        : [],
      location: this.isClient
        ? this.dashboardFormGroup.controls.location.value
          ? [this.dashboardFormGroup.controls.location.value.name]
          : []
        : [], // specialty === [] ? [] : location && location.length > 0 ? location : [],
      facility: this.isClient
        ? this.dashboardFormGroup.controls.clientfacility.value
          ? this.dashboardFormGroup.controls.clientfacility.value.map(
              element => element.name
            )
          : []
        : this.dashboardFormGroup.controls.omegafacility.value
        ? this.dashboardFormGroup.controls.omegafacility.value.map(
            element => element.name
          )
        : [], // location === [] ? [] : this.facilitySelectModel,
      fromDate: this.dashboardFormGroup.controls.fromDate.value.format(
        'YYYY-MM-DD'
      ),
      loginNtlg: this.UserName,
      loginRole: this.userCode,
      toDate: this.dashboardFormGroup.controls.toDate.value.format(
        'YYYY-MM-DD'
      ),
      userNames: this.dashboardFormGroup.controls.teamLead.value
        ? this.dashboardFormGroup.controls.teamLead.value.map(
            element => element.name
          )
        : []
    };
    return param;
  }
  public getChartData(param): void {
    let barChartLabels;
    let barChartDatavalues = [];
    const lineChartLabels = [];
    const chartsCountData = [];
    const accuracyData = [];
    let doughnutChartData = [];
    let facilityChartLabels = [];
    let facilityChartData = [];
    this.dougnutCharts = null;
    this.facilityChartData = null;
    this.barchartData = null;
    this.linechartsData = null;
    this.dashboardService
      .getChartServices(param, this.serviceRole)
      .subscribe((data: any) => {
        if (
          data &&
          (data.statistics ||
            data.modality ||
            data.hourlyAccuracy ||
            data.hourlyCounts)
        ) {
          if (
            this.serviceRole === 'omegaManager' ||
            this.serviceRole === 'clientManager'
          ) {
            // facility Chart
            if (data.facility) {
              facilityChartLabels = Object.keys(data.facility);
              facilityChartData = Object.values(data.facility);
              this.getOrganizationChartData(
                facilityChartLabels,
                facilityChartData
              );
            }
            // doughnut Chart
            if (data.statistics) {
              doughnutChartData = [
                data.statistics.abovePotentialTat
                  ? data.statistics.abovePotentialTat
                  : 0,
                data.statistics.backlog ? data.statistics.backlog : 0,
                data.statistics.completed ? data.statistics.completed : 0,
                data.statistics.pending ? data.statistics.pending : 0,
                data.statistics.potentialTat ? data.statistics.potentialTat : 0,
                data.statistics.received ? data.statistics.received : 0
              ];
              this.getDonutChartsManagerData(doughnutChartData);
            }
            // Bar Chart
            if (data.modality) {
              const barChartDataLabel1 = Object.keys(data.modality);
              barChartDatavalues = Object.values(data.modality);
              const barChartDataReceived = [];
              const barChartDataCompleted = [];
              const barChartDataBacklog = [];
              barChartDatavalues.forEach(ele => {
                barChartDataReceived.push(ele.received);
                barChartDataCompleted.push(ele.completed);
                barChartDataBacklog.push(ele.backlog);
              });
              barChartLabels = barChartDataLabel1;
              this.getBarChartsManagerData(
                barChartDataReceived,
                barChartDataCompleted,
                barChartDataBacklog,
                barChartLabels
              );
            }
            // line charts
            if (data.hourlyAccuracy || data.hourlyCounts) {
              const lineChartHourlyAccuracyData: any[] = Object.values(
                data.hourlyAccuracy
              );
              const lineChartHourlyCountsData: any[] = Object.values(
                data.hourlyCounts
              );
              lineChartHourlyAccuracyData.forEach(hours => {
                lineChartLabels.push(hours.hour);
                accuracyData.push(hours.counts);
              });
              lineChartHourlyCountsData.forEach(defect => {
                chartsCountData.push(defect.counts);
              });
              this.getLineChartsData(
                lineChartLabels,
                chartsCountData,
                accuracyData
              );
            }
          } else {
            // doughnut Chart
            this.myQueueVal = data.myQueue ? data.myQueue : 0;
            this.acknowledgedVal = data.acknowledged ? data.acknowledged : 0;
            doughnutChartData = [
              data.auditorCmp ? data.auditorCmp : 0,
              data.coderCmp ? data.coderCmp : 0,
              data.auditorPen ? data.auditorPen : 0,
              data.coderPen ? data.coderPen : 0,
              data.chartDiscard ? data.chartDiscard : 0,
              data.chartRai ? data.chartRai : 0,
              data.chartSuspend ? data.chartSuspend : 0,
              data.errors ? data.errors : 0
            ];
            this.getDonutChartsData(doughnutChartData);
            // Bar Chart
            if (data.modality) {
              const barChartDataLabel = Object.keys(data.modality);
              barChartDatavalues = Object.values(data.modality);
              const barChartDataPending = [];
              const barChartDataCompleted = [];
              barChartDatavalues.forEach(ele => {
                barChartDataPending.push(ele.pending);
                barChartDataCompleted.push(ele.completed);
              });
              this.getStackedBarChartsData(
                barChartDataPending,
                barChartDataCompleted,
                barChartDataLabel
              );
            }
            // line charts
            if (data.hourlyAccuracy || data.hourlyCounts) {
              const lineChartHourlyAccuracyData: any[] = Object.values(
                data.hourlyAccuracy
              );
              const lineChartHourlyCountsData: any[] = Object.values(
                data.hourlyCounts
              );
              lineChartHourlyAccuracyData.forEach(hours => {
                lineChartLabels.push(hours.hour);
                accuracyData.push(hours.counts);
              });
              lineChartHourlyCountsData.forEach(defect => {
                chartsCountData.push(defect.counts);
              });
              this.getLineChartsData(
                lineChartLabels,
                chartsCountData,
                accuracyData
              );
            }
          }
        } else {
          const rec = [];
          const completed = [];
          const backlog = [];
          const pending = [];
          this.facilityChartData = null;
          this.dougnutCharts = null;
          this.barchartData = null;
          this.linechartsData = null;
          this.serviceRole === 'omegaManager'
            ? this.getDonutChartsManagerData(doughnutChartData)
            : this.getDonutChartsData(doughnutChartData);
          this.getLineChartsData(
            lineChartLabels,
            chartsCountData,
            accuracyData
          );
          this.serviceRole === 'omegaManager'
            ? this.getBarChartsManagerData(
                rec,
                completed,
                backlog,
                barChartLabels
              )
            : this.getStackedBarChartsData(pending, completed, barChartLabels);
        }
      });
  }
  public getOrganizationChartData(labels, chartCountData): void {
    const sortedLabel = labels.sort(function(a, b) {
      return a - b;
    });
    let totalCount = 0;
    for (let index = 0; index < chartCountData.length; index++) {
      totalCount += chartCountData[index];
    }
    this.facilityChartData = {
      labels: sortedLabel,
      datasets: [
        {
          label: 'Facility',
          data: chartCountData,
          backgroundColor: [
            '#27bc56',
            '#68e890',
            '#2659f2',
            '#4968c6',
            '#edbe25',
            '#ed7f31',
            '#f45053',
            '#a6a6a6'
          ],
          borderColor: 'teal'
        }
      ]
    };
    this.lineChartOptions = {
      title: {
        display: true,
        text: 'Total : ' + totalCount,
        fontSize: 16,
        color: 'teal'
      },
      legend: {
        position: top
      },
      plugins: {
        datalabels: {
          align: 'middle',
          anchor: 'middle',
          borderRadius: 4,
          backgroundColor: '#27bc56',
          padding: 4,
          color: 'white',
          font: {
            weight: 'normal',
            size: 9
          }
        }
      }
    };
  }
  public getDonutChartsData(data): void {
    this.dougnutCharts = {
      labels: [
        'Auditor Completed',
        'Coder Completed',
        'Auditor Pending',
        'Coder Pending',
        'Chart Discard',
        'Chart RAI',
        'Chart Suspend',
        'Errors'
      ],
      datasets: [
        {
          data: data,
          backgroundColor: [
            '#27bc56', // auditor completed
            '#68e890', // coder completed
            '#2659f2', // auditor pending
            '#4968c6', // coder pending
            '#edbe25', // discard
            '#ed7f31', // rai
            '#f45053', // suspend
            '#a6a6a6' // errors
          ],
          borderWidth: 2
        }
      ]
    };
  }
  public getDonutChartsManagerData(data): void {
    this.dougnutCharts = {
      labels: [
        'Above Potential Tat',
        'Backlog',
        'Completed',
        'Pending',
        'Potential Tat',
        'Received'
      ],
      datasets: [
        {
          data: data,
          backgroundColor: [
            '#ed7f31', // abov epotential tat
            '#c7c7c7', // backlog
            '#27bc56', // completed
            '#e43b3e', // pending
            '#f9bd57', // potential tat
            '#02aafd' // received
          ],
          borderWidth: 1
        }
      ]
    };
    this.productionOptions = {
      plugins: {
        datalabels: {
          align: 'middle',
          anchor: 'middle',
          borderRadius: 4,
          backgroundColor: '#2d2d2d',
          padding: 4,
          color: 'white',
          font: {
            weight: 'normal',
            size: 9
          }
        }
      },
      legend: {
        position: 'left'
      }
    };
  }
  public getBarChartsManagerData(received, completed, backlog, label): void {
    this.barchartData = {
      labels: label,
      datasets: [
        {
          label: 'Received',
          backgroundColor: '#02aafd',
          data: received,
          barThickness: 1
        },
        {
          label: 'Completed',
          backgroundColor: '#27bc56',
          data: completed,
          barThickness: 1
        },
        {
          label: 'Backlog',
          backgroundColor: '#c7c7c7',
          data: backlog,
          barThickness: 1
        }
      ]
    };
  }
  public getStackedBarChartsData(pending, completed, label): void {
    this.barchartData = {
      labels: label,
      datasets: [
        {
          label: 'Pending',
          backgroundColor: '#6899f9',
          data: pending
        },
        {
          label: 'Completed',
          backgroundColor: '#63ed8e',
          data: completed
        }
      ]
    };
  }
  public getLineChartsData(labels, chartCountData, accuracyData): void {
    const sortedLabel = labels.sort(function(a, b) {
      return a - b;
    });
    this.linechartsData = {
      labels: sortedLabel,
      datasets: [
        {
          label: 'Productivity %',
          data: chartCountData,
          fill: false,
          borderColor: '#4d4d4d'
        },
        {
          label: 'Accuracy %',
          data: accuracyData,
          fill: false,
          borderColor: '#27bc56'
        }
      ]
    };
    this.proAccLineChartOptions = {
      plugins: {
        datalabels: {
          align: 'middle',
          anchor: 'middle',
          borderRadius: 4,
          backgroundColor: '#27bc56',
          padding: 4,
          color: 'white',
          font: {
            weight: 'normal',
            size: 9
          }
        }
      }
    };
  }
  validateDate(event, field?: string): any {
    const toDateControl = this.dashboardFormGroup.controls['toDate'];
    const fromDateControl = this.dashboardFormGroup.controls['fromDate'];
    const validate = this.dateService.dateValidation(
      event,
      fromDateControl,
      toDateControl,
      field
    );
    this.fromDateErrorMessage = '';
    this.toDateErrorMessage = '';
    if (
      validate.toDateControl.status === 'INVALID' &&
      validate.fromDateControl.status === 'INVALID'
    ) {
      setTimeout(() => {
        toDateControl.setErrors({ invalid: true });
        fromDateControl.setErrors({ invalid: true });
        this.toDateErrorMessage = validate.toDateErrorMessage;
        this.fromDateErrorMessage = validate.fromDateErrorMessage;
      }, 100);
    } else if (validate.toDateControl.status === 'INVALID') {
      setTimeout(() => {
        toDateControl.setErrors({ invalid: true });
        this.toDateErrorMessage = validate.toDateErrorMessage;
      }, 100);
    } else if (validate.fromDateControl.status === 'INVALID') {
      setTimeout(() => {
        fromDateControl.setErrors({ invalid: true });
        this.fromDateErrorMessage = validate.fromDateErrorMessage;
      }, 100);
    } else if (
      validate.toDateControl.status === 'VALID' &&
      validate.fromDateControl.status === 'VALID'
    ) {
      setTimeout(() => {
        toDateControl.setErrors(null);
        fromDateControl.setErrors(null);
      }, 100);
    }
  }
  private selectionChange() {
    this.dashboardFormGroup.controls.client.valueChanges.subscribe(val => {
      this.getSpecialtyList1(val);
    });
    this.dashboardFormGroup.controls.specialty.valueChanges.subscribe(val => {
      this.getLocationList1(val);
    });
    this.dashboardFormGroup.controls.location.valueChanges.subscribe(val => {
      this.getFacilityList1(val);
    });
  }
  getSpecialtyList1(value) {
    this.dashboardFormGroup.controls.specialty.setValue('');
    this.specialtyList = [];
    if (value) {
      this.specialtyList = value.speciality;
    }
  }
  getLocationList1(value) {
    if (this.serviceRole === 'omegaManager') {
      this.dashboardFormGroup.controls.omegafacility.setValue([]);
      if (value) {
        this.getFacilitiesByOmegaLocation();
      }
    } else {
      this.dashboardFormGroup.controls.location.setValue('');
      this.locationList = [];
      if (value) {
        this.locationList = value.location;
      }
    }
  }
  getFacilityList1(value) {
    this.dashboardFormGroup.controls.clientfacility.setValue([]);
    this.facilityList = [];
    if (value) {
      this.facilityList = value.facility;
    }
  }
  ngAfterViewChecked() {
    this.changeDetector.detectChanges();
  }
}
