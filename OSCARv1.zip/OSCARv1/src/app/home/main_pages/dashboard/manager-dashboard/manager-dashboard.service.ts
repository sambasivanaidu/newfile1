import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
@Injectable()
export class ManagerDashboardService {
  private sub = new Subject<any>();
  getMessage(): Observable<any> {
    return this.sub.asObservable();
  }
  sendMessage(message: string) {
    this.sub.next({ text: message });
  }
}
