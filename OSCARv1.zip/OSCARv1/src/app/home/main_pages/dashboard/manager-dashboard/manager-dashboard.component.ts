import { Component } from '@angular/core';
import { ManagerDashboardService } from './manager-dashboard.service';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-manager-dashboard',
  templateUrl: './manager-dashboard.component.html',
  styleUrls: ['./manager-dashboard.component.scss']
})
export class ManagerDashboardComponent {
  public subscribeTabLabel: Subscription;
  public tabLabel: string;
  public serviceRole: string;
  constructor(private _ManagerDashboardService: ManagerDashboardService) {}
  tabValue(role): void {
    this._ManagerDashboardService.sendMessage(role);
  }
  onTabClick(tabGroupParent) {
    if (tabGroupParent._selectedIndex === 1) {
      this.serviceRole = 'omegaManager';
    } else if (tabGroupParent._selectedIndex === 0) {
      this.serviceRole = 'clientManager';
    }
    this.tabValue(this.serviceRole);
  }
}
