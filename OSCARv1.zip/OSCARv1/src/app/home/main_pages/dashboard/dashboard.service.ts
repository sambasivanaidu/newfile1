import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/forkJoin';
import { HttpClient } from '@angular/common/http';
import { ToastsManager } from 'ng2-toastr';
import { environment } from '../../../../environments/environment';
import { HeaderAuthenticationToken } from '../../../auth/authetication-header';
@Injectable()
export class DashboardService {
  public httpOption;
  public envURL = environment.URL;
  public localURl = 'http://10.8.34.92:9599/';
  public userName;
  public storage: Storage = environment.storage;
  constructor(
    private httpClient: HttpClient,
    private __httpHeader: HeaderAuthenticationToken
  ) {
    this.httpOption = this.__httpHeader.setHeaderToken();
    this.userName = this.storage.getItem('UserName');
  }
  getChartServices(param, role) {
    const url = this.envURL + 'dashboardsummary/' + role + '/allSections';
    return this.httpClient.post(url, param, this.httpOption);
  }
  getSmeChartServices(param) {
    const url = this.envURL + 'dashboardsummary/allSmeData';
    return this.httpClient.post(url, param, this.httpOption);
  }
  getCoderQaService(param) {
    const url = this.envURL + 'usermaster/searchCoderQA';
    return this.httpClient.post(url, param, this.httpOption);
  }
  getCoderQaServiceOnRole(param, role) {
    let url = '';
    if (role === 'team lead') {
      url = 'usermaster/searchUsermaster?teamlead=' + param.teamlead;
    } else if (role === 'manager') {
      url = 'usermaster/searchCoderByManager?manager=' + param.manager;
    } else {
      url = 'usermaster/searchCoderQA';
    }
    return this.httpClient.get(this.envURL + url, this.httpOption);
  }
  getTeamLeadService(param) {
    const url = this.envURL + 'usermaster/searchTeamlead';
    return this.httpClient.post(url, param, this.httpOption);
  }
  getOmegaFacilityByManager(param) {
    let url = '';
    url = 'usermaster/searchOmegaFacilityByManager?manager=' + param;
    return this.httpClient.get(this.envURL + url, this.httpOption);
  }
}
