import { BreadCrumbModule } from './../reports/bread-crumb/bread-crumb.module';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { MaterialModule } from './../../../imports/material.module';
import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OmgCliDashboardComponent } from './manager-dashboard/omg-cli-dashboard/omg-cli-dashboard.component';
import { ManagerDashboardComponent } from './manager-dashboard/manager-dashboard.component';
import { DashboardComponent } from './dashboard.component';
import { ManagerDashboardService } from './manager-dashboard/manager-dashboard.service';
import { ChartModule } from 'primeng/chart';
import { MatDynamicDdModule } from '../../../imports/_utilities/mat-dynamic-dd/mat-dynamic-dd.module';
const routes: Routes = [
  {
    path: '',
    component: DashboardComponent
  },
  {
    path: 'managerdashboard',
    component: ManagerDashboardComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    MaterialModule,
    ChartModule,
    MatDynamicDdModule,
    FormsModule,
    ReactiveFormsModule,
    BreadCrumbModule
  ],
  declarations: [
    DashboardComponent,
    ManagerDashboardComponent,
    OmgCliDashboardComponent
  ],
  providers: [ManagerDashboardService]
})
export class DashboardModule {}
