import { Component, OnInit, ViewChild } from '@angular/core';
import { ClientSelectionService } from '../../../../users/client-selection/client-selection.service';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import * as _moment from 'moment';
import { ValidationService } from '../../../../services/validation.service';
import { ToastsManager } from 'ng2-toastr';
import { environment } from '../../../../../environments/environment';
import { HomeComponentService } from '../../../home.component.service';
import { DateFormatter } from '../../../../imports/_utilities/date-formatter';
import {
  MomentDateAdapter,
  MAT_MOMENT_DATE_FORMATS
} from '@angular/material-moment-adapter';
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE
} from '@angular/material';
import { RaiService } from '../rai.service';
import { DateService } from '../../../../_shared-services/date-service/date.service';
@Component({
  selector: 'app-rai-dashboard',
  templateUrl: './rai-dashboard.component.html',
  styleUrls: ['./rai-dashboard.component.scss'],
  providers: [
    DateService,
    ClientSelectionService,
    ValidationService,
    HomeComponentService,
    DateFormatter,
    RaiService,
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS }
  ]
})
export class RaiDashboardComponent implements OnInit {
  public storage: Storage = environment.storage;
  facilityOptionList = [];
  locationList = [];
  raiDashboardFormGroup: FormGroup;
  public facilitySelectModel: any;
  selectLocationModel: any;
  fromDateErrorMessage = 'Please enter valid date.';
  toDateErrorMessage = 'Please enter valid date.';
  public chartResponsive = true;
  public maxDate = new Date();
  @ViewChild('filters') filters;
  workBenchDetailsData: any; // donut data
  IcdCptBreakupData: any;
  statusBreakUpData: any;
  icdCptTotal = 0;
  workBenchTotal = 0;
  donutChartOptions = {
    plugins: {
      datalabels: {
        align: 'middle',
        anchor: 'middle',
        borderRadius: 5,
        backgroundColor: '#2d2d2d',
        padding: 5,
        color: 'white',
        font: {
          weight: 'normal',
          size: 9
        }
      }
    },
    legend: {
      position: 'left'
    }
  };
  constructor(
    private formBuilder: FormBuilder,
    private raiService: RaiService,
    private dateService: DateService,
    public _toastr: ToastsManager
  ) {}
  ngOnInit() {
    this.getFacilityList();
    this.getLocationList();
    this.intializeRaiChartForm();
    this.getdashboardData();
  }
  getFacilityList() {
    this.facilityOptionList = [];
    this.raiService.getFacility().subscribe(response => {
      if (response && response.length > 0) {
        this.facilityOptionList = response.map(elemnt => {
          return { name: elemnt };
        });
      }
    });
  }
  getLocationList() {
    this.locationList = [];
    this.raiService.getLocations().subscribe(response => {
      if (response && response.length > 0) {
        this.locationList = response.map(eleme => {
          return { name: eleme };
        });
      }
    });
  }
  intializeRaiChartForm() {
    this.raiDashboardFormGroup = this.formBuilder.group({
      fromDate: new FormControl(_moment([])),
      toDate: new FormControl(_moment([])),
      clientLocation: new FormControl(''),
      facility: new FormControl([])
    });
  }
  fetchWorkBenchDetailsDonut(data) {
    this.workBenchDetailsData = {
      labels: ['24 Hrs', '48 Hrs', '72 Hrs', '96 Hrs'],
      datasets: [
        {
          data: data,
          backgroundColor: ['#27bc56', '#9bbbc9', '#3886e2', '#ed6161'],
          borderWidth: 1
        }
      ]
    };
  }
  fetchIcdCptBreakUpDonut(data) {
    this.IcdCptBreakupData = {
      labels: ['CPT', 'ICD', 'MIPS', 'Modifier', 'Others'],
      datasets: [
        {
          data: data,
          backgroundColor: [
            '#ef8026',
            '#8eb9cc',
            '#2659f2',
            '#35b4f2',
            '#27bc56'
          ],
          borderWidth: 1
        }
      ]
    };
  }
  fetchBreakUpStatusDonut(data) {
    this.statusBreakUpData = {
      labels: ['My Queue', 'Completed', 'Hold'],
      datasets: [
        {
          data: data,
          backgroundColor: ['#2659f2', '#27bc56', '#8eb9cc'],
          borderWidth: 1
        }
      ]
    };
  }
  prepareRaiDonuts(workBenchDetailsData, icdCptBreakupData, statusBreakUpData) {
    this.fetchWorkBenchDetailsDonut(workBenchDetailsData);
    this.fetchIcdCptBreakUpDonut(icdCptBreakupData);
    this.fetchBreakUpStatusDonut(statusBreakUpData);
  }
  public getdashboardData(): void {
    let param;
    // const facility = [];
    // if (this.facilitySelectModel) {
    //   this.facilitySelectModel.forEach(element => {
    //     facility.push(element.name);
    //   });
    // }
    param = {
      fromDate: this.raiDashboardFormGroup.controls.fromDate.value.format(
        'YYYY-MM-DD'
      ),
      toDate: this.raiDashboardFormGroup.controls.toDate.value.format(
        'YYYY-MM-DD'
      ),
      facilityname: this.raiDashboardFormGroup.controls.facility.value
        ? this.raiDashboardFormGroup.controls.facility.value.map(
            eleme => eleme.name
          )
        : [], // facility && facility.length > 0 ? facility : [],
      locationname: this.raiDashboardFormGroup.controls.clientLocation.value
        ? this.raiDashboardFormGroup.controls.clientLocation.value.map(
            eleme => eleme.name
          )
        : []
      // 'raiDashboardFormGroup.controls.clientLocation
      //   this.selectLocationModel && this.selectLocationModel.length > 0
      //     ? this.selectLocationModel
      //     : []
    };
    let workBenchDetailsData = [];
    let icdCptBreakupData = [];
    let statusBreakUpData = [];
    this.prepareRaiDonuts(
      workBenchDetailsData,
      icdCptBreakupData,
      statusBreakUpData
    );
    this.raiService.getRaiDashboardData(param).subscribe(response => {
      if (response) {
        if (
          response.workbenchDetails &&
          response.categoryDetails &&
          response.breakUpStatusDetails
        ) {
          workBenchDetailsData = [
            response.workbenchDetails.request24,
            response.workbenchDetails.request48,
            response.workbenchDetails.request72,
            response.workbenchDetails.request96
          ];
          icdCptBreakupData = [
            response.categoryDetails.cpt,
            response.categoryDetails.icd,
            response.categoryDetails.mips,
            response.categoryDetails.modifier,
            response.categoryDetails.others
          ];
          statusBreakUpData = [
            response.breakUpStatusDetails.freshrai,
            response.breakUpStatusDetails.completed,
            response.breakUpStatusDetails.hold
          ];
          this.workBenchTotal = response.workbenchDetails.requestTotal;
          this.icdCptTotal = response.categoryDetails.total;
          this.prepareRaiDonuts(
            workBenchDetailsData,
            icdCptBreakupData,
            statusBreakUpData
          );
        }
      }
    });
  }
  public getSelectedFacility(event): void {
    if (event) {
      this.facilitySelectModel = [];
      if (event[0] === -1) {
        this.facilitySelectModel = [];
      } else {
        this.facilitySelectModel = event;
      }
    }
  }
  getSelectedLocation(event): void {
    if (event) {
      this.selectLocationModel = [];
      if (event[0] === -1) {
        this.selectLocationModel = [];
      } else {
        this.selectLocationModel = event;
      }
    }
  }
  validateDate(event, field?: string): any {
    const toDateControl = this.raiDashboardFormGroup.controls['toDate'];
    const fromDateControl = this.raiDashboardFormGroup.controls['fromDate'];
    const validate = this.dateService.dateValidation(
      event,
      fromDateControl,
      toDateControl,
      field
    );
    this.fromDateErrorMessage = '';
    this.toDateErrorMessage = '';
    if (
      validate.toDateControl.status === 'INVALID' &&
      validate.fromDateControl.status === 'INVALID'
    ) {
      setTimeout(() => {
        toDateControl.setErrors({ invalid: true });
        fromDateControl.setErrors({ invalid: true });
        this.toDateErrorMessage = validate.toDateErrorMessage;
        this.fromDateErrorMessage = validate.fromDateErrorMessage;
      }, 100);
    } else if (validate.toDateControl.status === 'INVALID') {
      setTimeout(() => {
        toDateControl.setErrors({ invalid: true });
        this.toDateErrorMessage = validate.toDateErrorMessage;
      }, 100);
    } else if (validate.fromDateControl.status === 'INVALID') {
      setTimeout(() => {
        fromDateControl.setErrors({ invalid: true });
        this.fromDateErrorMessage = validate.fromDateErrorMessage;
      }, 100);
    } else if (
      validate.toDateControl.status === 'VALID' &&
      validate.fromDateControl.status === 'VALID'
    ) {
      setTimeout(() => {
        toDateControl.setErrors(null);
        fromDateControl.setErrors(null);
      }, 100);
    }
  }
}
