import { Injectable } from '@angular/core';
import { environment } from '../../../../environments/environment';
import { HeaderAuthenticationToken } from '../../../auth/authetication-header';
import { HttpClient } from '../../../../../node_modules/@angular/common/http';
import { map } from '../../../../../node_modules/rxjs/operators';
import { ToastsManager } from '../../../../../node_modules/ng2-toastr';
@Injectable()
export class RaiService {
  public envURL = environment.URL;
  public httpOption;
  public httpFileOption;
  constructor(
    private httpHeader: HeaderAuthenticationToken,
    private httpClient: HttpClient,
    private toaster: ToastsManager
  ) {
    this.httpOption = this.httpHeader.setHeaderToken();
    this.httpFileOption = this.httpHeader.setFileHeaderToken();
  }
  public fetchRAIQueueData(params) {
    const APIUrl = this.envURL + 'chartinformation/searchchartinformation';
    return this.httpClient.post(APIUrl, params, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  public getRaiJsonLocal() {
    return this.httpClient.get('./assets/rai.json', this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  public updateRaiDetails(params) {
    const APIUrl = this.envURL + 'chartinformation/updateraidetails';
    return this.httpClient.post(APIUrl, params, this.httpOption).pipe(
      map((response: any) => {
        if (!response.apierror) {
          return response;
        } else {
          this.toaster.info(response.apierror.message);
        }
      })
    );
  }
  public postFile1(formData) {
    // : Observable<HttpEvent<any>>
    const APIUrl = this.envURL + 'chartinformation/uploadfiles';
    return this.httpClient.post(APIUrl, formData, this.httpFileOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  public getLocations() {
    const APIUrl = this.envURL + 'facilitymaster/location';
    return this.httpClient.get(APIUrl, this.httpOption).pipe(
      map((response: any) => {
        if (!response.apierror) {
          return response;
        } else {
          this.toaster.info(response.apierror.message);
        }
      })
    );
  }
  public getFacility() {
    const APIUrl = this.envURL + 'facilitymaster/facility';
    return this.httpClient.get(APIUrl, this.httpOption).pipe(
      map((response: any) => {
        if (!response.apierror) {
          return response;
        } else {
          this.toaster.info(response.apierror.message);
        }
      })
    );
  }
  public getRaiDashboardData(param) {
    const APIUrl = this.envURL + 'clientdashboard/allSectionClient';
    return this.httpClient.post(APIUrl, param, this.httpOption).pipe(
      map((response: any) => {
        if (!response.apierror) {
          return response;
        } else {
          this.toaster.info(response.apierror.message);
        }
      })
    );
  }
  public getRaiReports(param) {
    const APIUrl = this.envURL + 'raireport/raiReport';
    return this.httpClient.post(APIUrl, param, this.httpOption).pipe(
      map((response: any) => {
        if (!response.apierror) {
          return response;
        } else {
          this.toaster.info(response.apierror.message);
        }
      })
    );
  }
}
