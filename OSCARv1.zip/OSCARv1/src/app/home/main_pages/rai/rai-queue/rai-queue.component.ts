import { Component, OnInit, OnChanges, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import * as _moment from 'moment';
import { ValidationService } from '../../../../services/validation.service';
import * as CryptoJS from 'crypto-js';
import { GridOptions } from 'ag-grid';
import { RaiService } from '../rai.service';
import { DateFormatter } from '../../../../imports/_utilities/date-formatter';
import { environment } from '../../../../../environments/environment';
import { Router } from '@angular/router';
import {
  MomentDateAdapter,
  MAT_MOMENT_DATE_FORMATS
} from '@angular/material-moment-adapter';
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE
} from '@angular/material';
import { ToastsManager } from 'ng2-toastr';
import { LocationStrategy } from '@angular/common';
import { CommonCodeService } from '../../../../_shared-services/common-code.services';
@Component({
  selector: 'app-rai-queue',
  templateUrl: './rai-queue.component.html',
  styleUrls: ['./rai-queue.component.scss'],
  providers: [
    ValidationService,
    RaiService,
    DateFormatter,
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS }
  ]
})
export class RaiQueueComponent implements OnInit, OnChanges {
  public raiQueueForm: FormGroup;
  public locationList = [];
  public statusList = [];
  public categoryList = [];
  public RaiQueueRequest = [];
  public workQueueGridOptions: GridOptions;
  public columnDefs;
  public rowSelection;
  public paginationPageSize;
  public workQueuecomponents;
  public workQueueframeworkComponents;
  public confidenceColorCode;
  public gridApi;
  public storage: Storage = environment.storage;
  public fromDateErrorMessage = 'Please enter valid date.';
  urlparameters: any;
  public maxDate = new Date();
  public height = 79;
  @ViewChild('filters') filters;
  constructor(
    private formBuilder: FormBuilder,
    public raiService: RaiService,
    private _dateFormatter: DateFormatter,
    private router: Router,
    public _toastr: ToastsManager,
    public location: LocationStrategy,
    private _commonCode: CommonCodeService
  ) {
    this.getLocationList();
    this.getStatusCategroryList();
    this.initializeForm();
    if (this.storage.getItem('confidenceColorCode')) {
      this.confidenceColorCode = this._commonCode.get_ConfidenceColor_Clientselection(
        'confidenceColorCode'
      );
    }
    history.pushState(
      null,
      null,
      window.location.href
    ); /* preventing back button in browser implemented by 'Samba Siva'  */
    this.location.onPopState(() => {
      history.pushState(null, null, window.location.href);
      console.clear();
    }); /* preventing back button END */
  }
  ngOnInit() {
    this.workQueueGridInit();
    this.getRaiQueue();
  }
  toggleFilter(event){
    if (event === 'block'){
      this.height = 70;
    } else{
      this.height = 79;
    }
  }
  initializeForm() {
    this.raiQueueForm = this.formBuilder.group({
      clientLocation: new FormControl([]),
      date: new FormControl(_moment([]), [ValidationService.DateValidator]),
      status: new FormControl(''),
      category: new FormControl('')
    });
  }
  onGridSizeChanged(params) {
    this.gridApi.sizeColumnsToFit();
  }
  public getStatusCategroryList() {
    this.categoryList = [];
    this.statusList = [];
    this.raiService.getRaiJsonLocal().subscribe(data => {
      if (data) {
        this.categoryList = data.category.map(elemnt => {
          return { name: elemnt };
        });
        this.statusList = data.status.map(elemnt => {
          return { name: elemnt };
        });
      }
    });
  }
  public getLocationList() {
    this.locationList = [];
    this.raiService.getLocations().subscribe(data => {
      if (data) {
        this.locationList = data.map(elemnt => {
          return { name: elemnt };
        });
      }
    });
  }
  public workQueueGridInit(): void {
    this.workQueueGridOptions = <GridOptions>{
      context: {
        componentParent: this
      }
    };
    this.workQueueGridOptions.columnDefs = [
      {
        headerName: 'SL.No.',
        field: 'serialNo',
        valueGetter: 'node.rowIndex + 1',
        suppressNavigable: true,
        cellClass: 'text-right',
        width: 50
      },
      {
        headerName: 'MRN',
        showRowGroup: true,
        cellClass: 'hyper-link',
        field: 'mrn',
        // width: 10,
        cellStyle: {
          fontSize: '14px'
        }
      },
      {
        headerName: 'Accession',
        field: 'accessionNo',
        tooltipField: 'Accession'
      },
      {
        headerName: 'PatientName',
        field: 'patientName',
        tooltipField: 'PatientName'
      },
      {
        headerName: 'DOS',
        field: 'dos',
        tooltipField: 'date',
        valueFormatter: this._dateFormatter.dos,
        cellClass: 'text-center'
      },
      {
        headerName: 'Category',
        field: 'raiCategory',
        tooltipField: 'Category'
      }
    ];
    this.RaiQueueRequest = []; // rowData= RaiQueueRequest
    this.rowSelection = 'single';
    this.paginationPageSize = 50;
    this.workQueuecomponents = {
      simpleCellRenderer: getSimpleCellRenderer()
    };
  }
  ngOnChanges() {
    this.RaiQueueRequest = this.RaiQueueRequest;
    this.autoSizeAll();
  }
  autoSizeAll() {
    if (this.gridApi) {
      this.gridApi.sizeColumnsToFit();
    }
  }
  getRaiQueue(): void {
    const clientRoleList = this.storage.getItem('Role');
    let clientRole;
    if (clientRoleList) {
      clientRole = JSON.parse(
        CryptoJS.AES.decrypt(clientRoleList, 'oscar').toString(
          CryptoJS.enc.Utf8
        )
      );
    }
    const paramsToFetchRAIData = {
      searchLocation: this.raiQueueForm.controls.clientLocation.value
        ? this.raiQueueForm.controls.clientLocation.value.map(elemnt => {
            return elemnt.name;
          })
        : [],
      raiStatus: this.raiQueueForm.controls.status.value
        ? this.raiQueueForm.controls.status.value.name
        : '',
      date: this.raiQueueForm.controls.date.value.format('YYYY-MM-DD')
        ? this.raiQueueForm.controls.date.value.format('YYYY-MM-DD')
        : '',
      raiCategory: this.raiQueueForm.controls.category.value
        ? this.raiQueueForm.controls.category.value.name
        : '',
      role: clientRole ? clientRole[0].role : '',
      userId: this.storage.getItem('UserName'),
      raiSearch: true
    };
    this.storage.setItem('raiParams', JSON.stringify(paramsToFetchRAIData));
    this.getQueueData(paramsToFetchRAIData);
  }
  getQueueData(params): void {
    this.RaiQueueRequest = [];
    this.raiService.fetchRAIQueueData(params).subscribe((data: any) => {
      if (data) {
        this.RaiQueueRequest = data;
      }
    });
  }
  workQueueGridReady(params) {
    this.gridApi = params.api;
    this.autoSizeAll();
    window.addEventListener('resize', function() {
      setTimeout(function() {
        params.api.sizeColumnsToFit();
      });
    });
  }
  onSelectionChanged(rowEvent) {
    const selectedRow = this.gridApi.getSelectedRows();
    this.urlparameters = CryptoJS.AES.encrypt(
      JSON.stringify(selectedRow[0]),
      'oscar'
    ).toString();
    localStorage.setItem('urlParameters', this.urlparameters);
    /* URL Sortening END */
    this.router.navigate(['index/rai/raiplatform']);
  }
}
function getSimpleCellRenderer() {
  function SimpleCellRenderer() {}
  SimpleCellRenderer.prototype.init = function(params) {
    let colorCode;
    const cellConfidenceScore = params.data.confidencescore;
    const confidenceColorCodeCheckList =
      params.context.componentParent.confidenceColorCode;
    confidenceColorCodeCheckList.forEach(elemnt => {
      if (params.context.componentParent.role !== 'admin') {
        if (elemnt.allocationRole !== 'admin') {
          const whichColorCode = between(
            cellConfidenceScore,
            elemnt.lowerLimit,
            elemnt.upperLimit
          );
          if (whichColorCode) {
            colorCode = elemnt.confidenceScore;
          }
        }
      } else {
        const whichColorCode = between(
          cellConfidenceScore,
          elemnt.lowerLimit,
          elemnt.upperLimit
        );
        if (whichColorCode) {
          colorCode = elemnt.confidenceScore;
        }
      }
    });
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML =
      params.value +
      '<span title="confidence Score: ' +
      colorCode +
      '" class="score scoreColor_' +
      colorCode +
      ' float-right">' +
      cellConfidenceScore +
      '</span>';
    this.eGui = tempDiv;
  };
  SimpleCellRenderer.prototype.getGui = function() {
    return this.eGui;
  };
  return SimpleCellRenderer;
}
function between(x, min, max) {
  return x >= min && x <= max;
}
