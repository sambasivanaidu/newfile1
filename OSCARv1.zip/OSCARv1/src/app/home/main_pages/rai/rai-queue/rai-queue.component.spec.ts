import {
  async,
  ComponentFixture,
  TestBed,
  inject
} from '@angular/core/testing';
import { RaiQueueComponent } from './rai-queue.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDynamicDdComponent } from '../../../../imports/_utilities/mat-dynamic-dd/mat-dynamic-dd.component';
import {
  MatDatepickerModule,
  MatNativeDateModule,
  MatSelectModule,
  MatFormFieldModule,
  MatInputModule
} from '@angular/material';
import { MaterialModule } from '../../../../imports/material.module';
import { AgGridModule, BaseComponentFactory } from 'ag-grid-angular';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { HeaderAuthenticationToken } from '../../../../auth/authetication-header';
import { ToastsManager, ToastOptions } from 'ng2-toastr';
import { DatePipe } from '@angular/common';
import { RouterTestingModule } from '@angular/router/testing';
import { RaiService } from '../rai.service';
import { ClientSelectionService } from '../../../../users/client-selection/client-selection.service';
import { HttpModule } from '@angular/http';
import * as CryptoJS from 'crypto-js';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import * as rai from 'assets/testMockData/raiMockData.json';
import { of } from 'rxjs/observable/of';
import { Location, CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { By } from '@angular/platform-browser';
import { CommonCodeService } from '../../../../_shared-services/common-code.services';
import { MatDynamicDdModule } from '../../../../imports/_utilities/mat-dynamic-dd/mat-dynamic-dd.module';
describe('RaiQueueComponent', () => {
  let component: RaiQueueComponent;
  let fixture: ComponentFixture<RaiQueueComponent>;
  let elementRefference;
  const raiQueue = rai['raiQueue'];
  let originalTimeout;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [RaiQueueComponent],
      imports: [
        HttpModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        MatDatepickerModule,
        MatNativeDateModule,
        AgGridModule,
        MatSelectModule,
        MatFormFieldModule,
        MatInputModule,
        HttpClientTestingModule,
        RouterTestingModule,
        NoopAnimationsModule,
        MatDynamicDdModule
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        HeaderAuthenticationToken,
        ToastsManager,
        ToastOptions,
        DatePipe,
        BaseComponentFactory,
        RaiService,
        ClientSelectionService,
        CommonCodeService
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RaiQueueComponent);
    component = fixture.componentInstance;
    elementRefference = fixture.debugElement;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('#search button should be disabled if form is invalid', () => {
    expect(component.raiQueueForm.valid).toBeTruthy();
    expect(
      elementRefference.nativeElement.querySelector('#search').disabled
    ).toBeFalsy();
  });

  it('#getRaiQueue should be called when #search button is clicked', () => {
    component.storage.setItem(
      'role',
      'U2FsdGVkX1+yS4HWRQArfM3Q5s0M7vXSH5A6q5VqqPdqW27QU4/XJset1Yql17NUIHnPEjv1U4G3JBQH/w67G3WN+o3iVMeJYdrPTS8Suz2McROs8uBLHGNIL97Lbhki'
    );
    component.storage.setItem('UserName', 'client');
    fixture.detectChanges();
    spyOn(component, 'getRaiQueue');
    elementRefference.nativeElement.querySelector('#search').click();
    expect(component.getRaiQueue).toHaveBeenCalled();
  });

  it('#getQueueData should be called in getRaiQueue', () => {
    const params = raiQueue['paramsTofetchRAIData'];
    spyOn(component, 'getQueueData');
    component.getQueueData(params);
    expect(component.getQueueData).toHaveBeenCalled();
  });

  it('#getQueueData when no filters', () => {
    const params = raiQueue['paramsTofetchRAIData'];
    const responseParams = raiQueue['data'];
    spyOn(component.raiService, 'fetchRAIQueueData').and.returnValue(
      of(responseParams)
    );
    component.raiService.fetchRAIQueueData(params).subscribe((data: any) => {
      if (data) {
        component.RaiQueueRequest = data;
        fixture.detectChanges();
      }
    });
    expect(component.raiService.fetchRAIQueueData).toHaveBeenCalled();
  });

  it('#getQueueData when there are filters', () => {
    const params = raiQueue['paramsTofetchRAIData_filter'];
    const responseParams = raiQueue['data_filter'];
    spyOn(component.raiService, 'fetchRAIQueueData').and.returnValue(
      of(responseParams)
    );
    component.raiService.fetchRAIQueueData(params).subscribe((data: any) => {
      if (data) {
        component.RaiQueueRequest = data;
        fixture.detectChanges();
      }
    });
    expect(component.raiService.fetchRAIQueueData).toHaveBeenCalled();
  });

  it('#getQueueData when service gives undefined response', () => {
    const params = raiQueue['paramsTofetchRAIData'];
    const responseParams = raiQueue['data_filter'];
    spyOn(component.raiService, 'fetchRAIQueueData').and.returnValue(
      of(undefined)
    );
    component.raiService.fetchRAIQueueData(params).subscribe((data: any) => {
      if (data) {
        component.RaiQueueRequest = data;
        fixture.detectChanges();
      }
      // Nothing to be done handled in service call
    });
    expect(component.raiService.fetchRAIQueueData).toHaveBeenCalled();
  });

});
