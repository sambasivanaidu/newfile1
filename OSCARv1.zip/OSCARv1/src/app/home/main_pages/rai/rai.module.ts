import { CommonModule } from '@angular/common';
import { BreadCrumbModule } from './../reports/bread-crumb/bread-crumb.module';
import { NgModule } from '@angular/core';
import { RaiComponent } from './rai.component';
import { MaterialModule } from '../../../imports/material.module';
import { RaiDashboardComponent } from './rai-dashboard/rai-dashboard.component';
import { RaiQueueComponent } from './rai-queue/rai-queue.component';
import { RaiPlatformComponent } from './rai-platform/rai-platform.component';
import { RouterModule, Routes } from '@angular/router';
import { MatDynamicDdModule } from '../../../imports/_utilities/mat-dynamic-dd/mat-dynamic-dd.module';
import { AgGridModule } from 'ag-grid-angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  PasswordModule,
  InputTextModule,
  PanelModule,
  DialogModule,
  ConfirmDialogModule,
  SharedModule,
  ContextMenuModule
} from 'primeng/primeng';
import { ChartModule } from 'primeng/chart';
import { OscarSharedModule } from '../oscar-shared/oscar-shared.module';
import { CoderModalChildComponent } from '../oscar-shared/coder-modal-child/coder-modal-child.component';
import { ContextMenuService } from 'ngx-contextmenu';
import { MipsDialogModule } from '../../../imports/_utilities/mips-dialog/mips-dialog.module';
const routes: Routes = [
  { path: '', component: RaiComponent },
  { path: 'raiqueue', component: RaiQueueComponent },
  { path: 'raiplatform', component: RaiPlatformComponent },
  { path: 'raidashboard', component: RaiComponent }
];
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    RouterModule.forChild(routes),
    MatDynamicDdModule,
    PasswordModule,
    InputTextModule,
    PanelModule,
    DialogModule,
    ConfirmDialogModule,
    SharedModule,
    ChartModule,
    AgGridModule,
    OscarSharedModule,
    ContextMenuModule,
    BreadCrumbModule,
    MipsDialogModule
  ],
  declarations: [
    RaiComponent,
    RaiDashboardComponent,
    RaiQueueComponent,
    RaiPlatformComponent
  ],
  exports: [],
  providers: [ContextMenuService],
  entryComponents: [CoderModalChildComponent]
})
export class RaiModule {}
