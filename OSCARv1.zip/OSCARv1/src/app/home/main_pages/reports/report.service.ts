import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HeaderAuthenticationToken } from '../../../auth/authetication-header';
import { environment } from '../../../../environments/environment';
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';
import { map } from 'rxjs/operators';
import { ToastsManager } from 'ng2-toastr';
const EXCEL_TYPE =
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
@Injectable()
export class ReportService {
  public envUrl: string = environment.URL;
  public httpOption: any;
  constructor(
    private _httpClient: HttpClient,
    private _httpHeader: HeaderAuthenticationToken,
    private toaster: ToastsManager
  ) {
    this.httpOption = this._httpHeader.setHeaderToken();
  }
  public getProductivityData(params) {
    const url = this.envUrl + 'productivityreport/productivity';
    return this._httpClient.post(url, params, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  getQualityData(params) {
    const url = this.envUrl + 'qualityaccuracy/qualityAccuracyReport';
    return this._httpClient.post(url, params, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  public getTatReconcillationReport(params) {
    const url = this.envUrl + 'tatvsreconciliation/tatvsrecons';
    return this._httpClient.post(url, params, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  public getAgingReport(params) {
    const url = this.envUrl + 'agingreport/agingReport';
    return this._httpClient.post(url, params, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  public getDailyStatusReport(params) {
    const url = this.envUrl + 'dailystatus/dailyStatus';
    return this._httpClient.post(url, params, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  public getDiscardLogReport(params) {
    const url = this.envUrl + 'discardlogreport/discardReport';
    return this._httpClient.post(url, params, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  public getDuplicatesLogReport(params) {
    const url = this.envUrl + 'duplicateslogreport/duplicateLogReport';
    return this._httpClient.post(url, params, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  public getErrorAnalysisReport(params) {
    const url = this.envUrl + 'erroranalysis/errorAnalysis';
    return this._httpClient.post(url, params, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  public getRAILogReport(params) {
    const url = this.envUrl + 'railogreport/raiReport';
    return this._httpClient.post(url, params, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  public getMonthlyInvoiceReport(params) {
    const url = this.envUrl + 'monthlyinvoice/monthlyInvoice';
    return this._httpClient.post(url, params, this.httpOption).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
  }
  downloadExcel(json: any[], excelFileName: string): void {
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(json);
    const workbook: XLSX.WorkBook = {
      Sheets: { data: worksheet },
      SheetNames: ['data']
    };
    const excelBuffer: any = XLSX.write(workbook, {
      bookType: 'xlsx',
      type: 'array'
    });
    this.saveAsExcelFile(excelBuffer, excelFileName);
  }
  saveAsExcelFile(buffer: any, filename: string): void {
    const contentType = EXCEL_TYPE;
    const blob = new Blob([buffer], { type: contentType });
    FileSaver.saveAs(blob, filename + '_' + this.getTimeString() + '.xlsx');
  }
  getTimeString() {
    const dateString = new Date().toDateString();
    const newDateString = dateString.split(' ').join('_');
    const timeString = new Date().toTimeString().split(' ')[0];
    const newTimeString = timeString.split(':').join('');
    const dateTime = newDateString + '_' + newTimeString;
    return dateTime;
  }
}
