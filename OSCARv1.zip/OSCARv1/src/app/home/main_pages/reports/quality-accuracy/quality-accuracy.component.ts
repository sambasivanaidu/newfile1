import { Component, OnInit, ViewChild } from '@angular/core';
import { ClientSelectionService } from '../../../../users/client-selection/client-selection.service';
import { ReportService } from '../report.service';
import { DateFormatter } from '../../../../imports/_utilities/date-formatter';
import { ObservableMedia } from '@angular/flex-layout';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ValidationService } from '../../../../services/validation.service';
import { ToastsManager } from 'ng2-toastr';
import {
  MAT_DATE_LOCALE,
  DateAdapter,
  MAT_DATE_FORMATS
} from '@angular/material';
import {
  MomentDateAdapter,
  MAT_MOMENT_DATE_FORMATS
} from '@angular/material-moment-adapter';
import * as CryptoJS from 'crypto-js';
import { GridOptions } from 'ag-grid';
import * as _moment from 'moment';
import { DatePipe } from '@angular/common';
import { environment } from '../../../../../environments/environment';
import { DateService } from '../../../../_shared-services/date-service/date.service';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
@Component({
  selector: 'app-quality-accuracy',
  templateUrl: './quality-accuracy.component.html',
  styleUrls: ['./quality-accuracy.component.scss'],
  providers: [
    DateFormatter,
    ValidationService,
    ClientSelectionService,
    ReportService,
    DateService,
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS }
  ]
})
export class QualityAccuracyComponent implements OnInit {
  public storage: Storage = environment.storage;
  selectedLocationModel: any;
  qualityData: any;
  fromDateErrorMessage: string;
  toDateErrorMessage: string;
  qualityFormGroup: FormGroup;
  gridColumnApi: any;
  gridApi: any;
  gridOptions: any;
  components: {};
  paginationPageSize: number;
  rowSelection: string;
  rowData: any[];
  facilitySelectModel: any[];
  facility: any[] = [];
  excelExportBtn: boolean = false;
  locationList = [];
  facilityOptionList: any;
  @ViewChild('filters') filters;
  public height = 76;
  constructor(
    private _reportService: ReportService,
    private formBuilder: FormBuilder,
    public toaster: ToastsManager,
    private dateService: DateService,
    private errorService: ErrorHandlingServices
  ) {
    this.getClientSelection();
  }
  ngOnInit() {
    this.gridInit();
    this.intializeQualityForm();
    this.getQualityData();
  }
  toggleFilter(event){
    if (event === 'block'){
      this.height = 67;
    } else{
      this.height = 76;
    }
  }
  public getClientSelection() {
    const clientObj = this.storage.getItem('clientSelectionObject');
    const client = JSON.parse(
      CryptoJS.AES.decrypt(clientObj, 'oscar').toString(CryptoJS.enc.Utf8)
    );
    const clientConfiguration = client.clientConfiguration;
    const clientRow = clientConfiguration.client.filter(
      element => element.name === client.client
    )[0];
    const specialityRow = clientRow.speciality.filter(
      element => element.name === client.specialty
    )[0];
    const locationRow = specialityRow.location.filter(
      element => element.name === client.location
    )[0];
    this.getFacilityList(locationRow);
    this.getLocationList(locationRow);
  }
  public getFacilityList(locationRow) {
    this.facilityOptionList = locationRow.facility;
  }
  public getLocationList(locationRow) {
    this.locationList.push(locationRow);
  }
  public getSelectedFacility(event): void {
    this.rowData = [];
    if (event) {
      this.facilitySelectModel = [];
      if (event[0] === -1) {
        this.facilitySelectModel = [];
      } else {
        this.facilitySelectModel = event;
      }
    }
  }
  gridInit(): void {
    this.gridOptions = <GridOptions>{
      context: {
        componentParent: this
      }
    };
    this.gridOptions.columnDefs = [
      {
        width: 45,
        pinned: 'left',
        suppressSizeToFit: true,
        suppressFilter: true,
        headerCheckboxSelectionFilteredOnly: true,
        editable: false,
        checkboxSelection: function(params) {
          return params.columnApi.getRowGroupColumns().length === 0;
        },
        headerCheckboxSelection: function(params) {
          return params.columnApi.getRowGroupColumns().length === 0;
        }
      },
      {
        headerName: 'S.No.',
        field: '',
        cellRenderer: 'serialNumber',
        width: 70,
        cellClass: 'text-right'
      },
      {
        headerName: 'Coder',
        field: 'coder',
        tooltipField: 'coder',
        width: 250
      },
      {
        headerName: 'Coded',
        field: 'coded',
        tooltipField: 'coded',
        width: 150,
        cellClass: 'text-right'
      },
      {
        headerName: 'Audited',
        field: 'audited',
        tooltipField: 'audited',
        width: 150,
        cellClass: 'text-right'
      },
      {
        headerName: 'Sampling %',
        field: 'samplingPercent',
        tooltipField: 'samplingPercent',
        width: 150,
        cellClass: 'text-right'
      },
      {
        headerName: 'Auditor',
        field: 'auditor',
        tooltipField: 'auditor'
      },
      {
        headerName: 'Total Errors ',
        field: 'totalErrors',
        tooltipField: 'totalErrors',
        cellRenderer: 'sumTotalErrors',
        enableValue: true,
        width: 150,
        cellClass: 'text-right'
      },
      {
        headerName: 'CPT Error',
        field: 'cptError',
        tooltipField: 'cptError',
        width: 150,
        cellClass: 'text-right'
      },
      {
        headerName: 'ICD Error',
        field: 'icdError',
        tooltipField: 'icdError',
        width: 150,
        cellClass: 'text-right'
      },
      {
        headerName: 'Modifier',
        field: 'modifier',
        tooltipField: 'modifier',
        width: 150,
        cellClass: 'text-right'
      },
      {
        headerName: 'Accuracy %',
        field: 'accuracy',
        cellRenderer: 'accuracy',
        width: 150,
        cellClass: 'text-right'
      }
    ];
    function Accuracy() {}
    Accuracy.prototype.init = function(params) {
      this.eGui = document.createElement('span');
      let calVal;
      calVal = Math.round(
        ((params.data.coded -
          (params.data.icdError +
            params.data.cptError +
            params.data.modifier)) /
          params.data.coded) *
          100
      );
      this.eGui.innerHTML = calVal;
    };
    Accuracy.prototype.getGui = function() {
      return this.eGui;
    };
    function SerialNumber() {}
    SerialNumber.prototype.init = function(params) {
      this.eGui = document.createElement('span');
      const sno = params.rowIndex + 1;
      this.eGui.innerHTML = sno;
    };
    SerialNumber.prototype.getGui = function() {
      return this.eGui;
    };
    function SumTotalErrors() {}
    SumTotalErrors.prototype.init = function(params) {
      this.eGui = document.createElement('span');
      this.text = '';
      this.text +=
        params.data.cptError + params.data.icdError + params.data.modifier;
      this.eGui.innerHTML = this.text;
    };
    SumTotalErrors.prototype.obj = function() {
      return this.text;
    };
    SumTotalErrors.prototype.getGui = function() {
      return this.eGui;
    };
    this.rowData = [];
    this.paginationPageSize = 30;
    (this.rowSelection = 'multiple'),
      (this.components = {
        sumTotalErrors: SumTotalErrors,
        serialNumber: SerialNumber,
        accuracy: Accuracy
      });
  }
  autoSizeAll() {
    this.gridApi.sizeColumnsToFit();
  }
  gridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.autoSizeAll();
  }
  public intializeQualityForm() {
    this.qualityFormGroup = this.formBuilder.group({
      fromDate: new FormControl(_moment([]), [ValidationService.DateValidator]),
      toDate: new FormControl(_moment([]), [ValidationService.DateValidator]),
      clientLocation: new FormControl(''),
      facility: new FormControl([])
    });
  }
  getQualityParams() {
    const param = {
      clientFacility: this.qualityFormGroup.controls.facility.value
        ? this.qualityFormGroup.controls.facility.value.map(element => {
            return element.name;
          })
        : [], // this.selectedFacility() === undefined ? [] : this.selectedFacility(),
      clientLocation: this.qualityFormGroup.controls.clientLocation.value
        ? this.qualityFormGroup.controls.clientLocation.value.name
        : '',
      fromDate: this.qualityFormGroup.controls.fromDate.value.format(
        'YYYY-MM-DD'
      ),
      toDate: this.qualityFormGroup.controls.toDate.value.format('YYYY-MM-DD'),
      loginUser: this.storage.getItem('UserName'),
      userRole: this.storage.getItem('osc-def-rol')
    };
    return param;
  }
  onSelectionChanged(event) {
    const selectedRows = event.api.getSelectedRows();
    if (selectedRows.length > 0) {
      this.excelExportBtn = true;
    } else {
      this.excelExportBtn = false;
    }
  }
  public getQualityData() {
    this.rowData = [];
    const params = this.getQualityParams();
    this._reportService.getQualityData(params).subscribe(data => {
      if (data) {
        this.rowData = data;
      }
    });
  }
  public dowloadExcel() {
    const date = new DatePipe('en-US');
    const param = this.gridApi.getSelectedRows();
    this._reportService.downloadExcel(param, 'Quality_report');
    this.errorService.throwSuccess('Excel download successful.');
  }
  validateDate(event, field?: string): any {
    const toDateControl = this.qualityFormGroup.controls['toDate'];
    const fromDateControl = this.qualityFormGroup.controls['fromDate'];
    const validate = this.dateService.dateValidation(
      event,
      fromDateControl,
      toDateControl,
      field
    );
    this.fromDateErrorMessage = '';
    this.toDateErrorMessage = '';
    if (
      validate.toDateControl.status === 'INVALID' &&
      validate.fromDateControl.status === 'INVALID'
    ) {
      setTimeout(() => {
        toDateControl.setErrors({ invalid: true });
        fromDateControl.setErrors({ invalid: true });
        this.toDateErrorMessage = validate.toDateErrorMessage;
        this.fromDateErrorMessage = validate.fromDateErrorMessage;
      }, 100);
    } else if (validate.toDateControl.status === 'INVALID') {
      setTimeout(() => {
        toDateControl.setErrors({ invalid: true });
        this.toDateErrorMessage = validate.toDateErrorMessage;
      }, 100);
    } else if (validate.fromDateControl.status === 'INVALID') {
      setTimeout(() => {
        fromDateControl.setErrors({ invalid: true });
        this.fromDateErrorMessage = validate.fromDateErrorMessage;
      }, 100);
    } else if (
      validate.toDateControl.status === 'VALID' &&
      validate.fromDateControl.status === 'VALID'
    ) {
      setTimeout(() => {
        toDateControl.setErrors(null);
        fromDateControl.setErrors(null);
      }, 100);
    }
  }
}
