// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { QualityAccuracyComponent } from './quality-accuracy.component';

// describe('QualityaccuracyComponent', () => {
//   let component: QualityAccuracyComponent;
//   let fixture: ComponentFixture<QualityAccuracyComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ QualityAccuracyComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(QualityAccuracyComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
