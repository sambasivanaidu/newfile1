import { NgModule } from '@angular/core';
import { AgingReportComponent } from './aging/aging.component';
import { DailyStatusReportComponent } from './daily-status/daily-status.component';
import { DiscardLogReportComponent } from './discard-log/discard-log.component';
import { DuplicatesLogReportComponent } from './duplicates-log/duplicates-log.component';
import { ErrorAnalysisComponent } from './error-analysis/error-analysis.component';
import { MonthlyInvoiceReportComponent } from './monthly-invoice/monthly-invoice.component';
import { ProductivityComponent } from './productivity/productivity.component';
import { QualityAccuracyComponent } from './quality-accuracy/quality-accuracy.component';
import { RAILogReportComponent } from './RAI Log/rai-log.component';
import { RaiReportsComponent } from './rai-reports/rai-reports.component';
import { TatReconcillationComponent } from './tat-reconcillation/tat-reconcillation.component';
import { MaterialModule } from '../../../imports/material.module';
import { RouterModule, Routes } from '@angular/router';
import { MatDynamicDdModule } from '../../../imports/_utilities/mat-dynamic-dd/mat-dynamic-dd.module';
import { AgGridModule } from 'ag-grid-angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
    PasswordModule,
    InputTextModule,
    PanelModule,
    DialogModule,
    ConfirmDialogModule,
    SharedModule

} from 'primeng/primeng';
import { ChartModule } from 'primeng/chart';
import { OscarSharedModule } from '../oscar-shared/oscar-shared.module';
import { PipesModule } from '../../../imports/pipes/pipes.module';
import { CommonModule } from '@angular/common';
import { ReportsComponent } from './reports.component';
import { BreadCrumbModule } from './bread-crumb/bread-crumb.module';

const routes: Routes = [
    { path: 'aging', component: AgingReportComponent},
    { path: 'dailyStatus', component: DailyStatusReportComponent},
    { path: 'discardLog', component: DiscardLogReportComponent},
    { path: 'duplicatesLog', component: DuplicatesLogReportComponent},
    { path: 'errorAnalysis', component: ErrorAnalysisComponent},
    { path: 'monthlyInvoice', component: MonthlyInvoiceReportComponent},
    { path: 'productivity', component: ProductivityComponent},
    { path: 'qualityaccuracy', component: QualityAccuracyComponent},
    { path: 'raiLog', component: RAILogReportComponent},
    { path: 'raiReports', component: RaiReportsComponent},
    { path: 'tatreconciliation', component: TatReconcillationComponent}
  ]
@NgModule({
    declarations: [
        AgingReportComponent,
        DailyStatusReportComponent,
        DiscardLogReportComponent,
        DuplicatesLogReportComponent,
        ErrorAnalysisComponent,
        MonthlyInvoiceReportComponent,
        ProductivityComponent,
        QualityAccuracyComponent,
        RAILogReportComponent,
        RaiReportsComponent,
        TatReconcillationComponent,
        ReportsComponent
    ],
    imports: [
        CommonModule,
        MaterialModule,
        RouterModule.forChild(routes),
        MatDynamicDdModule,
        AgGridModule,
        FormsModule,
        ReactiveFormsModule,
        PasswordModule,
        InputTextModule,
        PanelModule,
        DialogModule,
        ConfirmDialogModule,
        SharedModule,
        ChartModule,
        OscarSharedModule,
        PipesModule,
        BreadCrumbModule
    ]
})

export class ReportsModule {}
