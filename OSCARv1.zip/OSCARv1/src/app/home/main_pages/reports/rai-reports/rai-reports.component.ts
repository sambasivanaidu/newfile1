import { Component, OnInit, ViewChild } from '@angular/core';
import { GridOptions } from 'ag-grid';
import { RaiService } from '../../rai/rai.service';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import * as _moment from 'moment';
import { ValidationService } from '../../../../services/validation.service';
import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter
} from '@angular/material-moment-adapter';
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE
} from '@angular/material/core';
import { ToastsManager } from 'ng2-toastr';
import { DateService } from '../../../../_shared-services/date-service/date.service';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
@Component({
  selector: 'app-rai-reports',
  templateUrl: './rai-reports.component.html',
  styleUrls: ['./rai-reports.component.scss'],
  providers: [
    RaiService,
    DateService,
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS }
  ]
})
export class RaiReportsComponent implements OnInit {
  public gridOptions: GridOptions;
  public columnDefs;
  public rowData: any;
  public gridApi;
  public gridColumnApi;
  public frameworkComponents;
  public rowSelection;
  public paginationPageSize;
  public components;
  public facilityList = [];
  public facilitySelectModel;
  fromDateErrorMessage = 'Please enter valid date.';
  toDateErrorMessage = 'Please enter valid date.';
  raiFormGroup: FormGroup;
  public maxDate = new Date();
  @ViewChild('filters') filters;
  public height = 76;
  constructor(
    private raiService: RaiService,
    private formBuilder: FormBuilder,
    public toaster: ToastsManager,
    private dateService: DateService,
    private errorService: ErrorHandlingServices
  ) {
    this.getFacility();
    this.intializeRaiForm();
    this.gridInit();
  }
  ngOnInit() {
    this.getReports();
  }
  public intializeRaiForm() {
    this.raiFormGroup = this.formBuilder.group({
      fromDate: new FormControl(_moment([]), [ValidationService.DateValidator]),
      toDate: new FormControl(_moment([]), [ValidationService.DateValidator]),
      facility: new FormControl([])
    });
  }
  toggleFilter(event){
    if (event === 'block'){
      this.height = 67;
    } else{
      this.height = 76;
    }
  }
  gridInit(): void {
    this.gridOptions = <GridOptions>{
      context: {
        componentParent: this
      }
    };
    this.gridOptions.columnDefs = [
      {
        width: 45,
        pinned: 'left',
        suppressSizeToFit: true,
        suppressFilter: true,
        headerCheckboxSelectionFilteredOnly: true,
        editable: false,
        checkboxSelection: function(params) {
          return params.columnApi.getRowGroupColumns().length === 0;
        },
        headerCheckboxSelection: function(params) {
          return params.columnApi.getRowGroupColumns().length === 0;
        }
      },
      {
        headerName: 'Batch ID',
        field: 'batchid',
        cellClass: 'text-right'
      },
      {
        headerName: 'Location',
        field: 'locationname',
        tooltipField: 'locationname'
      },
      {
        headerName: 'Facility',
        field: 'facilityname',
        tooltipField: 'facilityname'
      },
      {
        headerName: 'Completed',
        headerClass: 'header header-completed',
        children: [
          {
            headerName: 'Total',
            field: 'totalcompleted',
            tooltipField: 'totalcompleted',
            cellClass: 'text-right'
          },
          {
            headerName: '24 hrs',
            headerTooltip: '24 hrs completed',
            field: 'completed24',
            cellClass: 'text-right'
          },
          {
            headerName: '48 hrs',
            headerTooltip: '48 hrs completed',
            field: 'completed48',
            cellClass: 'text-right'
          },
          {
            headerName: '72 hrs',
            headerTooltip: '72 hrs completed',
            field: 'completed72',
            cellClass: 'text-right'
          },
          {
            headerName: '96 hrs',
            headerTooltip: '96 hrs completed',
            field: 'completed96',
            cellClass: 'text-right'
          },
          {
            headerName: '> 96 hrs',
            headerTooltip: '96 hrs completed',
            field: 'completedo96',
            cellClass: 'text-right'
          }
        ]
      },
      {
        headerName: 'Hold',
        headerClass: 'header header-posted',
        children: [
          {
            headerName: 'Total',
            field: 'totalhold',
            tooltipField: 'totalhold',
            cellClass: 'text-right'
          },
          {
            headerName: '24 hrs',
            headerTooltip: '24 hrs completed',
            field: 'hold24',
            cellClass: 'text-right'
          },
          {
            headerName: '48 hrs',
            headerTooltip: '48 hrs completed',
            field: 'hold48',
            cellClass: 'text-right'
          },
          {
            headerName: '72 hrs',
            headerTooltip: '72 hrs completed',
            field: 'hold72',
            cellClass: 'text-right'
          },
          {
            headerName: '96 hrs',
            headerTooltip: '96 hrs completed',
            field: 'hold96',
            cellClass: 'text-right'
          },
          {
            headerName: '> 96 hrs',
            headerTooltip: '96 hrs completed',
            field: 'holdo96',
            cellClass: 'text-right'
          }
        ]
      },
      {
        headerName: 'Grand Total',
        field: 'totalreceived',
        tooltipField: 'totalreceived',
        cellClass: 'text-right'
      }
    ];
    this.gridOptions.defaultColDef = {
      width: 50
    };
    this.rowData = [];
    this.rowSelection = 'multiple';
    this.paginationPageSize = 30;
  }
  autoSizeAll() {
    this.gridApi.sizeColumnsToFit();
  }
  public getFacility() {
    const paramArr = [];
    this.facilityList = [];
    this.raiService.getFacility().subscribe(res => {
      if (res && res.length > 0) {
        res.forEach(ele => {
          paramArr.push({
            name: ele
          });
        });
      }
      this.facilityList = paramArr;
    });
  }
  public gridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.autoSizeAll();
  }
  public getSelectedFacility(event): void {
    if (event) {
      this.facilitySelectModel = [];
      if (event[0] === -1) {
        this.facilitySelectModel = [];
      } else {
        this.facilitySelectModel = event;
      }
    }
  }
  getReports() {
    this.rowData = [];
    const param = {
      fromDate: this.raiFormGroup.controls.fromDate.value.format('YYYY-MM-DD'),
      toDate: this.raiFormGroup.controls.fromDate.value.format('YYYY-MM-DD'),
      facilityname: this.raiFormGroup.controls.facility.value
        ? this.raiFormGroup.controls.facility.value.map(data => data.name)
        : []
    };
    this.raiService.getRaiReports(param).subscribe(data => {
      if (data) {
        this.rowData = data;
      }
    });
  }
  validateDate(event, field?: string): any {
    const toDateControl = this.raiFormGroup.controls['toDate'];
    const fromDateControl = this.raiFormGroup.controls['fromDate'];
    const validate = this.dateService.dateValidation(
      event,
      fromDateControl,
      toDateControl,
      field
    );
    this.fromDateErrorMessage = '';
    this.toDateErrorMessage = '';
    if (
      validate.toDateControl.status === 'INVALID' &&
      validate.fromDateControl.status === 'INVALID'
    ) {
      setTimeout(() => {
        toDateControl.setErrors({ invalid: true });
        fromDateControl.setErrors({ invalid: true });
        this.toDateErrorMessage = validate.toDateErrorMessage;
        this.fromDateErrorMessage = validate.fromDateErrorMessage;
      }, 100);
    } else if (validate.toDateControl.status === 'INVALID') {
      setTimeout(() => {
        toDateControl.setErrors({ invalid: true });
        this.toDateErrorMessage = validate.toDateErrorMessage;
      }, 100);
    } else if (validate.fromDateControl.status === 'INVALID') {
      setTimeout(() => {
        fromDateControl.setErrors({ invalid: true });
        this.fromDateErrorMessage = validate.fromDateErrorMessage;
      }, 100);
    } else if (
      validate.toDateControl.status === 'VALID' &&
      validate.fromDateControl.status === 'VALID'
    ) {
      setTimeout(() => {
        toDateControl.setErrors(null);
        fromDateControl.setErrors(null);
      }, 100);
    } else {
    }
  }
}
