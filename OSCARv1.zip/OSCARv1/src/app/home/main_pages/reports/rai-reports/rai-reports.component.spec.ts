// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { RaiReportsComponent } from './rai-reports.component';

// describe('RaiReportsComponent', () => {
//   let component: RaiReportsComponent;
//   let fixture: ComponentFixture<RaiReportsComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ RaiReportsComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(RaiReportsComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
