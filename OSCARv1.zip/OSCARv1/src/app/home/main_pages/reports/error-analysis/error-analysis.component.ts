import { Component, OnInit, ViewChild } from '@angular/core';
import {
  MatGridList,
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE
} from '@angular/material';
import { GridOptions } from 'ag-grid';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { ReportService } from '../report.service';
import { DateFormatter } from '../../../../imports/_utilities/date-formatter';
import { ValidationService } from '../../../../services/validation.service';
import { ToastsManager } from 'ng2-toastr';
import * as CryptoJS from 'crypto-js';
import * as _moment from 'moment';
import {
  MomentDateAdapter,
  MAT_MOMENT_DATE_FORMATS
} from '@angular/material-moment-adapter';
import { DashboardService } from '../../dashboard/dashboard.service';
import { environment } from '../../../../../environments/environment';
import { DateService } from '../../../../_shared-services/date-service/date.service';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
@Component({
  selector: 'app-err-analysis',
  templateUrl: './error-analysis.component.html',
  providers: [
    DateFormatter,
    ValidationService,
    ReportService,
    DateService,
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
    DashboardService
  ]
})
export class ErrorAnalysisComponent implements OnInit {
  selectedLocationModel: any;
  @ViewChild('grid') grid: MatGridList;
  public storage: Storage = environment.storage;
  public facility;
  public gridOptions: GridOptions;
  public columnDefs;
  public rowData: any;
  public gridApi;
  public gridColumnApi;
  public frameworkComponents;
  public rowSelection;
  public paginationPageSize;
  public components;
  public toDateModel: any = new Date();
  public formDateModel: any = new Date();
  fromDateErrorMessage = 'Please enter valid date.';
  toDateErrorMessage = 'Please enter valid date.';
  ErrorAnalysisFormGroup: FormGroup;
  excelExportBtn: boolean = false;
  facilityOptionList: any;
  public facilitySelectModel: any;
  locationList = [];
  specialtyList = [];
  coderOptionList: any = [];
  public QACoderSelectModel: any;
  maxDate = new Date();
  role;
  @ViewChild('filters') filters;
  public height = 76;
  constructor(
    private _reportService: ReportService,
    private _dateFormatter: DateFormatter,
    private formBuilder: FormBuilder,
    public toaster: ToastsManager,
    private dashboardService: DashboardService,
    private dateService: DateService,
    private errorService: ErrorHandlingServices
  ) {
    this.role = this.storage.getItem('osc-def-rol');
    this.getClientSelection();
    this.getQACoderList();
  }
  public ngOnInit(): void {
    this.gridInit();
    this.intializeErrorAnaysisForm();
    this.getErrorAnalysisData();
  }
  toggleFilter(event){
    if (event === 'block'){
      this.height = 67;
    } else{
      this.height = 76;
    }
  }
  public getClientSelection() {
    const clientObj = this.storage.getItem('clientSelectionObject');
    const client = JSON.parse(
      CryptoJS.AES.decrypt(clientObj, 'oscar').toString(CryptoJS.enc.Utf8)
    );
    const clientConfiguration = client.clientConfiguration;
    const clientRow = clientConfiguration.client.filter(
      element => element.name === client.client
    )[0];
    const specialityRow = clientRow.speciality.filter(
      element => element.name === client.specialty
    )[0];
    const locationRow = specialityRow.location.filter(
      element => element.name === client.location
    )[0];
    this.getFacilityList(locationRow);
    this.getLocationList(locationRow);
    this.getSpecialityList(specialityRow);
  }
  public getFacilityList(locationRow) {
    this.facilityOptionList = locationRow.facility;
  }
  public getLocationList(locationRow) {
    this.locationList.push(locationRow);
  }
  public getSpecialityList(specialityRow) {
    this.specialtyList.push(specialityRow);
  }
  gridInit(): void {
    this.gridOptions = <GridOptions>{
      context: {
        componentParent: this
      }
    };
    this.gridOptions.columnDefs = [
      {
        width: 45,
        pinned: 'left',
        suppressSizeToFit: true,
        suppressFilter: true,
        headerCheckboxSelectionFilteredOnly: true,
        editable: false,
        checkboxSelection: function(params) {
          return params.columnApi.getRowGroupColumns().length === 0;
        },
        headerCheckboxSelection: function(params) {
          return params.columnApi.getRowGroupColumns().length === 0;
        }
      },
      {
        headerName: 'S.No.',
        field: 'serialNo',
        valueGetter: 'node.rowIndex + 1',
        suppressNavigable: true,
        cellClass: 'text-right',
        type: 'serialNumberCol'
      },
      {
        headerName: 'Location',
        field: 'location',
        tooltipField: 'location',
        type: 'shortAlphaColumn'
      },
      {
        headerName: 'Specialty',
        field: 'specialty',
        tooltipField: 'specialty',
        type: 'shortAlphaColumn'
      },
      {
        headerName: 'Facility',
        field: 'facility',
        tooltipField: 'facility',
        type: 'alphaColumn'
      },
      {
        headerName: 'Batch',
        field: 'batchId',
        tooltipField: 'batchId',
        type: 'alphaColumn'
      },
      {
        headerName: 'Coder',
        field: 'coderName',
        tooltipField: 'coderName',
        type: 'shortAlphaColumn'
      },
      {
        headerName: 'Coded Date',
        field: 'codedDate',
        valueFormatter: this._dateFormatter.reportDate,
        cellClass: 'text-center',
        type: 'shortAlphaColumn'
      },
      {
        headerName: 'Auditor',
        field: 'qaBy',
        tooltipField: 'qaBy',
        type: 'shortAlphaColumn'
      },
      {
        headerName: 'Audited Date',
        field: 'qaDate',
        valueFormatter: this._dateFormatter.qaDate,
        cellClass: 'text-center',
        type: 'shortAlphaColumn'
      },
      {
        headerName: 'Accession No',
        field: 'accessionNumber',
        tooltipField: 'accessionNumber',
        type: 'alphaColumn'
      },
      {
        headerName: 'Error Category',
        headerClass: 'header header-outstanding',
        children: [
          {
            headerName: 'CPT',
            field: 'cptError',
            cellClass: 'text-right text-success font-weight-bold',
            type: 'numberColumn'
          },
          {
            headerName: 'ICD',
            field: 'icdError',
            cellClass: 'text-right text-info font-weight-bold',
            type: 'numberColumn'
          },
          {
            headerName: 'Modifier',
            field: 'modifierError',
            cellClass: 'text-right text-warning font-weight-bold',
            type: 'numberColumn'
          },
          {
            headerName: 'HPCS Level 2',
            field: 'hcpcsLevel3',
            cellClass: 'text-right text-primary font-weight-bold',
            headerTooltip: 'HPCS Level 2',
            type: 'numberColumn'
          },
          {
            headerName: 'Others',
            field: 'otherErrors',
            cellClass: 'text-right text-danger font-weight-bold',
            type: 'numberColumn'
          }
        ]
      }
    ];
    this.gridOptions.defaultColDef = {
      width: 50
    };
    this.gridOptions.columnTypes = {
      ['serialNumberCol']: { width: 80 },
      ['numberColumn']: { width: 100 },
      ['alphaColumn']: { width: 180 },
      ['shortAlphaColumn']: { width: 120 }
    };
    this.rowData = [];
    this.rowSelection = 'multiple';
    this.paginationPageSize = 30;
  }
  autoSizeAll() {
    this.gridApi.sizeColumnsToFit();
  }
  public gridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    // this.autoSizeAll();
  }
  public intializeErrorAnaysisForm() {
    this.ErrorAnalysisFormGroup = this.formBuilder.group({
      fromDate: new FormControl(_moment([]), [ValidationService.DateValidator]),
      toDate: new FormControl(_moment([]), [ValidationService.DateValidator]),
      clientLocation: new FormControl(''),
      specialty: new FormControl(''),
      coderQA: new FormControl([]),
      facility: new FormControl([])
    });
  }
  onSelectionChanged(event) {
    const selectedRows = event.api.getSelectedRows();
    if (selectedRows.length > 0) {
      this.excelExportBtn = true;
    } else {
      this.excelExportBtn = false;
    }
  }
  selectedFacility() {
    this.facility = [];
    if (this.facilitySelectModel) {
      this.facilitySelectModel.forEach(element => {
        this.facility.push(element.name);
      });
      return this.facility;
    }
  }
  public getQACoderList() {
    if (this.role === 'manager') {
      const param = {
        manager: this.storage.getItem('UserName')
      };
      this.dashboardService
        .getCoderQaServiceOnRole(param, this.role)
        .subscribe((data: any) => {
          const tempData = [];
          data.forEach(element => {
            tempData.push({
              id: element.id,
              name: element.userId
            });
          });
          this.coderOptionList = tempData;
        });
    } else if (this.role === 'team lead') {
      const param = {
        teamlead: this.storage.getItem('UserName')
      };
      this.dashboardService
        .getCoderQaServiceOnRole(param, this.role)
        .subscribe((data: any) => {
          const tempData = [];
          data.forEach(element => {
            tempData.push({
              id: element.id,
              name: element.userId
            });
          });
          this.coderOptionList = tempData;
        });
    }
  }
  getParams() {
    const param = {
      clientFacility: this.ErrorAnalysisFormGroup.controls.facility.value
        ? this.ErrorAnalysisFormGroup.controls.facility.value.map(element => {
            return element.name;
          })
        : [], // this.selectedFacility() === undefined ? [] : this.selectedFacility(),
      clientLocation: this.ErrorAnalysisFormGroup.controls.clientLocation.value
        ? [this.ErrorAnalysisFormGroup.controls.clientLocation.value.name]
        : [],
      fromDate: this.ErrorAnalysisFormGroup.controls.fromDate.value.format(
        'YYYY-MM-DD'
      ),
      toDate: this.ErrorAnalysisFormGroup.controls.toDate.value.format(
        'YYYY-MM-DD'
      ),
      specialty: this.ErrorAnalysisFormGroup.controls.specialty.value
        ? [this.ErrorAnalysisFormGroup.controls.specialty.value.name]
        : [],
      coders: this.ErrorAnalysisFormGroup.controls.coderQA.value
        ? this.ErrorAnalysisFormGroup.controls.coderQA.value.map(element => {
            return element.name;
          })
        : [],
      loginUser: this.storage.getItem('UserName'),
      userRole: this.storage.getItem('osc-def-rol')
    };
    return param;
  }
  public getErrorAnalysisData() {
    this.rowData = [];
    const param = this.getParams();
    this._reportService.getErrorAnalysisReport(param).subscribe(data => {
      if (data) {
        this.rowData = data;
      }
    });
  }
  public dowloadExcel() {
    const param = this.gridApi.getSelectedRows();
    const result = this.flatten(param);
    this._reportService.downloadExcel(param, 'Error Analysis_report');
    this.errorService.throwSuccess('Excel download successful.');
  }
  public flatten(array) {
    const someArray = array,
      result = someArray.reduce(function(r, a) {
        return Object.assign(r, a);
      }, {});
    return result;
  }
  validateDate(event, field?: string): any {
    const toDateControl = this.ErrorAnalysisFormGroup.controls['toDate'];
    const fromDateControl = this.ErrorAnalysisFormGroup.controls['fromDate'];
    const validate = this.dateService.dateValidation(
      event,
      fromDateControl,
      toDateControl,
      field
    );
    this.fromDateErrorMessage = '';
    this.toDateErrorMessage = '';
    if (
      validate.toDateControl.status === 'INVALID' &&
      validate.fromDateControl.status === 'INVALID'
    ) {
      setTimeout(() => {
        toDateControl.setErrors({ invalid: true });
        fromDateControl.setErrors({ invalid: true });
        this.toDateErrorMessage = validate.toDateErrorMessage;
        this.fromDateErrorMessage = validate.fromDateErrorMessage;
      }, 100);
    } else if (validate.toDateControl.status === 'INVALID') {
      setTimeout(() => {
        toDateControl.setErrors({ invalid: true });
        this.toDateErrorMessage = validate.toDateErrorMessage;
      }, 100);
    } else if (validate.fromDateControl.status === 'INVALID') {
      setTimeout(() => {
        fromDateControl.setErrors({ invalid: true });
        this.fromDateErrorMessage = validate.fromDateErrorMessage;
      }, 100);
    } else if (
      validate.toDateControl.status === 'VALID' &&
      validate.fromDateControl.status === 'VALID'
    ) {
      setTimeout(() => {
        toDateControl.setErrors(null);
        fromDateControl.setErrors(null);
      }, 100);
    }
  }
}
