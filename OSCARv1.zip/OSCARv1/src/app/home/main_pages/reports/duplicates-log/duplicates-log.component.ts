import { Component, OnInit, ViewChild } from '@angular/core';
import {
  MatGridList,
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE
} from '@angular/material';
import { GridOptions } from 'ag-grid';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { ReportService } from '../report.service';
import { DateFormatter } from '../../../../imports/_utilities/date-formatter';
import { ValidationService } from '../../../../services/validation.service';
import { ToastsManager } from 'ng2-toastr';
import * as CryptoJS from 'crypto-js';
import * as _moment from 'moment';
import {
  MomentDateAdapter,
  MAT_MOMENT_DATE_FORMATS
} from '@angular/material-moment-adapter';
import { environment } from '../../../../../environments/environment';
import { DateService } from '../../../../_shared-services/date-service/date.service';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
@Component({
  selector: 'report-duplicates-log',
  templateUrl: './duplicates-log.component.html',
  providers: [
    DateFormatter,
    ValidationService,
    ReportService,
    DateService,
    ErrorHandlingServices,
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS }
  ]
})
export class DuplicatesLogReportComponent implements OnInit {
  selectedLocationModel: any;
  @ViewChild('grid') grid: MatGridList;
  public storage: Storage = environment.storage;
  public facility;
  public gridOptions: GridOptions;
  public columnDefs;
  public rowData: any;
  public gridApi;
  public gridColumnApi;
  public frameworkComponents;
  public rowSelection;
  public paginationPageSize;
  fromDateErrorMessage = 'Please enter valid date.';
  toDateErrorMessage = 'Please enter valid date.';
  duplicatesLogFormGroup: FormGroup;
  excelExportBtn: boolean = false;
  facilityOptionList: any;
  public facilitySelectModel: any;
  locationList = [];
  specialtyList = [];
  maxDate = new Date();
  @ViewChild('filters') filters;
  public height = 76;
  constructor(
    private _reportService: ReportService,
    private formBuilder: FormBuilder,
    public toaster: ToastsManager,
    private dateService: DateService,
    private errorService: ErrorHandlingServices
  ) {
    this.getClientSelection();
  }
  toggleFilter(event){
    if (event === 'block'){
      this.height = 67;
    } else{
      this.height = 76;
    }
  }
  public ngOnInit(): void {
    this.gridInit();
    this.intializeDuplicatesLogForm();
    this.getDuplicatesLogData();
  }
  public getClientSelection() {
    const clientObj = this.storage.getItem('clientSelectionObject');
    const client = JSON.parse(
      CryptoJS.AES.decrypt(clientObj, 'oscar').toString(CryptoJS.enc.Utf8)
    );
    const clientConfiguration = client.clientConfiguration;
    const clientRow = clientConfiguration.client.filter(
      element => element.name === client.client
    )[0];
    const specialityRow = clientRow.speciality.filter(
      element => element.name === client.specialty
    )[0];
    const locationRow = specialityRow.location.filter(
      element => element.name === client.location
    )[0];
    this.getFacilityList(locationRow);
    this.getLocationList(locationRow);
    this.getSpecialityList(specialityRow);
  }
  public getFacilityList(locationRow) {
    this.facilityOptionList = locationRow.facility;
  }
  public getLocationList(locationRow) {
    this.locationList.push(locationRow);
  }
  public getSpecialityList(specialityRow) {
    this.specialtyList.push(specialityRow);
  }
  gridInit(): void {
    this.gridOptions = <GridOptions>{
      context: {
        componentParent: this
      }
    };
    this.gridOptions.columnDefs = [
      {
        width: 45,
        pinned: 'left',
        suppressSizeToFit: true,
        suppressFilter: true,
        headerCheckboxSelectionFilteredOnly: true,
        editable: false,
        checkboxSelection: function(params) {
          return params.columnApi.getRowGroupColumns().length === 0;
        },
        headerCheckboxSelection: function(params) {
          return params.columnApi.getRowGroupColumns().length === 0;
        }
      },
      {
        headerName: 'S.No.',
        field: 'serialNo',
        valueGetter: 'node.rowIndex + 1',
        suppressNavigable: true,
        width: 60,
        cellClass: 'text-right'
      },
      {
        headerName: 'Location',
        field: 'location',
        tooltipField: 'location'
      },
      {
        headerName: 'Specialty',
        field: 'specialty',
        tooltipField: 'specialty'
      },
      {
        headerName: 'Batch Name',
        field: 'facility',
        tooltipField: 'facility'
      },
      {
        headerName: 'Received Reports',
        field: 'received',
        tooltipField: 'received',
        cellClass: 'text-right text-success font-weight-bold'
      },
      {
        headerName: 'Duplicates Reports',
        field: 'duplicates',
        tooltipField: 'duplicates',
        cellClass: 'text-right text-danger font-weight-bold'
      }
    ];
    this.rowData = [];
    this.rowSelection = 'multiple';
    this.paginationPageSize = 30;
  }
  intializeDuplicatesLogForm() {
    this.duplicatesLogFormGroup = this.formBuilder.group({
      fromDate: new FormControl(_moment([]), [ValidationService.DateValidator]),
      toDate: new FormControl(_moment([]), [ValidationService.DateValidator]),
      clientLocation: new FormControl(''),
      specialty: new FormControl(''),
      batchId: new FormControl(''),
      facility: new FormControl([])
    });
  }
  onSelectionChanged(event) {
    const selectedRows = event.api.getSelectedRows();
    if (selectedRows.length > 0) {
      this.excelExportBtn = true;
    } else {
      this.excelExportBtn = false;
    }
  }
  getParams() {
    const param = {
      batchId: this.duplicatesLogFormGroup.controls.batchId.value
        ? this.duplicatesLogFormGroup.controls.batchId.value
        : '',
      clientFacility: this.duplicatesLogFormGroup.controls.facility.value
        ? this.duplicatesLogFormGroup.controls.facility.value.map(element => {
            return element.name;
          })
        : [], // this.selectedFacility() === undefined ? [] : this.selectedFacility(),
      clientLocation: this.duplicatesLogFormGroup.controls.clientLocation.value
        ? [this.duplicatesLogFormGroup.controls.clientLocation.value.name]
        : [],
      fromDate: this.duplicatesLogFormGroup.controls.fromDate.value.format(
        'YYYY-MM-DD'
      ),
      toDate: this.duplicatesLogFormGroup.controls.toDate.value.format(
        'YYYY-MM-DD'
      ),
      specialty: this.duplicatesLogFormGroup.controls.specialty.value
        ? [this.duplicatesLogFormGroup.controls.specialty.value.name]
        : []
    };
    return param;
  }
  getDuplicatesLogData() {
    this.rowData = [];
    const param = this.getParams();
    this._reportService.getDuplicatesLogReport(param).subscribe(data => {
      if (data) {
        this.rowData = data;
      }
    });
  }
  dowloadExcel() {
    const param = this.gridApi.getSelectedRows();
    this._reportService.downloadExcel(param, 'Duplicates Log_report');
    this.errorService.throwSuccess('Excel download successful.');
  }
  autoSizeAll() {
    this.gridApi.sizeColumnsToFit();
  }
  gridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.autoSizeAll();
  }
  validateDate(event, field?: string): any {
    const toDateControl = this.duplicatesLogFormGroup.controls['toDate'];
    const fromDateControl = this.duplicatesLogFormGroup.controls['fromDate'];
    const validate = this.dateService.dateValidation(
      event,
      fromDateControl,
      toDateControl,
      field
    );
    this.fromDateErrorMessage = '';
    this.toDateErrorMessage = '';
    if (
      validate.toDateControl.status === 'INVALID' &&
      validate.fromDateControl.status === 'INVALID'
    ) {
      setTimeout(() => {
        toDateControl.setErrors({ invalid: true });
        fromDateControl.setErrors({ invalid: true });
        this.toDateErrorMessage = validate.toDateErrorMessage;
        this.fromDateErrorMessage = validate.fromDateErrorMessage;
      }, 100);
    } else if (validate.toDateControl.status === 'INVALID') {
      setTimeout(() => {
        toDateControl.setErrors({ invalid: true });
        this.toDateErrorMessage = validate.toDateErrorMessage;
      }, 100);
    } else if (validate.fromDateControl.status === 'INVALID') {
      setTimeout(() => {
        fromDateControl.setErrors({ invalid: true });
        this.fromDateErrorMessage = validate.fromDateErrorMessage;
      }, 100);
    } else if (
      validate.toDateControl.status === 'VALID' &&
      validate.fromDateControl.status === 'VALID'
    ) {
      setTimeout(() => {
        toDateControl.setErrors(null);
        fromDateControl.setErrors(null);
      }, 100);
    }
  }
}
