import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { GridOptions } from 'ag-grid';
import { DateFormatter } from '../../../../imports/_utilities/date-formatter';
import { ValidationService } from '../../../../services/validation.service';
import { ClientSelectionService } from '../../../../users/client-selection/client-selection.service';
import {
  DateAdapter,
  MAT_DATE_LOCALE,
  MAT_DATE_FORMATS
} from '@angular/material/core';
import {
  MomentDateAdapter,
  MAT_MOMENT_DATE_FORMATS
} from '@angular/material-moment-adapter';
import * as _moment from 'moment';
import { MatGridList } from '@angular/material';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { ToastsManager } from 'ng2-toastr';
import * as CryptoJS from 'crypto-js';
import { ReportService } from '../report.service';
import * as _ from 'lodash';
import { environment } from '../../../../../environments/environment';
import { DateService } from '../../../../_shared-services/date-service/date.service';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
@Component({
  selector: 'app-productivity',
  templateUrl: './productivity.component.html',
  styleUrls: ['./productivity.component.scss'],
  providers: [
    DateFormatter,
    ValidationService,
    ClientSelectionService,
    ReportService,
    DateService,
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS }
  ]
})
export class ProductivityComponent implements OnInit {
  selectedLocationModel: any;
  @ViewChild('grid') grid: MatGridList;
  public storage: Storage = environment.storage;
  productivityData: any;
  public facility;
  public gridOptions: GridOptions;
  public columnDefs;
  public rowData: any;
  public gridApi;
  public gridColumnApi;
  public frameworkComponents;
  public rowSelection;
  public paginationPageSize;
  public components;
  public toDateModel: any = new Date();
  public formDateModel: any = new Date();
  fromDateErrorMessage = 'Please enter valid date.';
  toDateErrorMessage = 'Please enter valid date.';
  productivityFormGroup: FormGroup;
  excelExportBtn: boolean = false;
  facilityOptionList: any;
  public facilitySelectModel: any;
  locationList = [];
  maxDate = new Date();
  @ViewChild('filters') filters;
  public height = 76;
  constructor(
    private _reportService: ReportService,
    private _dateFormatter: DateFormatter,
    private formBuilder: FormBuilder,
    public toaster: ToastsManager,
    private dateService: DateService,
    private errorService: ErrorHandlingServices
  ) {
    this.getClientSelection();
  }
  toggleFilter(event){
    if (event === 'block'){
      this.height = 67;
    } else{
      this.height = 76;
    }
  }
  public getClientSelection() {
    const clientObj = this.storage.getItem('clientSelectionObject');
    const client = JSON.parse(
      CryptoJS.AES.decrypt(clientObj, 'oscar').toString(CryptoJS.enc.Utf8)
    );
    const clientConfiguration = client.clientConfiguration;
    const clientRow = clientConfiguration.client.filter(
      element => element.name === client.client
    )[0];
    const specialityRow = clientRow.speciality.filter(
      element => element.name === client.specialty
    )[0];
    const locationRow = specialityRow.location.filter(
      element => element.name === client.location
    )[0];
    this.getFacilityList(locationRow);
    this.getLocationList(locationRow);
  }
  public getFacilityList(locationRow) {
    this.facilityOptionList = locationRow.facility;
  }
  public getLocationList(locationRow) {
    this.locationList.push(locationRow);
  }
  ngOnInit() {
    this.gridInit();
    this.intializeProductivityForm();
    this.getProductivityData();
  }
  public getSelectedFacility(event): void {
    this.rowData = [];
    if (event) {
      this.facilitySelectModel = [];
      if (event[0] === -1) {
        this.facilitySelectModel = [];
      } else {
        this.facilitySelectModel = event;
      }
    }
  }
  gridInit(): void {
    this.gridOptions = <GridOptions>{
      context: {
        componentParent: this
      }
    };
    this.gridOptions.columnDefs = [
      {
        width: 45,
        pinned: 'left',
        suppressSizeToFit: true,
        suppressFilter: true,
        headerCheckboxSelectionFilteredOnly: true,
        editable: false,
        checkboxSelection: function(params) {
          return params.columnApi.getRowGroupColumns().length === 0;
        },
        headerCheckboxSelection: function(params) {
          return params.columnApi.getRowGroupColumns().length === 0;
        }
      },
      {
        headerName: 'S.No.',
        field: 'serialNo',
        cellRenderer: 'serialNumber',
        cellClass: 'text-right',
        width: 70
      },
      {
        headerName: 'Name',
        field: 'coder',
        tooltipField: 'coder'
      },
      {
        headerName: 'Production',
        field: 'production',
        tooltipField: 'production',
        cellClass: 'text-right'
      },
      {
        headerName: 'Coded Date',
        field: 'date',
        tooltipField: 'date',
        valueFormatter: this._dateFormatter.reportDate,
        cellClass: 'text-center'
      },
      {
        headerName: 'CPH(Chart per hour)',
        field: 'cph',
        tooltipField: 'cph',
        cellClass: 'text-right'
      },
      {
        headerName: 'Productivity %',
        field: 'productivityPercent',
        tooltipField: 'productivityPercent',
        cellClass: 'text-right'
      },
      {
        headerName: 'APT(Average processing time)',
        headerTooltip: 'APT(Average processing time)',
        field: 'apt',
        tooltipField: 'apt',
        cellClass: 'text-right'
      },
      {
        headerName: 'Accuracy %',
        field: 'acuuracyPercent',
        tooltipField: 'Accuracy Percent',
        cellClass: 'text-right'
      }
    ];
    this.rowData = [];
    this.rowSelection = 'multiple';
    this.paginationPageSize = 30;
    this.components = {
      sesrialNumber: 'SerialNumber'
    };
    function SerialNumber() {}
    SerialNumber.prototype.init = function(params) {
      this.eGui = document.createElement('span');
      let sno = 0;
      sno += params.rowIndex + 1;
      this.eGui.innerHTML = sno;
    };
    SerialNumber.prototype.getGui = function() {
      return this.eGui;
    };
  }
  autoSizeAll() {
    this.gridApi.sizeColumnsToFit();
  }
  public gridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.autoSizeAll();
  }
  public intializeProductivityForm() {
    this.productivityFormGroup = this.formBuilder.group({
      fromDate: new FormControl(_moment([]), [ValidationService.DateValidator]),
      toDate: new FormControl(_moment([]), [ValidationService.DateValidator]),
      clientLocation: new FormControl(''),
      facility: new FormControl([])
    });
  }
  onSelectionChanged(event) {
    const selectedRows = event.api.getSelectedRows();
    if (selectedRows.length > 0) {
      this.excelExportBtn = true;
    } else {
      this.excelExportBtn = false;
    }
  }
  getProductivityParams() {
    const param = {
      clientFacility: this.productivityFormGroup.controls.facility.value
        ? this.productivityFormGroup.controls.facility.value.map(element => {
            return element.name;
          })
        : [], // this.selectedFacility() === undefined ? [] : this.selectedFacility(),
      clientLocation: this.productivityFormGroup.controls.clientLocation.value
        .name,
      fromDate: this.productivityFormGroup.controls.fromDate.value.format(
        'YYYY-MM-DD'
      ),
      toDate: this.productivityFormGroup.controls.toDate.value.format(
        'YYYY-MM-DD'
      ),
      loginUser: this.storage.getItem('UserName'),
      userRole: this.storage.getItem('osc-def-rol')
    };
    return param;
  }
  public getProductivityData() {
    this.rowData = [];
    const param = this.getProductivityParams();
    this._reportService.getProductivityData(param).subscribe(data => {
      if (data) {
        this.rowData = data;
      }
    });
  }
  public dowloadExcel() {
    const date = new DatePipe('en-US');
    const param = this.gridApi.getSelectedRows();
    _.each(param, function(item) {
      item.date = date.transform(item.date, 'MM/dd/YYYY');
    });
    this._reportService.downloadExcel(param, 'Productivity_report');
    this.errorService.throwSuccess('Excel download successful.');
  }
  validateDate(event, field?: string): any {
    const toDateControl = this.productivityFormGroup.controls['toDate'];
    const fromDateControl = this.productivityFormGroup.controls['fromDate'];
    const validate = this.dateService.dateValidation(
      event,
      fromDateControl,
      toDateControl,
      field
    );
    this.fromDateErrorMessage = '';
    this.toDateErrorMessage = '';
    if (
      validate.toDateControl.status === 'INVALID' &&
      validate.fromDateControl.status === 'INVALID'
    ) {
      setTimeout(() => {
        toDateControl.setErrors({ invalid: true });
        fromDateControl.setErrors({ invalid: true });
        this.toDateErrorMessage = validate.toDateErrorMessage;
        this.fromDateErrorMessage = validate.fromDateErrorMessage;
      }, 100);
    } else if (validate.toDateControl.status === 'INVALID') {
      setTimeout(() => {
        toDateControl.setErrors({ invalid: true });
        this.toDateErrorMessage = validate.toDateErrorMessage;
      }, 100);
    } else if (validate.fromDateControl.status === 'INVALID') {
      setTimeout(() => {
        fromDateControl.setErrors({ invalid: true });
        this.fromDateErrorMessage = validate.fromDateErrorMessage;
      }, 100);
    } else if (
      validate.toDateControl.status === 'VALID' &&
      validate.fromDateControl.status === 'VALID'
    ) {
      setTimeout(() => {
        toDateControl.setErrors(null);
        fromDateControl.setErrors(null);
      }, 100);
    }
  }
}
