import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from './../../../../imports/material.module';
import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BreadcrumbComponent } from './bread-crumb.component';
import { LookupDataService } from '../../../../_shared-services/unrelated-data-services/lookup-data.service';
import { PlatformService } from '../../../../services/main-pages/paltform-services/platform-service.service';
@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [BreadcrumbComponent],
  exports: [BreadcrumbComponent],
  providers: [LookupDataService, PlatformService]
})
export class BreadCrumbModule {}
