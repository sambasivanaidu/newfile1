import { Component, Input, Output, EventEmitter } from '@angular/core';
import { LookupDataService } from '../../../../_shared-services/unrelated-data-services/lookup-data.service';
import { DomSanitizer } from '@angular/platform-browser';
import { PlatformService } from '../../../../services/main-pages/paltform-services/platform-service.service';
@Component({
  selector: 'bread-crumb',
  templateUrl: './bread-crumb.component.html',
  styleUrls: ['./bread-crumb.component.scss']
})
export class BreadcrumbComponent {
  @Input() title;
  @Input() linkBackUrl;
  @Input() linkBackName;
  @Input() page;
  @Input() isFilter;
  @Input() filters;
  @Input() isLookUp;
  @Input() guide;
  @Input() lookupGuidePath;
  @Input() fileURL;
  @Input() displayPdf;
  @Output() toggleFilter = new EventEmitter();
  public homeHeaderLink = '/index';
  public lookups;
  public lookUpOption;
  constructor(
    public _lookupDataService: LookupDataService,
    public _platformService: PlatformService,
    public sanitzer: DomSanitizer
  ) {}

  doFilter(param) {
    if (param) {
      this._lookupDataService.getLookUpData(param).subscribe(data => {
        if (data) {
          this.lookUpOption = data;
        }
      });
    }
  }
  openpdf(): void {
    if (this.lookupGuidePath) {
      this._platformService
        .fetchPdfFileData(this.lookupGuidePath)
        .subscribe(res => {
          this.fileURL = URL.createObjectURL(res);
          this.fileURL = this.sanitzer.bypassSecurityTrustResourceUrl(
            this.fileURL
          );
        });
      this.displayPdf = 'block';
    }
  }
  toggleFilters() {
    this.filters.style.display === 'none' ? this.filters.style.display = 'block' : this.filters.style.display = 'none';
  }
  onCloseHandled(): void {
    this.displayPdf = 'none';
  }
}
