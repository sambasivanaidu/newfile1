// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { TatReconcillationComponent } from './tat-reconcillation.component';

// describe('TatreconcillationComponent', () => {
//   let component: TatReconcillationComponent;
//   let fixture: ComponentFixture<TatReconcillationComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ TatReconcillationComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(TatReconcillationComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
