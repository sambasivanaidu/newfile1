import { Component, OnInit, ViewChild } from '@angular/core';
import {
  MatGridList,
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE
} from '@angular/material';
import { GridOptions } from 'ag-grid';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { ClientSelectionService } from '../../../../users/client-selection/client-selection.service';
import { ReportService } from '../report.service';
import { DateFormatter } from '../../../../imports/_utilities/date-formatter';
import { ValidationService } from '../../../../services/validation.service';
import { ToastsManager } from 'ng2-toastr';
import * as CryptoJS from 'crypto-js';
import * as _moment from 'moment';
import {
  MomentDateAdapter,
  MAT_MOMENT_DATE_FORMATS
} from '@angular/material-moment-adapter';
import { environment } from '../../../../../environments/environment';
import { DateService } from '../../../../_shared-services/date-service/date.service';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
@Component({
  selector: 'app-tat-reconcillation',
  templateUrl: './tat-reconcillation.component.html',
  styleUrls: ['./tat-reconcillation.component.scss'],
  providers: [
    DateFormatter,
    ValidationService,
    ClientSelectionService,
    ReportService,
    DateService,
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS }
  ]
})
export class TatReconcillationComponent implements OnInit {
  selectedLocationModel: any;
  @ViewChild('grid') grid: MatGridList;
  public facility;
  public gridOptions: GridOptions;
  public columnDefs;
  public rowData: any;
  public gridApi;
  public gridColumnApi;
  public frameworkComponents;
  public rowSelection;
  public paginationPageSize;
  public components;
  public toDateModel: any = new Date();
  public formDateModel: any = new Date();
  fromDateErrorMessage = 'Please enter valid date.';
  toDateErrorMessage = 'Please enter valid date.';
  TatReconcillationFormGroup: FormGroup;
  excelExportBtn: boolean = false;
  facilityOptionList: any;
  public facilitySelectModel: any;
  locationList = [];
  public storage: Storage = environment.storage;
  maxDate = new Date();
  @ViewChild('filters') filters;
  public height = 76;
  constructor(
    private _reportService: ReportService,
    private _dateFormatter: DateFormatter,
    private formBuilder: FormBuilder,
    public toaster: ToastsManager,
    private dateService: DateService,
    private errorService: ErrorHandlingServices
  ) {
    this.getClientSelection();
  }
  public ngOnInit(): void {
    this.gridInit();
    this.intializeTatReconcillationForm();
    this.getTatReconcillationData();
  }
  toggleFilter(event){
    if (event === 'block'){
      this.height = 67;
    } else{
      this.height = 76;
    }
  }
  public getClientSelection() {
    const clientObj = this.storage.getItem('clientSelectionObject');
    const client = JSON.parse(
      CryptoJS.AES.decrypt(clientObj, 'oscar').toString(CryptoJS.enc.Utf8)
    );
    const clientConfiguration = client.clientConfiguration;
    const clientRow = clientConfiguration.client.filter(
      element => element.name === client.client
    )[0];
    const specialityRow = clientRow.speciality.filter(
      element => element.name === client.specialty
    )[0];
    const locationRow = specialityRow.location.filter(
      element => element.name === client.location
    )[0];
    this.getFacilityList(locationRow);
    this.getLocationList(locationRow);
  }
  public getFacilityList(locationRow) {
    this.facilityOptionList = locationRow.facility;
  }
  public getLocationList(locationRow) {
    this.locationList.push(locationRow);
  }
  gridInit(): void {
    this.gridOptions = <GridOptions>{
      context: {
        componentParent: this
      }
    };
    this.gridOptions.columnDefs = [
      {
        width: 45,
        pinned: 'left',
        suppressSizeToFit: true,
        suppressFilter: true,
        headerCheckboxSelectionFilteredOnly: true,
        editable: false,
        checkboxSelection: function(params) {
          return params.columnApi.getRowGroupColumns().length === 0;
        },
        headerCheckboxSelection: function(params) {
          return params.columnApi.getRowGroupColumns().length === 0;
        }
      },
      {
        headerName: 'SL.No.',
        field: 'serialNo',
        valueGetter: 'node.rowIndex + 1',
        suppressNavigable: true,
        cellClass: 'text-right',
        type: 'numberColumn'
      },
      {
        headerName: 'Location',
        field: 'location',
        tooltipField: 'location',
        type: 'alphaColumn'
      },
      {
        headerName: 'Facility',
        field: 'facilityname',
        tooltipField: 'facilityname',
        type: 'alphaColumn'
      },
      {
        headerName: 'Speciality',
        field: 'specialityname',
        tooltipField: 'specialityname',
        type: 'alphaColumn'
      },
      {
        headerName: 'Batch Id',
        field: 'batchId',
        tooltipField: 'batchId',
        type: 'alphaColumn'
      },
      {
        headerName: 'Batch Rec Date',
        field: 'date',
        tooltipField: 'date',
        valueFormatter: this._dateFormatter.reportDate,
        cellClass: 'text-center',
        type: 'alphaColumn'
      },
      {
        headerName: 'Charts Per Batch',
        field: 'chartReceived',
        tooltipField: 'chartReceived',
        cellClass: 'text-right',
        type: 'alphaColumn'
      },
      {
        headerName: 'Duplicate',
        field: 'duplicatecharts',
        tooltipField: 'duplicatecharts',
        cellClass: 'text-right',
        type: 'alphaColumn'
      },
      {
        headerName: 'Discard',
        field: 'discard',
        tooltipField: 'discard',
        cellClass: 'text-center',
        type: 'numberColumn'
      },
      {
        headerName: 'TAT Completed %',
        field: 'tatComPercent',
        cellClass: 'text-right',
        type: 'alphaColumn'
      },
      {
        headerName: 'Avg TAT',
        field: 'totalavgtat',
        cellClass: 'text-right'
      },
      {
        headerName: 'Completed',
        headerClass: 'header header-completed',
        children: [
          {
            headerName: 'Total',
            field: 'completedInfo.subTotal',
            tooltipField: 'completedInfo.subTotal',
            cellClass: 'text-right',
            type: 'numberColumn'
          },
          {
            headerName: '24 hrs',
            headerTooltip: '24 hrs completed',
            field: 'completedInfo.hrs24',
            cellClass: 'text-right',
            type: 'numberColumn'
          },
          {
            headerName: '48 hrs',
            headerTooltip: '48 hrs completed',
            field: 'completedInfo.hrs48',
            cellClass: 'text-right',
            type: 'numberColumn'
          },
          {
            headerName: '72 hrs',
            headerTooltip: '72 hrs completed',
            field: 'completedInfo.hrs72',
            cellClass: 'text-right',
            type: 'numberColumn'
          },
          {
            headerName: '96 hrs',
            headerTooltip: '96 hrs completed',
            field: 'completedInfo.hrs96',
            cellClass: 'text-right',
            type: 'numberColumn'
          },
          {
            headerName: '> 96 hrs',
            headerTooltip: 'Above 96 hrs completed',
            field: 'completedInfo.hrsAbove96',
            cellClass: 'text-right',
            type: 'numberColumn'
          }
        ]
      },
      {
        headerName: 'Outstanding',
        headerClass: 'header header-outstanding',
        children: [
          {
            headerName: 'Total',
            field: 'outstandingInfo.subTotal',
            tooltipField: 'outstandingInfo.subTotal',
            cellClass: 'text-right',
            type: 'numberColumn'
          },
          {
            headerName: '24 hrs',
            headerTooltip: '24 hrs Outstanding',
            field: 'outstandingInfo.hrs24',
            cellClass: 'text-right',
            type: 'numberColumn'
          },
          {
            headerName: '48 hrs',
            headerTooltip: '48 hrs Outstanding',
            field: 'outstandingInfo.hrs48',
            cellClass: 'text-right',
            type: 'numberColumn'
          },
          {
            headerName: '72 hrs',
            headerTooltip: '72 hrs Outstanding',
            field: 'outstandingInfo.hrs72',
            cellClass: 'text-right',
            type: 'numberColumn'
          },
          {
            headerName: '96 hrs',
            headerTooltip: '96 hrs Outstanding',
            field: 'outstandingInfo.hrs96',
            cellClass: 'text-right',
            type: 'numberColumn'
          },
          {
            headerName: '> 96 hrs',
            headerTooltip: 'Above 96 hrs Outstanding',
            field: 'outstandingInfo.hrsAbove96',
            cellClass: 'text-right',
            type: 'numberColumn'
          }
        ]
      },
      {
        headerName: 'RAI Info',
        headerClass: 'header header-posted',
        children: [
          {
            headerName: 'Total',
            field: 'raiInfo.subTotal',
            cellClass: 'text-right',
            type: 'numberColumn'
          },
          {
            headerName: '24 hrs',
            headerTooltip: '24 hrs completed',
            field: 'raiInfo.hrs24',
            cellClass: 'text-right',
            type: 'numberColumn'
          },
          {
            headerName: '48 hrs',
            headerTooltip: '48 hrs completed',
            field: 'raiInfo.hrs48',
            cellClass: 'text-right',
            type: 'numberColumn'
          },
          {
            headerName: '72 hrs',
            headerTooltip: '72 hrs completed',
            field: 'raiInfo.hrs72',
            cellClass: 'text-right',
            type: 'numberColumn'
          },
          {
            headerName: '96 hrs',
            headerTooltip: '96 hrs completed',
            field: 'raiInfo.hrs96',
            cellClass: 'text-right',
            type: 'numberColumn'
          },
          {
            headerName: '> 96 hrs',
            headerTooltip: 'Above 96 hrs completed',
            field: 'raiInfo.hrsAbove96',
            cellClass: 'text-right',
            type: 'numberColumn'
          }
        ]
      },
      {
        headerName: 'SSQ Info',
        headerClass: 'header header-discarded',
        children: [
          {
            headerName: 'Total',
            field: 'ssqInfo.subTotal',
            tooltipField: 'ssqInfo.subTotal',
            cellClass: 'text-right',
            type: 'numberColumn'
          },
          {
            headerName: '24 hrs',
            headerTooltip: '24 hrs completed',
            field: 'ssqInfo.hrs24',
            cellClass: 'text-right',
            type: 'numberColumn'
          },
          {
            headerName: '48 hrs',
            headerTooltip: '48 hrs completed',
            field: 'ssqInfo.hrs48',
            cellClass: 'text-right',
            type: 'numberColumn'
          },
          {
            headerName: '72 hrs',
            headerTooltip: '72 hrs completed',
            field: 'ssqInfo.hrs72',
            cellClass: 'text-right',
            type: 'numberColumn'
          },
          {
            headerName: '96 hrs',
            headerTooltip: '96 hrs completed',
            field: 'ssqInfo.hrs96',
            cellClass: 'text-right',
            type: 'numberColumn'
          },
          {
            headerName: '> 96 hrs',
            headerTooltip: 'Above 96 hrs completed',
            field: 'ssqInfo.hrsAbove96',
            cellClass: 'text-right',
            type: 'numberColumn'
          }
        ]
      },
      {
        headerName: 'QA Info',
        headerClass: 'header header-response',
        children: [
          {
            headerName: 'Total',
            field: 'qaInfo.subTotal',
            tooltipField: 'qaInfo.subTotal',
            cellClass: 'text-right',
            type: 'numberColumn'
          },
          {
            headerName: '24 hrs',
            headerTooltip: '24 hrs completed',
            field: 'qaInfo.hrs24',
            cellClass: 'text-right',
            type: 'numberColumn'
          },
          {
            headerName: '48 hrs',
            headerTooltip: '48 hrs completed',
            field: 'qaInfo.hrs48',
            cellClass: 'text-right',
            type: 'numberColumn'
          },
          {
            headerName: '72 hrs',
            headerTooltip: '72 hrs completed',
            field: 'qaInfo.hrs72',
            cellClass: 'text-right',
            type: 'numberColumn'
          },
          {
            headerName: '96 hrs',
            headerTooltip: '96 hrs completed',
            field: 'qaInfo.hrs96',
            cellClass: 'text-right',
            type: 'numberColumn'
          },
          {
            headerName: '> 96 hrs',
            headerTooltip: 'Above 96 hrs completed',
            field: 'qaInfo.hrsAbove96',
            cellClass: 'text-right',
            type: 'numberColumn'
          }
        ]
      },
      {
        headerName: 'Grand Total',
        field: 'grandTotal',
        tooltipField: 'grandTotal',
        cellClass: 'text-right',
        type: 'alphaColumn'
      }
    ];
    this.gridOptions.defaultColDef = {
      width: 50
    };
    this.gridOptions.columnTypes = {
      ['numberColumn']: { width: 70 },
      ['alphaColumn']: { width: 180 }
    };
    this.rowData = [];
    this.rowSelection = 'multiple';
    this.paginationPageSize = 30;
  }
  autoSizeAll() {
    this.gridApi.sizeColumnsToFit();
  }
  public gridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  public intializeTatReconcillationForm() {
    this.TatReconcillationFormGroup = this.formBuilder.group({
      fromDate: new FormControl(_moment([]), [ValidationService.DateValidator]),
      toDate: new FormControl(_moment([]), [ValidationService.DateValidator]),
      clientLocation: new FormControl([]),
      facility: new FormControl([])
    });
  }
  onSelectionChanged(event) {
    const selectedRows = event.api.getSelectedRows();
    if (selectedRows.length > 0) {
      this.excelExportBtn = true;
    } else {
      this.excelExportBtn = false;
    }
  }
  getParams() {
    const param = {
      clientFacility: this.TatReconcillationFormGroup.controls.facility.value
        ? this.TatReconcillationFormGroup.controls.facility.value.map(
            element => {
              return element.name;
            }
          )
        : [],
      clientLocation: this.TatReconcillationFormGroup.controls.clientLocation
        .value
        ? this.TatReconcillationFormGroup.controls.clientLocation.value.map(
            element => {
              return element.name;
            }
          )
        : [],
      fromDate: this.TatReconcillationFormGroup.controls.fromDate.value.format(
        'YYYY-MM-DD'
      ),
      toDate: this.TatReconcillationFormGroup.controls.toDate.value.format(
        'YYYY-MM-DD'
      ),
      loginUser: this.storage.getItem('UserName'),
      userRole: this.storage.getItem('osc-def-rol')
    };
    return param;
  }
  public getTatReconcillationData() {
    this.rowData = [];
    const param = this.getParams();
    this._reportService.getTatReconcillationReport(param).subscribe(data => {
      if (data) {
        this.rowData = data;
      }
    });
  }
  public dowloadExcel() {
    const param = this.gridApi.getSelectedRows();
    const result = this.flatten(param);
    this._reportService.downloadExcel(param, 'TatvsReconcillation_report');
    this.errorService.throwSuccess('Excel download successful.');
  }
  public flatten(array) {
    const someArray = array,
      result = someArray.reduce(function(r, a) {
        return Object.assign(r, a);
      }, {});
    return result;
  }
  validateDate(event, field?: string): any {
    const toDateControl = this.TatReconcillationFormGroup.controls['toDate'];
    const fromDateControl = this.TatReconcillationFormGroup.controls[
      'fromDate'
    ];
    const validate = this.dateService.dateValidation(
      event,
      fromDateControl,
      toDateControl,
      field
    );
    this.fromDateErrorMessage = '';
    this.toDateErrorMessage = '';
    if (
      validate.toDateControl.status === 'INVALID' &&
      validate.fromDateControl.status === 'INVALID'
    ) {
      setTimeout(() => {
        toDateControl.setErrors({ invalid: true });
        fromDateControl.setErrors({ invalid: true });
        this.toDateErrorMessage = validate.toDateErrorMessage;
        this.fromDateErrorMessage = validate.fromDateErrorMessage;
      }, 100);
    } else if (validate.toDateControl.status === 'INVALID') {
      setTimeout(() => {
        toDateControl.setErrors({ invalid: true });
        this.toDateErrorMessage = validate.toDateErrorMessage;
      }, 100);
    } else if (validate.fromDateControl.status === 'INVALID') {
      setTimeout(() => {
        fromDateControl.setErrors({ invalid: true });
        this.fromDateErrorMessage = validate.fromDateErrorMessage;
      }, 100);
    } else if (
      validate.toDateControl.status === 'VALID' &&
      validate.fromDateControl.status === 'VALID'
    ) {
      setTimeout(() => {
        toDateControl.setErrors(null);
        fromDateControl.setErrors(null);
      }, 100);
    }
  }
}
