interface WorkQueueModel {
    accessionNo: string;
    auditorAllocatedOn: number;
    auditorAllocatedTo: string;
    auditorComments: null;
    auditorConflict: null;
    auditorEndedOn: null;
    auditorErrorFound: null;
    auditorHour: null;
    auditorStartedOn: null;
    backlog: boolean;
    batchId: string;
    chartReasonCode: null;
    chartRemarks: null;
    chartStatus: string;
    coderAcknowledgeOn: null;
    coderAcknowledged: null;
    coderAllocatedOn: null;
    coderAllocatedTo: string;
    coderEndedOn: null;
    coderErrorFound: null;
    coderHour: null;
    coderStartedOn: number;
    correctiveAction: null;
    createdOn: null;
    createdbBy: null;
    dos: number;
    facilityId: string;
    id: number;
    locationId: string;
    managerId: null;
    modality: null;
    modifiedBy: null;
    modifiedOn: null;
    mrn: string;
    patientName: string;
    physicianName: string;
    preventiveAction: null;
    priority: null;
    relatedCharts: boolean;
    rootCause: null;
    smeHour: null;
    specialtyId: string;
    teamLeadId: null;
    uniqueId: string;
    updatedBy: null;
    updatedOn: null;
}

export {
    WorkQueueModel
};
