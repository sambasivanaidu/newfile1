import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ToastsManager, ToastOptions } from 'ng2-toastr';
import { ContextMenuService, ContextMenuModule } from 'ngx-contextmenu';
import { AgGridModule } from 'ag-grid-angular';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';
import { FlexLayoutModule } from '@angular/flex-layout';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DatePipe } from '@angular/common';
import { WorkQueueComponent } from './work-queue.component';
import { HttpModule, Http, ConnectionBackend } from '@angular/http';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { HeaderAuthenticationToken } from '../../../../auth/authetication-header';
import { SMEService } from '../../sme/sme.component.service';
import { of } from 'rxjs/observable/of';
import { CommonCodeService } from '../../../../_shared-services/common-code.services';
import { QueueService } from '../../../../services/main-pages/queue.service';
describe('WorkQueueComponent', () => {
  let component: WorkQueueComponent;
  let fixture: ComponentFixture<WorkQueueComponent>;
  let router: Router;
  let smeService: SMEService;
  let mockSMEServiceStub = {
    startTimerForSME() {
      return of(1);
    }
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [WorkQueueComponent],
      imports: [
        AgGridModule.withComponents([WorkQueueComponent]),
        ContextMenuModule,
        RouterTestingModule.withRoutes([]),
        BrowserAnimationsModule,
        HttpClientTestingModule,
        PerfectScrollbarModule,
        HttpModule
      ],
      providers: [
        ToastsManager,
        ToastOptions,
        DatePipe,
        CommonCodeService,
        HeaderAuthenticationToken,
        { provide: SMEService, useValue: mockSMEServiceStub },
        QueueService
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WorkQueueComponent);
    component = fixture.componentInstance;
    router = TestBed.get(Router);
    smeService = TestBed.get(SMEService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('#onSelectionChanged() is called, we should get urlparameters ', () => {
    component.gridApi = {
      getSelectedRows: function() {
        let data = [
          {
            uniqueId: 'M002327078~4112142001~2016-02-12 00:00:00.0',
            chartRemarks: null,
            facilityId: 'CHSHCF2',
            isProcessed: null,
            auditorAllocatedTo: 'sugavanen'
          }
        ];
        return data;
      }
    };
    component.onSelectionChanged(event);
    expect(component.urlparameters).toBeTruthy();
  });
  //   it('#onSelectionChanged() is called and coderResult is sme, then it should navigate to smePlatform ',()=>{
  //     component.coderResult = 'sme';
  //     // spyOn(smeService, 'startTimerForSME').and.returnValue(of(2));
  //     let navigateSpy = spyOn(router, 'navigate');

  //     component.gridApi = {
  //         getSelectedRows: function() {
  //         let data = [{
  //             uniqueId: 'M002327078~4112142001~2016-02-12 00:00:00.0',
  //             chartRemarks: null,
  //             facilityId: 'CHSHCF2',
  //             isProcessed: null,
  //             auditorAllocatedTo: 'sugavanen'

  //         }];
  //         return data;
  //     }
  //     };
  //     component.onSelectionChanged(event);
  //     // fixture.detectChanges();

  //     expect(navigateSpy).not.toHaveBeenCalledWith(['index/smePlatform']);
  //   });
});
