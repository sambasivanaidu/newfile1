import { Component, OnInit, Input } from '@angular/core';
import { GridOptions } from 'ag-grid';
import { DateFormatter } from '../../../../imports/_utilities/date-formatter';
import { Router } from '@angular/router';
import * as CryptoJS from 'crypto-js';
import { SMEService } from '../../sme/sme.component.service';
import { environment } from '../../../../../environments/environment';
import { LocationStrategy } from '@angular/common';
import { CommonCodeService } from '../../../../_shared-services/common-code.services';
import { QueueService } from '../../../../services/main-pages/queue.service';

@Component({
  selector: 'app-work-queue',
  templateUrl: './work-queue.component.html',
  styleUrls: ['./work-queue.component.scss'],
  providers: [DateFormatter, SMEService]
})
export class WorkQueueComponent implements OnInit {
  @Input() childMessage: any = [];
  @Input() platformType: string;
  @Input() auditorType: boolean;
  urlparameters: any;
  @Input() set setDisplayHeight(value) {
    this.height = value ? value : 630;
  }
  height = 630;
  public storage: Storage = environment.storage;
  public workQueueGridOptions: GridOptions;
  public columnDefs;
  public rowData: any;
  public gridApi;
  public gridColumnApi;
  public workQueueframeworkComponents;
  public rowSelection;
  public paginationPageSize;
  public workQueuecomponents;
  private confidenceColorCode;
  coderResult;
  public role;
  constructor(
    private _coderQueueService: QueueService,
    private router: Router,
    private _dateFilter: DateFormatter,
    private smeService: SMEService,
    public location: LocationStrategy,
    private _commonCode: CommonCodeService
  ) {
    if (this.storage.getItem('confidenceColorCode')) {
      this.confidenceColorCode = this._commonCode.get_ConfidenceColor_Clientselection(
        'confidenceColorCode'
      );
    }
    /* preventing back button in browser implemented by 'Samba Siva'  */
    history.pushState(null, null, window.location.href);
    this.location.onPopState(() => {
      history.pushState(null, null, window.location.href);
      console.clear();
    });
    /* preventing back button END */
    if (this.storage.getItem('clientSelectionObject')) {
      const clientObj = this._commonCode.get_ConfidenceColor_Clientselection(
        'clientSelectionObject'
      );
      this.role = clientObj.workRole.role;
    }
  }
  public ngOnInit(): void {
    this.workQueueGridInit();
  }
  public workQueueGridInit(): void {
    this.workQueueGridOptions = <GridOptions>{
      context: {
        componentParent: this
      }
    };
    this.workQueueGridOptions.columnDefs = [
      {
        headerName: 'Unique ID',
        field: 'uniqueId',
        hide: true,
        tooltipField: 'uniqueId'
      },
      {
        width: 40,
        field: 'confidencescore',
        suppressResize: true,
        suppressSizeToFit: true,
        cellRenderer: 'simpleCellRenderer',
        cellRendererParams: {
          innerRenderer: 'simpleCellRenderer'
        }
      },
      {
        headerName: 'MRN',
        showRowGroup: true,
        cellClass: 'hyper-link',
        field: 'mrn',
        width: 10,
        cellStyle: {
          fontSize: '14px'
        }
      },
      {
        headerName: 'Accession Number',
        field: 'accessionNo',
        tooltipField: 'accessionNo',
        width: 10,
        cellClass: 'text-right',
        cellStyle: { fontSize: '14px' }
      },
      {
        headerName: 'Patient Name',
        field: 'patientName',
        tooltipField: 'patientName',
        width: 10,
        cellStyle: { fontSize: '14px' }
      },
      {
        headerName: 'Date of Service',
        field: 'dos',
        valueFormatter: this._dateFilter.dos,
        tooltipField: 'dos',
        width: 5,
        cellStyle: { fontSize: '14px' },
        cellClass: 'text-center'
      },
      {
        headerName: 'Physician Name',
        field: 'physicianName',
        tooltipField: 'physicianName',
        width: 12,
        cellStyle: { fontSize: '14px' }
      },
      {
        headerName: 'Facility',
        field: 'facilityId',
        tooltipField: 'facilityId',
        width: 15,
        cellStyle: { fontSize: '14px' }
      },
      {
        headerName: 'confidencescore',
        field: 'confidencescore',
        tooltipField: 'facilityId',
        hide: true,
        width: 15,
        cellStyle: { fontSize: '14px' }
      }
    ];
    this.rowData = [];
    this.rowSelection = 'single';
    this.paginationPageSize = 50;
    this.workQueuecomponents = {
      simpleCellRenderer: getSimpleCellRenderer()
    };
  }
  ngOnChanges() {
    this.rowData = this.childMessage;
    this.coderResult = this.platformType;
    this.autoSizeAll();
  }
  autoSizeAll() {
    if (this.gridApi) {
      this.gridApi.sizeColumnsToFit();
    }
  }
  workQueueGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.autoSizeAll();
    window.addEventListener('resize', function() {
      setTimeout(function() {
        params.api.sizeColumnsToFit();
      });
    });
  }
  onSelectionChanged(rowEvent) {
    const platformNavigate = this.coderResult;
    const selectedRow = this.gridApi && this.gridApi.getSelectedRows();
    const uniqueID = selectedRow[0].uniqueId;
    const chartRemarks = selectedRow[0].chartRemarks
      ? selectedRow[0].chartRemarks
      : '';
    const facility = selectedRow[0].facilityId ? selectedRow[0].facilityId : '';
    const isProcessed = selectedRow[0].isProcessed
      ? selectedRow[0].isProcessed
      : false;
    const auditorAllocatedTo = selectedRow[0].auditorAllocatedTo
      ? selectedRow[0].auditorAllocatedTo
      : '';
    /*     author: Samba SIva
           functionality: URL Sortening
           Date: 01/07/2019
    */
    this.urlparameters = CryptoJS.AES.encrypt(
      JSON.stringify(selectedRow[0]),
      'oscar'
    ).toString();
    localStorage.setItem('urlParameters', this.urlparameters);
    /* URL Sortening END*/
    if (platformNavigate === 'sme') {
      this.smeService.startTimerForSME(uniqueID).subscribe((response: any) => {
        if (response) {
          if (response === 1) {
            this.router.navigate(['index/sme/platform']); // ,selectedModalityList: this.modalitySelectModel , selectedFacilityList:this.facilitySelectModel
          }
        }
      });
    } else if (platformNavigate === 'updatecoderstartedon') {
      const auditAck = this.storage.getItem('osc-aud-ack');
      if (auditAck === 'true') {
        this.router.navigate(['/index/coder/platform']);
      } else {
        this._coderQueueService
          .updateStartTimeforCoder(uniqueID, platformNavigate)
          .subscribe(responseList => {
            if ( responseList && responseList === 1) {
              this.router.navigate(['/index/coder/platform']);
            }
          });
      }
    } else if (platformNavigate === 'updateauditorstartedon') {
      if (this.auditorType) {
        this.router.navigate(['index/L2auditor/platform']);
      } else {
        const auditAck = this.storage.getItem('osc-aud-ack');
        if (auditAck === 'true') {
          this.router.navigate(['index/auditor/platform']);
        } else {
          this._coderQueueService
            .updateStartTimeforCoder(uniqueID, platformNavigate)
            .subscribe(responseList => {
              if (responseList && responseList === 1) {
                this.router.navigate(['index/auditor/platform']);
              }
            });
        }
      }
    }
  }
}
// confidencescore
function getSimpleCellRenderer() {
  function SimpleCellRenderer() {}
  SimpleCellRenderer.prototype.init = function(params) {
    let colorCode;
    const cellConfidenceScore = params.data.confidencescore;
    const confidenceColorCodeCheckList =
      params.context.componentParent.confidenceColorCode;
    if (confidenceColorCodeCheckList) {
      confidenceColorCodeCheckList.forEach(element => {
        if (params.context.componentParent.role !== 'admin') {
          if (element.allocationRole !== 'admin') {
            const whichColorCode = between(
              cellConfidenceScore,
              element.lowerLimit,
              element.upperLimit
            );
            if (whichColorCode) {
              colorCode = element.confidenceScore;
            }
          }
        } else {
          const whichColorCode = between(
            cellConfidenceScore,
            element.lowerLimit,
            element.upperLimit
          );
          if (whichColorCode) {
            colorCode = element.confidenceScore;
          }
        }
      });
    }
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML =
    '<span title="confidence Score: ' +
    colorCode +
    '" class="score scoreColor_' +
    colorCode +
    ' float-right">' +
    cellConfidenceScore +
    '</span>';
    this.eGui = tempDiv;
  };
  SimpleCellRenderer.prototype.getGui = function() {
    return this.eGui;
  };
  return SimpleCellRenderer;
}
function between(x, min, max) {
  return x >= min && x <= max;
}
