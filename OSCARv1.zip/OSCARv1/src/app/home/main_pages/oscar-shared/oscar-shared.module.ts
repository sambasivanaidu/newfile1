import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CoderModalChildComponent } from './coder-modal-child/coder-modal-child.component';
import { CptInfoComponent } from './cpt-info/cpt-info.component';
import { IcdInfoComponent } from './icd-info/icd-info.component';
import { PateintInfoComponent } from './pateint-info/pateint-info.component';
import { PateintMedicalReportComponent } from './pateint-medical-report/pateint-medical-report.component';
import { RecordInfoComponent } from './record-info/record-info.component';
import { RelatedVisitComponent } from './related-visit/related-visit.component';
import { WorkQueueComponent } from './work-queue/work-queue.component';
import { MaterialModule } from '../../../imports/material.module';
import { AgGridModule } from 'ag-grid-angular';
import { ContextMenuModule } from 'ngx-contextmenu';
import { PipesModule } from '../../../imports/pipes/pipes.module';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { MatDialogDraggableTitleDirective } from '../../../imports/directive/mat-dialog-draggable-title.directive';
import { CellDeleteBtnRendererComponent } from '../../../imports/ag-grid/delete-btn-render';
import { QueueService } from '../../../services/main-pages/queue.service';
import { MipsDialogModule } from '../../../imports/_utilities/mips-dialog/mips-dialog.module';
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};
@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
    AgGridModule,
    ContextMenuModule,
    PipesModule,
    PerfectScrollbarModule,
    MipsDialogModule
  ],
  declarations: [
    MatDialogDraggableTitleDirective,
    CoderModalChildComponent,
    CptInfoComponent,
    IcdInfoComponent,
    PateintInfoComponent,
    PateintMedicalReportComponent,
    RecordInfoComponent,
    RelatedVisitComponent,
    WorkQueueComponent,
    CellDeleteBtnRendererComponent
  ],
  exports: [
    CoderModalChildComponent,
    CptInfoComponent,
    IcdInfoComponent,
    PateintInfoComponent,
    PateintMedicalReportComponent,
    RecordInfoComponent,
    RelatedVisitComponent,
    WorkQueueComponent
  ],
  entryComponents: [CellDeleteBtnRendererComponent],
  providers: [
    QueueService,
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    }
  ]
})
export class OscarSharedModule {}
