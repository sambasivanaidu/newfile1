import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AgGridModule } from 'ag-grid-angular/main';
import { CptInfoComponent } from './cpt-info.component';
import { MaterialModule } from '../../../../imports/material.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastOptions, ToastsManager } from 'ng2-toastr';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
import { Router, ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { LookupDataService } from '../../../../_shared-services/unrelated-data-services/lookup-data.service';
import { HttpModule } from '@angular/http';
import { HeaderAuthenticationToken } from '../../../../auth/authetication-header';
import { DateFormatter } from '../../../../imports/_utilities/date-formatter';
import { DatePipe } from '@angular/common';
import { CommonCodeService } from '../../../../_shared-services/common-code.services';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component } from '@angular/core';
describe('cptInfoComponent', () => {
  let component: CptInfoComponent;
  let fixture: ComponentFixture<CptInfoComponent>;
  const fakeActivatedRoute = {
    snapshot: { data: {} }
  } as ActivatedRoute;
  let originalTimeout;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CptInfoComponent],
      imports: [
        HttpModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        RouterTestingModule,
        AgGridModule.withComponents([CptInfoComponent]),
        BrowserAnimationsModule,
        HttpClientTestingModule
      ],
      providers: [
        ToastsManager,
        HeaderAuthenticationToken,
        ToastOptions,
        LookupDataService,
        // ErrorHandlingServices,
        DateFormatter,
        DatePipe,
        CommonCodeService,
        ErrorHandlingServices
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 5000;
    fixture = TestBed.createComponent(CptInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(()=> {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = originalTimeout;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('#toggleCol() should call hideShowGridColumnDefs() if platform is auditor', () => {
    spyOn(component, 'hideShowGridColumnDefs');
    component.toggleCol('auditor');
    expect(component.hideShowGridColumnDefs).toHaveBeenCalled();
  });

  it('#toggleCol() should call hideShowGridColumnDefs() if platform is tl', () => {
    spyOn(component, 'hideShowGridColumnDefs');
    component.toggleCol('tl');
    expect(component.hideShowGridColumnDefs).toHaveBeenCalled();
  });

  it('#toggleCol() should call hideShowGridColumnDefs() if platform is sme', () => {
    spyOn(component, 'hideShowGridColumnDefs');
    component.toggleCol('sme');
    expect(component.hideShowGridColumnDefs).toHaveBeenCalled();
  });


  it('#toggleCol() should not call hideShowGridColumnDefs() if platform is not auditor or tl or sme', () => {
    spyOn(component, 'hideShowGridColumnDefs');
    component.toggleCol('test');
    expect(component.hideShowGridColumnDefs).not.toHaveBeenCalled();
  });

  it('#hideShowGridColumnDefs() should call autoSizeAll() ', () => {
    spyOn(component, 'autoSizeAll');
    component.hideShowGridColumnDefs();
    expect(component.autoSizeAll).toHaveBeenCalled();
  });

  it('#checkIcdData() should call addBlankICDGrid() and set eventICD to undefined', () => {
    spyOn(component, 'autoSizeAll');
    component.hideShowGridColumnDefs();
    expect(component.autoSizeAll).toHaveBeenCalled();
  });

  it('#validateICD(event) should return true if icd Value length is lesser than 10', () => {
    const cpt = 'qwert';
    expect(component.validateCPT(cpt)).toBeTruthy();
  });

  it('#validateICD(event) should return false if icd Value length is greater than 10', () => {
    const cpt = 'qwertyuiopp';
    expect(component.validateCPT(cpt)).toBeTruthy();
  });

  it('#accesionNo', () => {
      fixture.detectChanges();
      component.accesionNo = '123456';
    expect(component.accesionNo).toBeDefined();
  });

  it('#platform', () => {
    fixture.detectChanges();
    expect(component.platform).toBeDefined();
});

it('#patientChart', () => {
    fixture.detectChanges();
    component.patientChart = { };
  expect(component.patientChart).toBeDefined();
});

it('#isAuditAcknowledge', () => {
    fixture.detectChanges();
    component.isAuditAcknowledge = true;
  expect(component.isAuditAcknowledge).toBeDefined();
});

it('#setCptSectionHeight', () => {
    fixture.detectChanges();
    component.setCptSectionHeight = ' ';
    expect(component.setCptSectionHeight).toBeUndefined();
});

it('#sanitizeAlert', () => {
    fixture.detectChanges();
        expect(component.sanitizeAlert).toBeDefined();
});

it('#sanitizeAlert', () => {
    fixture.detectChanges();
     expect(component.sanitizeAlert).toEqual(true);
});

it('#newRowData', () => {
    fixture.detectChanges();
     expect(component.newRowData).toBeDefined(true);
});

it('#checkCptData() havebeen called', () => {
    spyOn(component, 'checkCptData');
    component.checkCptData();
    expect(component.checkCptData).toHaveBeenCalled();
  });

  it('#patientMedicalCharts() havebeen called', () => {
    spyOn(component, 'patientMedicalCharts');
    component.patientMedicalCharts();
    expect(component.patientMedicalCharts).toHaveBeenCalled();
  });

  it('#getCptRowData', () => {
    fixture.detectChanges();
        expect(component.getCptRowData).toBeDefined();
});

it('#isHavingCpt', () => {
    fixture.detectChanges();
     expect(component.isHavingCpt).toBeDefined();
});

it('#getSearchTerm', () => {
    fixture.detectChanges();
     expect(component.getSearchTerm).toBeDefined(true);
});

});