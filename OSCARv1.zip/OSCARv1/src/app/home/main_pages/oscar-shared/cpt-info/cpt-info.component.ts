import {
  Component,
  OnInit,
  Input,
  EventEmitter,
  Output,
  OnChanges,
  SecurityContext
} from '@angular/core';
import { GridOptions } from 'ag-grid';
import { CellDeleteBtnRendererComponent } from '../../../../imports/ag-grid/delete-btn-render';
import { ToastsManager } from 'ng2-toastr';
import { LookupDataService } from '../../../../_shared-services/unrelated-data-services/lookup-data.service';
import { environment } from '../../../../../environments/environment';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
import { CommonCodeService } from '../../../../_shared-services/common-code.services';
import { DomSanitizer } from '@angular/platform-browser';
@Component({
  selector: 'app-cpt-info',
  templateUrl: './cpt-info.component.html',
  styleUrls: ['./cpt-info.component.scss']
})
export class CptInfoComponent implements OnInit, OnChanges {
  public storage: Storage = environment.storage;
  public GridOptions: GridOptions;
  public columnDefs;
  public rowData: any;
  public gridApi;
  public gridColumnApi;
  public frameworkComponents;
  public rowSelection;
  public editType;
  public components;
  private confidenceColorCode;
  private deletedCptObj = [];
  public previousnewRowData: any[] = [];
  @Input() CPTInfoRequest: any;
  @Input() accesionNo: any;
  @Input() platform: string = '';
  @Input() eventCPT;
  @Input() cciCheck: any;
  @Input() isAuditAcknowledge: boolean;
  @Output() getCptRowData = new EventEmitter();
  @Output() isHavingCpt = new EventEmitter();
  @Output() getSearchTerm = new EventEmitter();
  @Output() cptIsPristines = new EventEmitter();
  @Output() deletedCpt = new EventEmitter();
  @Input() dateOfService: any;
  @Input() dateOfBirth: any;
  @Input() gender: any;
  @Input() facility: any;
  @Input() patientChart: any;
  rationaleData: any;
  @Output() lastCptDx = new EventEmitter();
  height: any;
  @Input() set setCptSectionHeight(value) {
    this.height = value ? value : 250;
  }
  public lastCptDxVal;
  movedRow: any;
  movedPosition: any;
  replacedRow: any;
  replacedIndex: any;
  newRowData: any[] = [];
  getselectedRow: any[];
  sanitizeAlert = true;
  public role;
  constructor(
    public _toastr: ToastsManager,
    public _lookupDataService: LookupDataService,
    private errorService: ErrorHandlingServices,
    private _sanitizer: DomSanitizer,
    private _commonCode: CommonCodeService
  ) { }
  ngOnInit() {
    if (
      this.storage.getItem('confidenceColorCode') &&
      this.storage.getItem('clientSelectionObject')
    ) {
      this.confidenceColorCode = this._commonCode.get_ConfidenceColor_Clientselection(
        'confidenceColorCode'
      );
      const clientObj = this._commonCode.get_ConfidenceColor_Clientselection(
        'clientSelectionObject'
      );
      this.role = clientObj.workRole.role;
    }
    this.GridInit();
  }
  GridInit() {
    this.GridOptions = <GridOptions>{
      context: {
        componentParent: this
      }
    };
    this.GridOptions.columnDefs = [
      // for coder
      {
        headerName: 'CPT',
        showRowGroup: true,
        field: 'predictCptCode',
        tooltipField: 'aapcCptDescription',
        width: 130,
        editable: function (params) {
          if (params.data[params.colDef.field] === '') {
            return true;
          } else {
            return false;
          }
        },
        rowDrag: true,
        cellEditor: 'simpleCellRenderer',
        onCellValueChanged: function (event) {
          //
        },
        cellStyle: function (params) {
          if (params.data.isActive === false) {
            return { color: 'red' };
          } else {
            return null;
          }
        }
      },
      {
        lockPosition: true,
        valueGetter: 'node.rowIndex + 1',
        field: 'counter',
        width: 60,
        cellClass: 'no-event',
        headerClass: 'hide-header',
        suppressNavigable: true,
        cellRenderer: 'confidenceScore',
        cellRendererParams: {
          innerRenderer: 'confidenceScore'
        }
      },
      // for auditor
      {
        headerName: 'CPT',
        showRowGroup: true,
        field: 'cptCode',
        tooltipField: 'aapcDescription',
        width: 100,
        editable: function (params) {
          if (params.data[params.colDef.field] === '') {
            return true;
          } else {
            return false;
          }
        },
        rowDrag: true,
        hide: true,
        cellEditor: 'simpleCellRenderer',
        cellStyle: function (params) {
          if (params.data.isActive === false) {
            return { color: 'red' };
          } else {
            return null;
          }
        }
      },
      // Common For Both
      {
        headerName: 'MOD',
        field: 'modifier',
        tooltipField: 'modifier',
        width: 90,
        editable: true,
        // editable: function(params) {
        //   if (!params.data.id && params.data[params.colDef.field] === '') {
        //     return true;
        //   } else {
        //     return false;
        //   }
        // },
        cellStyle: function (params) {
          if (params.data.isActive === false) {
            return { color: 'red' };
          } else {
            return null;
          }
        }
      },
      {
        headerName: 'ICD Ref',
        field: 'dxRef',
        tooltipField: 'dxRef',
        width: 100,
        editable: true,
        cellClass: 'text-right',
        cellStyle: function (params) {
          if (params.data.isActive === false) {
            return { color: 'red' };
          } else {
            return null;
          }
        }
      },
      {
        headerName: 'Units',
        field: 'units',
        tooltipField: 'units',
        width: 70,
        editable: true,
        cellClass: 'text-right',
        cellStyle: function (params) {
          if (params.data.isActive === false) {
            return { color: 'red' };
          } else {
            return null;
          }
        }
      },
      {
        headerName: 'rationale data',
        field: 'rationaleData',
        hide: true
        // editable: true
      },
      // common for both
      // for coder
      {
        headerName: 'Accession No.',
        field: 'accession',
        tooltipField: 'accession',
        width: 125,
        // editable: true,
        editable: function (params) {
          return params.node.data.hasOwnProperty('isCoded');
        },
        cellStyle: function (params) {
          if (params.data.isActive === false) {
            return { color: 'red' };
          } else {
            return null;
          }
        }
      },
      // for auditor
      {
        headerName: 'Accession No.',
        field: 'accessionNo',
        tooltipField: 'accessionNo',
        width: 125,
        editable: function (params) {
          return params.node.data.hasOwnProperty('isCoded');
        },
        hide: true,
        cellStyle: function (params) {
          if (params.data.isActive === false) {
            return { color: 'red' };
          } else {
            return null;
          }
        }
      },
      {
        headerName: 'Score',
        field: 'probabilityScore',
        tooltipField: 'probabilityScore',
        editable: false,
        hide: true
      },
      {
        width: 30,
        editable: false,
        cellRenderer: 'deleteBtn',
        cellClass: 'p-0'
      },
      {
        headerName: 'Is Active',
        field: 'isActive',
        hide: true
      }
    ];
    this.GridOptions.onCellEditingStopped = function (evt) {
      this.context.componentParent.clearSelection();
      /* Added previous CPT DexRef Value to New Row implemented by Samba siva  */
      const rowCount =
        evt.context.componentParent.gridApi.getDisplayedRowCount() - 1;
      evt.context.componentParent.gridApi.forEachNode(function (rowNode, index) {
        if (rowCount === index) {
          const lastCptDxVal = rowNode.data.dxRef;
          evt.context.componentParent.lastCptDx.emit(lastCptDxVal);
        }
      });
      if (
        evt.colDef.field === 'accession' ||
        evt.colDef.field === 'accessionNo'
      ) {
        let accessionNumber;
        if (evt.data.accessionNo) {
          accessionNumber = evt.data.accessionNo.trim('').toUpperCase();
          evt.node.data[evt.colDef.field] = accessionNumber;
          evt.api.refreshView();
        } else {
          accessionNumber = evt.data.accession.trim('').toUpperCase();
          evt.node.data[evt.colDef.field] = accessionNumber;
          evt.api.refreshView();
        }
        const accessionValue = evt.context.componentParent.accesionNo;
        const accessionArray = accessionValue.split(' ');
        if (accessionArray.length > 0) {
          let count = 0;
          accessionArray.forEach(element => {
            if (element.toUpperCase() === accessionNumber) {
              count++;
            }
          });
          if (count < 1) {
            evt.context.componentParent._toastr.warning(
              'Wrong ' + evt.colDef.headerName + ' not allowed.'
            );
            evt.node.data[evt.colDef.field] = '';
            evt.api.refreshView();
          }
        } else {
          if (evt.context.componentParent.accesionNo !== accessionNumber) {
            evt.context.componentParent._toastr.warning(
              'Wrong ' + evt.colDef.headerName + ' not allowed.'
            );
            evt.node.data[evt.colDef.field] = '';
            evt.api.refreshView();
          }
        }
      }
      if (
        evt.colDef.field === 'cptCode' ||
        evt.colDef.field === 'predictCptCode'
      ) {
        evt.context.componentParent.gridApi.stopEditing();
        evt.context.componentParent.gridApi.forEachNode(function (node) {
          node.setSelected(true);
        });
        const getselectedRow = evt.context.componentParent.gridApi.getSelectedRows();
        const cptCount = evt.context.componentParent.validateCPT(
          evt.node.data[evt.colDef.field]
        );
        getselectedRow.push(evt.data);
        if (!cptCount) {
          evt.context.componentParent._toastr.warning(
            evt.colDef.headerName + ' Code cannot be greater than 11'
          );
          evt.node.data[evt.colDef.field] = '';
          evt.api.refreshView();
        }
      }
    };
    this.components = {
      simpleCellRenderer: getSimpleCellRenderer(),
      confidenceScore: getConfidenceScore()
    };
    this.rowData = [];
    this.rowSelection = 'multiple';
    this.frameworkComponents = {
      deleteBtn: CellDeleteBtnRendererComponent
    };
    const cptData = {
      length: this.gridApi ? this.gridApi.getSelectedRows().length : null,
      component: 'cpt'
    };
  }
  validateCPT(event) {
    const cptValue = event;
    const isValid = cptValue && cptValue.length > 11 ? false : true;
    return isValid;
  }
  deleteRowNode(node) {
    let lastCptDxVal;
    this.sanitizeAlert = false;
    if (node.data.id === null) {
      this.gridApi.updateRowData({ remove: [node.data] });
    } else {
      node.setDataValue('isActive', false);
      this.deletedCptObj = node.data;
      this.deletedCpt.emit(this.deletedCptObj);
      this.gridApi.updateRowData({ remove: [node.data] });
      this.gridApi.refreshView();
    }
    const cptData = {
      length: this.gridApi.getSelectedRows().length,
      component: 'cpt'
    };
    const rowCount = this.gridApi.getDisplayedRowCount() - 1;
    this.gridApi.forEachNode(function (rowNode, index) {
      if (rowCount === index) {
        lastCptDxVal = rowNode.data.dxRef;
      }
    });
    this.lastCptDx.emit(lastCptDxVal);
    this.getAllRowData();
  }
  clearSelection() {
    const selectedText = document.querySelectorAll(
      '.highlighted, .ht, .htb, .hted'
    );
    let parent;
    for (let i = 0; i < selectedText.length; i++) {
      parent = selectedText[i].parentNode;
      if (selectedText[i].firstChild) {
        parent.insertBefore(selectedText[i].firstChild, selectedText[i]);
      }
      parent.removeChild(selectedText[i]);
    }
  }
  validateDuplicate(cptList, objKey) {
    const values = cptList;
    const code = objKey;
    const valueArr = values.map(function (item) {
      return item[code];
    });
    const isDuplicate = valueArr.some(function (item, idx) {
      return valueArr.indexOf(item) !== idx;
    });
    return isDuplicate;
  }
  refreshCellData() {
    this.gridApi.refreshView();
  }
  ngOnChanges() {
    this.toggleCol(this.platform);
    this.patientMedicalCharts();
    this.fetchCptInfo();
    this.checkCptData();
    this.checkAllRow();
    this.getAllRowData();
    if (this.cciCheck) {
      this.updateCptModifier(this.cciCheck);
    }
  }
  onCellClicked(event: any) {
    if (
      event.colDef.field === 'cptCode' ||
      event.colDef.field === 'predictCptCode'
    ) {
      let objRational;
      const code =
        event.data.cptCode !== undefined
          ? event.data.cptCode
          : event.data.predictCptCode;
      const strData = event.data.rationaleData;
      if (strData) {
        if (typeof event.data.rationaleSection === 'undefined') {
          objRational = null;
        } else {
          objRational = event.data.rationaleSection;
        }
        const obj =
          objRational === null
            ? null
            : objRational
              .filter(o => o.sectionName === 'NOT FOUND')
              .map(s => s.sectionName)
              .includes('NOT FOUND');
        if (obj) {
          this.errorService.throwInfo(
            'No section name found for highlighted text'
          );
        }
        event.context.componentParent.getSearchTerm.emit(strData);
      } else {
        setTimeout(() => {
          this.errorService.throwInfo('No Rationale found for CPT: ' + code);
        }, 10);
      }
    } else {
      this.clearSelection();
    }
  }
  updateCptModifier(param) {
    const modifier = param.modifier;
    if (modifier && modifier.length > 0) {
      const cptRowData = this.gridApi.getSelectedRows();
      cptRowData.forEach(element => {
        const cptCode = element.predictCptCode
          ? element.predictCptCode
          : element.cptCode;
        modifier.forEach(modifierArray => {
          if (modifierArray.cptcode === cptCode) {
            element.modifier = modifierArray.modifier;
          }
        });
      });
      setTimeout(() => {
        this.gridApi.updateRowData({ update: cptRowData });
      }, 10);
    }
    this.cciCheck = [];
  }
  // cptDescription
  highlightStr(event: any) {
    const param = [];
    let strValue;
    if (event.value) {
      if (event.context.componentParent.platform === 'auditor') {
        strValue = event.data.cptDescription;
      } else {
        strValue = event.data.cptChart;
      }
      const str = strValue.split(':');
      str.forEach(element => {
        if (element && element !== '') {
          param.push({
            text: element.trim()
          });
        }
      });
      event.context.componentParent.getSearchTerm.emit(param);
    }
  }
  toggleCol(platform) {
    if (platform === 'auditor' || platform === 'tl' || platform === 'sme') {
      this.hideShowGridColumnDefs();
    }
  }
  checkCptData() {
    if (this.eventCPT) {
      if (Object.keys(this.eventCPT).length !== 0) {
        this.eventCPT.isCoded = true;
        this.addBlankCPTGrid(this.eventCPT);
      }
      this.eventCPT = undefined;
    }
  }
  patientMedicalCharts() {
    if (this.patientChart) {
      const pc = JSON.stringify(this.patientChart);
      this.rationaleData = JSON.parse(pc);
    }
  }
  fetchCptInfo() {
    if (this.CPTInfoRequest) {
      this.addRationaleData();
      this.rowData = this.CPTInfoRequest;
      this.CPTInfoRequest.forEach((element, index) => {
        if (this.CPTInfoRequest.length - 1 === index) {
          const lastCptDxVal = element.dxRef;
          this.lastCptDx.emit(lastCptDxVal);
        }
      });
      setTimeout(() => {
        this.rowData = this.CPTInfoRequest;
        this.getCptRowData.emit(this.rowData);
      }, 20);
    }
  }
  addRationaleData() {
    if (this.patientChart) {
      if (!this.isAuditAcknowledge) {
        this.CPTInfoRequest.filter(cptList => {
          cptList.rationaleData = this.appendRationale(
            this.patientChart,
            cptList.rationaleSection
          );
        });
      }
      this.CPTInfoRequest;
    }
  }

  groupBy(arr) {
    let result = [];
    result = arr.reduce(function (r, a) {
      r[a.section] = r[a.section] || [];
      r[a.section].push(a);
      return r;
    }, Object.create(null));
    return result;
  }

  appendRationale(originalText, sectionArr) {
    try {
      if (originalText && sectionArr) {
        sectionArr.forEach((element, i) => {
          if (element.section !== '' || element.value !== '' || element.phrase !== '') {
            let regName, regValue, secValue, valueText;
            const htmlName = '<span class="htb">$&</span><oscar' + i + '>';
            const htmlValue = '<span class="htn">$&</span>';
            regName = new RegExp('\\b' + element.section + '\\b', 'i');
            originalText = originalText.replace(regName, htmlName);
            secValue = element.phrase.split('|');
            valueText = originalText.split('<oscar' + i + '>');
            secValue.forEach((element) => {
              const eleValue = element.replace(/\.$/, ' ');
              const eleVal = eleValue.trim();
              regValue = new RegExp('\\b' + eleVal + '\\b', 'i');
              valueText[1] = valueText[1].replace(regValue, htmlValue);
            });
            originalText = valueText[0] + valueText[1];
          } else {
            originalText = originalText;
          }
        });
        return originalText;
      }
    } catch (error) {
    }
  }

  hideShowGridColumnDefs() {
    if (this.GridOptions) {
      this.GridOptions.columnApi.setColumnsVisible(
        ['cptCode', 'accessionNo', 'aapcDescription', 'cptDescription'],
        true
      );
      this.GridOptions.columnApi.setColumnsVisible(
        ['predictCptCode', 'accession', 'aapcCptDescription', 'cptChart'],
        false
      );
      this.autoSizeAll();
    }
  }
  onGridSizeChanged(params) {
    this.gridApi.sizeColumnsToFit();
  }
  private sanitizeHtml(input) {
    return this._sanitizer.sanitize(SecurityContext.HTML, input);
  }
  onCellValueChanged($event) {
    const currentvalue = $event.newValue;
    if (typeof currentvalue === 'string') {
      const sanitizedvalue = this.sanitizeHtml(currentvalue);
      if (currentvalue != sanitizedvalue) {
        if (this.sanitizeAlert) {
          this._toastr.info('Entered value can\'t be accepted', 'Info', 'Oops!');
        }
        $event.node.data[$event.column.colId] = '';
        $event.api.refreshView();
      }
    }
    this.checkAllRow();
    this.validateBlankRecord();
    this.getAllRowData();
    this.isCellvalueChanges($event);
  }
  isCellvalueChanges(params) {
    if (params.newValue !== params.oldValue) {
      this.cptIsPristines.emit(true);
    }
  }
  validateBlankRecord() {
    let tempCpt;
    let getselectedRow;
    if (this.gridApi) {
      getselectedRow = this.gridApi.getSelectedRows();
      if (getselectedRow.length > 0) {
        tempCpt = this.checkArray(getselectedRow) === undefined ? true : false;
      } else {
        tempCpt = false;
      }
      setTimeout(() => {
        this.isHavingCpt.emit(tempCpt);
      }, 10);
    }
  }
  checkArray(my_arr) {
    for (let i = 0; i < my_arr.length; i++) {
      if (
        this.platform === 'auditor' ||
        this.platform === 'tl' ||
        this.platform === 'sme'
      ) {
        if (my_arr[i].cptCode === '' || my_arr[i].cptCode === null) {
          return false;
        }
      } else {
        if (
          my_arr[i].predictCptCode === '' ||
          my_arr[i].predictCptCode === null
        ) {
          return false;
        }
      }
    }
  }
  gridFocus(event) {
    window.setTimeout(function () {
      if (document.getElementById('ajax')) {
        document.getElementById('ajax').focus();
      }
    }, 0);
  }
  // Add Blank row
  addBlankCPTGrid(newItem) {
    this.gridApi.updateRowData({ add: [newItem] });
    this.checkAllRow();
    this.getAllRowData();
  }
  getAllRowData() {
    if (this.gridApi) {
      setTimeout(() => {
        let lastCptDxVal;
        const getselectedRow = this.gridApi.getSelectedRows();
        const removeEmptyData = getselectedRow.filter(
          value => Object.keys(value).length !== 0
        );
        this.getCptRowData.emit(removeEmptyData);
        const rowCount = this.gridApi.getDisplayedRowCount() - 1;
        this.gridApi.forEachNode(function (rowNode, index) {
          if (rowCount === index) {
            lastCptDxVal = rowNode.data.dxRef;
          }
        });
        this.lastCptDx.emit(lastCptDxVal);
        this.newRowData = [];
        this.gridApi.forEachNode((node, index) => {
          this.newRowData.push(node.data);
          node.data.counter = node.childIndex;
        });
        this.getCptRowData.emit(this.newRowData);
        const cptData = {
          length: this.gridApi.getSelectedRows().length,
          component: 'cpt'
        };
      }, 20);
    }
  }
  removeHighlight() {
    const selectedText = document.querySelectorAll('.highlighted');
    for (let i = 0; i < selectedText.length; i++) {
      selectedText[i].classList.remove('highlighted');
    }
  }
  checkAllRow() {
    if (this.gridApi) {
      setTimeout(() => {
        this.gridApi.forEachNode(function (node) {
          node.setSelected(true);
        });
      }, 10);
    }
  }
  autoSizeAll() {
    this.gridApi.sizeColumnsToFit();
  }
  GridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.autoSizeAll();
    this.checkAllRow();
    this.validateBlankRecord();
  }
  onRowDragEnd(e) {
    const displayModel = e.api.getModel();
    const rowNode = displayModel.rowsToDisplay[e.node.rowIndex];
    rowNode.setDataValue('counter', e.overIndex + 1);
  }
}
// confidencescore
function getConfidenceScore() {
  function SimpleCellRenderer() { }
  SimpleCellRenderer.prototype.init = function (params) {
    let tempDiv;
    if (params.context.componentParent.platform === 'coder') {
      const cellConfidenceScore = Math.round(params.data.probabilityScore);
      if (cellConfidenceScore) {
        let colorCode;
        const confidenceColorCodeCheckList =
          params.context.componentParent.confidenceColorCode;
        confidenceColorCodeCheckList.forEach(element => {
          if (params.context.componentParent.role !== 'admin') {
            if (element.allocationRole !== 'admin') {
              const whichColorCode = between(
                cellConfidenceScore,
                element.lowerLimit,
                element.upperLimit
              );
              if (whichColorCode) {
                colorCode = element.confidenceScore;
              }
            }
          } else {
            const whichColorCode = between(
              cellConfidenceScore,
              element.lowerLimit,
              element.upperLimit
            );
            if (whichColorCode) {
              colorCode = element.confidenceScore;
            }
          }
        });
        tempDiv = document.createElement('div');
        tempDiv.innerHTML =
          '<span class="block">' +
          params.value +
          '</span>' +
          '<span title="ICD: ' +
          params.value +
          ' , Probability Score: ' +
          colorCode +
          '" class="probability probabilityColor_' +
          colorCode +
          ' float-right">' +
          cellConfidenceScore +
          '</span>';
        this.eGui = tempDiv;
      } else {
        tempDiv = document.createElement('div');
        tempDiv.innerHTML =
          params.value +
          '<span class="probability probabilityColor_nps float-right">NPS</span>';
      }
    } else {
      tempDiv = document.createElement('div');
      tempDiv.innerHTML = params.value;
    }
    this.eGui = tempDiv;
  };
  SimpleCellRenderer.prototype.getGui = function () {
    return this.eGui;
  };
  return SimpleCellRenderer;
}
function getSimpleCellRenderer() {
  function SimpleCellRenderer() { }
  SimpleCellRenderer.prototype.getGui = function () {
    return this.eGui;
  };
  SimpleCellRenderer.prototype.getValue = function () {
    const inputvalue = this.eGui.firstElementChild.value;
    let retValue;
    if (this.dataListValue && this.dataListValue.length > 0) {
      const updatedValue = this.dataListValue.find(o => o.code === inputvalue)
        ? inputvalue
        : '';
      if (updatedValue !== '') {
        retValue = updatedValue;
      } else {
        this.param.context.componentParent._toastr.warning('Invalid CPT Code');
        retValue = this.oldValue;
      }
      if (this.param.context.componentParent.platform === 'coder') {
        this.param.node.data.aapcCptDescription = this.dataListValue[0].desc;
      } else {
        this.param.node.data.aapcDescription = this.dataListValue[0].desc;
      }
    } else {
      this.param.context.componentParent._toastr.warning('No Data Found');
      retValue = this.oldValue;
    }
    return retValue;
  };
  SimpleCellRenderer.prototype.isPopup = function () {
    return true;
  };
  SimpleCellRenderer.prototype.afterGuiAttached = function () {
    const changedWidth = this.colWidth + 'px';
    this.eGui.parentElement.style.width = changedWidth;
  };
  SimpleCellRenderer.prototype.destroy = function() {
    this.eGui.removeEventListener('keyup', myFunction);
    this.eGui.removeEventListener('change', myFunction);
  };
  SimpleCellRenderer.prototype.init = function (params) {
    let multiDD,
      colWidth,
      param,
      autoCompleteInput,
      parentElementDiv,
      dataListDiv,
      oldValue;
    this.param = params;
    this.oldValue = this.param.value;
    this.colWidth = this.param.column.actualWidth;
    this.multiDD = this.param.node.data.rationaleSection;
    parentElementDiv = document.createElement('div');
    parentElementDiv.setAttribute('class', 'data-list');
    autoCompleteInput = document.createElement('input');
    autoCompleteInput.setAttribute('value', this.param.value);
    autoCompleteInput.setAttribute('type', 'text');
    autoCompleteInput.setAttribute('id', 'ajax');
    autoCompleteInput.setAttribute('class', 'data-list-input');
    autoCompleteInput.setAttribute('list', 'json-datalist');
    autoCompleteInput.setAttribute('placeholder', 'e.g. datalist');
    autoCompleteInput.setAttribute('autocomplete', 'off');
    autoCompleteInput.setAttribute('autofocus', 'autofocus');
    dataListDiv = document.createElement('datalist');
    dataListDiv.setAttribute('id', 'json-datalist');
    autoCompleteInput.addEventListener('keyup', myFunction.bind(null, this.param, dataListDiv, autoCompleteInput, this), false);
    autoCompleteInput.addEventListener('change', optionMyFun.bind(null, this.param, dataListDiv, autoCompleteInput, this), true);
    parentElementDiv.appendChild(autoCompleteInput);
    parentElementDiv.appendChild(dataListDiv);
    this.eGui = parentElementDiv;
  };
  return SimpleCellRenderer;
}
function myFunction(params, dataListDiv, autoCompleteInput, that) {
  dataListDiv.innerHTML = '';
  if (autoCompleteInput.value.length > 2) {
    const gender = params.context.componentParent.gender;
    const dob = params.context.componentParent.dateOfBirth;
    const dos = params.context.componentParent.dateOfService;
    const facility = params.context.componentParent.facility;
    params.context.componentParent._lookupDataService
      .getIcdCptLookUpData(
        autoCompleteInput.value,
        gender,
        dob,
        dos,
        facility,
        'cpt'
      )
      .subscribe((data: any) => {
        that.dataListValue = data;
        if (that.dataListValue.length > 0) {
          that.dataListValue.forEach(function (item) {
            const option = document.createElement('option');
            option.value = item.code;
            dataListDiv.appendChild(option);
          });
        } else {
          const option = document.createElement('option');
          option.value = '';
          option.text = '';
          dataListDiv.appendChild(option);
        }
        autoCompleteInput.addEventListener(
          'change',
          optionMyFun.bind(
            null,
            that['param'],
            dataListDiv,
            autoCompleteInput,
            this
          ),
          false
        );
      });
  }
}
function optionMyFun(a, b, c, d, e) {
  a.context.componentParent.gridApi.stopEditing();
}
function between(x, min, max) {
  return x >= min && x <= max;
}
