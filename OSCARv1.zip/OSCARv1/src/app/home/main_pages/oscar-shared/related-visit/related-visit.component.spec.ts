import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RelatedVisitComponent } from './related-visit.component';
import { AgGridModule } from 'ag-grid-angular';
import { GridOptions } from 'ag-grid';
import { DatePipe } from '@angular/common';
describe('RelatedVisitComponent', () => {
    let component: RelatedVisitComponent;
    let fixture: ComponentFixture<RelatedVisitComponent>;
    let GridOptions: GridOptions;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [RelatedVisitComponent],
            imports: [AgGridModule.withComponents([])],
            providers: [DatePipe]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(RelatedVisitComponent);
        component = fixture.componentInstance;

    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('#GridReady should call autoSizeAll', () => {
        spyOn(component, "autoSizeAll");
        component.GridReady('');
        expect(component.autoSizeAll).toHaveBeenCalled();
    });

    it('#ngOnInit should call GridInit ', () => {
        spyOn(component, "GridInit");
        component.ngOnInit();
        expect(component.GridInit).toHaveBeenCalled();
    });

    it('#GridInit should initialize rowSelection to single', () => {

        component.GridInit();
        expect(component.rowSelection).toEqual('single');
    });

    it('#ngOnChanges should replace rowdata with relatedVisitChildData if relatedVisitChildData has valid value ', () => {
        component.relatedVisitChildData = { data: 'abc' };
        component.ngOnChanges();
        expect(component.rowData).toEqual(component.relatedVisitChildData);
    });

    it('#ngOnChanges should not replace rowdata with relatedVisitChildData if relatedVisitChildData has invalid value ', () => {
        component.relatedVisitChildData = undefined;
        component.rowData = { data: 'abc' };
        component.ngOnChanges();
        expect(component.rowData).not.toEqual(component.relatedVisitChildData);
    });

});
