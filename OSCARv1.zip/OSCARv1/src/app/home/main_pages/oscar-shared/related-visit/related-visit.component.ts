import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  OnChanges
} from '@angular/core';
import { GridOptions } from 'ag-grid';
import { DateFormatter } from '../../../../imports/_utilities/date-formatter';
@Component({
  selector: 'app-related-visit',
  templateUrl: './related-visit.component.html',
  styleUrls: ['./related-visit.component.scss'],
  providers: [DateFormatter]
})
export class RelatedVisitComponent implements OnInit, OnChanges {
  @Input() relatedVisitChildData: any;
  @Input() isAuditAcknowledge: boolean;
  @Output() displayChange = new EventEmitter();
  @Output() gridResponsive = new EventEmitter();
  public GridOptions: GridOptions;
  public columnDefs;
  public rowData: any;
  public gridApi;
  public gridColumnApi;
  public frameworkComponents;
  public rowSelection;
  display: boolean = false;
  constructor(private _dateFilter: DateFormatter) {}
  ngOnInit() {
    this.GridInit();
  }
  GridInit() {
    this.GridOptions = <GridOptions>{
      context: {
        componentParent: this
      }
    };
    this.GridOptions.columnDefs = [
      {
        field: 'uniqueId',
        hide: true
      },
      {
        headerName: 'Patient Name',
        field: 'patientName'
      },
      {
        headerName: 'MRN',
        field: 'mrn'
      },
      {
        headerName: 'Accession No',
        field: 'accessionNo'
      },
      {
        headerName: 'MOD',
        field: 'modality'
      },
      {
        headerName: 'DOS',
        field: 'dos',
        valueFormatter: this._dateFilter.dos
      },
      {
        headerName: 'Performing Physician',
        field: 'physicianName'
      },
      {
        headerName: 'Status',
        field: 'chartStatus'
      }
    ];
    this.rowData = [];
    this.rowSelection = 'single';
  }
  autoSizeAll() {
    this.gridApi.sizeColumnsToFit();
  }
  ngOnChanges() {
    if (this.relatedVisitChildData) {
      this.rowData = this.relatedVisitChildData;
    }
  }
  GridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.autoSizeAll();
  }
  showDialog(event) {
    setTimeout(() => {
      this.displayChange.emit(event);
    }, 100);
  }
  onGridSizeChanged(params) {
    this.gridApi.sizeColumnsToFit();
  }
}
