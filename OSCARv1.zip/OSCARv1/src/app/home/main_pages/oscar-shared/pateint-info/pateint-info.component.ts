import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { GridOptions } from 'ag-grid';
@Component({
  selector: 'app-pateint-info',
  templateUrl: './pateint-info.component.html',
  styleUrls: ['./pateint-info.component.scss'],
  providers: []
})
export class PateintInfoComponent implements OnInit, OnChanges {
  uniqueID = '';
  @Input() patientInfoChild: any;
  patientInfo = [];
  public GridOptions: GridOptions;
  public columnDefs;
  public rowData: any;
  public gridApi;
  public gridColumnApi;
  public frameworkComponents;
  public rowSelection;
  constructor() {}
  ngOnInit() {
    this.GridInit();
  }
  GridInit() {
    this.GridOptions = <GridOptions>{
      context: {
        componentParent: this
      }
    };
    this.GridOptions.columnDefs = [
      {
        headerName: '',
        field: 'label',
        tooltipField: 'label',
        width: 130,
        headerClass: 'text-center d-none',
        cellClass: 'grid-label-text'
      },
      {
        headerName: '',
        field: 'desc',
        tooltipField: 'desc',
        width: 160,
        headerClass: 'text-center d-none',
        // valueFormatter: this._dateFilter.dob,
        cellStyle: function(params) {
          if (
            params.node.data.label === 'Gender' &&
            params.node.data.desc !== 'M'
          ) {
            return { fontWeight: 'bold', backgroundColor: '#c0ecc1' };
          } else {
            return null;
          }
        }
      }
    ];
    this.rowData = [];
    this.rowSelection = 'single';
  }
  autoSizeAll() {
    this.gridApi.sizeColumnsToFit();
  }
  GridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  ngOnChanges() {
    this.fetchPatientInfo();
  }
  fetchPatientInfo() {
    this.patientInfo = [];
    if (this.patientInfoChild) {
      const patientKeys = Object.keys(this.patientInfoChild);
      const patientvalues = Object.values(this.patientInfoChild);
      for (let i = 0; i < patientKeys.length; i++) {
        this.patientInfo.push({
          label: patientKeys[i],
          desc: patientvalues[i]
        });
      }
      this.rowData = this.patientInfo;
    }
  }
  restoreRowData(event) {
    event.context.componentParent.gridApi.refreshView();
  }
  onGridSizeChanged(params) {
    this.gridApi.sizeColumnsToFit();
  }
}
