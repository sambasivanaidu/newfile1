// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { PateintInfoComponent } from './pateint-info.component';

// describe('PateintInfoComponent', () => {
//   let component: PateintInfoComponent;
//   let fixture: ComponentFixture<PateintInfoComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ PateintInfoComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(PateintInfoComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
