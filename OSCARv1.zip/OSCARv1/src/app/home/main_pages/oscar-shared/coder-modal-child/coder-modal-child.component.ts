import {
  Component,
  OnInit,
  Inject,
  ViewChild,
  Renderer,
  ElementRef
} from '@angular/core';
import 'rxjs/add/operator/map';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatDialogOverviewComponent } from '../../../../imports/_utilities/mat-dialog-overview/mat-dialog-overview.component';
import { FormControl } from '@angular/forms';
import { LookupDataService } from '../../../../_shared-services/unrelated-data-services/lookup-data.service';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
import { MipsDialogComponent } from '../../../../imports/_utilities/mips-dialog/mips-dialog.component';
import { CommonCodeService } from '../../../../_shared-services/common-code.services';
import { PlatformService } from '../../../../services/main-pages/paltform-services/platform-service.service';
@Component({
  selector: 'app-coder-modal-child',
  templateUrl: './coder-modal-child.component.html',
  styleUrls: ['./coder-modal-child.component.scss'],
  host: {
    '(document:keyup)': 'onKeyUp($event)'
  },
  providers: [LookupDataService]
})
export class CoderModalChildComponent implements OnInit {
  patientInfoGender: any;
  dateOfBirth: any;
  dateOfService: any;
  patientName: string;
  customCollapsedHeight: string = '30px';
  customExpandedHeight: string = '35px';
  expanded: boolean = true;
  uniqueID = '';
  status;
  platform: string = 'coder';
  errorMsg = 'Something went wrong, please try again later';
  patientChart: any;
  patientInfoParent: any;
  patientRecordInfoParent: any;
  relatedVisitParentData: any;
  ICDInfoRequest: any;
  CPTInfoRequest: any;
  ICDInfoRequestOld: any;
  public MRN: string = '';
  public isDisabled: boolean;
  public isIcdValidated: boolean;
  public isCptValidated: boolean;
  public reason = '';
  public clickedEventICD: any;
  public clickedEventCPT: any;
  public isStatusActive = true;
  public searchTerm: any;
  public fetchICDRowData: any = [];
  public fetchCPTRowData: any = [];
  public selectedModality;
  public selectedFacility;
  public disableMIPS: boolean;
  public disableLCD: boolean;
  public disableCCI: boolean;
  myControl = new FormControl();
  lookups: string;
  lookUpOption: any;
  public display: boolean = false;
  autocompleteFormGroup: boolean = false;
  panelOpenState: boolean = true;
  height = 750;
  public facility: string;
  public lcdCheckStatus;
  public cciCheck: any;
  public lcdNcdClicked = false;
  public cciClicked = false;
  public pqrsMipsClicked = false;
  public validateCptInfo = [];
  public validateIcdInfo = [];
  public saveDeletedICDObj = [];
  public saveDeletedCPTObj = [];
  reference: any;
  smeLearning: boolean = false;
  modalHide: boolean;
  @ViewChild('myDiv') myDiv: ElementRef;
  statusActive: boolean;
  lastCptDxVal: any;
  icdIsPristines: boolean = false;
  cptIsPristines: boolean = false;
  suppressRowEdit: boolean = false;
  cptSectionHeight: any;
  icdSectionHeight: any;
  constructor(
    public _platformService: PlatformService,
    public _toastr: ToastsManager,
    public dialog: MatDialog,
    private errorService: ErrorHandlingServices,
    public _lookupDataService: LookupDataService,
    public modalDialogRef: MatDialogRef<CoderModalChildComponent>,
    private _commonCode: CommonCodeService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}
  ngOnInit() {
    this.uniqueID =
      this.data.displayName && this.data.displayName.data.uniqueId;
    this.status = this.data.status;
    this.reference = this.data.reference;
    if (this.reference === 'sme' || this.status !== 'allocated') {
      this.statusActive = true;
      this.suppressRowEdit = true;
    } else {
      this.statusActive = false;
      this.suppressRowEdit = this.status !== 'allocated' ? true : false;
    }
    if (this.uniqueID) {
      this.disableBtn(this.status);
      this.getPateintInfo(this.uniqueID);
      this.getRecordInfo(this.uniqueID);
      this.getMedicalReoprt(this.uniqueID);
      this.getIcd(this.uniqueID);
      this.getCpt(this.uniqueID);
    }
  }
  onKeyUp(ev: KeyboardEvent) {
    if (ev.keyCode === 27) {
      this.modalDialogRef.close(false);
    }
  }
  public getMIPSDisableCheck() {
    this._platformService
      .fetchMIPSDisableCheck(this.selectedFacility)
      .subscribe(response => {
        if (response) {
          this.disableMIPS = response.pqrsMipsEnabled;
          this.disableCCI = response.ccienabled;
          this.disableLCD = response.lcdenabled;
        }
      });
  }
  disableBtn(status) {
    if (status === 'allocated') {
      this.isStatusActive = false;
    } else {
      this.isStatusActive = true;
    }
  }
  setHeight() {
    setTimeout(() => {
      this.customExpandedHeight = '45px';
    }, 1);
  }
  setCptIcdHeight(functionName) {
    if (functionName === 'setCptHeight') {
      this.cptSectionHeight = this._commonCode.setCptHeight();
    } else if (functionName === 'setIcdHeight') {
      this.icdSectionHeight = this._commonCode.setIcdHeight();
    } else if (functionName === 'pateintrecordinfoheight') {
      this.cptSectionHeight = this._commonCode.pateintRecordInfoHeight();
      this.icdSectionHeight = this.cptSectionHeight;
    }
  }
  // For Patient Medical Report
  getMedicalReoprt(uniqueID) {
    this.patientChart = [];
    this._platformService.fetchPatientChart(uniqueID).subscribe((data: any) => {
      this.patientChart = data.observationValue;
    });
  }
  // For Pateint Informtation
  getPateintInfo(uniqueID) {
    this._platformService.fetchPatientInfo(uniqueID).subscribe(response => {
      if (response) {
        this.patientInfoParent = response;
        let firstname = response['First name'];
        const lastChar = response['First name'].charAt(
          response['First name'].length - 1
        );
        firstname = lastChar === ' ' ? firstname.trim() : firstname;
        this.patientName = response['Last name'] + ' ' + firstname;
        this.dateOfService = response['DOS'];
        this.dateOfBirth = response['DOB'];
        this.patientInfoGender = response['Gender'];
      }
    });
  }
  // For Record Information
  getRecordInfo(uniqueID) {
    this._platformService
      .fetchPatientRecordInfo(uniqueID)
      .subscribe(response => {
        if (response) {
          this.selectedFacility = response['Facility name'];
          this.patientRecordInfoParent = response;
          // fetch lookupguidepath after the facility is received.
          if (this.selectedFacility) {
            this.getMIPSDisableCheck();
          }
        }
      });
  }
  // For ICD 10 - CM
  getIcd(uniqueID) {
    this.ICDInfoRequest = [];
    this._platformService
      .fetchPredictedICDInfo(uniqueID)
      .subscribe(response => {
        if (response) {
          this.ICDInfoRequest = response;
        }
      });
  }
  // For CPT - CM
  getCpt(uniqueID) {
    this.CPTInfoRequest = [];
    this._platformService
      .fetchPredictedCPTInfo(uniqueID)
      .subscribe(response => {
        if (response) {
          this.CPTInfoRequest = response;
        }
      });
  }
  ICDRowData(event) {
    if (event.length > 0) {
      this.fetchICDRowData = [];
      this.fetchICDRowData = event;
    }
  }
  CPTRowData(event) {
    if (event.length > 0) {
      this.fetchCPTRowData = [];
      this.fetchCPTRowData = event;
    }
  }
  // On Click Save Function
  saveCodedChart() {
    this.isDisabled = true;
    this.validateCptInfo = [];
    this.validateIcdInfo = [];
    const saveCptInfo = this.fetchCPTRowData;
    const saveIcdInfo = this.fetchICDRowData;
    saveCptInfo.forEach((element, i) => {
      if (saveCptInfo[i].isActive !== false) {
        this.validateCptInfo.push(element);
      }
    });
    saveIcdInfo.forEach((element, i) => {
      if (saveIcdInfo[i].isActive !== false) {
        this.validateIcdInfo.push(element);
      }
    });
    if (saveCptInfo && saveCptInfo.length === 1) {
      if (saveCptInfo[0].isActive === false) {
        this.validateCptInfo = [];
      }
    }
    if (saveIcdInfo && saveIcdInfo.length === 1) {
      if (saveIcdInfo[0].isActive === false) {
        this.validateIcdInfo = [];
      }
    }
    const dxIsEmpty = this._lookupDataService.cptDxRefValidationCheck(
      this.validateCptInfo
    );
    const isValidate = this._lookupDataService.validateBlankRecordCoder(
      this.validateCptInfo,
      this.validateIcdInfo
    );
    const conflictStatus =
      this.icdIsPristines || this.cptIsPristines ? true : false;
    if (dxIsEmpty && dxIsEmpty.code === 1) {
      if (
        this.validateCptInfo.length === 0 ||
        this.validateIcdInfo.length === 0
      ) {
        this.errorService.throwWarning(
          '1 ICD and CPT is mandatory to save the chart'
        );
      } else if (
        isValidate.cptCodeIsEmpty.length === 0 &&
        isValidate.icdCodeIsEmpty.length === 0 &&
        isValidate.cptAccessionEmpty.length === 0
      ) {
        this.checkForlcdCciMipsValidation(saveCptInfo, saveIcdInfo);
      } else {
        const msg = this.getValidationMessage(isValidate);
        this.errorService.throwWarning(msg);
      }
    } else if (dxIsEmpty) {
      this.errorService.throwWarning(dxIsEmpty.msg);
    } else {
      this.errorService.throwWarning(
        '1 ICD and CPT is mandatory to save the chart'
      );
    }
  }
  public getValidationMessage(isValidate): string {
    let message: string;
    if (!isValidate.icdCodeIsEmpty) {
      message = 'Please enter ICD code.';
    } else if (!isValidate.cptCodeIsEmpty) {
      message = 'Please enter CPT code.';
    } else if (!isValidate.cptAccessionEmpty) {
      message = 'Please enter CPT Accession Number.';
    }
    return message;
  }
  saveCoderChart(cptInfo, icdInfo) {
    const saveIcdObj = [];
    const saveCptObj = [];
    icdInfo.forEach(element => {
      saveIcdObj.push(element);
    });
    if (this.saveDeletedICDObj && this.saveDeletedICDObj.length > 0) {
      this.saveDeletedICDObj.forEach(ele => {
        saveIcdObj.push(ele);
      });
    }
    cptInfo.forEach(element => {
      saveCptObj.push(element);
    });
    if (this.saveDeletedCPTObj && this.saveDeletedCPTObj.length > 0) {
      this.saveDeletedCPTObj.forEach(ele => {
        saveCptObj.push(ele);
      });
    }
    this._platformService
      .saveCodedChart(
        saveCptObj,
        saveIcdObj,
        this.uniqueID,
        this.selectedModality,
        this.icdIsPristines || this.cptIsPristines ? true : false
      )
      .subscribe(responseList => {
        if (responseList) {
          this.modalDialogRef.close(true);
        }
      });
  }
  partialSave(event, reasonName) {
    const cptInfo = this.fetchCPTRowData;
    const icdInfo = this.fetchICDRowData;
    this.reason = reasonName;
    this._platformService
      .auditorChartService(event, cptInfo, icdInfo, this.platform)
      .subscribe(responseList => {
        if (responseList) {
          this.openDialog(responseList, this.reason, cptInfo, icdInfo);
        }
      });
  }
  openDialog(responseList, reasonName, cptInfo, icdInfo) {
    const dialogRef = this.dialog.open(MatDialogOverviewComponent, {
      hasBackdrop: false,
      width: '450px',
      data: {
        dataList: responseList,
        reason: reasonName,
        uniqueId: this.uniqueID,
        platform: 'coder',
        closeParam: this.modalDialogRef,
        cptInfo: cptInfo ? cptInfo : '',
        icdInfo: icdInfo ? icdInfo : '',
        isSaved: false,
        modality: this.selectedModality
      }
    });
    dialogRef.afterClosed().subscribe(result => { });
  }
  // Add ICD New Row on Click
  childEventClickedICD(event: any) {
    this.getSectionSplit(event, 'ICD');
  }
  // Add ICD New Row on Click
  childEventClickedCPT(event: any) {
    this.getSectionSplit(event, 'CPT');
  }
  highlightText(event: any) {
    if (event) {
      this.searchTerm = ' ';
      setTimeout(() => {
        this.searchTerm = event;
      }, 10);
    }
  }
  getSectionSplit(innerHtml, code) {
    const param = {
      uniqueId: this.uniqueID,
      originalText: innerHtml.textInnerHtml
    };
    this._platformService.sectionSplitService(param).subscribe(res => {
      if (res) {
        if (code === 'ICD') {
          this.addICDrowData(
            res,
            innerHtml.highlightedText,
            innerHtml.textInnerHtml,
            res[0].sectionName
          );
        } else {
          this.addCPTrowData(
            res,
            innerHtml.highlightedText,
            innerHtml.textInnerHtml,
            res[0].sectionName
          );
        }
      }
    });
  }
  addICDrowData(event, selectedWord, originalText, sectionName) {
    const html = '<span class="highlightText">$&</span>';
    const reg = new RegExp('\\b' + sectionName + '\\b', 'i');
    originalText = originalText.replace(reg, html);
    originalText = originalText.replace(/highlight/g, 'ht');
    originalText = originalText.replace(/htText/g, 'htb');
    const newIcdRow = {
      id: null,
      predictIcdCode: '',
      aapcIcdDescription: '',
      isActive: true,
      accessionNo: '',
      icdDescription: selectedWord,
      rationaleData: originalText,
      rationaleSection: event,
      lcdStatus: ''
    };
    this.clickedEventICD = newIcdRow;
  }
  getDxval(event) {
    this.lastCptDxVal = event;
  }
  addCPTrowData(event, selectedWord, originalText, sectionName) {
    const html = '<span class="highlightText">$&</span>';
    const reg = new RegExp('\\b' + sectionName + '\\b', 'i');
    originalText = originalText.replace(reg, html);
    originalText = originalText.replace(/highlight/g, 'ht');
    originalText = originalText.replace(/htText/g, 'htb');
    const newCptRow = {
      id: null,
      predictCptCode: '',
      modifier: '',
      units: '1',
      dxRef: this.lastCptDxVal === undefined ? '1' : this.lastCptDxVal,
      accessionNo: '',
      aapcCptDescription: '',
      cptDescription: selectedWord,
      rationaleData: originalText,
      rationaleSection: event,
      isActive: true
    };
    this.clickedEventCPT = newCptRow;
  }
  getModalityData(event) {
    this.selectedModality = event;
  }
  // get deleted ICD
  public deletedIcd(event) {
    this.saveDeletedICDObj.push(event);
  }
  // get deleted CPT
  public deletedCpt(event) {
    this.saveDeletedCPTObj.push(event);
  }
  // CCI MIPS LCD Validation functions
  public prepareLCDParam(cptInfo, icdInfo) {
    let cptCodeEmpty = false;
    const icdCodeEmpty = false;
    let CPTCodes = '';
    let ICDCodes = '';
    const lcdInput = {
      clientFacilityName: this.facility,
      cptInput: '',
      icdInput: ''
    };
    cptInfo.forEach((element, index) => {
      if (element.predictCptCode || element.cptCode) {
        if (index > 0) {
          CPTCodes = lcdInput.cptInput.concat(CPTCodes, '~');
        }
        CPTCodes = element.predictCptCode
          ? lcdInput.cptInput.concat(CPTCodes, element.predictCptCode)
          : lcdInput.cptInput.concat(CPTCodes, element.cptCode);
      } else {
        cptCodeEmpty = true;
        this.errorService.throwWarning(
          'Please enter CPT Code for LCD/NCD check'
        );
      }
    });
    icdInfo.forEach((element, index) => {
      if (element.predictIcdCode || element.icdCode) {
        if (index > 0) {
          ICDCodes = lcdInput.icdInput.concat(ICDCodes, '~');
        }
        ICDCodes = element.predictIcdCode
          ? lcdInput.icdInput.concat(ICDCodes, element.predictIcdCode)
          : lcdInput.icdInput.concat(ICDCodes, element.icdCode);
      } else {
        cptCodeEmpty = true;
        this.errorService.throwWarning(
          'Please enter ICD Code for LCD/NCD check'
        );
      }
    });
    lcdInput.cptInput = CPTCodes;
    lcdInput.icdInput = ICDCodes;
    return { lcdInput, cptCodeEmpty, icdCodeEmpty };
  }
  public preapreMIPSParam(cptInfo) {
    let cptCodeEmpty = false;
    const MIPSMeasureInput = {
      cptcode: '',
      uniqueId: this.uniqueID
    };
    let CPTCodes = '';
    if (cptInfo && cptInfo.length) {
      cptInfo.forEach((element, index) => {
        if (element.predictCptCode || element.cptCode) {
          if (index > 0) {
            CPTCodes = MIPSMeasureInput.cptcode.concat(CPTCodes, '~');
          }
          CPTCodes = element.predictCptCode
            ? MIPSMeasureInput.cptcode.concat(CPTCodes, element.predictCptCode)
            : MIPSMeasureInput.cptcode.concat(CPTCodes, element.cptCode);
        } else {
          cptCodeEmpty = true;
          this.errorService.throwWarning(
            'Please enter CPT Code for MIPS Measure'
          );
        }
      });
    }
    MIPSMeasureInput.cptcode = CPTCodes;
    return { MIPSMeasureInput, cptCodeEmpty };
  }
  public prepareCCIParam(cptInfo) {
    let cptCodeEmpty = false;
    const CCIInputMeasure = {
      cptMod: '',
      currentChartID: this.uniqueID
    };
    let CPTCodes = '';
    if (cptInfo && cptInfo.length) {
      cptInfo.forEach((element, index) => {
        if (element.predictCptCode || element.cptCode) {
          if (index > 0) {
            CPTCodes = CCIInputMeasure.cptMod.concat(CPTCodes, '~');
          }
          CPTCodes = element.predictCptCode
            ? CCIInputMeasure.cptMod.concat(CPTCodes, element.predictCptCode)
            : CCIInputMeasure.cptMod.concat(CPTCodes, element.cptCode);
          CPTCodes = CCIInputMeasure.cptMod.concat(CPTCodes, '*');
          CPTCodes = element.modifier
            ? CCIInputMeasure.cptMod.concat(CPTCodes, element.modifier)
            : CCIInputMeasure.cptMod.concat(CPTCodes, '');
        } else {
          cptCodeEmpty = true;
          this.errorService.throwWarning(
            'Please enter CPT Code for CCI Modifier'
          );
        }
      });
    }
    CCIInputMeasure.cptMod = CPTCodes;
    return { CCIInputMeasure, cptCodeEmpty };
  }
  public updateLCDNCDCol(lcdDetails) {
    const param = [];
    lcdDetails.forEach(element => {
      param.push({
        lcdStatus: element.icdCheckStatus,
        icdCode: element.icdCode
      });
    });
    const x = {
      status: param,
      colName: 'predictIcdCode'
    };
    this.lcdCheckStatus = x;
  }
  public updateMoidifierCol(response) {
    const param = [];
    let message = false;
    response.forEach(element => {
      param.push({
        modifier: element.cciModifier,
        cptcode: element.cpt
      });
      if (element.cciModifier === 'Not Applicable') {
        message = true;
      }
      const x = {
        modifier: param,
        colName: 'predictIcdCode'
      };
      this.cciCheck = x;
    });
    return message;
  }
  public lcdCheck(event) {
    event.stopPropagation();
    this.lcdNcdClicked = true;
    const cptInfo = this.fetchCPTRowData;
    const icdInfo = this.fetchICDRowData;
    const isValidate = this._lookupDataService.validateBlankRecordCoder(
      cptInfo,
      icdInfo
    );
    if (isValidate.icdCodeIsEmpty.length === 0) {
      const inputParam = this.prepareLCDParam(cptInfo, icdInfo);
      if (
        inputParam.cptCodeEmpty === false &&
        inputParam.icdCodeEmpty === false
      ) {
        this._platformService
          .fetchlcdmipsccicheck(null, inputParam.lcdInput, null)
          .subscribe(res => {
            if (res) {
              if (res.validDetails && res.validDetails.lcd.length > 0) {
                this.updateLCDNCDCol(res.validDetails.lcd);
                this.errorService.throwSuccess('LCD status updated.');
              }
            }
          });
      }
    } else {
      const msg = this.getValidationMessage(isValidate);
      this.errorService.throwWarning(msg);
    }
  }
  public getCCIModifier(event) {
    event.stopPropagation();
    this.cciClicked = true;
    const cptInfo = this.fetchCPTRowData;
    const inputParam = this.prepareCCIParam(cptInfo);
    if (!inputParam.cptCodeEmpty) {
      let msg;
      this._platformService
        .fetchlcdmipsccicheck(inputParam.CCIInputMeasure, null, null)
        .subscribe(response => {
          if (response) {
            if (
              response.validDetails &&
              response.validDetails.cci &&
              response.validDetails.cci.length > 0
            ) {
              msg = this.updateMoidifierCol(response.validDetails.cci);
              this.errorService.throwSuccess('Modifier updated.');
            } else {
              msg = true;
            }
          }
          if (msg) {
            this.errorService.throwInfo('CCI modifier is not applicable');
          }
        });
    }
  }
  public getMIPSMeasure(event) {
    event.stopPropagation();
    this.pqrsMipsClicked = true;
    const cptInfo = this.fetchCPTRowData;
    const inputParam = this.preapreMIPSParam(cptInfo);
    if (!inputParam.cptCodeEmpty) {
      this._platformService
        .fetchlcdmipsccicheck(null, null, inputParam.MIPSMeasureInput)
        .subscribe(response => {
          if (response) {
            if (
              response.validDetails &&
              response.validDetails.mips &&
              response.validDetails.mips.length > 0
            ) {
              const dialogRef = this.dialog.open(MipsDialogComponent, {
                hasBackdrop: true,
                width: '950px',
                data: {
                  uniqueId: this.uniqueID,
                  mipsData: response.validDetails.mips
                },
                disableClose: true
              });
            } else {
              this.errorService.throwInfo('MIPS not applicable.');
            }
          }
        });
    }
  }
  public checkForlcdCciMipsValidation(saveCptInfo, saveIcdInfo) {
    let setValidationError = false;
    const cptInfo = this.fetchCPTRowData;
    const icdInfo = this.fetchICDRowData;
    const lcdParam = this.prepareLCDParam(cptInfo, icdInfo);
    const cciParam = this.prepareCCIParam(cptInfo);
    const mipsParam = this.preapreMIPSParam(cptInfo);
    const param = {
      cciInput: null,
      lcdInput: null,
      mipsInput: null
    };
    if (this.lcdNcdClicked === false) {
      param.lcdInput = lcdParam.lcdInput;
    }
    if (this.cciClicked === false) {
      param.cciInput = cciParam.CCIInputMeasure;
    }
    // if (this.pqrsMipsClicked === false) {
    param.mipsInput = mipsParam.MIPSMeasureInput;
    // }
    if (
      lcdParam.cptCodeEmpty === false &&
      lcdParam.icdCodeEmpty === false &&
      cciParam.cptCodeEmpty === false &&
      mipsParam.cptCodeEmpty === false
    ) {
      this._platformService
        .fetchlcdmipsccicheck(param.cciInput, param.lcdInput, param.mipsInput)
        .subscribe(response => {
          if (response) {
            if (
              response.validDetails &&
              (response.validDetails.lcd ||
                response.validDetails.mips ||
                response.validDetails.cci)
            ) {
              setValidationError = true;
              if (this.lcdNcdClicked === false) {
                if (
                  response.validDetails &&
                  response.validDetails.lcd &&
                  response.validDetails.lcd.length > 0
                ) {
                  this.updateLCDNCDCol(response.validDetails.lcd);
                  this.lcdNcdClicked = true;
                }
              }
              if (this.cciClicked === false) {
                if (
                  response.validDetails &&
                  response.validDetails.cci &&
                  response.validDetails.cci.length > 0
                ) {
                  this.updateMoidifierCol(response.validDetails.cci);
                  this.cciClicked = true;
                }
              }
              const dialogRef = this.dialog.open(MipsDialogComponent, {
                hasBackdrop: true,
                width: '950px',
                data: {
                  uniqueId: this.uniqueID,
                  mipsData: response.validDetails.mips,
                  cciData: response.validDetails.cci,
                  lcdData: response.validDetails.lcd
                },
                disableClose: true
              });
            } else {
              this.saveCoderChart(cptInfo, icdInfo);
            }
          }
        });
    }
  }
  checkIcdIsPrisitine(event) {
    if (event) {
      this.icdIsPristines = event;
    }
  }
  checkCptIsPrisitine(event) {
    if (event) {
      this.cptIsPristines = event;
    }
  }
}
