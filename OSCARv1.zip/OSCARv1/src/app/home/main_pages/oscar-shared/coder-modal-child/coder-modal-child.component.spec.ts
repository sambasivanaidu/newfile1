import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CoderModalChildComponent } from './coder-modal-child.component';
import { PateintMedicalReportComponent } from '../pateint-medical-report/pateint-medical-report.component';
import { PateintInfoComponent } from '../pateint-info/pateint-info.component';
import { RecordInfoComponent } from '../record-info/record-info.component';
import { IcdInfoComponent } from '../icd-info/icd-info.component';
import { CptInfoComponent } from '../cpt-info/cpt-info.component';
import { AgGridComponent } from '../../../../imports/_utilities/ag-grid/ag-grid.component';
import { AgGridModule } from 'ag-grid-angular';
// import { HighlightTextDirective } from '../../../../imports/directive/highlight-text.directive';
import { HighlightSearch } from '../../../../imports/pipes/highlights.pipe';
import { ContextMenuModule } from 'ngx-contextmenu';
// import { CoderQueueService } from '../../coder-queue/coder-queue.service';
// import { mockCoderService } from '../../coder-queue/mockCoder-queue.service';
import {
  Http,
  RequestOptions,
  HttpModule,
  ConnectionBackend,
  BaseRequestOptions
} from '@angular/http';
import { HeaderAuthenticationToken } from '../../../../auth/authetication-header';
import { ToastsManager, ToastOptions } from 'ng2-toastr';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { DateFormatter } from '../../../../imports/_utilities/date-formatter';
import { DatePipe } from '@angular/common';
import { FormBuilder, FormsModule } from '@angular/forms';
import { ObservableMedia } from '@angular/flex-layout';
import { MatDialogRef, MatDialogModule } from '@angular/material';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import * as CryptoJS from 'crypto-js';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClient } from 'selenium-webdriver/http';
import { environment } from '../../../../../environments/environment';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import { Observable } from 'rxjs';
import { HttpResponse } from '@angular/common/http';
import { of } from 'rxjs/observable/of';
import { NgProgressModule } from 'ngx-progressbar';
import { CommonCodeService } from '../../../../_shared-services/common-code.services';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
import { QueueService } from '../../../../services/main-pages/queue.service';
import { PlatformService } from '../../../../services/main-pages/paltform-services/platform-service.service';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('CoderModalChildComponent', () => {
  let component: CoderModalChildComponent;
  let fixture: ComponentFixture<CoderModalChildComponent>;
  let httpMock: HttpTestingController;
  let coderservice: QueueService;
  let platformservice: PlatformService;
  let submitEl;
  let originalTimeout;
  const RequestOptionsMock = function() {
    return 'mockedResponse';
  };
  const fakeActivatedRoute = {
    snapshot: { data: {} }
  } as ActivatedRoute;
  const mockDialogRef = {
    close: jasmine.createSpy('close')
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        HighlightSearch,
        CoderModalChildComponent,
        RecordInfoComponent,
        IcdInfoComponent,
        CptInfoComponent,
        PateintMedicalReportComponent,
        PateintInfoComponent
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        HttpClientTestingModule,
        BrowserAnimationsModule,
        MatDialogModule,
        FormsModule,
        HttpModule,
        RouterTestingModule,
        ContextMenuModule.forRoot(),
        AgGridModule.withComponents([]),
        NgProgressModule
      ],
      providers: [
        { provide: MAT_DIALOG_DATA, useValue: {} },
        { provide: MatDialogRef, useValue: {} },
        QueueService,
        PlatformService,
        FormBuilder,
        ObservableMedia,
        DateFormatter,
        DatePipe,
        ToastsManager,
        { provide: ActivatedRoute, useValue: fakeActivatedRoute },
        ToastOptions,
        // HighlightTextDirective,
        HeaderAuthenticationToken,
        CommonCodeService,
        ErrorHandlingServices
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 5000;
    fixture = TestBed.createComponent(CoderModalChildComponent);
    component = fixture.componentInstance;
    httpMock = TestBed.get(HttpTestingController);
    coderservice = TestBed.get(QueueService);
    platformservice = TestBed.get(PlatformService);
    submitEl = fixture.debugElement;
  });

  afterEach(() => {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = originalTimeout;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('#disableBtn() should set isStatusActive to false if status is allocated ', () => {
    component.disableBtn('allocated');
    fixture.detectChanges();
    expect(component.isStatusActive).toBeFalsy();
  });

  it('#disableBtn() should set isStatusActive to true if status is coded', () => {
    component.disableBtn('coded');
    fixture.detectChanges();
    expect(component.isStatusActive).toBeTruthy();
  });

  it('if isStatusActive is true, button should be disabled', () => {
    component.isStatusActive = true;
    fixture.detectChanges();
    expect(
      submitEl.nativeElement.querySelector('#saveBtn').disabled
    ).toBeTruthy();
    expect(
      submitEl.nativeElement.querySelector('#discardBtn').disabled
    ).toBeTruthy();
    expect(
      submitEl.nativeElement.querySelector('#rerouteBtn').disabled
    ).toBeTruthy();
    expect(
      submitEl.nativeElement.querySelector('#suspendBtn').disabled
    ).toBeTruthy();
  });

  it('#partialSave("DISCARD REASON", "Discard") should be called when discard is clicked', () => {
    submitEl.nativeElement.querySelector('#discardBtn').click();
    spyOn(component, 'partialSave');
    expect(component.reason).toBe('Discard');
  });

  it('#partialSave("REROUTE REASON", "Reroute") should be called when reroute is clicked', () => {
    submitEl.nativeElement.querySelector('#rerouteBtn').click();
    spyOn(component, 'partialSave');
    expect(component.reason).toBe('Reroute');
  });

  it('#partialSave() should call auditorChartService and if gets responseList, should open dialog', () => {
    spyOn(component._platformService, 'auditorChartService').and.returnValue(
      of({ response: { abc: 'dff' } })
    );
    spyOn(component, 'openDialog');
    component.partialSave('event', 'reasonName');
    fixture.detectChanges();
    component._platformService
      .auditorChartService('', '', '', '')
      .subscribe(response => {
        if (response) {
          expect(component.openDialog).toHaveBeenCalled();
        }
      });
  });

});
