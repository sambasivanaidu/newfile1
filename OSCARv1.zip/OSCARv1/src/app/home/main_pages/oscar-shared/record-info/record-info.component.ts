import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  OnChanges
} from '@angular/core';
import { GridOptions } from 'ag-grid';
import { DateFormatter } from '../../../../imports/_utilities/date-formatter';
import { QueueService } from '../../../../services/main-pages/queue.service';

@Component({
  selector: 'app-record-info',
  templateUrl: './record-info.component.html',
  styleUrls: ['./record-info.component.scss'],
  providers: [DateFormatter]
})
export class RecordInfoComponent implements OnInit, OnChanges {
  public GridOptions: GridOptions;
  public columnDefs;
  public rowData: any;
  public gridApi;
  public gridColumnApi;
  public frameworkComponents;
  public rowSelection;
  public attrgridComponent;
  public context;
  recordInfo = [];
  modalityList = [];
  @Input() patientRecordInfoChild: any;
  @Input() isAuditAcknowledge: boolean;
  @Output() getModalityRowData = new EventEmitter();
  constructor(
    private _dateFilter: DateFormatter,
    private _coderQueueService: QueueService
  ) {}
  ngOnInit() {
    this.GridInit();
    this.getModality();
  }
  GridInit() {
    this.GridOptions = <GridOptions>{
      context: {
        componentParent: this
      }
    };
    this.GridOptions.columnDefs = [
      {
        // headerName: 'Label',
        field: 'label',
        tooltipField: 'label',
        cellClass: 'grid-label-text',
        editable: false
      },
      {
        // headerName: 'Description',
        field: 'desc',
        tooltipField: 'desc',
        colId: 'modalityList',
        valueFormatter: this._dateFilter.dob,
        cellEditor: '_singleSelect',
        editable: false,
        onCellValueChanged: this.getSelectedModality,
        onCellClicked(value): void {
          if (value.node.data.label === 'Modality') {
            value.colDef.editable = true;
          } else {
            value.colDef.editable = false;
          }
        }
      }
    ];
    this.GridOptions.getRowClass = function(params) {
      const nodeValue = params.node.data.label;
      if (nodeValue === 'Modality') {
        return 'grid-row-enable';
      } else {
        return 'grid-row-disable';
      }
    };
    this.attrgridComponent = {
      _singleSelect: SingleSelect()
    };
    this.GridOptions.onCellDoubleClicked;
    this.rowData = [];
    this.rowSelection = 'single';
  }
  getSelectedModality(event) {
    event.context.componentParent.getModalityRowData.emit(event.newValue);
  }
  autoSizeAll() {
    this.gridApi.sizeColumnsToFit();
  }
  GridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.autoSizeAll();
  }
  ngOnChanges() {
    this.patientRelatedInfo();
  }
  getModality() {
    this.modalityList = [];
    this._coderQueueService.fetchModality().subscribe((res: any) => {
      if (res){
        this.modalityList = res;
      }
    });
  }
  patientRelatedInfo() {
    this.recordInfo = [];
    if (this.patientRecordInfoChild) {
      const patientKeys = Object.keys(this.patientRecordInfoChild);
      const patientvalues = Object.values(this.patientRecordInfoChild);
      for (let i = 0; i < patientKeys.length; i++) {
        if (patientKeys[i] !== 'lookupGuidePath') {
          this.recordInfo.push({
            label: patientKeys[i],
            desc: patientvalues[i]
          });
        }
      }
      this.rowData = this.recordInfo;
    }
  }
  OnBodyScroll(event) {
    this.gridApi.stopEditing();
  }
  onGridSizeChanged(params) {
    this.gridApi.sizeColumnsToFit();
  }
}
// END OF CLASS COMPONENT---->
function SingleSelect() {
  function SingleSelectDropDown() {}
  SingleSelectDropDown.prototype.getGui = function() {
    return this.eGui;
  };
  SingleSelectDropDown.prototype.getValue = function() {
    const arr = [];
    let commaValues;
    for (let i = 0; i < this.eGui.firstChild.selectedOptions.length; i++) {
      const selectedItemValueGridDD = this.eGui.firstChild.selectedOptions[i]
        .value;
      arr.push(selectedItemValueGridDD);
      commaValues = arr.join(',');
    }
    this.value = commaValues;
    return this.value;
  };
  SingleSelectDropDown.prototype.isPopup = function() {
    return true;
  };
  SingleSelectDropDown.prototype.afterGuiAttached = function() {
    const changedWidth = this.colWidth + 'px';
    this.eGui.parentElement.style.width = changedWidth;
  };
  SingleSelectDropDown.prototype.init = function(params) {
    let multiDD: any = [];
    let myarr: any = [];
    let tempElement;
    let tempElementDiv;
    let optionDefault;
    let option;
    this.param = params;
    multiDD = this.param.context.componentParent[this.param.column.colId];
    if (multiDD && multiDD.length > 0) {
      if (this.param.value !== undefined) {
        myarr = params.value.split(',');
      } else if (this.param.value === undefined) {
        myarr = [];
      }
      this.colWidth = this.param.column.actualWidth;
      tempElement = document.createElement('div');
      tempElement.setAttribute('id', 'multiSel');
      tempElement.setAttribute('class', 'multiselect singleSelect');
      tempElementDiv = document.createElement('select');
      tempElementDiv.setAttribute(
        'class',
        'multiselect-ui custom-select form-control'
      );
      tempElementDiv.setAttribute('id', 'multiselect-ui');
      for (let i = 0; i < multiDD.length; i++) {
        option = document.createElement('option');
        option.setAttribute('value', multiDD[i].modlaityid);
        option.text = multiDD[i].modlaityid;
        if (multiDD[i].modlaityid === myarr[0]) {
          option.setAttribute('selected', 'selected');
        }
        tempElementDiv.appendChild(option);
        tempElement.appendChild(tempElementDiv);
      }
      this.eGui = tempElement;
    } else {
      return false;
    }
  };
  return SingleSelectDropDown;
}
function currencyFormatter(params) {
  if (params.data.label === 'DOS') {
    return this._dateFilter.dob;
  } else {
    return params.value;
  }
}
