import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { GridOptions } from 'ag-grid';
import { CellDeleteBtnRendererComponent } from '../../../../imports/ag-grid/delete-btn-render';
import { AccessionListDataService } from '../../../../_shared-services/unrelated-data-services/accession-list-data.service';
import { ToastsManager } from 'ng2-toastr';
import { LookupDataService } from '../../../../_shared-services/unrelated-data-services/lookup-data.service';
import { environment } from '../../../../../environments/environment';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
import { CommonCodeService } from '../../../../_shared-services/common-code.services';
@Component({
  selector: 'app-icd-info',
  templateUrl: './icd-info.component.html',
  styleUrls: ['./icd-info.component.scss'],
  providers: [AccessionListDataService]
})
export class IcdInfoComponent implements OnInit {
  public storage: Storage = environment.storage;
  public GridOptions: GridOptions;
  public columnDefs;
  public rowData: any;
  public gridApi;
  public gridColumnApi;
  public frameworkComponents;
  public rowSelection;
  public editType;
  public components;
  private confidenceColorCode;
  private deletedIcdObj = [];
  @Input() ICDInfoRequest: any;
  @Input() platform: string = '';
  @Input() eventICD;
  @Input() isAuditAcknowledge: boolean;
  @Input() lcdCheckStatus;
  @Output() getIcdRowData = new EventEmitter();
  @Output() icdIsPristines = new EventEmitter();
  @Output() isHavingIcd = new EventEmitter();
  @Output() getSearchTerm = new EventEmitter();
  @Output() deletedIcd = new EventEmitter();
  // @Output() icdDataLength = new EventEmitter();
  @Input() dateOfService: any;
  @Input() dateOfBirth: any;
  @Input() gender: any;
  @Input() facility: any;
  height: any;
  @Input() set deselectrows(val: boolean) {
    if (val) {
      if (this.GridOptions) {
        const val2 = this.gridApi.getSelectedRows();
        this.GridOptions.api.deselectAll();
        const val1 = this.gridApi.getSelectedRows();
      }
    }
  }
  movedRow: any;
  movedPosition: any;
  replacedRow: any;
  replacedIndex: any;
  newRowData: any[] = [];
  public previousnewRowData: any[] = [];
  public authToken;
  public envURL = environment.URL;
  public userName: string;
  @Input() patientChart: any;
  message = [];
  focusedCell: any;
  rationaleSectionSpit: any;
  rationaleData: any;
  getselectedRow: any;
  public role;
  @Input() set setIcdSectionHeight(value) {
    this.height = value ? value : 250;
  }
  constructor(
    private errorService: ErrorHandlingServices,
    public _lookupDataService: LookupDataService,
    public _toastr: ToastsManager,
    private _commonCode: CommonCodeService
  ) { }
  ngOnInit() {
    this.authToken = this.storage.getItem('Token');
    this.userName = this.storage.getItem('UserName');
    this.eventICD = {};
    if (
      this.storage.getItem('confidenceColorCode') &&
      this.storage.getItem('clientSelectionObject')
    ) {
      this.confidenceColorCode = this._commonCode.get_ConfidenceColor_Clientselection(
        'confidenceColorCode'
      );
      const clientObj = this._commonCode.get_ConfidenceColor_Clientselection(
        'clientSelectionObject'
      );
      this.role = clientObj.workRole.role;
    }
    this.GridInit();
  }
  ngOnChanges() {
    if (this.lcdCheckStatus) {
      this.updateStatus(this.lcdCheckStatus);
    }
    this.toggleCol(this.platform);
    this.patientMedicalCharts();
    this.fetchIcdInfo();
    this.checkIcdData();
    this.checkAllRow();
    this.getAllRowData();
  }
  GridInit() {
    this.GridOptions = <GridOptions>{
      context: {
        componentParent: this
      }
    };
    this.GridOptions.columnDefs = [
      {
        lockPosition: true,
        valueGetter: 'node.rowIndex + 1',
        width: 43,
        editable: false,
        field: 'counter',
        cellClass: 'no-event',
        headerClass: 'hide-header',
        suppressNavigable: true,
        cellRenderer: 'confidenceScore',
        cellRendererParams: {
          innerRenderer: 'confidenceScore'
        }
      },
      // START CODER COLDEFS
      {
        headerName: 'ICD',
        field: 'predictIcdCode',
        tooltipField: 'aapcIcdDescription',
        width: 150,
        editable: function (params) {
          if (params.data[params.colDef.field] === '') {
            return true;
          } else {
            return false;
          }
        },
        rowDrag: true,
        cellEditor: 'simpleCellRenderer',
        cellStyle: function (params) {
          if (params.data.isActive === false) {
            return { color: 'red' };
          } else {
            return null;
          }
        }
      },
      {
        headerName: 'Description',
        field: 'aapcIcdDescription',
        tooltipField: 'aapcIcdDescription',
        width: 180,
        editable: true,
        hide: true,
        cellStyle: function (params) {
          if (params.data.isActive === false) {
            return { color: 'red' };
          } else {
            return null;
          }
        }
      },
      {
        headerName: 'Rationale',
        field: 'icdChart',
        tooltipField: 'icdChart',
        width: 160,
        editable: true,
        hide: true
      },
      // END CODER COLDEFS
      // START AUDITOR COLDEFS
      {
        headerName: 'ICD',
        showRowGroup: true,
        field: 'icdCode',
        tooltipField: 'aapcDescription',
        width: 160,
        editable: function (params) {
          if (params.data[params.colDef.field] === '') {
            return true;
          } else {
            return false;
          }
        },
        hide: true,
        rowDrag: true,
        cellEditor: 'simpleCellRenderer',
        cellStyle: function (params) {
          if (params.data.isActive === false) {
            return { color: 'red' };
          } else {
            return null;
          }
        }
      },
      {
        headerName: 'Description',
        field: 'aapcDescription',
        tooltipField: 'aapcDescription',
        width: 180,
        editable: true,
        hide: true,
        cellStyle: function (params) {
          if (params.data.isActive === false) {
            return { color: 'red' };
          } else {
            return null;
          }
        }
      },
      {
        headerName: 'Rationale',
        field: 'icdDescription',
        tooltipField: 'icdDescription',
        width: 160,
        editable: true,
        hide: true
      },
      {
        headerName: 'LCD Status',
        field: 'lcdStatus',
        tooltipField: 'lcdStatus',
        editable: false,
        cellStyle: function (params) {
          if (params.data.isActive === false) {
            return { color: 'red' };
          } else {
            return null;
          }
        }
      },
      // END AUDITOR COLDEFS
      // START COLDEFS HIDE FOR BOTH
      {
        headerName: 'Description',
        field: 'rationaleSection',
        tooltipField: 'icdChart',
        width: 160,
        hide: true,
        cellStyle: function (params) {
          if (params.data.isActive === false) {
            return { color: 'red' };
          } else {
            return null;
          }
        }
      },
      {
        headerName: 'Score',
        field: 'probabilityScore',
        tooltipField: 'probabilityScore',
        editable: false,
        hide: true
      },
      {
        headerName: 'Is Active',
        field: 'isActive',
        hide: true
      },
      {
        headerName: 'rationale data',
        field: 'rationaleData',
        hide: true
      },
      // END COLDEF HIDE FOR BOTH
      // COMMON FOR BOTH CODER AND AUDITOR
      {
        width: 30,
        editable: false,
        cellRenderer: 'deleteBtn',
        cellClass: 'p-0'
      },
      {
        headerName: 'rationaleSection',
        field: 'rationaleSection',
        width: 130,
        editable: true,
        hide: true,
        cellRenderer: 'rationaleFormatter',
        cellRendererParams: {
          innerRenderer: 'rationaleFormatter'
        }
      }
    ];
    this.GridOptions.onCellEditingStopped = function (evt) {
      this.context.componentParent.clearSelection();
      if (
        evt.colDef.field === 'icdCode' ||
        evt.colDef.field === 'predictIcdCode'
      ) {
        evt.context.componentParent.gridApi.stopEditing();
        evt.context.componentParent.gridApi.forEachNode(function (node) {
          node.setSelected(true);
        });
        const getselectedRow = evt.context.componentParent.gridApi.getSelectedRows();
        const isHavingDuplicate = evt.context.componentParent.validateDuplicate(
          getselectedRow,
          evt.colDef.field
        );
        const icdCount = evt.context.componentParent.validateICD(
          evt.node.data[evt.colDef.field]
        );
        getselectedRow.push(evt.data);
        if (!icdCount) {
          evt.context.componentParent._toastr.warning(
            evt.colDef.headerName + ' Code cannot be greater than 10'
          );
          evt.node.data[evt.colDef.field] = '';
          evt.api.refreshView();
        }
        if (isHavingDuplicate) {
          evt.context.componentParent._toastr.warning(
            'Duplicate ' + evt.colDef.headerName + ' code not allowed.'
          );
          evt.node.data[evt.colDef.field] = '';
          evt.api.refreshView();
        }
      }
    };
    this.components = {
      simpleCellRenderer: getSimpleCellRenderer(),
      rationaleFormatter: rationaleFormat(),
      confidenceScore: getConfidenceScore()
    };
    this.rowData = [];
    this.rowSelection = 'multiple';
    this.frameworkComponents = {
      deleteBtn: CellDeleteBtnRendererComponent
    };
    const icdData = {
      length: this.gridApi ? this.gridApi.getSelectedRows().length : null,
      component: 'icd'
    };
    // this.icdDataLength.emit(icdData);
  }
  clearSelection() {
    const selectedText = document.querySelectorAll(
      '.highlighted, .ht, .htb, .htn, .hted'
    );
    let parent;
    for (let i = 0; i < selectedText.length; i++) {
      parent = selectedText[i].parentNode;
      if (selectedText[i].firstChild) {
        parent.insertBefore(selectedText[i].firstChild, selectedText[i]);
      }
      parent.removeChild(selectedText[i]);
    }
  }
  validateICD(event) {
    const icdValue = event;
    const isValid = icdValue && icdValue.length > 10 ? false : true;
    return isValid;
  }
  updateStatus(param) {
    const status = param.status;
    if (status && status.length > 0) {
      this.gridApi.forEachNode(function (node) {
        node.setSelected(true);
      });
      const icdRowData = this.gridApi.getSelectedRows();
      icdRowData.forEach(element => {
        const icdCode = element.predictIcdCode
          ? element.predictIcdCode
          : element.icdCode;
        status.forEach(modifierArray => {
          if (modifierArray.icdCode === icdCode) {
            element.lcdStatus = modifierArray.lcdStatus;
          }
        });
      });
      setTimeout(() => {
        this.gridApi.updateRowData({ update: icdRowData });
      }, 0);
    }
    this.lcdCheckStatus = [];
  }
  toggleCol(platform) {
    if (platform === 'auditor' || platform === 'tl' || platform === 'sme') {
      this.hideShowGridColumnDefs();
    }
  }
  onGridSizeChanged(params) {
    this.gridApi.sizeColumnsToFit();
  }
  aapcDescription;
  onCellClicked(event: any) {
    // this.gridFocus(event);
    if (
      event.colDef.field === 'icdCode' ||
      event.colDef.field === 'predictIcdCode'
    ) {
      const code =
        event.data.icdCode !== undefined
          ? event.data.icdCode
          : event.data.predictIcdCode;
      const strData = event.data.rationaleData;
      if (strData) {
        const obj =
          event.data.rationaleSection === null
            ? null
            : event.data.rationaleSection
              .filter(o => o.sectionName === 'NOT FOUND')
              .map(s => s.sectionName)
              .includes('NOT FOUND');
        if (obj) {
          this.errorService.throwInfo(
            'No section name found for highlighted text'
          );
        }
        event.context.componentParent.getSearchTerm.emit(strData);
      } else {
        setTimeout(() => {
          this.errorService.throwInfo('No Rationale found for ICD: ' + code);
        }, 10);
      }
    } else {
      this.clearSelection();
    }
  }
  hideShowGridColumnDefs() {
    if (this.GridOptions) {
      this.GridOptions.columnApi.setColumnsVisible(['icdCode'], true);
      this.GridOptions.columnApi.setColumnsVisible(
        ['predictIcdCode', 'aapcIcdDescription', 'icdChart'],
        false
      );
      this.autoSizeAll();
    }
  }
  checkIcdData() {
    if (this.eventICD) {
      if (Object.keys(this.eventICD).length !== 0) {
        this.addBlankICDGrid(this.eventICD);
      }
      this.eventICD = undefined;
    }
  }
  // Add Blank row
  addBlankICDGrid(newItem) {
    this.gridApi.updateRowData({ add: [newItem] });
    this.checkAllRow();
    this.getAllRowData();
  }
  gridFocus(event) {
    window.setTimeout(function () {
      document.getElementById('ajax').focus();
    }, 0);
  }
  patientMedicalCharts() {
    if (this.patientChart) {
      const pc = JSON.stringify(this.patientChart);
      this.rationaleData = JSON.parse(pc);
    }
  }
  fetchIcdInfo() {
    if (this.ICDInfoRequest) {
      this.addRationaleData();
      setTimeout(() => {
        this.rowData = this.ICDInfoRequest;
        this.getIcdRowData.emit(this.rowData);
      }, 0);
    }
  }
  addRationaleData() {
    if (this.patientChart) {
      if (!this.isAuditAcknowledge) {
        this.ICDInfoRequest.filter(icdList => {
          icdList.rationaleData = this.appendRationale(
            this.patientChart,
            icdList.rationaleSection
          );
        });
      }
      this.ICDInfoRequest;
    }
  }

  groupBy(arr) {
    let result = [];
    result = arr.reduce(function (r, a) {
      r[a.section] = r[a.section] || [];
      r[a.section].push(a);
      return r;
    }, Object.create(null));
    return result;
  }

  appendRationale(originalText, sectionArr) {
    try {
      if (originalText && sectionArr) {
        let groupedSectionArr = this.groupBy(sectionArr);
        let groupedObj = Object.keys(groupedSectionArr);
        groupedObj.forEach((ele, index) => {
          let regName, valueText, secondOriginalText;
          const htmlName = '<span class="htb">$&</span><oscar' + index + '>';
          let groupedArr = groupedSectionArr[ele];
          regName = new RegExp('\\b' + ele + '\\b', 'i');
          let originalTextTemp = originalText.replace(regName, htmlName);
          valueText = originalTextTemp.split('<oscar' + index + '>');
          groupedArr.forEach((element, i) => {
            if (element.section || element.section === "" || element.value || element.value === "" || element.phrase === "") {
              let regValue,
                secValue,
                newElement;
              const htmlValue = '<span class="htn">$&</span>';
              const icdPhrase = element.phrase.split('|');
              secValue = element.value.trim().split('|');
              secValue.forEach((element, j) => {
                if (valueText[1].toLowerCase().match(element.toLowerCase()) === null) {
                  console.log("");
                } else {
                  newElement = '<oscarP' + j + '>' + element + '<oscarP' + j + '>';
                  valueText[1] = valueText[1].replace(element, newElement);
                  secondOriginalText = valueText[1].split('<oscarP' + j + '>');
                  icdPhrase.forEach((element) => {
                    element = element.replace(/\.+$/, '');
                    regValue = new RegExp('\\b' + element + '\\b', 'i');
                    secondOriginalText[1] = secondOriginalText[1].replace(regValue, htmlValue);
                  });
                  originalText = valueText[0] + secondOriginalText[0] + secondOriginalText[1] + secondOriginalText[2];
                  valueText[1] = secondOriginalText[0] + secondOriginalText[1] + secondOriginalText[2];
                }
              });
            } else {
              originalText = originalText;
            }
          });
        });
        return originalText;
      }
    } catch (error) {
      console.log(error);
    }
  }
  onCellValueChanged($event) {
    this.checkAllRow();
    this.validateBlankRecord();
    this.getAllRowData();
    this.isCellvalueChanges($event);
  }
  validateBlankRecord() {
    let tempIcd;
    let getselectedRow;
    if (this.gridApi) {
      getselectedRow = this.gridApi.getSelectedRows();
      if (getselectedRow.length > 0) {
        tempIcd = this.checkArray(getselectedRow) === undefined ? true : false;
      } else {
        tempIcd = false;
      }
      setTimeout(() => {
        this.isHavingIcd.emit(tempIcd);
      }, 1);
    }
  }
  checkArray(my_arr) {
    for (let i = 0; i < my_arr.length; i++) {
      if (
        this.platform === 'auditor' ||
        this.platform === 'tl' ||
        this.platform === 'sme'
      ) {
        if (my_arr[i].icdCode === '' || my_arr[i].icdCode === null) {
          return false;
        }
      } else {
        if (
          my_arr[i].predictIcdCode === '' ||
          my_arr[i].predictIcdCode === null
        ) {
          return false;
        }
      }
    }
  }
  getAllRowData(cellName?) {
    let isHavingDuplicate;
    if (this.gridApi) {
      setTimeout(() => {
        const getselectedRow = this.gridApi.getSelectedRows();
        const removeEmptyData = getselectedRow.filter(
          value => Object.keys(value).length !== 0
        );
        this.getIcdRowData.emit(removeEmptyData);
        /* ICD sequencing order implemented by Samba Siva */
        this.newRowData = [];
        this.gridApi.forEachNode((node, index) => {
          this.newRowData.push(node.data);
          node.data.counter = node.childIndex;
        });
        this.getIcdRowData.emit(this.newRowData);
        const icdData = {
          length: this.gridApi.getSelectedRows().length,
          component: 'icd'
        };
        // this.icdDataLength.emit(icdData);
        /* ICD sequencing order END*/
      }, 20);
    }
  }
  validateDuplicate(icdList, objKey) {
    const values = icdList;
    const code = objKey;
    const valueArr = values.map(function (item) {
      return item[code];
    });
    const isDuplicate = valueArr.some(function (item, idx) {
      return valueArr.indexOf(item) !== idx;
    });
    return isDuplicate;
  }
  autoSizeAll() {
    if (this.gridApi) {
      this.gridApi.sizeColumnsToFit();
    }
  }
  deleteRowNode(node) {
    this.deletedIcdObj = [];
    if (node.data.id === null) {
      this.gridApi.updateRowData({ remove: [node.data] });
    } else {
      node.setDataValue('isActive', false);
      this.deletedIcdObj = node.data;
      this.deletedIcd.emit(this.deletedIcdObj);
      this.gridApi.updateRowData({ remove: [node.data] });
    }
    const icdData = {
      length: this.gridApi.getSelectedRows().length,
      component: 'icd'
    };
    // this.icdDataLength.emit(icdData);
    this.getAllRowData();
  }
  GridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.autoSizeAll();
    this.checkAllRow();
    this.validateBlankRecord();
    params.api.stopEditing();
  }
  checkAllRow() {
    if (this.gridApi) {
      setTimeout(() => {
        this.gridApi.forEachNode(function (node) {
          node.setSelected(true);
        });
      }, 10);
    }
  }
  isCellvalueChanges(params) {
    if (params.newValue !== params.oldValue) {
      this.icdIsPristines.emit(true);
    }
  }
  onRowDragEnd(e) {
    const displayModel = e.api.getModel();
    const rowNode = displayModel.rowsToDisplay[e.node.rowIndex];
    rowNode.setDataValue('counter', e.overIndex + 1);
  }
  /* de-select selected grid rows */
  public deSelection() {
    this.gridApi.deselectAll();
  }
}
// confidencescore
function rationaleFormat() {
  function cellRationaleFormat() { }
  cellRationaleFormat.prototype.init = function (params) {
    let tempDiv;
    tempDiv = document.createElement('div');
    tempDiv.innerHTML =
      '<span>' +
      JSON.stringify(params.data.rationale.rationaleSection) +
      '</span>';
    this.eGui = tempDiv;
  };
  cellRationaleFormat.prototype.getGui = function () {
    return this.eGui;
  };
  return cellRationaleFormat;
}
// confidencescore
function getConfidenceScore() {
  function SimpleCellRenderer() { }
  SimpleCellRenderer.prototype.init = function (params) {
    let tempDiv;
    if (params.context.componentParent.platform === 'coder') {
      const cellConfidenceScore = Math.round(params.data.probabilityScore);
      if (cellConfidenceScore) {
        let colorCode;
        const confidenceColorCodeCheckList =
          params.context.componentParent.confidenceColorCode;
        confidenceColorCodeCheckList.forEach(element => {
          if (params.context.componentParent.role !== 'admin') {
            if (element.allocationRole !== 'admin') {
              const whichColorCode = between(
                cellConfidenceScore,
                element.lowerLimit,
                element.upperLimit
              );
              if (whichColorCode) {
                colorCode = element.confidenceScore;
              }
            }
          } else {
            const whichColorCode = between(
              cellConfidenceScore,
              element.lowerLimit,
              element.upperLimit
            );
            if (whichColorCode) {
              colorCode = element.confidenceScore;
            }
          }
        });
        tempDiv = document.createElement('div');
        tempDiv.innerHTML =
          '<span class="block">' +
          params.value +
          '</span>' +
          '<span title="ICD: ' +
          params.value +
          ' , Probability Score: ' +
          colorCode +
          '" class="probability probabilityColor_' +
          colorCode +
          ' float-right">' +
          cellConfidenceScore +
          '</span>';
        this.eGui = tempDiv;
      } else {
        tempDiv = document.createElement('div');
        tempDiv.innerHTML =
          params.value +
          '<span class="probability probabilityColor_nps float-right">NPS</span>';
        this.eGui = tempDiv;
      }
    } else {
      tempDiv = document.createElement('div');
      tempDiv.innerHTML = params.value;
      this.eGui = tempDiv;
    }
  };
  SimpleCellRenderer.prototype.getGui = function () {
    return this.eGui;
  };
  return SimpleCellRenderer;
}
function getSimpleCellRenderer() {
  function SimpleCellRenderer() { }
  SimpleCellRenderer.prototype.getGui = function () {
    return this.eGui;
  };
  SimpleCellRenderer.prototype.getValue = function () {
    const inputvalue = this.eGui.firstElementChild.value;
    let retValue;
    if (this.dataListValue && this.dataListValue.length > 0) {
      const updatedValue = this.dataListValue.find(o => o.code === inputvalue)
        ? inputvalue
        : '';
      if (updatedValue !== '') {
        retValue = updatedValue;
      } else {
        this.param.context.componentParent._toastr.warning('Invalid ICD Code');
        retValue = this.oldValue;
      }
      if (this.param.context.componentParent.platform === 'coder') {
        this.param.node.data.aapcIcdDescription = this.dataListValue[0].desc;
      } else {
        this.param.node.data.aapcDescription = this.dataListValue[0].desc;
      }
    } else {
      this.param.context.componentParent._toastr.warning('No Data Found');
      retValue = this.oldValue;
    }
    return retValue;
  };
  SimpleCellRenderer.prototype.isPopup = function () {
    return true;
  };
  SimpleCellRenderer.prototype.afterGuiAttached = function () {
    const changedWidth = this.colWidth + 'px';
    this.eGui.parentElement.style.width = changedWidth;
  };
  SimpleCellRenderer.prototype.destroy = function() {
    this.eGui.removeEventListener('keyup', myFunction);
    this.eGui.removeEventListener('change', myFunction);
  };
  SimpleCellRenderer.prototype.init = function (params) {
    let multiDD,
      colWidth,
      param,
      autoCompleteInput,
      parentElementDiv,
      dataListDiv,
      value;
    this.param = params;
    this.oldValue = this.param.value;
    this.colWidth = this.param.column.actualWidth;
    multiDD = this.param.node.data.rationaleSection;
    parentElementDiv = document.createElement('div');
    parentElementDiv.setAttribute('class', 'data-list');
    autoCompleteInput = document.createElement('input');
    autoCompleteInput.setAttribute('value', this.param.value);
    autoCompleteInput.setAttribute('type', 'text');
    autoCompleteInput.setAttribute('id', 'ajax');
    autoCompleteInput.setAttribute('class', 'data-list-input');
    autoCompleteInput.setAttribute('list', 'json-datalist');
    autoCompleteInput.setAttribute('placeholder', 'Please Start Typing...');
    autoCompleteInput.setAttribute('autocomplete', 'off');
    autoCompleteInput.setAttribute('autofocus', 'autofocus');
    dataListDiv = document.createElement('datalist');
    dataListDiv.setAttribute('id', 'json-datalist');
    autoCompleteInput.addEventListener(
      'keyup',
      myFunction.bind(null, this.param, dataListDiv, autoCompleteInput, this),
      false
    );
    autoCompleteInput.addEventListener(
      'change',
      optionMyFun.bind(null, this.param, dataListDiv, autoCompleteInput, this),
      false
    );
    parentElementDiv.appendChild(autoCompleteInput);
    parentElementDiv.appendChild(dataListDiv);
    this.eGui = parentElementDiv;
  };
  return SimpleCellRenderer;
}
function myFunction(params, dataListDiv, autoCompleteInput, that) {
  const dataListValue = [];
  dataListDiv.innerHTML = '';
  if (autoCompleteInput.value.length > 2) {
    const gender = params.context.componentParent.gender;
    const dob = params.context.componentParent.dateOfBirth;
    const dos = params.context.componentParent.dateOfService;
    const facility = params.context.componentParent.facility;
    params.context.componentParent._lookupDataService
      .getIcdCptLookUpData(
        autoCompleteInput.value,
        gender,
        dob,
        dos,
        facility,
        'icd'
      )
      .subscribe((data: any) => {
        that.dataListValue = data;
        if (that.dataListValue.length > 0) {
          that.dataListValue.forEach(function (item) {
            const option = document.createElement('option');
            option.value = item.code;
            dataListDiv.appendChild(option);
          });
        } else {
          const option = document.createElement('option');
          option.value = '';
          option.text = '';
          dataListDiv.appendChild(option);
        }
      });
  }
}
function optionMyFun(a, b, c, d, e) {
  a.context.componentParent.gridApi.stopEditing();
}
function between(x, min, max) {
  return x >= min && x <= max;
}
