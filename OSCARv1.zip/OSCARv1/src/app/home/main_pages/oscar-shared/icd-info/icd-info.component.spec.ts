import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AgGridModule } from 'ag-grid-angular/main';
import { IcdInfoComponent } from './icd-info.component';
import { MaterialModule } from '../../../../imports/material.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastOptions, ToastsManager } from 'ng2-toastr';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
import { Router, ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { LookupDataService } from '../../../../_shared-services/unrelated-data-services/lookup-data.service';
import { HttpModule } from '@angular/http';
import { HeaderAuthenticationToken } from '../../../../auth/authetication-header';
import { DateFormatter } from '../../../../imports/_utilities/date-formatter';
import { DatePipe } from '@angular/common';
import { CommonCodeService } from '../../../../_shared-services/common-code.services';
import { HttpClientTestingModule } from '@angular/common/http/testing';
fdescribe('IcdInfoComponent', () => {
  let component: IcdInfoComponent;
  let fixture: ComponentFixture<IcdInfoComponent>;
  const fakeActivatedRoute = {
    snapshot: { data: {} }
  } as ActivatedRoute;
  let originalTimeout;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [IcdInfoComponent],
      imports: [
        HttpModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        RouterTestingModule,
        AgGridModule.withComponents([IcdInfoComponent]),
        BrowserAnimationsModule,
        HttpClientTestingModule
      ],
      providers: [
        ToastsManager,
        HeaderAuthenticationToken,
        ToastOptions,
        LookupDataService,
        // ErrorHandlingServices,
        DateFormatter,
        DatePipe,
        CommonCodeService,
        ErrorHandlingServices
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 5000;
    fixture = TestBed.createComponent(IcdInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(()=> {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = originalTimeout;
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('#toggleCol() should call hideShowGridColumnDefs() if platform is auditor', () => {
    spyOn(component, 'hideShowGridColumnDefs');
    component.toggleCol('auditor');
    expect(component.hideShowGridColumnDefs).toHaveBeenCalled();
  });

  it('#toggleCol() should call hideShowGridColumnDefs() if platform is tl', () => {
    spyOn(component, 'hideShowGridColumnDefs');
    component.toggleCol('tl');
    expect(component.hideShowGridColumnDefs).toHaveBeenCalled();
  });

  it('#toggleCol() should call hideShowGridColumnDefs() if platform is sme', () => {
    spyOn(component, 'hideShowGridColumnDefs');
    component.toggleCol('sme');
    expect(component.hideShowGridColumnDefs).toHaveBeenCalled();
  });

  it('#toggleCol() should not call hideShowGridColumnDefs() if platform is not auditor or tl or sme', () => {
    spyOn(component, 'hideShowGridColumnDefs');
    component.toggleCol('test');
    expect(component.hideShowGridColumnDefs).not.toHaveBeenCalled();
  });

  it('#hideShowGridColumnDefs() should call autoSizeAll() ', () => {
    spyOn(component, 'autoSizeAll');
    component.hideShowGridColumnDefs();
    expect(component.autoSizeAll).toHaveBeenCalled();
  });

  it('#checkIcdData() should call addBlankICDGrid() and set eventICD to undefined', () => {
    spyOn(component, 'autoSizeAll');
    component.hideShowGridColumnDefs();
    expect(component.autoSizeAll).toHaveBeenCalled();
  });

  it('should have expected column headers', () => {
    fixture.detectChanges();

    const elm = fixture.nativeElement;
    const grid = elm.querySelector('ag-grid-angular');
    const headerCells = grid.querySelectorAll('.ag-header-cell-text');
    const headerTitles = Array.from(headerCells).map((cell: any) =>
      cell.textContent.trim()
    );
    expect(headerTitles).toEqual(['Counter', 'ICD', 'LCD Status', '']);
  });

  it('#validateICD(event) should return true if icd Value length is lesser than 10', () => {
    const icd = 'qwert';

    expect(component.validateICD(icd)).toBeTruthy();
  });

  it('#validateICD(event) should return false if icd Value length is greater than 10', () => {
    const icd = 'qwertyuiopp';

    expect(component.validateICD(icd)).toBeFalsy();
  });

it('#platform', () => {
  fixture.detectChanges();
  expect(component.platform).toBeDefined();
});

it('#patientChart', () => {
  fixture.detectChanges();
  component.patientChart = { };
expect(component.patientChart).toBeDefined();
});

it('#isAuditAcknowledge', () => {
  fixture.detectChanges();
  component.isAuditAcknowledge = true;
expect(component.isAuditAcknowledge).toBeDefined();
});

it('#setIcdSectionHeight', () => {
  fixture.detectChanges();
  component.setIcdSectionHeight = ' ';
  expect(component.setIcdSectionHeight).toBeUndefined();
});


it('#newRowData', () => {
  fixture.detectChanges();
   expect(component.newRowData).toBeDefined(true);
});

it('#checkIcdData() havebeen called', () => {
  spyOn(component, 'checkIcdData');
  component.checkIcdData();
  expect(component.checkIcdData).toHaveBeenCalled();
});

it('#patientMedicalCharts() havebeen called', () => {
  spyOn(component, 'patientMedicalCharts');
  component.patientMedicalCharts();
  expect(component.patientMedicalCharts).toHaveBeenCalled();
});

it('#getIcdRowData', () => {
  fixture.detectChanges();
      expect(component.getIcdRowData).toBeDefined();
});

it('#isHavingIcd', () => {
  fixture.detectChanges();
   expect(component.isHavingIcd).toBeDefined();
});

it('#getSearchTerm', () => {
  fixture.detectChanges();
   expect(component.getSearchTerm).toBeDefined(true);
});


});
