// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { PateintMedicalReportComponent } from './pateint-medical-report.component';

// describe('PateintMedicalReportComponent', () => {
//   let component: PateintMedicalReportComponent;
//   let fixture: ComponentFixture<PateintMedicalReportComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ PateintMedicalReportComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(PateintMedicalReportComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
