import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  ViewChild,
  AfterViewInit
} from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { CopyToClipBoard } from '../../../../imports/_utilities/copy-to-clipboard';
import { ErrorHandlingServices } from '../../../../services/error-handling.services';
@Component({
  selector: 'app-pateint-medical-report',
  templateUrl: './pateint-medical-report.component.html',
  styleUrls: ['./pateint-medical-report.component.scss'],
  providers: [CopyToClipBoard],
 })
export class PateintMedicalReportComponent implements OnInit, AfterViewInit {
  patientCharts: String;
  zoom;
  lineHeight;
   searchstring: any;
  @Input() set setDisplayHeight(value) {
    this.height = value ? value : 585;
  }
  @Input() set setZoom(value) {
    this.zoom = value;
  }
  @Input() set setLineHeight(value) {
    this.lineHeight = value;
  }
  @Input() isDisableContextMenu;
  @Input() patientChart: any;
  @Input() searchTerm: string;
  @Input() isAuditAcknowledge: boolean;
  @Output() eventClickedICD = new EventEmitter();
  @Output() eventClickedCPT = new EventEmitter();
  @ViewChild(PateintMedicalReportComponent)
  public basicMenu: PateintMedicalReportComponent;
  @ViewChild('mulitHighlight') hl;
  @ViewChild('reportText') reportText;
  @ViewChild('scrollTo') scrollTo;
  @Input() mrHeight = '440px';
  height = 585;
  pointerNone;
  private subject = new Subject<any>();
  helpMenuOpen: string;
  public el;
  highlightedText = [];
  constructor(
    public _toastr: ToastsManager,
    private _copyToClipBoard: CopyToClipBoard,
    private errorService: ErrorHandlingServices
  ) {}
  checkHighlight(event) {
    this.el = this.reportText.nativeElement as HTMLElement;
    const checkHighlight = this.el.querySelectorAll('.htn, .ht, .htb');
    if (checkHighlight.length > 0) {
      const selectedText = document.querySelectorAll('.htn, .ht, .htb');
      this.clearSelection(selectedText);
    } else {
      return;
    }
  }
  ngOnInit() {
    this.searchTerm = '';
    this.helpMenuOpen = 'out';
  }
  addToGridPlatform(platform) {
    this.highlightedText = [];
    const elements = this.hl.nativeElement.querySelectorAll('.highlighted');
    const textInnerHtml = this.reportText.nativeElement.innerHTML;
    elements.forEach(value => {
      this.highlightedText.push(value.innerText);
    });
    const selectedText = this.highlightedText.join(' ');
    const param = {
      highlightedText: selectedText,
      textInnerHtml: textInnerHtml
    };
    if (selectedText.length > 0) {
      if (selectedText.length > 500) {
        this.errorService.throwWarning(
          'More than 500 characters are not allowed.'
        );
      } else {
        this.clearSelection(elements);
        if (platform === 'ICD') {
          this.eventClickedICD.emit(param);
        } else {
          this.eventClickedCPT.emit(param);
        }
      }
    } else {
      this.errorService.throwStringError(
        'Please Select from patient Medical Report to Add'
      );
    }
  }
  toggleHelpMenu(): void {
    this.helpMenuOpen = this.helpMenuOpen === 'out' ? 'in' : 'out';
  }

  ngOnChanges() {
    this.patientMedicalCharts();
    this.pointerNone = this.isAuditAcknowledge ? 'none' : null;
    if (this.searchTerm) {
      this.searchTerm;
      this.scrollRational();
    }
  }

  scrollRational() {
    setTimeout(() => {
      this.searchstring = this.hl.nativeElement.querySelector(
        '.htb, .htn'
      );
       if(this.searchstring) {
        this.scrollTo.nativeElement.scrollTo( 0, this.searchstring.offsetTop - 40);
      }
      }, 10);
  }

  ngAfterViewInit() {
    if (this.searchTerm) {
      this.searchTerm;
    }
    loadJavaScript();
  }
  clearSelection(selectedText) {
    if (!selectedText) {
      selectedText = this.hl.nativeElement.querySelectorAll(
        '.highlighted, .htn, .ht, .htb, .hted'
      );
    }
    if (selectedText.length > 0) {
      let parent;
      for (let i = 0; i < selectedText.length; i++) {
        parent = selectedText[i].parentNode;
        if (selectedText[i].firstChild) {
          parent.insertBefore(selectedText[i].firstChild, selectedText[i]);
        }
        parent.removeChild(selectedText[i]);
      }
    }
  }
  reloadReports(eve) {
    if (this.searchTerm) {
      this.patientMedicalCharts();
    }
    this.searchTerm = null;
  }
  copySelection() {
    const copiedList: any = [];
    let copiedText;
    const selectedText: any = this.hl.nativeElement.querySelectorAll(
      '.highlighted'
    );
    if (selectedText.length > 0) {
      for (let i = 0; i < selectedText.length; i++) {
        selectedText[i].classList.remove('highlighted');
        copiedList.push(selectedText[i].innerHTML);
      }
      copiedText = copiedList.join(' ');
      const result = this._copyToClipBoard.copyTextToClipboard(copiedText);
      if (result) {
        this.clearSelection(selectedText);
        this.errorService.throwInfo('Copied to Clipboard');
      }
    } else {
      this.errorService.throwInfo('Please select from the Report to copy');
    }
  }
  getMessage(): Observable<any> {
    return this.subject.asObservable();
  }
  patientMedicalCharts() {
    if (this.patientChart) {
      const patientCharts = JSON.stringify(this.patientChart);
      this.patientCharts = JSON.parse(patientCharts);
    }
  }
}
function loadJavaScript() {
  let url = 'assets/js/rationaleHighlight.js';
  let s = document.createElement('script');
  s.setAttribute('src', url);
  document.head.appendChild(s);
}
