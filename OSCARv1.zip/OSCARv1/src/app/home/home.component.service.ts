import { Injectable, ViewContainerRef } from '@angular/core';
import { HeaderAuthenticationToken } from '../auth/authetication-header';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { ToastsManager } from 'ng2-toastr';
import { Observable } from 'rxjs';
import { checkAndUpdatePureExpressionInline } from '@angular/core/src/view/pure_expression';

@Injectable()
export class HomeComponentService {
  public httpOption;
  public httpOptionLogout;
  public envURL = environment.URL;
  public storage: Storage = environment.storage;
  constructor(
    private httpClient: HttpClient,
    private __httpHeader: HeaderAuthenticationToken,
    public toaster: ToastsManager
  ) {
    this.httpOption = this.__httpHeader.setHeaderToken();
  }

  public getDashboardSummaryDetails(role, date): any {
    const userId = this.storage.getItem('UserName');
    const URL =
      this.envURL + 'dashboardsummary/' + role + '/readMyDashboardDetails';

    const param =
      role === 'tl'
        ? {
            userId: userId,
            currentDate: date
          }
        : {
            userId: userId,
            role: role,
            currentDate: date
          };

    return this.httpClient.post(URL, param, this.httpOption).pipe(
      map((response: any) => {
        if (!response.apierror) {
          return response;
        } else {
          this.toaster.info(response.apierror.message);
        }
      })
    );
  }

  public clearCharts(user, role): Observable<any> {
    const URL =
      this.envURL +
      'chartinformation/clearCharts?user=' +
      user +
      '&role=' +
      role;
    return this.httpClient.get(URL, this.httpOption).pipe(
      map((response: any) => {
        if (!response.apierror) {
          return response;
        } else {
          this.toaster.info(response.apierror.message);
        }
      })
    );
  }

  public saveLogoutDetails(param): Observable<any> {
    const URL = this.envURL + 'logindetails/updateLogindetails';

    return this.httpClient.post(URL, param, this.httpOption).pipe(
      map((response: any) => {
        if (!response.apierror) {
          return response;
        } else {
          this.toaster.info(response.apierror.message);
        }
      })
    );
  }

  // public logoutDetails(user, role, param): Observable<any> {
  //     let URL1 = 'http://10.8.34.114:9517' + '/clearCharts?user=' + user + '&role=' + role;
  //     let URL='http://10.8.34.114:9532'+'/updateLogindetails';
  //     return Observable.forkJoin(
  //         this.httpClient.get(URL1, this.httpOption).map((res: any) => res.json()),
  //         this.httpClient.post(URL, param, this.httpOption).map((res: any) => res.json()),
  //     )
  // }
}
