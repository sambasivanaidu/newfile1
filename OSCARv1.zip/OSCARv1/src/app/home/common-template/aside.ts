import { OnInit } from '@angular/core';
import { Component } from '@angular/core';

@Component({
    selector: 'app-aside',
    template: `
    <ul class="nav nav-tabs" role="tablist">
      <li class="nav-item">
        <a class="nav-link active" data-toggle="tab" href="#tab1" role="tab">
          Search Filter
        </a>
      </li>
    </ul>
    <!-- Tab panes-->
    <div class="tab-content">
      <div class="tab-pane p-3 active" id="tab1" role="tabpanel">
        Search Filter Content
      </div>
    </div>`
})

export class AsideComponent implements OnInit {
    private year;
    constructor() {
        this.year = (new Date()).getFullYear();
    }

    ngOnInit() { }
}
