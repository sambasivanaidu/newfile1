import { Component, OnInit, NgZone } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  template: `
    <header class="demo-header">
        <button class="demo-header__toggle">Toggle sidebar</button>
        <span>Oscar</span>
        <mat-menu #appMenu="matMenu" class="col-md-12">
            <ng-template matMenuContent let-name="name">
                <button mat-menu-item>Settings</button>
                <mat-divider ></mat-divider>
                <button mat-icon-button class="icon-padding" (click)="Logout()">
                    <mat-icon aria-hidden="true">exit_to_app</mat-icon>
                    <strong>Logout</strong>
                </button>
            </ng-template>
        </mat-menu>
        <button mat-mini-fab mat-icon-button [matMenuTriggerFor]="appMenu" [matMenuTriggerData]="{name: 'Sally'}">
            <mat-icon>more_vert</mat-icon>
        </button>
    </header>
  `,
})
export class HeaderComponent {

}
