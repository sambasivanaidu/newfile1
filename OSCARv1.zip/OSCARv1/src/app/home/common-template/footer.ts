import { OnInit } from '@angular/core';
import { Component } from '@angular/core';

@Component({
    selector: 'app-footer',
    template: `
    <div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2" >
                    <p class="pl-0 p-text text-red">Copyright &copy; 2019 | Omega Healthcare All rights reserved</p>
                </div> `,
    styles:
        [`
        .text-red {
            color: #ad2922
        }
        .version-text {
            color: white;
        }
        .p-text{
            padding: 6px;
        }

        section .section-title {
            text-align: center;
            color: #007b5e;
            margin-bottom: 50px;
            text-transform: uppercase;
        }
        #footer {
            font-family: 'Noto Sans JP', sans-serif !important;
            font-weight: bold;
            border: 1px solid #bfbfbf;
            font-size: 12px;
        }

        #footer a {
            color: #ffffff;
            text-decoration: none !important;
            background-color: transparent;
            -webkit-text-decoration-skip: objects;
        }
    `]
})

export class FooterComponent implements OnInit {
    private year;
    constructor() {
        this.year = (new Date()).getFullYear();
    }

    ngOnInit() { }
}
