import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from '../imports/material.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { DatePipe } from '@angular/common';
// App Gaurd
import { AuthGuard } from '../auth/auth.guard';
import { SidebarModule } from 'ng-sidebar';
// App Router Class
import { appRoutes } from '../routes';
import {
  HashLocationStrategy,
  LocationStrategy,
  CommonModule
} from '@angular/common';
// App Node Modules
import {
  PasswordModule,
  InputTextModule,
  PanelModule,
  DialogModule,
  ConfirmDialogModule,
  SharedModule
} from 'primeng/primeng';
import { ChartModule } from 'primeng/chart';
import { OrganizationChartModule } from 'primeng/organizationchart';
import { DeviceDetectorModule } from 'ngx-device-detector';
import { AgGridModule } from 'ag-grid-angular';
import { NgProgressModule } from 'ngx-progressbar';
// App Services
import { UserService } from '../users/shared/user.service';
import { HeaderAuthenticationToken } from '../auth/authetication-header';
// App Component
import { RouterModule, Routes } from '@angular/router';
import { HeaderComponent } from '../home/common-template/header';
import { FooterComponent } from '../home/common-template/footer';
import { AsideComponent } from '../home/common-template/aside';
import { HomeComponent } from '../home/home.component';
import { MatDialogOverviewComponent } from '../imports/_utilities/mat-dialog-overview/mat-dialog-overview.component';
import { MatDialogCheckDuplicateComponent } from '../imports/_utilities/mat-dialog-check-duplicate/mat-dialog-check-duplicate.component';
import { OscDropdownDirective } from '../imports/directive/osc-dropdown.directive';
import { MatDropdownSearch } from '../imports/_utilities/mat-dropdown-search';
import { DeleteConfirmDialogComponent } from '../imports/_utilities/delete-confirm-dialog';
import { MatUserRulesDialogComponent } from '../imports/_utilities/mat-user-rules-dialog/mat-user-rules-dialog.component';
import { AuditAcknowledgeDialogComponent } from '../imports/_utilities/mat-dialog-acknowledge/mat-dialog-acknowledge.component';
import { NgIdleModule } from '@ng-idle/core';
import { FileUploadComponent } from '../imports/_utilities/file-upload/file-upload.component';
import { AgGridComponent } from '../imports/_utilities/ag-grid/ag-grid.component';
import { IsAgreeCheckboxComponent } from '../imports/_utilities/mat-dialog-acknowledge/isAgreeCheckbox';
import { UserMappingService } from '../_shared-services/user-mapping/user-mapping.service';
// import { MipsDialogComponent } from '../imports/_utilities/mips-dialog/mips-dialog.component';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { MatDialogFeedbackComponent } from '../imports/_utilities/mat-dialog-feedback/mat-dialog-feedback.component';
import { PlatformOnloadCheckComponent } from '../imports/_utilities/platform-onload-check/platform-onload-check.component';
import { ActionDDComponent } from '../imports/_utilities/platform-onload-check/action-dd.component';
import { DateFormatter } from '../imports/_utilities/date-formatter';
import {
  MatButtonModule,
  MatFormFieldModule,
  MatInputModule,
  MatIconModule
} from '@angular/material';
import { MatProgressButtonsModule } from 'mat-progress-buttons';
import { MatDynamicDdModule } from '../imports/_utilities/mat-dynamic-dd/mat-dynamic-dd.module';
import { PipesModule } from '../imports/pipes/pipes.module';
import { BreadCrumbModule } from '../home/main_pages/reports/bread-crumb/bread-crumb.module';
import { TimeoutModalModule } from '../imports/_utilities/timeout-modal/timeout-modal.module';
import { MatMessageDialogModule } from '../imports/_utilities/mat-message-dialog/mat-message-dialog.module';
import { MatSearchDdModule } from '../imports/_utilities/mat-search-dd/mat-search-dd.module';
import { PlatformService } from '../services/main-pages/paltform-services/platform-service.service';
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};
const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
    children: [
      {
        path: '',
        loadChildren:
          'app/home/main_pages/dashboard/dashboard.module#DashboardModule'
      },
      {
        path: 'rai',
        loadChildren: 'app/home/main_pages/rai/rai.module#RaiModule',
        canActivate: [AuthGuard]
      },
      {
        path: 'coder',
        loadChildren: 'app/home/main_pages/coder/coder.module#CoderModule',
        canActivate: [AuthGuard]
      },
      {
        path: 'auditor',
        loadChildren:
          'app/home/main_pages/auditor/auditor.module#AuditorModule',
        canActivate: [AuthGuard]
      },
      {
        path: 'L2auditor',
        loadChildren:
          'app/home/main_pages/audit-l2/audit-l2.module#AuditL2Module',
        canActivate: [AuthGuard]
      },
      {
        path: 'sme',
        loadChildren: 'app/home/main_pages/sme/sme.module#SmeModule',
        canActivate: [AuthGuard]
      },
      {
        path: 'teamlead',
        loadChildren:
          'app/home/main_pages/team-lead/team-lead.module#TeamLeadModule',
        canActivate: [AuthGuard]
      },
      {
        path: 'reports',
        loadChildren:
          'app/home/main_pages/reports/reports.module#ReportsModule',
        canActivate: [AuthGuard]
      }
    ]
  }
];
@NgModule({
  declarations: [
    HeaderComponent,
    FooterComponent,
    AsideComponent,
    HomeComponent,
    PlatformOnloadCheckComponent,
    MatDialogOverviewComponent,
    MatUserRulesDialogComponent,
    MatDialogCheckDuplicateComponent,
    DeleteConfirmDialogComponent,
    OscDropdownDirective,
    MatDialogFeedbackComponent,
    AgGridComponent,
    AuditAcknowledgeDialogComponent,
    FileUploadComponent,
    IsAgreeCheckboxComponent,
    ActionDDComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    MatButtonModule,
    MatSearchDdModule,
    MatMessageDialogModule,
    TimeoutModalModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    FormsModule,
    ConfirmDialogModule,
    SharedModule,
    SidebarModule.forRoot(),
    RouterModule.forChild(appRoutes),
    DeviceDetectorModule.forRoot(),
    AgGridModule.withComponents([]),
    MatProgressButtonsModule.forRoot(),
    FlexLayoutModule,
    MaterialModule,
    ChartModule,
    PasswordModule,
    InputTextModule,
    PanelModule,
    DialogModule,
    ReactiveFormsModule,
    NgProgressModule,
    OrganizationChartModule,
    NgIdleModule.forRoot(),
    CommonModule,
    PerfectScrollbarModule,
    MatDynamicDdModule,
    PipesModule,
    BreadCrumbModule
  ],
  entryComponents: [
    MatDialogOverviewComponent,
    MatDialogFeedbackComponent,
    PlatformOnloadCheckComponent,
    MatUserRulesDialogComponent,
    MatDialogCheckDuplicateComponent,
    DeleteConfirmDialogComponent,
    AgGridComponent,
    AuditAcknowledgeDialogComponent,
    IsAgreeCheckboxComponent,
    ActionDDComponent,
    // MipsDialogComponent,
    HomeComponent
  ],
  providers: [
    DatePipe,
    UserService,
    HeaderAuthenticationToken,
    MatDropdownSearch,
    AuthGuard,
    DateFormatter,
    {
      provide: LocationStrategy,
      useClass: HashLocationStrategy
    },
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    },
    PlatformService,
    UserMappingService
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class HomeModule {}
