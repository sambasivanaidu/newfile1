import { Routes } from "@angular/router";
import { AuthGuard } from "./auth/auth.guard";

export const appRoutes: Routes = [
  {
    path: "index",
    loadChildren: "app/home/home.module#HomeModule",
    canActivate: [AuthGuard]
  },
  {
    path: "welcome",
    loadChildren: "app/users/users.module#UsersModule"
  },
  {
    path: "",
    redirectTo: "/welcome/login",
    pathMatch: "full",
    canActivate: [AuthGuard]
  },
  { path: "404", redirectTo: "/welcome/login" }
];
