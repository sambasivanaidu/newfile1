export interface IAuditorService {
    saveAuditorChartInfo(param: any): void;
    fetchPatientChart(params: String);
    fetchPatientInfo(params: any);
    fetchPatientRecordInfo(params: String);
}
