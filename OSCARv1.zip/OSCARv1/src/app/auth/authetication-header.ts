import { Injectable } from '@angular/core';
import { Headers, RequestOptions, ResponseContentType } from '@angular/http';

@Injectable()
export class HeaderAuthenticationToken {
  public httpOption;
  public storage: Storage = sessionStorage;

  setHeaderNoToken() {
    const header = new Headers();
    header.append('Content-Type', 'application/json');
    this.httpOption = new RequestOptions({
      headers: header
    });
    return this.httpOption;
  }

  setHeaderToken() {
    const authToken = this.storage.getItem('Token');
    const header = new Headers();
    header.append('Content-Type', 'application/json');
    header.append('Authorization', 'bearer ' + authToken);
    this.httpOption = new RequestOptions({
      headers: header
    });
    return this.httpOption;
  }

  setHeaderTokenForLogout() {
    const authToken = this.storage.getItem('Token');
    const header = new Headers();
    header.append('Content-Type', 'application/json');
    header.append('Authorization', 'bearer ' + authToken);
    this.httpOption = new RequestOptions({
      headers: header
    });
    this.storage.clear();
    return this.httpOption;
  }

  setpdfHeaderToken() {
    const authToken = this.storage.getItem('Token');
    const header: any = new Headers();
    header.set('Content-Type', 'application/json');
    header.set('Authorization', 'bearer ' + authToken);
    this.httpOption = {
      headers: header,
      responseType: 'blob'
    }
    return this.httpOption;
  }

  setFileHeaderToken() {
    const authToken = this.storage.getItem('Token');
    const header = new Headers();
    header.append('Content-Type', 'multipart/form-data');
    header.append('Accept', 'application/json');
    header.append('Authorization', 'bearer ' + authToken);
    this.httpOption = new RequestOptions({
      headers: header
    });
    return this.httpOption;
  }

  setFileHeader2Token() {
    const authToken = this.storage.getItem('Token');
    const header = new Headers();
    header.append('Content-Type', 'multipart/form-data');
    header.append('Authorization', 'bearer ' + authToken);
    this.httpOption = new RequestOptions({
      headers: header
    });
    return this.httpOption;
  }

  setFileHeader3Token() {
    const authToken = this.storage.getItem('Token');
    const header = new Headers();

    header.append('Content-Type', 'application/json');
    header.append('Authorization', 'bearer ' + authToken);

    this.httpOption = new RequestOptions({
      responseType: ResponseContentType.Blob,
      headers: header
    });
    return this.httpOption;
  }
}
