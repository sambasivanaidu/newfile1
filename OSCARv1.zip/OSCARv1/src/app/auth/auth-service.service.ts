import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';

@Injectable()
export class AuthService {
  public storage: Storage = environment.storage;
  public getToken(): string {
    return this.storage.getItem('Token');
  }

  public isAuthenticated(): boolean {
    // get the token
    const token = this.getToken();
    return tokenNotExpired(token);
  }

}

function tokenNotExpired(token) {
  return true;
}
