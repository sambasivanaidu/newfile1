// import { TestBed, async, ComponentFixture } from '@angular/core/testing';

// import { NgModule , CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
// import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { BrowserXhr, HttpModule } from '@angular/http';
// import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
// import { AppComponent } from './app.component';
// import { BrowserAnimationsModule, NoopAnimationsModule } from '@angular/platform-browser/animations';
// import { MaterialModule } from './imports/material.module';
// import {
//     MatButtonModule,
//     MatIconModule,
//     MatInputModule,
//     MatFormFieldModule
// } from '@angular/material';
// import { FlexLayoutModule } from '@angular/flex-layout';
// import { HighlightTextDirective } from './imports/directive/highlight-text.directive';
// import { ResponsiveColsDirective } from './imports/directive/responsive-cols.directive';
// import { MatDialogDraggableTitleDirective } from './imports/directive/mat-dialog-draggable-title.directive';
// import { HighlightSearch } from './imports/pipes/highlights.pipe';
// import { MatDynamicDdComponent } from './imports/_utilities/mat-dynamic-dd/mat-dynamic-dd.component';
// import { UsrMappingComponent } from './home/main_pages/usr-mapping/usr-mapping.component';
// import { ReplaceLineBreaksPipe } from './imports/pipes/replace-line-breaks.pipe';
// // Ag-Grid Utilities
// import { BatchCheckboxRendererComponent } from './imports/ag-grid/batch-checkbox-renderer';
// import { AgGridCellCheckboxRendererComponent } from './imports/ag-grid/ag-grid-cell-checkbox';
// import { CellDeleteBtnRendererComponent } from './imports/ag-grid/delete-btn-render';
// import { MatFacilityDdComponent } from './imports/_utilities/mat-facility-dd/mat-facility-dd.component';
// import { DatePipe } from '@angular/common';
// // App Gaurd
// import { AuthGuard } from './auth/auth.guard';
// import { SidebarModule } from 'ng-sidebar';
// // App Router Class
// import { appRoutes } from './routes';

// import { HashLocationStrategy, LocationStrategy, CommonModule } from '@angular/common';
// // App Node Modules
// import {
//     PasswordModule,
//     InputTextModule,
//     PanelModule,
//     DialogModule,
//     MessageService

// } from 'primeng/primeng';

// import { ChartModule } from 'primeng/chart';
// import { OrganizationChartModule } from 'primeng/organizationchart';

// // import { NgxChartsModule } from '@swimlane/ngx-charts';
// import { ToastModule } from 'ng2-toastr';
// import { ToastOptions } from 'ng2-toastr';
// import { AgGridModule } from 'ag-grid-angular';
// import { NgProgressModule, NgProgressBrowserXhr, NgProgressInterceptor } from 'ngx-progressbar';
// import { ContextMenuModule } from 'ngx-contextmenu';
// import { CustomOption } from './imports/_utilities/toast-option';

// // App Services
// import { UserService } from './users/shared/user.service';
// import { CoderQueueService } from './home/main_pages/coder-queue/coder-queue.service';
// import { HeaderAuthenticationToken } from './auth/authetication-header';
// // App Component
// import { RouterModule } from '@angular/router';
// import { LoginComponent } from './users/login/login.component';
// import { HeaderComponent } from './home/common-template/header';
// import { FooterComponent } from './home/common-template/footer';
// import { UsersComponent } from './users/users.component';
// import { SignInComponent } from './users/sign-in/sign-in.component';
// import { HomeComponent } from './home/home.component';
// import { DashboardComponent } from './home/main_pages/dashboard/dashboard.component';
// import { ClientSelectionComponent } from './users/client-selection/client-selection.component';
// import { CoderQueueComponent } from './home/main_pages/coder-queue/coder-queue.component';
// import { WorkQueueComponent } from './home/main_pages/_shared-component/work-queue/work-queue.component';
// import { CoderPlatformComponent } from './home/main_pages/coder-platform/coder-platform.component';
// import { IcdInfoComponent } from './home/main_pages/_shared-component/icd-info/icd-info.component';
// import { CptInfoComponent } from './home/main_pages/_shared-component/cpt-info/cpt-info.component';
// import { RelatedVisitComponent } from './home/main_pages/_shared-component/related-visit/related-visit.component';
// import { PateintMedicalReportComponent } from './home/main_pages/_shared-component/pateint-medical-report/pateint-medical-report.component';
// import { PateintInfoComponent } from './home/main_pages/_shared-component/pateint-info/pateint-info.component';
// import { RecordInfoComponent } from './home/main_pages/_shared-component/record-info/record-info.component';
// import { AuditorQueueComponent } from './home/main_pages/auditor-queue/auditor-queue.component';
// import { AuditorPlatformComponent } from './home/main_pages/auditor-platform/auditor-platform.component';
// import { MatDialogOverviewComponent } from './imports/_utilities/mat-dialog-overview/mat-dialog-overview.component';
// import { PrimeDialogComponent } from './imports/_utilities/prime-dialog/prime-dialog.component';
// import { MatDialogCheckDuplicateComponent } from './imports/_utilities/mat-dialog-check-duplicate/mat-dialog-check-duplicate.component';
// import { SmeComponent } from './home/main_pages/sme/sme.component';
// import { BatchUploadSummaryComponent } from './home/main_pages/batch-upload-summary/batch-upload-summary.component';
// import { BatchProcessSummaryComponent } from './home/main_pages/batch-process-summary/batch-process-summary.component';
// import { OscDropdownDirective } from './imports/directive/osc-dropdown.directive';
// import { WorkAllocationComponent } from './home/main_pages/work-allocation/work-allocation.component';
// import { CoderModalChildComponent } from './home/main_pages/_shared-component/coder-modal-child/coder-modal-child.component';
// import { RuleListComponent } from './home/main_pages/work-allocation/rule-list/rule-list.component';
// import { CreateRuleComponent } from './home/main_pages/work-allocation/create-rule/create-rule.component';
// import { MatModalityDdComponent } from './imports/_utilities/mat-modality-dd/mat-modality-dd.component';
// import { MatDropdownSearch } from './imports/_utilities/mat-dropdown-search';
// import { DeleteConfirmDialogComponent } from './imports/_utilities/delete-confirm-dialog';
// import { ErrorHandlingServices } from './services/error-handling.services';
// import { MatUserRulesDialogComponent } from './imports/_utilities/mat-user-rules-dialog/mat-user-rules-dialog.component';
// import { TatReconcillationComponent } from './home/main_pages/reports/tat-reconcillation/tat-reconcillation.component';
// import { QualityAccuracyComponent } from './home/main_pages/reports/quality-accuracy/quality-accuracy.component';
// import { ProductivityComponent } from './home/main_pages/reports/productivity/productivity.component';
// import { TlComponent } from './home/main_pages/team-lead/team-lead.component';
// import { ConflictManagementComponent } from './home/main_pages/team-lead/conflict-management/conflict-management.component';
// import { TLPlatformComponent } from './home/main_pages/team-lead/teamLead-platform/teamLead-platform.component';
// import { AuditAcknowledgeDialogComponent } from './imports/_utilities/mat-dialog-acknowledge/mat-dialog-acknowledge.component';
// import { LearningSystemComponent } from './home/main_pages/sme/learning-system/learning-system.component';
// import { ReportsComponent } from './home/main_pages/reports/reports.component';
// import { InventoryUploadComponent } from './home/main_pages/team-lead/inventory-upload/inventory-upload.component';
// import { AgingReportComponent } from './home/main_pages/reports/aging/aging.component';
// import { DailyStatusReportComponent } from './home/main_pages/reports/daily-status/daily-status.component';
// import { HttpErrorInterceptor } from './http-error-interceptor';
// import { DiscardLogReportComponent } from './home/main_pages/reports/discard-log/discard-log.component';
// import { DuplicatesLogReportComponent } from './home/main_pages/reports/duplicates-log/duplicates-log.component';
// import { TimeoutModalComponent } from './imports/_utilities/timeout-modal/timeout-modal.component';
// import { NgIdleModule } from '@ng-idle/core';
// import { ErrorAnalysisComponent } from './home/main_pages/reports/error-analysis/error-analysis.component';
// import { RAILogReportComponent } from './home/main_pages/reports/RAI Log/rai-log.component';
// import { SMEQueueComponent } from './home/main_pages/sme/sme-queue/sme-queue.component';
// import { SMEPlatformComponent } from './home/main_pages/sme/sme-platform/sme-platform.component';
// import { AdminComponent } from './home/main_pages/admin/admin.component';
// // import { AdminComponent } from './admin/admin.component';
// import { FileUploadComponent } from './imports/_utilities/file-upload/file-upload.component';
// import { MonthlyInvoiceReportComponent } from './home/main_pages/reports/monthly-invoice/monthly-invoice.component';
// import { PlatformService } from './_shared-services/paltform-services/platform-service.service';
// import { RaiComponent } from './home/main_pages/rai/rai.component';
// import { RaiDashboardComponent } from './home/main_pages/rai/rai-dashboard/rai-dashboard.component';
// import { RaiQueueComponent } from './home/main_pages/rai/rai-queue/rai-queue.component';
// import { RaiPlatformComponent } from './home/main_pages/rai/rai-platform/rai-platform.component';
// import { AuditL2Component } from './home/main_pages/audit-l2/audit-l2.component';
// import { UserMappingComponent } from './home/main_pages/user-mapping/user-mapping.component';
// import { ClientMappingComponent } from './home/main_pages/user-mapping/client-mapping/client-mapping.component';
// import { LoginInfoComponent } from './home/main_pages/user-mapping/login-info/login-info.component';
// import { ProfileMappingComponent } from './home/main_pages/user-mapping/profile-mapping/profile-mapping.component';
// import { TeamMappingComponent } from './home/main_pages/user-mapping/team-mapping/team-mapping.component';
// import { AgGridComponent } from './imports/_utilities/ag-grid/ag-grid.component';
// import { IsAgreeCheckboxComponent } from './imports/_utilities/mat-dialog-acknowledge/isAgreeCheckbox';
// import { MatModalityDd1Component } from './imports/_utilities/mat-modality-dd1/mat-modality-dd1.component';
// import { UserMappingService } from './_shared-services/user-mapping/user-mapping.service';
// import { MatLocationDdComponent } from './imports/_utilities/mat-location-dd/mat-location-dd.component';
// import { MatDropdownSearchString } from './imports/_utilities/mat-dropdown-search-string';
// import { MaterialFileInputModule } from 'ngx-material-file-input';
// import { AuditL2PlatformComponent } from './home/main_pages/audit-l2/audit-l2-platform/audit-l2-platform.component';

// import { MatSearchDdComponent } from './imports/_utilities/mat-search-dd/mat-search-dd.component';
// import { MipsDialogComponent } from './imports/_utilities/mips-dialog/mips-dialog.component';
// import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
// import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
// import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
// import { ManagerDashboardComponent } from './home/main_pages/manager-dashboard/manager-dashboard.component';
// import { OmgCliDashboardComponent } from './home/main_pages/manager-dashboard/omg-cli-dashboard/omg-cli-dashboard.component';
// import { ManagerDashboardService } from './home/main_pages/manager-dashboard/manager-dashboard.service';
// import { RaiReportsComponent } from './home/main_pages/reports/rai-reports/rai-reports.component';
// import { PlatformOnloadCheckComponent } from './imports/_utilities/platform-onload-check/platform-onload-check.component';
// import { MatDialogFeedbackComponent } from './imports/_utilities/mat-dialog-feedback/mat-dialog-feedback.component';
// import { ActionDDComponent } from './imports/_utilities/platform-onload-check/action-dd.component';
// import { RouterTestingModule } from '@angular/router/testing';
// import { PageNotFoundComponent } from './users/page-not-found/page-not-found.component';

// describe('AppComponent', () => {
//   let component: AppComponent;
//   let fixture: ComponentFixture<AppComponent>;
//   let originalTimeout;
//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//         declarations: [
//             AppComponent,
//             // LoginComponent,
//             HeaderComponent,
//             FooterComponent,
//             UsersComponent,
//             TimeoutModalComponent,
//             SignInComponent,
//             HomeComponent,
//             DashboardComponent,
//             // ClientSelectionComponent,
//             PlatformOnloadCheckComponent,
//             CoderQueueComponent,
//             MatDialogOverviewComponent,
//             MatUserRulesDialogComponent,
//             PrimeDialogComponent,
//             MatDialogCheckDuplicateComponent,
//             DeleteConfirmDialogComponent,
//             WorkQueueComponent,
//             CoderPlatformComponent,
//             IcdInfoComponent,
//             CptInfoComponent,
//             RelatedVisitComponent,
//             PateintMedicalReportComponent,
//             PateintInfoComponent,
//             RecordInfoComponent,
//             AuditorQueueComponent,
//             AuditorPlatformComponent,
//             SmeComponent,
//             LearningSystemComponent,
//             HighlightTextDirective,
//             MatDialogDraggableTitleDirective,
//             HighlightSearch,
//             ReplaceLineBreaksPipe,
//             ResponsiveColsDirective,
//             BatchUploadSummaryComponent,
//             BatchProcessSummaryComponent,
//             BatchCheckboxRendererComponent,
//             AgGridCellCheckboxRendererComponent,
//             CellDeleteBtnRendererComponent,
//             OscDropdownDirective,
//             MatDialogFeedbackComponent,
//             MatFacilityDdComponent,
//             MatSearchDdComponent,
//             MatLocationDdComponent,
//             AgGridComponent,
//             MatModalityDdComponent,
//             MatModalityDd1Component,
//             WorkAllocationComponent,
//             RuleListComponent,
//             CreateRuleComponent,
//             CoderModalChildComponent,
//             TLPlatformComponent,
//             TatReconcillationComponent,
//             QualityAccuracyComponent,
//             ProductivityComponent,
//             TlComponent,
//             ConflictManagementComponent,
//             AuditAcknowledgeDialogComponent,
//             ReportsComponent,
//             InventoryUploadComponent,
//             AgingReportComponent,
//             DailyStatusReportComponent,
//             DiscardLogReportComponent,
//             DuplicatesLogReportComponent,
//             ErrorAnalysisComponent,
//             RAILogReportComponent,
//             SMEQueueComponent,
//             SMEPlatformComponent,
//             AdminComponent,
//             FileUploadComponent,
//             MonthlyInvoiceReportComponent,
//             RaiComponent,
//             RaiDashboardComponent,
//             RaiQueueComponent,
//             RaiPlatformComponent,
//             AuditL2Component,
//             UserMappingComponent,
//             TeamMappingComponent,
//             ProfileMappingComponent,
//             LoginInfoComponent,
//             ClientMappingComponent,
//             IsAgreeCheckboxComponent,
//             ActionDDComponent,
//             AuditL2PlatformComponent,
//             ManagerDashboardComponent,
//             OmgCliDashboardComponent,
//             RaiReportsComponent,
//             MatDynamicDdComponent,
//             UsrMappingComponent,
//             PageNotFoundComponent
//         ],
//         imports: [
//             MatButtonModule,
//             MatIconModule,
//             MatInputModule,
//             MatFormFieldModule,
//             RouterTestingModule,
//             FormsModule,
//             HttpModule,
//             HttpClientModule,
//             SidebarModule.forRoot(),
//             RouterModule.forRoot(
//                 appRoutes,
//                 {
//                     useHash: true
//                 }
//             ),
//             ToastModule.forRoot(),
//             AgGridModule.withComponents([]),
//             ContextMenuModule.forRoot(),
//             BrowserAnimationsModule,
//             NoopAnimationsModule,
//             FlexLayoutModule,
//             MaterialModule,
//             ChartModule,
//             PasswordModule,
//             InputTextModule,
//             PanelModule,
//             DialogModule,
//             ReactiveFormsModule,
//             NgProgressModule,
//             OrganizationChartModule,
//             NgIdleModule.forRoot(),
//             CommonModule,
//             MaterialFileInputModule,
//             PerfectScrollbarModule,
//         ],
//         schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
//     jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
//     fixture = TestBed.createComponent(AppComponent);
//     component = fixture.componentInstance;
//   });

//   afterEach(()=>{
//     jasmine.DEFAULT_TIMEOUT_INTERVAL = originalTimeout;
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
//   it(`should have title as'OSCAR'`, () => {
//     expect(component.title).toBe('OSCAR');
//   });

// });
