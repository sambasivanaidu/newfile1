import { Injectable } from '@angular/core';
import {
  HttpEvent,
  HttpInterceptor,
  HttpHandler,
  HttpRequest,
  HttpResponse,
  HttpErrorResponse
} from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/empty';
import 'rxjs/add/operator/retry'; // don't forget the imports
import { ToastsManager } from 'ng2-toastr';
import {
  MatDialog,
  MatDialogRef
} from '@angular/material';
import { environment } from '../environments/environment';
import { NgProgress } from '../../node_modules/ngx-progressbar';
import { MatMessageDialogComponent } from './imports/_utilities/mat-message-dialog/mat-message-dialog.component';
import { tap, catchError } from 'rxjs/operators';
import * as messageData from 'assets/message.json';
@Injectable()
export class HttpErrorInterceptor implements HttpInterceptor {
  public storage: Storage = environment.storage;
  public alert = true;
  fileNameDialogRef: MatDialogRef<MatMessageDialogComponent>;
  private messages: any = messageData;
  constructor(
    public toaster: ToastsManager,
    private ngProgress: NgProgress,
    private dialog: MatDialog
  ) {}

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    let clonedrequest = request;
    if (this.storage.getItem('Token') != null) {
      clonedrequest = request.clone({
        headers: request.headers.set(
          'Authorization',
          'Bearer ' + this.storage.getItem('Token')
        )
      });
    }

    return next.handle(clonedrequest).pipe(
      tap((event: HttpEvent<any>) => {
        if (event instanceof HttpResponse) {
          if (event.status === 204){
            if (!event.url.includes('chartinformation/searchchartinformation') ){
              if (event.url.includes('usermaster/userId')) {
                return;
              } else {
                throw new Error(JSON.stringify(event.status));
              }
            } else {
              this.toaster.info('Data not found!');
              // throw new Error(JSON.stringify(event.status));
            }
          } else if (event.status === 200 && event.body.apierror) {
            this.toaster.info(event.body.apierror.message);
            throw new Error(JSON.stringify(event.status));
          }
        }
      }),
      catchError((err: HttpErrorResponse) => {
       if (err.message === '204') {
          this.toaster.info('Data not found!');
        } else if (err.status === 401) {
          this.openAddFileDialog();
        }
        else if (err.message === '200') {
          console.log("Old api error handling implementaion. Ignore this.");
        } else {
          if (
            this.alert &&
            err.error.error &&
            err.error.error === 'invalid_token'
          ) {
            this.alert = false;
            this.openAddFileDialog();
            return;
          } else {
            if (err.error.apierror) {
              if (err.error.apierror.message.match(/cache is empty/g)) {
                sessionStorage.clear();
                window.location.reload();
              } else{
                this.toaster.info(err.error.apierror.message);
              }
            } else {
              this.toaster.error(err.error.error);
            }
          }
        }
        this.ngProgress.done();
        return Observable.empty<HttpEvent<any>>();
      })
    );
  }

  openAddFileDialog() {
    const param = {
      displayString: 'User already logged in. Click OK to continue.',
      title: 'Logout'
    };
    this.fileNameDialogRef = this.dialog.open(MatMessageDialogComponent, {
      hasBackdrop: true,
      disableClose: true,
      width: '20%',
      data: param
    });

    this.fileNameDialogRef.afterClosed().subscribe(result => {
      sessionStorage.clear();
      location.reload();
    });
  }
}
