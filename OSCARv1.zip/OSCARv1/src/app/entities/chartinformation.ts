export class ChartInformation {
  private uniqueId: string;
  private auditorComments: string;
  private chartStatus: string;
  private currentTime: number;
  private updatedBy: string;
  private updatedOn: number;
  private auditorConflict: boolean;
  private modality: string;
  private addToLearning: boolean;

  constructor(
    uniqueId: string,
    currentTime: number,
    chartStatus: string,
    auditorComments: string,
    auditorConflict: boolean,
    updatedBy: string,
    modality: string,
    addToLearning: boolean
  ) {
    this.uniqueId = uniqueId;
    this.currentTime = currentTime;
    this.chartStatus = chartStatus;
    this.auditorComments = auditorComments;
    this.auditorConflict = auditorConflict;
    this.modality = modality;
    this.updatedBy = updatedBy;
    this.updatedOn = currentTime;
    this.addToLearning = addToLearning;
  }
}
