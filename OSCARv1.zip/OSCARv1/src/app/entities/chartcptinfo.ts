class ChartCPTInfo {
    private id: number;
    private uniqueId: string;
    private aapcDescription: string;
    private accessionNo: string;
    private codingRole: string;
    private cptCode: string;
    private cptDescription: string;
    private dxRef: string;
    private modifier: string;
    private units: string;
    private approved: boolean = false;
    private isDiscarded: null;
    private addToLearningSystem: boolean = false;
    private approvedBy: null;
    private approvedOn: null;
    private modifiedBy: null;
    private modifiedOn: null;
    private isActive: boolean = true;
    private createdBy: string;
    private createdOn: string;

    constructor
        (
            id: number,
            uniqueId: string,
            aapcDescription: string,
            accessionNo: string,
            codingRol: string,
            cptCode: string,
            cptDescription: string,
            dxRef: string,
            modifier: string,
            units: string
        ) {
        this.id = id;
        this.uniqueId = uniqueId;
        this.aapcDescription = aapcDescription;
        this.accessionNo = accessionNo;
        this.codingRole = codingRol;
        this.cptCode = cptCode;
        this.cptDescription = cptDescription;
        this.dxRef = dxRef;
        this.modifier = modifier;
        this.units = units;
    }
}

enum codingRole {
    coder = 'coder',
    auditor = 'auditor',
    tl = 'TL',
}
