interface PropType {
    id: number;
    value: string;
}

export {
    PropType
};
