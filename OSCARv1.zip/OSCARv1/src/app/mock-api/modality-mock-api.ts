export class RowDataCoderCPT {
    id: number;
    predictCptCode: string;
    modifier: string;
    units: string;
    dxRef: string;
    accession: string;
    aapcCptDescription: string;
    cptChart: string;
}

export class RowDataCoderICD {
    id: number;
    predictIcdCode: string;
    aapcIcdDescription: string;
    accession: string;
    icdChart: string;
}
