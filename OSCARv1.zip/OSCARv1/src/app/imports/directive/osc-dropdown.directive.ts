import { Directive } from '@angular/core';

@Directive({
  selector: '[appOscDropdown]'
})
export class OscDropdownDirective {

  constructor() { }

}
