// import { OscDropdownDirective } from './osc-dropdown.directive';

// describe('OscDropdownDirective', () => {
//   it('should create an instance', () => {
//     const directive = new OscDropdownDirective();
//     expect(directive).toBeTruthy();
//   });
// });
