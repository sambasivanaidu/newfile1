// import { MatDialogDraggableTitleDirective } from './mat-dialog-draggable-title.directive';

// describe('MatDialogDraggableTitleDirective', () => {
//   it('should create an instance', () => {
//     // const directive = new MatDialogDraggableTitleDirective();
//     // expect(directive).toBeTruthy();
//   });
// });
