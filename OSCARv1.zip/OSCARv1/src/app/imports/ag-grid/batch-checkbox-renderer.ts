import { Component, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';

@Component({
    selector: 'checkbox-cell',
    template: `<mat-checkbox [disabled]='checkboxIsDisable' (ngModelChange)='onChange($event)'></mat-checkbox>`
})

export class BatchCheckboxRendererComponent implements ICellRendererAngularComp {

    @ViewChild('.checkbox') checkbox: ElementRef;
    public params: any;
    checkboxIsDisable = true;
    agInit(params: any): void {
        this.params = params;
    }

    constructor() { }

    refresh(): boolean {
        return false;
    }

    public onChange(event: any) {
        this.params.data[this.params.colDef.field] = event.currentTarget.checked;
    }
}
