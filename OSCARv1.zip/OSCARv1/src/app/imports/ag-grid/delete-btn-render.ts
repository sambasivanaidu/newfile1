import { Component, AfterViewInit, ViewChild, ElementRef, style } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { MatDialog } from '@angular/material';
import { DeleteConfirmDialogComponent } from '../_utilities/delete-confirm-dialog';
import { ActivatedRoute } from '@angular/router';
import { environment } from '../../../environments/environment';

@Component({
    selector: 'cell-delete-btn',
    template: ` <button mat-raised-button class='bg-danger text-white cell-btn' (click)='deleteRow()' [disabled]='isDisabled'>
                    <mat-icon class='del-icon btn-color'>clear</mat-icon>
                </button>
            `,
    styles: [`.cell-btn {
            line-height: 2;
            margin-left: 0;
            padding: 0;
            height: 0%;
            min-width: 100%;
        }
        .btn-color {
            color: #f73e3e;
            font-weight: bold;
            font-size: 15px;
        }`]
})
export class CellDeleteBtnRendererComponent implements ICellRendererAngularComp {
    public params: any;
    public uniqueID: string;
    public isDisabled = false;
    public storage = environment.storage;
    // <mat-icon class="del-icon btn-color">delete_forever</mat-icon>

    constructor(public dialog: MatDialog, private activeRoute: ActivatedRoute, ) { }

    agInit(params: any): void {
        this.params = params;
        this.uniqueID = this.activeRoute.snapshot.params['uniqueID'];
        this.checkAuditAck();
    }

    refresh(): boolean {
        return false;
    }

    public deleteRow() {
        this.clearSelection();
        const displayModel = this.params.node.gridApi.getModel();
        const rowNode = displayModel.rowsToDisplay[this.params.node.rowIndex];
        const context = this.params.context.componentParent;
        this.openConfirmDialog(context, rowNode);
    }

    clearSelection() {
        const selectedText = document.querySelectorAll(".highlighted, .ht, .htb");
        let parent;
        for (let i = 0; i < selectedText.length; i++) {
          parent = selectedText[i].parentNode;
          if (selectedText[i].firstChild) {
            parent.insertBefore(selectedText[i].firstChild, selectedText[i]);
          }
          parent.removeChild(selectedText[i]);
        }
      }

    openConfirmDialog(context, node) {
        const rowNode = node;
        const param = context;

        const dialogRef = this.dialog.open(DeleteConfirmDialogComponent, {
            hasBackdrop: false,
            width: '350px',
            data: 'delete'
        });

        dialogRef.afterClosed().subscribe(result => {
            if (result === 'delete') {
                param.deleteRowNode(rowNode);
            } else {
                param.refreshCellData();
            }
        });
    }

    public checkAuditAck() {
        const auditAck = this.storage.getItem('osc-aud-ack');
        if (auditAck === 'true') {
            this.isDisabled = true;
        }
    }
}
