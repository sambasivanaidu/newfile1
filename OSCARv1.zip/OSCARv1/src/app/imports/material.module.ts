import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
    MatAutocompleteModule,
    MatButtonModule, MatCardModule, MatCheckboxModule, MatChipsModule, MatDatepickerModule, MatDialogModule,
    MatExpansionModule,
    MatFormFieldModule, MatGridListModule,
    MatIconModule,
    MatInputModule, MatListModule, MatMenuModule, MatNativeDateModule, MatProgressBarModule, MatSelectModule,
    MatSidenavModule,
    MatSnackBarModule,
    MatStepperModule,
    MatTabsModule,
    MatRippleModule,
    MatRadioModule,
    MatToolbarModule, MatTooltipModule
} from '@angular/material';
// import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTableModule } from '@angular/material/table';
// import { MatLocationDdComponent } from './_utilities/mat-location-dd/mat-location-dd.component';
// import { MipsDialogComponent } from './_utilities/mips-dialog/mips-dialog.component';
// import { MatSearchDdComponent } from './_utilities/mat-search-dd/mat-search-dd.component';
import { MatSliderModule} from '@angular/material/slider';
// import { AgGridComponent } from './_utilities/ag-grid/ag-grid.component';
import { MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { MaterialFileInputModule } from 'ngx-material-file-input';
@NgModule({
    imports: [
        CommonModule,
        MatChipsModule,
        MatFormFieldModule,
        MatInputModule,
        MatDialogModule,
        MatButtonModule,
        MatTabsModule,
        MatCardModule,
        MatTableModule,
        MatIconModule,
        MatSidenavModule,
        MatToolbarModule,
        MatListModule,
        MatExpansionModule,
        MatSnackBarModule,
        MatProgressBarModule,
        MatCheckboxModule,
        MatTooltipModule,
        MatGridListModule,
        MatStepperModule,
        MatAutocompleteModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatSelectModule,
        // NgxMatSelectSearchModule,
        MatRippleModule,
        MatRadioModule,
        MatSlideToggleModule,
        MatProgressSpinnerModule,
        MatSliderModule,
        MatMenuModule,
        MaterialFileInputModule
    ],
    exports: [
        MatChipsModule,
        MatFormFieldModule,
        MatInputModule,
        MatDialogModule,
        MatButtonModule,
        MatCardModule,
        MatTableModule,
        MatIconModule,
        MatSliderModule,
        MatTabsModule,
        MatSidenavModule,
        MatToolbarModule,
        MatMenuModule,
        MatListModule,
        MatExpansionModule,
        MatSnackBarModule,
        MatProgressBarModule,
        MatCheckboxModule,
        MatTooltipModule,
        MatGridListModule,
        MatStepperModule,
        MatAutocompleteModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatSelectModule,
        // NgxMatSelectSearchModule,
        MatRippleModule,
        MatRadioModule,
        MatSlideToggleModule,
        MatProgressSpinnerModule,
        MaterialFileInputModule
    ],
    declarations: []
})
export class MaterialModule {
    // static forRoot() {
    //     return {
    //       ngModule: MaterialModule
    //     //   providers: []
    //     }
    //   }
}
