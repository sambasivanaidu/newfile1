import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'SpilitFilePath' })

export class SpilitFilePathPipe implements PipeTransform {
  transform(value: string): string {
    if (value) {
      const fileName = value.split('/RAI/');
      return fileName[1];
    }
  }
}
