import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'highlight'
})

export class HighlightSearch implements PipeTransform {

    transform(value: any, args: any): any {
        const text = '';
        if (value && args) {
            // text = value;
            // let newText;
            // let finalText = '';
            // let temp = '';
            // const search = args;
            // for (let i = 0; i < search.length; i++) {

            //     const s = search[i].text.split(" ");
            //     s.forEach(element => {
            //         const html = '<span class="highlightText">$&</span>';
            //         const reg = new RegExp('\\b' + element + '\\b', 'i');
            //         if (i % 2 === 1) {
            //             newText = text.split(temp);
            //             if (newText.length < 2) {
            //                 text = text.replace(reg, html);
            //             } else {
            //                 finalText = newText[1].replace(reg, html);
            //                 text = newText[0] + temp + finalText;
            //             }
            //         } else {
            //             temp = '<span class="highlightText">' + element + '</span>';
            //             text = text.replace(reg, html);
            //         }
            //     });

            return args;

        } else {
            return value;
        }

    }
}
