import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'replaceLineBreaks' })

export class ReplaceLineBreaksPipe implements PipeTransform {
  transform(value: string): string {
    let str;
    if (value) {
      str = value.replace(/\\.br\\\\.br\\/gi, '\n\n');
      return str.replace(/\\.br\\/gi, '\n');
    }
  }
}
