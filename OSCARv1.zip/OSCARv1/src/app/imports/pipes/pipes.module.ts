import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HighlightSearch } from './highlights.pipe';
import { ReplaceLineBreaksPipe } from './replace-line-breaks.pipe';
import { SpilitFilePathPipe } from './splitFilePath.pipe';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    HighlightSearch,
    ReplaceLineBreaksPipe,
    SpilitFilePathPipe
  ],
  exports: [
    HighlightSearch,
    ReplaceLineBreaksPipe,
    SpilitFilePathPipe
  ]
})
export class PipesModule { }
