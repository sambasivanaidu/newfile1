// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { FormsModule } from '@angular/forms';
// import { MaterialModule } from '../../material.module';
// import { ToastModule, ToastsManager, ToastOptions } from 'ng2-toastr';
// import { RouterModule, Router } from '@angular/router';
// import { ErrorHandlingServices } from '../../../services/error-handling.services';
// import { ViewContainerRef, ErrorHandler } from '@angular/core';
// import { MatModalService } from '../mat-dialog-overview/mat-modal.service';
// import { MatDialogRef } from '@angular/material';

// import { RouterTestingModule } from '@angular/router/testing';
// import { HttpModule } from '@angular/http';
// import { PlatformService } from '../../../_shared-services/paltform-services/platform-service.service';
// import { HttpClient, HttpHandler } from '@angular/common/http';
// import { HeaderAuthenticationToken } from '../../../auth/authetication-header';

// import { MatDialogFeedbackComponent } from './mat-dialog-feedback.component';

// describe('MatDialogFeedbackComponent', () => {
//   let component: MatDialogFeedbackComponent;
//   let fixture: ComponentFixture<MatDialogFeedbackComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       imports: [
//         FormsModule,
//         MaterialModule,
//         ToastModule,
//         HttpModule,

//         RouterTestingModule
//         // ErrorHandler,
//         // ViewContainerRef,
//         // MatModalService,
//         // MatDialogRef
//       ],
//       declarations: [MatDialogFeedbackComponent],
//       providers: [
//         ToastsManager,
//         ToastOptions,
//         HeaderAuthenticationToken,
//         PlatformService,
//         HttpClient,
//         HttpHandler
//       ]
//     }).compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(MatDialogFeedbackComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
