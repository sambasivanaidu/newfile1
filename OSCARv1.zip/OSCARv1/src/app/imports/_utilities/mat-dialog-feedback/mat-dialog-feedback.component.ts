import { Component, OnInit, Inject, ViewContainerRef } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ToastsManager } from 'ng2-toastr';
import { ErrorHandlingServices } from '../../../services/error-handling.services';
import { environment } from '../../../../environments/environment';
import { MatModalService } from '../mat-dialog-overview/mat-modal.service';
import { MatDialogOverviewComponent } from '../mat-dialog-overview/mat-dialog-overview.component';
import { Router, ActivatedRoute } from '@angular/router';
import { DateFormatter } from '../date-formatter';
@Component({
  selector: 'app-mat-dialog-feedback',
  templateUrl: './mat-dialog-feedback.component.html',
  styleUrls: ['./mat-dialog-feedback.component.scss'],
  providers: [
    MatModalService,
    // ErrorHandlingServices,
    DateFormatter
  ]
})
export class MatDialogFeedbackComponent implements OnInit {
  public uniqueID = '';
  public userName;
  public storage: Storage = environment.storage;
  public cptInfo: any;
  public icdInfo: any;
  comments: string = '';
  private conflicts;
  private chartStatus;
  private modality;
  private auditorAllocatedTo;
  private isRetroed;
  constructor(
    private _router: Router,
    public toaster: ToastsManager,
    private errorService: ErrorHandlingServices,
    // private viewContainerRef: ViewContainerRef,
    private _matModalService: MatModalService,
    public dialogRef: MatDialogRef<MatDialogOverviewComponent>,
    private dateFormatter: DateFormatter,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    // this.toaster.setRootViewContainerRef(viewContainerRef);
    this.userName = this.storage.getItem('UserName');
  }

  ngOnInit() {
    this.uniqueID = this.data.UniqueID;
    this.cptInfo = this.data.cptInfo;
    this.icdInfo = this.data.icdInfo;
    this.comments = '';
    this.conflicts = this.data.conflicts;
    this.chartStatus = 'retroed';
    this.modality = this.data.modality;
    this.isRetroed = this.data.isRetroed;
    this.auditorAllocatedTo = this.data.auditorAllocatedTo;
  }

  saveComments() {
    const clientObj = this.storage.getItem('clientSelectionObject');
    const param: any = {
      auditorComments: this.comments,
      auditorConflict: true,
      chartStatus: 'retroed',
      modality: this.modality,
      uniqueId: this.uniqueID,
      updatedBy: this.userName,
      updatedOn: Date.now(),
      auditorAllocatedTo: this.auditorAllocatedTo,
      isRetroed: this.isRetroed
    };

    this._matModalService.savePlatFormCommentsForL2Auditor(param).subscribe(
      responseList => {
        if (responseList) {
          this.dialogRef.close(true);
        }
      }
    );
  }

  onNoClick(param): void {
    this.dialogRef.close(param);
  }
}
