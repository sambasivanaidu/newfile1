import { ToastOptions } from 'ng2-toastr';
import { Component } from '@angular/core';

@Component({
  selector: "app-home",
  templateUrl: "./toast-option.html"
})

export class CustomOption extends ToastOptions {
  animate = 'flyRight';
  newestOnTop = false;
  showCloseButton = true;
  positionClass = 'toast-top-right';
}
