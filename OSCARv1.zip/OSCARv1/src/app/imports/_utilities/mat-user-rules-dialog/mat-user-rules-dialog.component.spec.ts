// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { MatUserRulesDialogComponent } from './mat-user-rules-dialog.component';

// describe('MatUserRulesDialogComponent', () => {
//   let component: MatUserRulesDialogComponent;
//   let fixture: ComponentFixture<MatUserRulesDialogComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [MatUserRulesDialogComponent]
//     })
//       .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(MatUserRulesDialogComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
