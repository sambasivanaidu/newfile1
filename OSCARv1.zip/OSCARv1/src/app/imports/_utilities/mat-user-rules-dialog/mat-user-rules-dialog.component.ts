import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { GridOptions } from 'ag-grid';

@Component({
  selector: 'app-mat-user-rules-dialog',
  templateUrl: './mat-user-rules-dialog.component.html',
  styleUrls: ['./mat-user-rules-dialog.component.scss']
})
export class MatUserRulesDialogComponent implements OnInit {

  rulesRowData;
  rulesGridoptions;
  rulesGridReady;
  rulesComponents;

  usersRowData;
  usersGridoptions;
  usersGridReady;
  usersComponents;

  public expanded: boolean = true;
  public defaultColDef;
  public gridApi: any;
  public gridColumnApi: any;
  public rowSelection;

   status;
   ruleDesc;
   ruleId;

  constructor(
    public dialogRef: MatDialogRef<MatUserRulesDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { }

  ngOnInit() {
    this.rulesGridInitialization();
    this.usersGridInitialization();
    this.usersRowData = this.data.UserList;
    this.rulesRowData = this.data.RuleList;
    this.status = this.data.Status;
    this.ruleDesc = this.data.RuleDesc;
    this.ruleId = this.data.RuleId;
  }

   rulesGridInitialization(): void {
    this.rulesGridoptions = <GridOptions>{
      context: {
        componentParent: this
      },
    };

    this.rulesGridoptions.columnDefs =
      [
        {
          headerName: 'Rule',
          field: 'rule'
        },
        {
          headerName: 'Priority',
          field: 'priority'
        },
        {
          headerName: 'Expressions',
          field: 'expression',
          tooltipField: 'expression'
        },
      ];
    this.rulesRowData = [];
    this.defaultColDef = {};
    this.rowSelection = 'single';
  }

   usersGridInitialization(): void {
    this.usersGridoptions = <GridOptions>{
      context: {
        componentParent: this
      },
    };

    this.usersGridoptions.columnDefs =
      [
        {
          headerName: 'Users',
          field: 'user'
        },
        {
          headerName: 'Sampling (%)',
          field: 'samplingPercentage'
        },
      ];
    this.usersRowData = [];
    this.defaultColDef = {};
    this.rowSelection = 'single';
  }

  gridReady(params): void {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }
}
