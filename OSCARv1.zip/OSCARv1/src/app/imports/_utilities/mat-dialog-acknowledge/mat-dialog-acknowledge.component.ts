import { uniqueId } from 'lodash-es';
import { element } from 'protractor';
import { Component, OnInit, Inject, ViewContainerRef } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormControl } from '@angular/forms';
import { AuditAcknowledgeService } from './mat-dialog-acknowledge.service';
import { Router } from '@angular/router';
import * as CryptoJS from 'crypto-js';
import { environment } from '../../../../environments/environment';
import { IsAgreeCheckboxComponent } from './isAgreeCheckbox';
import { GridOptions } from 'ag-grid';
import { ToastsManager } from 'ng2-toastr';
import { ErrorHandlingServices } from '../../../services/error-handling.services';
export interface GridColumnParam {
  cellRendererParams?: any;
  headerName?: string;
  field?: string;
  tooltipField?: string;
  cellRenderer?: string;
  valueGetter?: string;
  cellClass?: string;
  cellEditor?: string;
  showRowGroup?: boolean;
  editable?: boolean;
  rowDrag?: boolean;
  hide?: boolean;
  lockPosition?: boolean;
  suppressNavigable?: boolean;
  width?: number;
  rowGroup?: boolean;
}

@Component({
  selector: 'app-audit-ack',
  templateUrl: './mat-dialog-acknowledge.component.html',
  providers: [AuditAcknowledgeService] // , ErrorHandlingServices]
})
export class AuditAcknowledgeDialogComponent implements OnInit {
  public agreed: boolean = false;
  public rootCauseControl: FormControl = new FormControl();
  public correctiveActionControl: FormControl = new FormControl();
  public preventiveActionControl: FormControl = new FormControl();
  public commentsControl: FormControl = new FormControl();
  public uniqueID: string;
  public userName: string;
  public closeModal;
  public title: string = '';
  public status: string;
  public storage: Storage = environment.storage;
  public columnParam: GridColumnParam[];

  public gridOptions: GridOptions;
  public frameworkComponents;
  public rowData;
  public icdData;
  public cptData;
  public autoGroupColumnDef;
  public rowSelection;
  public gridApi;
  public gridColumnApi;
  public getNodeChildDetails;
  public getRowNodeId;
  public updateAcknowledge: boolean = true;
  // public l2Auditor = false;
  public codingRole: string;
  enableAuditor: any;
  acknowledged: any;
  acknowledgedOn: any;
  public remarks;
  public isProcessed;
  public hideAckAuditor;
  public auditorConflict;
  public l2auditorConflict;
  public errorFeedBack;
  public singleClickEdit = true;
  public isDiscarded = false;
  constructor(
    public dialogRef: MatDialogRef<AuditAcknowledgeDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public auditAcknowledgeService: AuditAcknowledgeService,
    private router: Router,
    public _toastr: ToastsManager,
    // private vcr: ViewContainerRef,
    private errorService: ErrorHandlingServices
  ) {
    // this._toastr.setRootViewContainerRef(vcr);
    this.userName = this.storage.getItem('UserName');
  }

  ngOnInit() {
    this.uniqueID = this.data.uniqueId;
    this.codingRole = this.data.codingRole;
    this.title = this.data.reason;
    this.status = this.data.status;
    this.icdData = this.data.icdData;
    this.cptData = this.data.cptData;
    // this.l2Auditor =
    //   this.icdData && this.icdData.length > 0
    //     ? this.icdData[0].l2Auditor
    //     : this.cptData && this.cptData.length > 0
    //     ? this.cptData[0].l2Auditor
    //     : false;

    // this.enableAuditor = this.data.l2auditor;
    this.acknowledged = this.codingRole + 'Acknowledged';
    this.acknowledgedOn = this.codingRole + 'AcknowledgeOn';
    if (this.codingRole === 'auditor') {
      this.updateAcknowledge = true;
    }
    this.remarks = this.data.remarks;
    this.isProcessed = this.data.isProcessed;
    this.hideAckAuditor = this.data.hideAckAuditor;
    this.auditorConflict = this.data.auditorConflict;
    this.l2auditorConflict = this.data.l2auditorConflict;
    this.errorFeedBack = this.data.errorFeedBack;
    this.GridInit();
    if (this.errorFeedBack) {
      this.getfeedBackRowData();
    } else {
      this.isDiscarded = this.data.isDiscarded; // new funtion for discard getRowDataDiscarded() is added because in request the discarded rows will not contain parent id to map against each value.
      if (this.isDiscarded) {
        this.getRowDataDiscarded();
      } else {
        this.getRowDataAcknowledge(); // new funtion with revised codes of getRowData1().
      }
    }
  }

  GridInit() {
    this.gridOptions = <GridOptions>{
      context: {
        componentParent: this
      }
    };
    this.gridOptions.columnDefs = this.errorFeedBack
      ? this.getColumnDefinitionTlFeedBackError()
      : this.getColumnDefinitionAcknowledgement();
    this.frameworkComponents = {
      agreeDisagree: IsAgreeCheckboxComponent
    };

    this.rowData = [];
    this.rowSelection = 'multiple';
  }

  getColumnDefinition() {
    return [
      {
        headerName: '#',
        field: 'count',
        hide: true
      },

      {
        headerName: '&nbsp;',
        field: 'type',
        cellRenderer: 'agGroupCellRenderer'
      },
      {
        headerName: '&nbsp;',
        field: 'id',
        hide: true
      },
      {
        headerName: 'Is Agree',
        field: 'isAgree',
        cellRenderer: 'agreeDisagree',
        editable: false
      },
      {
        headerName: 'Field Name',
        field: 'fieldName',
        editable: false
      },
      {
        headerName: 'Coder',
        field: 'coder',
        editable: false,
        hide: this.codingRole !== 'coder' ? true : false
        // this.enableAuditor,
      },
      {
        headerName: 'Auditor',
        field: 'coder',
        editable: false,
        hide: this.codingRole === 'auditor' ? false : true
        // (this.codingRole == 'coder' ? this.hideAckAuditor : (!this.auditorConflict && this.l2auditorConflict ? true : false))
      },
      {
        headerName: 'Auditor',
        field: 'auditor',
        editable: false,
        hide: this.codingRole === 'coder' ? this.hideAckAuditor : true
      },
      {
        headerName: 'L2 Auditor',
        field: 'auditor',
        editable: false,
        hide:
          this.codingRole === 'coder'
            ? !this.hideAckAuditor
            : !this.auditorConflict && this.l2auditorConflict
            ? true
            : false
      },
      {
        headerName: 'Corrective Action',
        field: 'correctiveAction',
        editable: params => {
          return params.data.isAgree;
        },
        headerTooltip: 'Corrective Action',
        minWidth: 150
      },
      {
        headerName: 'Preventive Action',
        field: 'preventiveAction',
        editable: params => {
          return params.data.isAgree;
        },

        headerTooltip: 'Preventive Action',
        minWidth: 150
      },
      {
        headerName: 'Root Cause',
        field: 'rootCause',
        editable: params => {
          return params.data.isAgree;
        },
        headerTooltip: 'Root Cause'
      },
      {
        headerName: 'Comments',
        field: 'comments',
        editable: params => {
          return !params.data.isAgree || !this.errorFeedBack;
        }
      }
    ];
  }

  getColumnDefinition1() {
    return [
      {
        headerName: '&nbsp;',
        field: 'uniqueID',
        hide: true
      },
      {
        headerName: 'Is Agree',
        field: 'isAgree',
        cellRenderer: 'agreeDisagree',
        editable: false,
        hide: this.errorFeedBack
      },
      {
        headerName: 'Field Name',
        field: 'fieldName',
        editable: false
      },
      {
        headerName: '&nbsp;',
        field: 'coder_id',
        hide: true
      },
      {
        headerName: 'Coder',
        field: 'coder_value',
        editable: false,
        tooltipField: 'coder_comments',
        hide: this.codingRole !== 'coder' ? true : false,
        cellStyle: function(params) {
          if (params.data.coder_isActive === false) {
            return { color: 'red' };
          } else {
            return null;
          }
        }
      },
      {
        headerName: '&nbsp;',
        field: 'auditor_id',
        hide: true
      },
      {
        headerName: 'Auditor',
        field: 'auditor_value',
        editable: false,
        tooltipField: 'auditor_comments',
        hide:
          this.codingRole === 'coder'
            ? !this.auditorConflict
            : this.codingRole === 'auditor'
            ? false
            : true
      },
      {
        headerName: '&nbsp;',
        field: 'l2auditor_id',
        hide: true
      },
      {
        headerName: 'L2Auditor',
        field: 'l2auditor_value',
        editable: false,
        tooltipField: 'l2auditor_comments',
        hide: !this.l2auditorConflict
      },
      {
        headerName: 'Old Value',
        field: 'oldValue',
        editable: false,
        tooltipField: ''
      },
      {
        headerName: 'New Value',
        field: 'newValue',
        editable: false,
        tooltipField: ''
      },
      {
        headerName: 'Corrective Action',
        field: 'correctiveAction',
        editable: params => {
          return params.data.isAgree;
        },
        headerTooltip: 'Corrective Action',
        minWidth: 150,
        hide: this.errorFeedBack
      },
      {
        headerName: 'Preventive Action',
        field: 'preventiveAction',
        editable: params => {
          return params.data.isAgree;
        },

        headerTooltip: 'Preventive Action',
        minWidth: 150,
        hide: this.errorFeedBack
      },
      {
        headerName: 'Root Cause',
        field: 'rootCause',
        editable: params => {
          return params.data.isAgree;
        },
        headerTooltip: 'Root Cause',
        hide: this.errorFeedBack
      },
      {
        headerName: 'Comments',
        field: 'comments',
        editable: params => {
          return !params.data.isAgree || !this.errorFeedBack;
        }
      }
    ];
  }

  getColumnDefinitionAcknowledgement() {
    return [
      {
        headerName: '&nbsp;',
        field: 'uniqueID',
        hide: true
      },
      {
        headerName: 'Is Agree',
        field: 'isAgree',
        cellRenderer: 'agreeDisagree',
        editable: false
      },
      {
        headerName: 'Field Name',
        field: 'fieldName',
        editable: false
      },
      {
        headerName: '&nbsp;',
        field: 'coder_id',
        hide: true
      },
      {
        headerName:
          this.codingRole === 'coder' ? 'Coder Changes' : 'Auditor Changes', // 'Óld Value'
        field: 'oldValue',
        editable: false,
        tooltipField: 'oldValueComments',
        cellStyle: function(params) {
          if (params.data.oldValueIsActive === false) {
            return { color: 'red' };
          } else {
            return null;
          }
        }
      },
      {
        headerName:
          this.codingRole === 'coder'
            ? this.l2auditorConflict
              ? 'L2 Changes'
              : 'Auditor Changes'
            : 'L2 Changes', // 'New Value',
        field: 'newValue',
        editable: false,
        tooltipField: 'newValueComments'
      },
      {
        headerName: 'Corrective Action',
        field: 'correctiveAction',
        editable: params => {
          return params.data.isAgree;
        },
        cellClassRules: {
          'not-allow-edit': function(params) {
            return !params.data.isAgree;
          },
          'allow-edit': function(params) {
            return params.data.isAgree;
          }
        },
        headerTooltip: 'Corrective Action',
        minWidth: 150
      },
      {
        headerName: 'Preventive Action',
        field: 'preventiveAction',
        editable: params => {
          return params.data.isAgree;
        },
        cellClassRules: {
          'not-allow-edit': function(params) {
            return !params.data.isAgree;
          },
          'allow-edit': function(params) {
            return params.data.isAgree;
          }
        },
        headerTooltip: 'Preventive Action',
        minWidth: 150
      },
      {
        headerName: 'Root Cause',
        field: 'rootCause',
        editable: params => {
          return params.data.isAgree;
        },
        cellClassRules: {
          'not-allow-edit': function(params) {
            return !params.data.isAgree;
          },
          'allow-edit': function(params) {
            return params.data.isAgree;
          }
        },
        headerTooltip: 'Root Cause'
      },
      {
        headerName: 'Comments',
        field: 'comments',
        editable: params => {
          return !params.data.isAgree;
        },
        cellClassRules: {
          'not-allow-edit': function(params) {
            return params.data.isAgree;
          },
          'allow-edit': function(params) {
            return !params.data.isAgree;
          }
        }
      }
    ];
  }

  getColumnDefinitionTlFeedBackError() {
    return [
      {
        headerName: '&nbsp;',
        field: 'uniqueID',
        hide: true
      },
      {
        headerName: 'Field Name',
        field: 'fieldName',
        editable: false
      },
      {
        headerName: 'Old Value',
        field: 'oldValue',
        editable: false,
        tooltipField: 'oldValueComments',
        cellStyle: function(params) {
          if (params.data.oldValueIsActive === false) {
            return { color: 'red' };
          } else {
            return null;
          }
        }
      },
      {
        headerName: 'New Value',
        field: 'newValue',
        editable: false,
        tooltipField: 'newValueComments'
      },
      {
        headerName: 'Comments',
        field: 'comments',
        editable: false
      }
    ];
  }

  getRow(
    coderData,
    auditorData,
    l2AuditorData,
    index,
    type,
    uniqueId,
    fieldName
  ) {
    const data = {
      count: index,
      type: type,
      uniqueID: uniqueId,
      fieldName: fieldName,
      isAgree: false,
      preventiveAction: '',
      correctiveAction: '',
      rootCause: '',
      comments: '',
      coder_id: coderData ? coderData.id : null,
      coder_value: coderData ? coderData.rowValue : null,
      coder_comments: coderData ? coderData.comments : null,
      coder_isActive: coderData ? coderData.isActive : null,
      coder_parentId: coderData ? coderData.parentId : null,
      auditor_id: auditorData ? auditorData.id : null,
      auditor_value: auditorData ? auditorData.rowValue : null,
      auditor_comments: auditorData ? auditorData.comments : null,
      auditor_isActive: auditorData ? auditorData.isActive : null,
      auditor_parentId: auditorData ? auditorData.parentId : null,
      l2auditor_id: l2AuditorData ? l2AuditorData.id : null,
      l2auditor_value: l2AuditorData ? l2AuditorData.rowValue : null,
      l2auditor_comments: l2AuditorData ? l2AuditorData.comments : null,
      l2auditor_isActive: l2AuditorData ? l2AuditorData.isActive : null,
      l2auditor_parentId: l2AuditorData ? l2AuditorData.parentId : null,
      oldValue:
        this.codingRole === 'coder'
          ? coderData
            ? coderData.rowValue
            : null
          : this.codingRole === 'auditor'
          ? auditorData
            ? auditorData.rowValue
            : null
          : null,
      oldValueIsActive:
        this.codingRole === 'coder'
          ? coderData
            ? coderData.isActive
            : null
          : this.codingRole === 'auditor'
          ? auditorData
            ? auditorData.isActive
            : null
          : null,
      oldValueComments:
        this.codingRole === 'coder'
          ? coderData
            ? coderData.comments
            : null
          : this.codingRole === 'auditor'
          ? auditorData
            ? auditorData.comments
            : null
          : null,
      newValue: l2AuditorData
        ? l2AuditorData.rowValue
        : auditorData
        ? auditorData.rowValue
        : null,
      newValueComments: l2AuditorData
        ? l2AuditorData.comments
        : auditorData
        ? auditorData.comments
        : null
    };
    return data;
  }

  getRowDataDiscarded() {
    switch (this.codingRole) {
      case 'coder':
        this.getCoderAcknowledgeDiscardRows();
        break;
      case 'auditor':
        this.getAuditorAcknowledgeDiscardRows();
        break;
    }
  }

  getCoderAcknowledgeDiscardRows() {
    const rows = [];
    let count = 0;
    this.rowData = [];
    if (this.l2auditorConflict) {
      if (this.cptData) {
        if (this.cptData.coder.length === this.cptData.l2Auditor.length) {
          this.cptData.coder.forEach((elementCpt, index) => {
            const data = this.getRow(
              elementCpt,
              null,
              this.cptData.l2Auditor[index],
              count++,
              'CPT',
              this.cptData.uniqueId,
              this.cptData.codeType
            );
            rows.push(data);
          });
        }
      }
      if (this.icdData) {
        if (this.icdData.coder.length === this.icdData.l2Auditor.length) {
          this.icdData.coder.forEach((elementIcd, index) => {
            const data = this.getRow(
              elementIcd,
              null,
              this.icdData.l2Auditor[index],
              count++,
              'ICD',
              this.icdData.uniqueId,
              this.icdData.codeType
            );
            rows.push(data);
          });
        }
      }
    } else if (this.auditorConflict) {
      if (this.cptData) {
        if (this.cptData.coder.length === this.cptData.auditor.length) {
          this.cptData.coder.forEach((elementCpt, index) => {
            const data = this.getRow(
              elementCpt,
              this.cptData.auditor[index],
              null,
              count++,
              'CPT',
              this.cptData.uniqueId,
              this.cptData.codeType
            );
            rows.push(data);
          });
        }
      }
      if (this.icdData) {
        if (this.icdData.coder.length === this.icdData.auditor.length) {
          this.icdData.coder.forEach((elementIcd, index) => {
            const data = this.getRow(
              elementIcd,
              this.icdData.auditor[index],
              null,
              count++,
              'ICD',
              this.icdData.uniqueId,
              this.icdData.codeType
            );
            rows.push(data);
          });
        }
      }
    }
    this.rowData = rows;
  }

  getAuditorAcknowledgeDiscardRows() {
    const rows = [];
    let count = 0;
    this.rowData = [];
    if (this.l2auditorConflict) {
      if (this.cptData) {
        if (this.cptData.auditor.length === this.cptData.l2Auditor.length) {
          this.cptData.auditor.forEach((elementCpt, index) => {
            const data = this.getRow(
              null,
              elementCpt,
              this.cptData.l2Auditor[index],
              count++,
              'CPT',
              this.cptData.uniqueId,
              this.cptData.codeType
            );
            rows.push(data);
          });
        }
      }
      if (this.icdData) {
        if (this.icdData.auditor.length === this.icdData.l2Auditor.length) {
          this.icdData.auditor.forEach((elementIcd, index) => {
            const data = this.getRow(
              null,
              elementIcd,
              this.icdData.l2Auditor[index],
              count++,
              'ICD',
              this.icdData.uniqueId,
              this.icdData.codeType
            );
            rows.push(data);
          });
        }
      }
    }
    this.rowData = rows;
  }

  getRowDataAcknowledge() {
    switch (this.codingRole) {
      case 'coder':
        this.getCoderAcknowledgeRows();
        break;
      case 'auditor':
        this.getAuditorAcknowledgeRows();
        break;
    }
  }

  getCoderAcknowledgeRows() {
    const rows = [];
    this.rowData = [];
    let count = 0;
    if (this.l2auditorConflict) {
      if (this.cptData) {
        if (this.cptData.coder) {
          this.cptData.coder.forEach(elementCpt => {
            const l2AuditorCorrespondingChange = this.cptData.l2Auditor
              ? this.cptData.l2Auditor.filter(
                  l2auditorrow =>
                    l2auditorrow.parentId !== null &&
                    l2auditorrow.parentId === elementCpt.id
                )[0]
              : null;
            const data = this.getRow(
              elementCpt,
              null,
              l2AuditorCorrespondingChange
                ? l2AuditorCorrespondingChange
                : null,
              count++,
              'CPT',
              this.cptData.uniqueId,
              this.cptData.codeType
            );
            rows.push(data);
          });
        }
        const l2auditorRows = this.cptData.l2Auditor
          ? this.cptData.l2Auditor.filter(
              l2auditorRow => l2auditorRow.parentId == null
            )
          : null;
        if (l2auditorRows) {
          l2auditorRows.forEach(elementl2adr => {
            const data = this.getRow(
              null,
              null,
              elementl2adr,
              count++,
              'CPT',
              this.cptData.uniqueId,
              this.cptData.codeType
            );
            rows.push(data);
          });
        }
      }
      if (this.icdData) {
        if (this.icdData.coder) {
          this.icdData.coder.forEach(elementicd => {
            const l2AuditorCorrespondingChange = this.icdData.l2Auditor
              ? this.icdData.l2Auditor.filter(
                  l2auditorrow =>
                    l2auditorrow.parentId !== null &&
                    l2auditorrow.parentId === elementicd.id
                )[0]
              : null;
            const data = this.getRow(
              elementicd,
              null,
              l2AuditorCorrespondingChange
                ? l2AuditorCorrespondingChange
                : null,
              count++,
              'ICD',
              this.icdData.uniqueId,
              this.icdData.codeType
            );
            rows.push(data);
          });
        }
        const l2auditorRows = this.icdData.l2Auditor
          ? this.icdData.l2Auditor.filter(
              l2auditorRow => l2auditorRow.parentId == null
            )
          : null;
        if (l2auditorRows) {
          l2auditorRows.forEach(elementl2adricd => {
            const data = this.getRow(
              null,
              null,
              elementl2adricd,
              count++,
              'ICD',
              this.icdData.uniqueId,
              this.icdData.codeType
            );
            rows.push(data);
          });
        }
      }
    } else if (this.auditorConflict) {
      if (this.cptData) {
        if (this.cptData.coder) {
          this.cptData.coder.forEach(elementCpt => {
            const auditorCorrespondingChange = this.cptData.auditor
              ? this.cptData.auditor.filter(
                  auditorRow =>
                    auditorRow.parentId !== null &&
                    auditorRow.parentId === elementCpt.id
                )[0]
              : null;
            const data = this.getRow(
              elementCpt,
              auditorCorrespondingChange ? auditorCorrespondingChange : null,
              null,
              count++,
              'CPT',
              this.cptData.uniqueId,
              this.cptData.codeType
            );
            rows.push(data);
          });
        }
        const auditorRows = this.cptData.auditor
          ? this.cptData.auditor.filter(
              auditorRow => auditorRow.parentId == null
            )
          : null;
        if (auditorRows) {
          auditorRows.forEach(elementadr => {
            const data = this.getRow(
              null,
              elementadr,
              null,
              count++,
              'CPT',
              this.cptData.uniqueId,
              this.cptData.codeType
            );
            rows.push(data);
          });
        }
      }
      if (this.icdData) {
        if (this.icdData.coder) {
          this.icdData.coder.forEach(elementicd => {
            const auditorCorrespondingChange = this.icdData.auditor
              ? this.icdData.auditor.filter(
                  auditorRow =>
                    auditorRow.parentId !== null &&
                    auditorRow.parentId === elementicd.id
                )[0]
              : null;
            const data = this.getRow(
              elementicd,
              auditorCorrespondingChange ? auditorCorrespondingChange : null,
              null,
              count++,
              'ICD',
              this.icdData.uniqueId,
              this.icdData.codeType
            );
            rows.push(data);
          });
        }
        const auditorRows = this.icdData.auditor
          ? this.icdData.auditor.filter(
              auditorRow => auditorRow.parentId == null
            )
          : null;
        if (auditorRows) {
          auditorRows.forEach(elementadr => {
            const data = this.getRow(
              null,
              elementadr,
              null,
              count++,
              'ICD',
              this.icdData.uniqueId,
              this.icdData.codeType
            );
            rows.push(data);
          });
        }
      }
    }
    this.rowData = rows;
  }

  getAuditorAcknowledgeRows() {
    const rows = [];
    this.rowData = [];
    let count = 0;
    if (this.l2auditorConflict) {
      if (this.cptData) {
        if (this.cptData.auditor) {
          this.cptData.auditor.forEach(elementCpt => {
            const l2AuditorCorrespondingChange = this.cptData.l2Auditor
              ? this.cptData.l2Auditor.filter(
                  l2auditorrow =>
                    l2auditorrow.parentId !== null &&
                    l2auditorrow.parentId === elementCpt.id
                )[0]
              : null;
            const data = this.getRow(
              null,
              elementCpt,
              l2AuditorCorrespondingChange
                ? l2AuditorCorrespondingChange
                : null,
              count++,
              'CPT',
              this.cptData.uniqueId,
              this.cptData.codeType
            );
            rows.push(data);
          });
        }
        const l2auditorRows = this.cptData.l2Auditor
          ? this.cptData.l2Auditor.filter(
              l2auditorRow => l2auditorRow.parentId == null
            )
          : null;
        if (l2auditorRows) {
          l2auditorRows.forEach(elementl2adr => {
            const data = this.getRow(
              null,
              null,
              elementl2adr,
              count++,
              'CPT',
              this.cptData.uniqueId,
              this.cptData.codeType
            );
            rows.push(data);
          });
        }
      }
      if (this.icdData) {
        if (this.icdData.auditor) {
          this.icdData.auditor.forEach(elementicdadr => {
            const l2AuditorCorrespondingChange = this.icdData.l2Auditor
              ? this.icdData.l2Auditor.filter(
                  l2auditorrow =>
                    l2auditorrow.parentId !== null &&
                    l2auditorrow.parentId === elementicdadr.id
                )[0]
              : null;
            const data = this.getRow(
              null,
              elementicdadr,
              l2AuditorCorrespondingChange
                ? l2AuditorCorrespondingChange
                : null,
              count++,
              'ICD',
              this.icdData.uniqueId,
              this.icdData.codeType
            );
            rows.push(data);
          });
        }
        const l2auditorRows = this.icdData.l2Auditor
          ? this.icdData.l2Auditor.filter(
              l2auditorRow => l2auditorRow.parentId == null
            )
          : null;
        if (l2auditorRows) {
          l2auditorRows.forEach(elementl2adricd => {
            const data = this.getRow(
              null,
              null,
              elementl2adricd,
              count++,
              'ICD',
              this.icdData.uniqueId,
              this.icdData.codeType
            );
            rows.push(data);
          });
        }
      }
    }
    this.rowData = rows;
  }

  // getRowDataAcknowledge() {
  //   const rows = [];
  //   this.rowData = [];
  //   let count = 0;
  //   if (this.cptData) {
  //     if (this.codingRole === 'coder') {
  //       if (this.cptData.coder) {
  //         this.cptData.coder.forEach(elementCpt => {
  //           const auditorCorrespondingChange = this.cptData.auditor
  //             ? this.cptData.auditor.filter(
  //                 auditorRow =>
  //                   auditorRow.parentId !== null &&
  //                   auditorRow.parentId === elementCpt.id
  //               )[0]
  //             : null;
  //           const l2AuditorCorrespondingChange = this.cptData.l2Auditor
  //             ? this.cptData.l2Auditor.filter(
  //                 l2auditorrow =>
  //                   l2auditorrow.parentId !== null &&
  //                   l2auditorrow.parentId === elementCpt.id
  //               )[0]
  //             : null;
  //           const data = this.getRow(
  //             elementCpt,
  //             auditorCorrespondingChange ? auditorCorrespondingChange : null,
  //             l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange
  //               : null,
  //             count++,
  //             'CPT',
  //             this.cptData.uniqueId,
  //             this.cptData.codeType
  //           );
  //           rows.push(data);
  //         });
  //       }

  //       const auditorRows = this.cptData.auditor
  //         ? this.cptData.auditor.filter(
  //             auditorRow => auditorRow.parentId == null
  //           )
  //         : null;
  //       if (auditorRows) {
  //         auditorRows.forEach(elementadr => {
  //           const data = this.getRow(
  //             null,
  //             elementadr,
  //             null,
  //             count++,
  //             'CPT',
  //             this.cptData.uniqueId,
  //             this.cptData.codeType
  //           );
  //           rows.push(data);
  //         });
  //       }
  //     }
  //     if (this.codingRole === 'auditor') {
  //       if (this.cptData.auditor) {
  //         this.cptData.auditor.forEach(elementCpt => {
  //           const l2AuditorCorrespondingChange = this.cptData.l2Auditor
  //             ? this.cptData.l2Auditor.filter(
  //                 l2auditorrow =>
  //                   l2auditorrow.parentId !== null &&
  //                   l2auditorrow.parentId === elementCpt.id
  //               )[0]
  //             : null;
  //           const data = this.getRow(
  //             null,
  //             elementCpt,
  //             l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange
  //               : null,
  //             count++,
  //             'CPT',
  //             this.cptData.uniqueId,
  //             this.cptData.codeType
  //           );
  //           rows.push(data);
  //         });
  //       }
  //     }
  //     const l2auditorRows = this.cptData.l2Auditor
  //       ? this.cptData.l2Auditor.filter(
  //           l2auditorRow => l2auditorRow.parentId == null
  //         )
  //       : null;
  //     if (l2auditorRows) {
  //       l2auditorRows.forEach(elementl2adr => {
  //         const data = this.getRow(
  //           null,
  //           null,
  //           elementl2adr,
  //           count++,
  //           'CPT',
  //           this.cptData.uniqueId,
  //           this.cptData.codeType
  //         );
  //         rows.push(data);
  //       });
  //     }
  //   }

  //   if (this.icdData) {
  //     if (this.codingRole === 'coder') {
  //       if (this.icdData.coder) {
  //         this.icdData.coder.forEach(elementicd => {
  //           const auditorCorrespondingChange = this.icdData.auditor
  //             ? this.icdData.auditor.filter(
  //                 auditorRow =>
  //                   auditorRow.parentId !== null &&
  //                   auditorRow.parentId === elementicd.id
  //               )[0]
  //             : null;
  //           const l2AuditorCorrespondingChange = this.icdData.l2Auditor
  //             ? this.icdData.l2Auditor.filter(
  //                 l2auditorrow =>
  //                   l2auditorrow.parentId !== null &&
  //                   l2auditorrow.parentId === elementicd.id
  //               )[0]
  //             : null;
  //           const data = this.getRow(
  //             elementicd,
  //             auditorCorrespondingChange ? auditorCorrespondingChange : null,
  //             l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange
  //               : null,
  //             count++,
  //             'ICD',
  //             this.icdData.uniqueId,
  //             this.icdData.codeType
  //           );
  //           rows.push(data);
  //         });
  //       }
  //       const auditorRows = this.icdData.auditor
  //         ? this.icdData.auditor.filter(
  //             auditorRow => auditorRow.parentId == null
  //           )
  //         : null;
  //       if (auditorRows) {
  //         auditorRows.forEach(elementadr => {
  //           const data = this.getRow(
  //             null,
  //             elementadr,
  //             null,
  //             count++,
  //             'ICD',
  //             this.icdData.uniqueId,
  //             this.icdData.codeType
  //           );
  //           rows.push(data);
  //         });
  //       }
  //     }
  //     if (this.codingRole === 'auditor') {
  //       if (this.icdData.auditor) {
  //         this.icdData.auditor.forEach(elementicdadr => {
  //           const l2AuditorCorrespondingChange = this.icdData.l2Auditor
  //             ? this.icdData.l2Auditor.filter(
  //                 l2auditorrow =>
  //                   l2auditorrow.parentId !== null &&
  //                   l2auditorrow.parentId === elementicdadr.id
  //               )[0]
  //             : null;
  //           const data = this.getRow(
  //             null,
  //             elementicdadr,
  //             l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange
  //               : null,
  //             count++,
  //             'ICD',
  //             this.icdData.uniqueId,
  //             this.icdData.codeType
  //           );
  //           rows.push(data);
  //         });
  //       }
  //     }
  //     const l2auditorRows = this.icdData.l2Auditor
  //       ? this.icdData.l2Auditor.filter(
  //           l2auditorRow => l2auditorRow.parentId == null
  //         )
  //       : null;
  //     if (l2auditorRows) {
  //       l2auditorRows.forEach(elementl2adricd => {
  //         const data = this.getRow(
  //           null,
  //           null,
  //           elementl2adricd,
  //           count++,
  //           'ICD',
  //           this.icdData.uniqueId,
  //           this.icdData.codeType
  //         );
  //         rows.push(data);
  //       });
  //     }
  //   }
  //   this.rowData = rows;
  // }

  // getRowData1() {
  //   const rows = [];
  //   this.rowData = [];
  //   let count = 0;
  //   if (this.codingRole === 'coder') {
  //     if (this.cptData) {
  //       if (this.cptData.coder) {
  //         this.cptData.coder.forEach(elementCpt => {
  //           const auditorCorrespondingChange = this.cptData.auditor
  //             ? this.cptData.auditor.filter(
  //                 auditorRow =>
  //                   auditorRow.parentId !== null &&
  //                   auditorRow.parentId === elementCpt.id
  //               )[0]
  //             : null;
  //           const l2AuditorCorrespondingChange = this.cptData.l2Auditor
  //             ? this.cptData.l2Auditor.filter(
  //                 l2auditorrow =>
  //                   l2auditorrow.parentId !== null &&
  //                   l2auditorrow.parentId === elementCpt.id
  //               )[0]
  //             : null;
  //           const data = {
  //             count: count++,
  //             type: 'CPT',
  //             uniqueID: this.cptData.uniqueId,
  //             fieldName: this.cptData.codeType,
  //             coder_id: elementCpt.id,
  //             coder_value: elementCpt.rowValue,
  //             coder_comments: elementCpt.comments,
  //             auditor_id: auditorCorrespondingChange
  //               ? auditorCorrespondingChange.id
  //               : null,
  //             auditor_value: auditorCorrespondingChange
  //               ? auditorCorrespondingChange.rowValue
  //               : null,
  //             auditor_comments: auditorCorrespondingChange
  //               ? auditorCorrespondingChange.comments
  //               : null,
  //             isAgree: false,
  //             preventiveAction: '',
  //             correctiveAction: '',
  //             rootCause: '',
  //             comments: '',
  //             coder_isActive: elementCpt.isActive,
  //             auditor_isActive: auditorCorrespondingChange
  //               ? auditorCorrespondingChange.isActive
  //               : null,
  //             coder_parentId: elementCpt.coder_id,
  //             auditor_parentId: auditorCorrespondingChange
  //               ? auditorCorrespondingChange.parentId
  //               : null,
  //             l2auditor_id: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.id
  //               : null,
  //             l2auditor_value: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.rowValue
  //               : null,
  //             l2auditor_comments: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.comments
  //               : null,
  //             l2auditor_isActive: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.isActive
  //               : null,
  //             l2auditor_parentId: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.parentId
  //               : null,
  //             oldValue: elementCpt.rowValue,
  //             oldValueIsActive: elementCpt.isActive,
  //             newValue: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.rowValue
  //               : auditorCorrespondingChange
  //               ? auditorCorrespondingChange.rowValue
  //               : null,
  //             oldValueComments: elementCpt.comments,
  //             newValueComments: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.comments
  //               : auditorCorrespondingChange
  //               ? auditorCorrespondingChange.comments
  //               : null
  //           };
  //           rows.push(data);
  //         });
  //       }
  //       const auditorRows = this.cptData.auditor
  //         ? this.cptData.auditor.filter(
  //             auditorRow => auditorRow.parentId == null
  //           )
  //         : null;
  //       if (auditorRows) {
  //         auditorRows.forEach(elementadr => {
  //           const data = {
  //             count: count++,
  //             type: 'CPT',
  //             uniqueID: this.cptData.uniqueId,
  //             fieldName: this.cptData.codeType,
  //             coder_id: null,
  //             coder_value: null,
  //             coder_comments: null,
  //             auditor_id: elementadr.id,
  //             auditor_value: elementadr.rowValue,
  //             auditor_comments: elementadr.comments,
  //             isAgree: false,
  //             preventiveAction: '',
  //             correctiveAction: '',
  //             rootCause: '',
  //             comments: '',
  //             coder_isActive: null,
  //             auditor_isActive: elementadr.isActive,
  //             coder_parentId: null,
  //             auditor_parentId: elementadr.parentId,
  //             l2auditor_id: null,
  //             l2auditor_value: null,
  //             l2auditor_comments: null,
  //             l2auditor_isActive: null,
  //             l2auditor_parentId: null,
  //             oldValue: null,
  //             oldValueIsActive: null,
  //             newValue: elementadr.rowValue,
  //             oldValueComments: null,
  //             newValueComments: elementadr.comments
  //           };
  //           rows.push(data);
  //         });
  //       }

  //       const l2auditorRows = this.cptData.l2Auditor
  //         ? this.cptData.l2Auditor.filter(
  //             l2auditorRow => l2auditorRow.parentId == null
  //           )
  //         : null;
  //       if (l2auditorRows) {
  //         l2auditorRows.forEach(elementl2adr => {
  //           const data = {
  //             count: count++,
  //             type: 'CPT',
  //             uniqueID: this.cptData.uniqueId,
  //             fieldName: this.cptData.codeType,
  //             coder_id: null,
  //             coder_value: null,
  //             coder_comments: null,
  //             auditor_id: null,
  //             auditor_value: null,
  //             auditor_comments: null,
  //             isAgree: false,
  //             preventiveAction: '',
  //             correctiveAction: '',
  //             rootCause: '',
  //             comments: '',
  //             coder_isActive: null,
  //             auditor_isActive: null,
  //             coder_parentId: null,
  //             auditor_parentId: null,
  //             l2auditor_id: elementl2adr.id,
  //             l2auditor_value: elementl2adr.rowValue,
  //             l2auditor_comments: elementl2adr.comments,
  //             l2auditor_isActive: elementl2adr.isActive,
  //             l2auditor_parentId: elementl2adr.parentId,
  //             oldValue: null,
  //             oldValueIsActive: null,
  //             newValue: elementl2adr.rowValue,
  //             oldValueComments: null,
  //             newValueComments: elementl2adr.comments
  //           };
  //           rows.push(data);
  //         });
  //       }
  //     }
  //   }

  //   if (this.codingRole === 'auditor') {
  //     if (this.cptData) {
  //       if (this.cptData.auditor) {
  //         this.cptData.auditor.forEach(elementCpt => {
  //           const l2AuditorCorrespondingChange = this.cptData.l2Auditor
  //             ? this.cptData.l2Auditor.filter(
  //                 l2auditorrow =>
  //                   l2auditorrow.parentId !== null &&
  //                   l2auditorrow.parentId === elementCpt.id
  //               )[0]
  //             : null;
  //           const data = {
  //             count: count++,
  //             type: 'CPT',
  //             uniqueID: this.cptData.uniqueId,
  //             fieldName: this.cptData.codeType,
  //             coder_id: null,
  //             coder_value: null,
  //             coder_comments: null,
  //             auditor_id: elementCpt.id,
  //             auditor_value: elementCpt.rowValue,
  //             auditor_comments: elementCpt.comments,
  //             isAgree: false,
  //             preventiveAction: '',
  //             correctiveAction: '',
  //             rootCause: '',
  //             comments: '',
  //             coder_isActive: null,
  //             auditor_isActive: elementCpt.isActive,
  //             coder_parentId: null,
  //             auditor_parentId: elementCpt.coder_id,
  //             l2auditor_id: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.id
  //               : null,
  //             l2auditor_value: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.rowValue
  //               : null,
  //             l2auditor_comments: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.comments
  //               : null,
  //             l2auditor_isActive: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.isActive
  //               : null,
  //             l2auditor_parentId: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.parentId
  //               : null,
  //             oldValue: elementCpt.rowValue,
  //             oldValueIsActive: elementCpt.isActive,
  //             newValue: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.rowValue
  //               : null,
  //             oldValueComments: elementCpt.rowValue,
  //             newValueComments: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.comments
  //               : null
  //           };
  //           rows.push(data);
  //         });
  //       }
  //       const l2auditorRows = this.cptData.l2Auditor
  //         ? this.cptData.l2Auditor.filter(
  //             l2auditorRow => l2auditorRow.parentId == null
  //           )
  //         : null;
  //       if (l2auditorRows) {
  //         l2auditorRows.forEach(elementl2adr => {
  //           const data = {
  //             count: count++,
  //             type: 'CPT',
  //             uniqueID: this.cptData.uniqueId,
  //             fieldName: this.cptData.codeType,
  //             coder_id: null,
  //             coder_value: null,
  //             coder_comments: null,
  //             auditor_id: null,
  //             auditor_value: null,
  //             auditor_comments: null,
  //             isAgree: false,
  //             preventiveAction: '',
  //             correctiveAction: '',
  //             rootCause: '',
  //             comments: '',
  //             coder_isActive: null,
  //             auditor_isActive: null,
  //             coder_parentId: null,
  //             auditor_parentId: null,
  //             l2auditor_id: elementl2adr.id,
  //             l2auditor_value: elementl2adr.rowValue,
  //             l2auditor_comments: elementl2adr.comments,
  //             l2auditor_isActive: elementl2adr.isActive,
  //             l2auditor_parentId: elementl2adr.parentId,
  //             oldValue: null,
  //             oldValueIsActive: null,
  //             newValue: elementl2adr.rowValue,
  //             oldValueComments: null,
  //             newValueComments: elementl2adr.comments
  //           };
  //           rows.push(data);
  //         });
  //       }
  //     }
  //   }
  //   if (this.icdData) {
  //     if (this.codingRole === 'coder') {
  //       if (this.icdData.coder) {
  //         this.icdData.coder.forEach(elementicd => {
  //           const auditorCorrespondingChange = this.icdData.auditor
  //             ? this.icdData.auditor.filter(
  //                 auditorRow =>
  //                   auditorRow.parentId !== null &&
  //                   auditorRow.parentId === elementicd.id
  //               )[0]
  //             : null;
  //           const l2AuditorCorrespondingChange = this.icdData.l2Auditor
  //             ? this.icdData.l2Auditor.filter(
  //                 l2auditorrow =>
  //                   l2auditorrow.parentId !== null &&
  //                   l2auditorrow.parentId === elementicd.id
  //               )[0]
  //             : null;

  //           const data = {
  //             count: count++,
  //             type: 'ICD',
  //             uniqueID: this.icdData.uniqueId,
  //             fieldName: this.icdData.codeType,
  //             coder_id: elementicd.id,
  //             coder_value: elementicd.rowValue,
  //             coder_comments: elementicd.comments,
  //             coder_isActive: elementicd.isActive,
  //             coder_parentId: elementicd.coder_id,
  //             auditor_id: auditorCorrespondingChange
  //               ? auditorCorrespondingChange.id
  //               : null,
  //             auditor_value: auditorCorrespondingChange
  //               ? auditorCorrespondingChange.rowValue
  //               : null,
  //             auditor_comments: auditorCorrespondingChange
  //               ? auditorCorrespondingChange.comments
  //               : null,
  //             auditor_isActive: auditorCorrespondingChange
  //               ? auditorCorrespondingChange.isActive
  //               : null,
  //             auditor_parentId: auditorCorrespondingChange
  //               ? auditorCorrespondingChange.parentId
  //               : null,
  //             isAgree: false,
  //             preventiveAction: '',
  //             correctiveAction: '',
  //             rootCause: '',
  //             comments: '',
  //             l2auditor_id: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.id
  //               : null,
  //             l2auditor_value: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.rowValue
  //               : null,
  //             l2auditor_comments: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.comments
  //               : null,
  //             l2auditor_isActive: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.isActive
  //               : null,
  //             l2auditor_parentId: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.parentId
  //               : null,
  //             oldValue: elementicd.rowValue,
  //             oldValueIsActive: elementicd.isActive,
  //             newValue: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.rowValue
  //               : auditorCorrespondingChange
  //               ? auditorCorrespondingChange.rowValue
  //               : null,
  //             oldValueComments: elementicd.comments,
  //             newValueComments: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.comments
  //               : auditorCorrespondingChange
  //               ? auditorCorrespondingChange.comments
  //               : null
  //           };
  //           rows.push(data);
  //         });
  //         if (!this.l2auditorConflict) {
  //           const auditorRows = this.icdData.auditor
  //             ? this.icdData.auditor.filter(
  //                 auditorRow => auditorRow.parentId == null
  //               )
  //             : null;
  //           if (auditorRows) {
  //             auditorRows.forEach(elementadr => {
  //               const data = {
  //                 count: count++,
  //                 type: 'ICD',
  //                 uniqueID: this.icdData.uniqueId,
  //                 fieldName: this.icdData.codeType,
  //                 coder_id: null,
  //                 coder_value: null,
  //                 coder_comments: null,
  //                 auditor_id: elementadr.id,
  //                 auditor_value: elementadr.rowValue,
  //                 auditor_comments: elementadr.comments,
  //                 isAgree: false,
  //                 preventiveAction: '',
  //                 correctiveAction: '',
  //                 rootCause: '',
  //                 comments: '',
  //                 coder_isActive: null,
  //                 auditor_isActive: elementadr.isActive,
  //                 coder_parentId: null,
  //                 auditor_parentId: elementadr.parentId,
  //                 l2auditor_id: null,
  //                 l2auditor_value: null,
  //                 l2auditor_comments: null,
  //                 l2auditor_isActive: null,
  //                 l2auditor_parentId: null,
  //                 oldValue: null,
  //                 oldValueIsActive: null,
  //                 newValue: elementadr.rowValue,
  //                 oldValueComments: null,
  //                 newValueComments: elementadr.comments
  //               };
  //               rows.push(data);
  //             });
  //           }
  //         } else {
  //           const l2auditorRows = this.icdData.l2Auditor
  //             ? this.icdData.l2Auditor.filter(
  //                 l2auditorRow => l2auditorRow.parentId == null
  //               )
  //             : null;
  //           if (l2auditorRows) {
  //             l2auditorRows.forEach(elementl2adr => {
  //               const data = {
  //                 count: count++,
  //                 type: 'ICD',
  //                 uniqueID: this.icdData.uniqueId,
  //                 fieldName: this.icdData.codeType,
  //                 coder_id: null,
  //                 coder_value: null,
  //                 coder_comments: null,
  //                 auditor_id: null,
  //                 auditor_value: null,
  //                 auditor_comments: null,
  //                 isAgree: false,
  //                 preventiveAction: '',
  //                 correctiveAction: '',
  //                 rootCause: '',
  //                 comments: '',
  //                 coder_isActive: null,
  //                 auditor_isActive: null,
  //                 coder_parentId: null,
  //                 auditor_parentId: null,
  //                 l2auditor_id: elementl2adr.id,
  //                 l2auditor_value: elementl2adr.rowValue,
  //                 l2auditor_comments: elementl2adr.comments,
  //                 l2auditor_isActive: elementl2adr.isActive,
  //                 l2auditor_parentId: elementl2adr.parentId,
  //                 oldValue: null,
  //                 oldValueIsActive: null,
  //                 newValue: elementl2adr.rowValue,
  //                 oldValueComments: null,
  //                 newValueComments: elementl2adr.comments
  //               };
  //               rows.push(data);
  //             });
  //           }
  //         }
  //       }
  //       // if (!this.l2auditorConflict) {
  //       //   if (this.icdData.auditor) {
  //       //     this.icdData.auditor.forEach(elementicdadr => {
  //       //       const data = {
  //       //         count: count++,
  //       //         type: 'ICD',
  //       //         uniqueID: this.icdData.uniqueId,
  //       //         fieldName: this.icdData.codeType,
  //       //         coder_id: null,
  //       //         coder_value: null,
  //       //         coder_comments: null,
  //       //         auditor_id: elementicdadr.id,
  //       //         auditor_value: elementicdadr.rowValue,
  //       //         auditor_comments: elementicdadr.comments,
  //       //         isAgree: false,
  //       //         preventiveAction: '',
  //       //         correctiveAction: '',
  //       //         rootCause: '',
  //       //         comments: '',
  //       //         coder_isActive: null,
  //       //         auditor_isActive: elementicdadr.isActive,
  //       //         coder_parentId: null,
  //       //         auditor_parentId: null,
  //       //         l2auditor_id: null,
  //       //         l2auditor_value: null,
  //       //         l2auditor_comments: null,
  //       //         l2auditor_isActive: null,
  //       //         l2auditor_parentId: null,
  //       //         oldValue:
  //       //           this.codingRole === 'auditor' ? elementicdadr.rowValue : null,
  //       //         oldValueIsActive:
  //       //           this.codingRole === 'auditor' ? elementicdadr.isActive : null,
  //       //         newValue:
  //       //           this.codingRole !== 'auditor' ? elementicdadr.rowValue : null,
  //       //         oldValueComments:
  //       //           this.codingRole === 'auditor' ? elementicdadr.comments : null,
  //       //         newValueComments:
  //       //           this.codingRole === 'auditor' ? elementicdadr.comments : null
  //       //       };
  //       //       rows.push(data);
  //       //     });
  //       //   }
  //       // } else {
  //       //   if (this.icdData.l2Auditor) {
  //       //     this.icdData.l2Auditor.forEach(elementl2adricd => {
  //       //       const data = {
  //       //         count: count++,
  //       //         type: 'ICD',
  //       //         uniqueID: this.icdData.uniqueId,
  //       //         fieldName: this.icdData.codeType,
  //       //         coder_id: null,
  //       //         coder_value: null,
  //       //         coder_comments: null,
  //       //         auditor_id: null,
  //       //         auditor_value: null,
  //       //         auditor_comments: null,
  //       //         isAgree: false,
  //       //         preventiveAction: '',
  //       //         correctiveAction: '',
  //       //         rootCause: '',
  //       //         comments: '',
  //       //         coder_isActive: null,
  //       //         auditor_isActive: null,
  //       //         coder_parentId: null,
  //       //         auditor_parentId: null,
  //       //         l2auditor_id: elementl2adricd.id,
  //       //         l2auditor_value: elementl2adricd.rowValue,
  //       //         l2auditor_comments: elementl2adricd.comments,
  //       //         l2auditor_isActive: elementl2adricd.isActive,
  //       //         l2auditor_parentId: null,
  //       //         oldValue: null,
  //       //         oldValueIsActive: null,
  //       //         newValue: elementl2adricd.rowValue,
  //       //         oldValueComments: null,
  //       //         newValueComments: elementl2adricd.comments
  //       //       };
  //       //       rows.push(data);
  //       //     });
  //       //   }
  //       // }
  //     }
  //     if (this.codingRole === 'auditor') {
  //       if (this.icdData.auditor) {
  //         this.icdData.auditor.forEach(elementicdadr => {
  //           const l2AuditorCorrespondingChange = this.icdData.l2Auditor
  //             ? this.icdData.l2Auditor.filter(
  //                 l2auditorrow =>
  //                   l2auditorrow.parentId !== null &&
  //                   l2auditorrow.parentId === elementicdadr.id
  //               )[0]
  //             : null;
  //           const data = {
  //             count: count++,
  //             type: 'ICD',
  //             uniqueID: this.icdData.uniqueId,
  //             fieldName: this.icdData.codeType,
  //             coder_id: null,
  //             coder_value: null,
  //             coder_comments: null,
  //             auditor_id: elementicdadr.id,
  //             auditor_value: elementicdadr.rowValue,
  //             auditor_comments: elementicdadr.comments,
  //             isAgree: false,
  //             preventiveAction: '',
  //             correctiveAction: '',
  //             rootCause: '',
  //             comments: '',
  //             coder_isActive: null,
  //             auditor_isActive: elementicdadr.isActive,
  //             coder_parentId: null,
  //             auditor_parentId: null,
  //             l2auditor_id: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.id
  //               : null,
  //             l2auditor_value: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.value
  //               : null,
  //             l2auditor_comments: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.comments
  //               : null,
  //             l2auditor_isActive: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.isActive
  //               : null,
  //             l2auditor_parentId: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.parentId
  //               : null,
  //             oldValue:
  //               this.codingRole === 'auditor' ? elementicdadr.rowValue : null,
  //             oldValueIsActive:
  //               this.codingRole === 'auditor' ? elementicdadr.isActive : null,
  //             newValue: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.rowValue
  //               : this.codingRole !== 'auditor'
  //               ? elementicdadr.rowValue
  //               : null,
  //             oldValueComments:
  //               this.codingRole === 'auditor' ? elementicdadr.comments : null,
  //             newValueComments: l2AuditorCorrespondingChange
  //               ? l2AuditorCorrespondingChange.rowValue
  //               : this.codingRole === 'auditor'
  //               ? elementicdadr.comments
  //               : null
  //           };
  //           rows.push(data);
  //         });
  //         const l2auditorRows = this.icdData.l2Auditor
  //           ? this.icdData.l2Auditor.filter(
  //               l2auditorRow => l2auditorRow.parentId == null
  //             )
  //           : null;
  //         if (l2auditorRows) {
  //           l2auditorRows.forEach(elementl2adricd => {
  //             const data = {
  //               count: count++,
  //               type: 'ICD',
  //               uniqueID: this.icdData.uniqueId,
  //               fieldName: this.icdData.codeType,
  //               coder_id: null,
  //               coder_value: null,
  //               coder_comments: null,
  //               auditor_id: null,
  //               auditor_value: null,
  //               auditor_comments: null,
  //               isAgree: false,
  //               preventiveAction: '',
  //               correctiveAction: '',
  //               rootCause: '',
  //               comments: '',
  //               coder_isActive: null,
  //               auditor_isActive: null,
  //               coder_parentId: null,
  //               auditor_parentId: null,
  //               l2auditor_id: elementl2adricd.id,
  //               l2auditor_value: elementl2adricd.rowValue,
  //               l2auditor_comments: elementl2adricd.comments,
  //               l2auditor_isActive: elementl2adricd.isActive,
  //               l2auditor_parentId: null,
  //               oldValue: null,
  //               oldValueIsActive: null,
  //               newValue: elementl2adricd.rowValue,
  //               oldValueComments: null,
  //               newValueComments: elementl2adricd.comments
  //             };
  //             rows.push(data);
  //           });
  //         }
  //       }
  //       // if (this.icdData.l2Auditor) {
  //       //   this.icdData.l2Auditor.forEach(elementl2adricd => {
  //       //     const data = {
  //       //       count: count++,
  //       //       type: 'ICD',
  //       //       uniqueID: this.icdData.uniqueId,
  //       //       fieldName: this.icdData.codeType,
  //       //       coder_id: null,
  //       //       coder_value: null,
  //       //       coder_comments: null,
  //       //       auditor_id: null,
  //       //       auditor_value: null,
  //       //       auditor_comments: null,
  //       //       isAgree: false,
  //       //       preventiveAction: '',
  //       //       correctiveAction: '',
  //       //       rootCause: '',
  //       //       comments: '',
  //       //       coder_isActive: null,
  //       //       auditor_isActive: null,
  //       //       coder_parentId: null,
  //       //       auditor_parentId: null,
  //       //       l2auditor_id: elementl2adricd.id,
  //       //       l2auditor_value: elementl2adricd.rowValue,
  //       //       l2auditor_comments: elementl2adricd.comments,
  //       //       l2auditor_isActive: elementl2adricd.isActive,
  //       //       l2auditor_parentId: null,
  //       //       oldValue: null,
  //       //       oldValueIsActive: null,
  //       //       newValue: elementl2adricd.rowValue,
  //       //       oldValueComments: null,
  //       //       newValueComments: elementl2adricd.comments
  //       //     };
  //       //     rows.push(data);
  //       //   });
  //       // }
  //     }
  //   }
  //   this.rowData = rows;
  // }

  // getRowData() {
  //   const rows = [];
  //   this.rowData = [];
  //   if (this.cptData) {
  //     if (this.cptData.coder) {
  //       this.cptData.coder.forEach(elementcpt => {
  //         const auditorCorrespondingChange = this.cptData.auditor
  //           ? this.cptData.auditor.filter(
  //               auditorRow => auditorRow.parentId === elementcpt.id
  //             )[0]
  //           : null;
  //         const l2AuditorCorrespondingChange = this.cptData.l2Auditor
  //           ? this.cptData.l2Auditor.filter(
  //               l2auditorrow => l2auditorrow.parentId === elementcpt.id
  //             )[0]
  //           : null;
  //         const data = {
  //           type: 'CPT',
  //           uniqueID: this.cptData.uniqueId,
  //           fieldName: this.cptData.codeType,
  //           coder_id: elementcpt.id,
  //           coder_value: elementcpt.rowValue,
  //           coder_comments: elementcpt.comments,
  //           auditor_id: auditorCorrespondingChange
  //             ? auditorCorrespondingChange.id
  //             : null,
  //           auditor_value: auditorCorrespondingChange
  //             ? auditorCorrespondingChange.rowValue
  //             : null,
  //           auditor_comments: auditorCorrespondingChange
  //             ? auditorCorrespondingChange.comments
  //             : null,
  //           isAgree: false,
  //           preventiveAction: '',
  //           correctiveAction: '',
  //           rootCause: '',
  //           comments: '',
  //           coder_isActive: elementcpt.isActive,
  //           auditor_isActive: auditorCorrespondingChange
  //             ? auditorCorrespondingChange.isActive
  //             : null,
  //           coder_parentId: elementcpt.coder_id,
  //           auditor_parentId: auditorCorrespondingChange
  //             ? auditorCorrespondingChange.parentId
  //             : null,
  //           l2auditor_id: l2AuditorCorrespondingChange
  //             ? l2AuditorCorrespondingChange.id
  //             : null,
  //           l2auditor_value: l2AuditorCorrespondingChange
  //             ? l2AuditorCorrespondingChange.rowValue
  //             : null,
  //           l2auditor_comments: l2AuditorCorrespondingChange
  //             ? l2AuditorCorrespondingChange.comments
  //             : null,
  //           l2auditor_isActive: l2AuditorCorrespondingChange
  //             ? l2AuditorCorrespondingChange.isActive
  //             : null,
  //           l2auditor_parentId: l2AuditorCorrespondingChange
  //             ? l2AuditorCorrespondingChange.parentId
  //             : null
  //         };
  //         rows.push(data);
  //       });
  //     }

  //     const auditorRows = this.cptData.auditor
  //       ? this.cptData.auditor.filter(auditorRow => auditorRow.parentId == null)
  //       : null;
  //     if (auditorRows) {
  //       auditorRows.forEach(elementadr => {
  //         const data = {
  //           type: 'CPT',
  //           uniqueID: this.cptData.uniqueId,
  //           fieldName: this.cptData.codeType,
  //           coder_id: null,
  //           coder_value: null,
  //           coder_comments: null,
  //           auditor_id: elementadr.id,
  //           auditor_value: elementadr.rowValue,
  //           auditor_comments: elementadr.comments,
  //           isAgree: false,
  //           preventiveAction: '',
  //           correctiveAction: '',
  //           rootCause: '',
  //           comments: '',
  //           coder_isActive: null,
  //           auditor_isActive: elementadr.isActive,
  //           coder_parentId: null,
  //           auditor_parentId: elementadr.parentId,
  //           l2auditor_id: null,
  //           l2auditor_value: null,
  //           l2auditor_comments: null,
  //           l2auditor_isActive: null,
  //           l2auditor_parentId: null
  //         };
  //         rows.push(data);
  //       });
  //     }

  //     const l2auditorRows = this.cptData.l2Auditor
  //       ? this.cptData.l2Auditor.filter(
  //           l2auditorRow => l2auditorRow.parentId == null
  //         )
  //       : null;
  //     if (l2auditorRows) {
  //       l2auditorRows.forEach(elementl2adr => {
  //         const data = {
  //           type: 'CPT',
  //           uniqueID: this.cptData.uniqueId,
  //           fieldName: this.cptData.codeType,
  //           coder_id: null,
  //           coder_value: null,
  //           coder_comments: null,
  //           auditor_id: null,
  //           auditor_value: null,
  //           auditor_comments: null,
  //           isAgree: false,
  //           preventiveAction: '',
  //           correctiveAction: '',
  //           rootCause: '',
  //           comments: '',
  //           coder_isActive: null,
  //           auditor_isActive: null,
  //           coder_parentId: null,
  //           auditor_parentId: null,
  //           l2auditor_id: elementl2adr.id,
  //           l2auditor_value: elementl2adr.rowValue,
  //           l2auditor_comments: elementl2adr.comments,
  //           l2auditor_isActive: elementl2adr.isActive,
  //           l2auditor_parentId: elementl2adr.parentId
  //         };
  //         rows.push(data);
  //       });
  //     }
  //   }
  //   if (this.icdData) {
  //     if (this.icdData.coder) {
  //       this.icdData.coder.forEach(elementicd => {
  //         const data = {
  //           type: 'ICD',
  //           uniqueID: this.icdData.uniqueId,
  //           fieldName: this.icdData.codeType,
  //           coder_id: elementicd.id,
  //           coder_value: elementicd.rowValue,
  //           coder_comments: elementicd.comments,
  //           auditor_id: null,
  //           auditor_value: null,
  //           auditor_comments: null,
  //           isAgree: false,
  //           preventiveAction: '',
  //           correctiveAction: '',
  //           rootCause: '',
  //           comments: '',
  //           coder_isActive: elementicd.isActive,
  //           auditor_isActive: null,
  //           coder_parentId: null,
  //           auditor_parentId: null,
  //           l2auditor_id: null,
  //           l2auditor_value: null,
  //           l2auditor_comments: null,
  //           l2auditor_isActive: null,
  //           l2auditor_parentId: null
  //         };
  //         rows.push(data);
  //       });
  //     }
  //     if (this.icdData.auditor) {
  //       this.icdData.auditor.forEach(elementicdadr => {
  //         const data = {
  //           type: 'ICD',
  //           uniqueID: this.icdData.uniqueId,
  //           fieldName: this.icdData.codeType,
  //           coder_id: null,
  //           coder_value: null,
  //           coder_comments: null,
  //           auditor_id: elementicdadr.id,
  //           auditor_value: elementicdadr.rowValue,
  //           auditor_comments: elementicdadr.comments,
  //           isAgree: false,
  //           preventiveAction: '',
  //           correctiveAction: '',
  //           rootCause: '',
  //           comments: '',
  //           coder_isActive: null,
  //           auditor_isActive: elementicdadr.isActive,
  //           coder_parentId: null,
  //           auditor_parentId: null,
  //           l2auditor_id: null,
  //           l2auditor_value: null,
  //           l2auditor_comments: null,
  //           l2auditor_isActive: null,
  //           l2auditor_parentId: null
  //         };
  //         rows.push(data);
  //       });
  //     }
  //     if (this.icdData.l2Auditor) {
  //       this.icdData.l2Auditor.forEach(elementl2adricd => {
  //         const data = {
  //           type: 'ICD',
  //           uniqueID: this.icdData.uniqueId,
  //           fieldName: this.icdData.codeType,
  //           coder_id: null,
  //           coder_value: null,
  //           coder_comments: null,
  //           auditor_id: null,
  //           auditor_value: null,
  //           auditor_comments: null,
  //           isAgree: false,
  //           preventiveAction: '',
  //           correctiveAction: '',
  //           rootCause: '',
  //           comments: '',
  //           coder_isActive: null,
  //           auditor_isActive: null,
  //           coder_parentId: null,
  //           auditor_parentId: null,
  //           l2auditor_id: elementl2adricd.id,
  //           l2auditor_value: elementl2adricd.rowValue,
  //           l2auditor_comments: elementl2adricd.comments,
  //           l2auditor_isActive: elementl2adricd.isActive,
  //           l2auditor_parentId: null
  //         };
  //         rows.push(data);
  //       });
  //     }
  //   }
  //   this.rowData = rows;
  // }

  getrowValue() {
    const cptGroupingRowDatas: any = [];
    let finalArr = {};
    let count = 1;
    if (this.cptData.length > 0) {
      this.cptData.forEach((rowValueData, i) => {
        cptGroupingRowDatas.push({
          count: count++,
          id: rowValueData.id,
          isAgree:
            rowValueData.isAgree === undefined || rowValueData.isAgree === false
              ? false
              : true,
          fieldName: rowValueData.fieldName,
          coder: rowValueData.coder,
          auditor: rowValueData.auditor,
          fieldValue: rowValueData.fieldvalue,
          preventiveAction: '',
          correctiveAction: '',
          rootCause: '',
          comments: '',
          type: rowValueData.codeType
        });
      });
      finalArr = {
        id: this.cptData[0].id,
        type: this.cptData[0].codeType,
        isAgree: 'key',
        uniqueId: this.cptData[0].uniqueId,
        rowD: cptGroupingRowDatas
      };
    }
    return finalArr;
  }

  getIcdRow() {
    const icdGroupingRowDatas: any = [];
    let finalArr = {};
    let count = this.cptData.length + 1;
    if (this.icdData.length > 0) {
      this.icdData.forEach((IcdRowData, i) => {
        icdGroupingRowDatas.push({
          count: count++,
          id: IcdRowData.id,
          isAgree:
            IcdRowData.isAgree === undefined || IcdRowData.isAgree === false
              ? false
              : true,
          fieldName: IcdRowData.fieldName,
          coder: IcdRowData.coder,
          auditor: IcdRowData.auditor,
          fieldValue: IcdRowData.fieldValue,
          preventiveAction: '',
          correctiveAction: '',
          rootCause: '',
          comments: '',
          type: IcdRowData.codeType
        });
      });
      finalArr = {
        id: this.icdData[0].id,
        type: this.icdData[0].codeType,
        isAgree: 'key',
        uniqueId: this.icdData[0].uniqueId,
        rowD: icdGroupingRowDatas
      };
    }
    return finalArr;
  }

  setData() {
    const cptData = this.getrowValue();
    const icdData = this.getIcdRow();
    this.rowData =
      Object.keys(icdData).length === 0
        ? Object.keys(cptData).length === 0
          ? []
          : [cptData]
        : Object.keys(cptData).length === 0
        ? [icdData]
        : [cptData, icdData];
    this.getNodeChildDetails = function getNodeChildDetails(rowItem) {
      if (rowItem && rowItem.rowD) {
        return {
          group: true,
          expanded: rowItem.type === 'ICD' || rowItem.type === 'CPT',
          children: rowItem.rowD,
          key: rowItem.rowD.count
        };
      } else {
        return null;
      }
    };
    this.getRowNodeId = function(data) {
      return data.count;
    };
  }

  saveAcknowledge() {
    this.checkAllRow();
    const param = this.getAcknowledgeParam();
    const validate = this.auditAcknowledgeService.validateMandatoryFields(
      param.icdRow,
      param.rowValue
    );
    if (!validate.actionIsEmpty && !validate.commentsIsEmpty) {
      this.auditAcknowledgeService
        .saveAuditAcknowledge(
          param.icdRow,
          param.rowValue,
          param.updateAckParam
        )
        .subscribe(res => {
          if (res) {
            this.errorService.throwSuccess('Chart saved successful.');
            this.dialogRef.close(true);
          } else {
            this.errorService.throwStringError('Chart is not saved.');
          }
        });
    } else if (validate.actionIsEmpty) {
      this.errorService.throwStringError(
        'Please enter the ' + validate.actionName + ' fields to agree'
      );
    } else {
      this.errorService.throwStringError(
        'Please enter the comments to disagree'
      );
    }
  }

  saveAcknowledge1() {
    this.checkAllRow();
    const param = this.getAcknowledgeParam1();
    const validate = this.auditAcknowledgeService.validateMandatoryFields(
      param.rowValueAcks,
      param.icdRowAcks
    );
    if (!validate.actionIsEmpty && !validate.commentsIsEmpty) {
      this.auditAcknowledgeService
        .saveAuditAcknowledge(
          param.icdRowAcks,
          param.rowValueAcks,
          param.updateAckParam
        )
        .subscribe(
          res => {
            if (res) {
              this.errorService.throwSuccess('Chart saved successful.');
              this.dialogRef.close(true);
            } else {
              this.errorService.throwStringError('Chart not saved.');
            }
          },
          error => {
            this.errorService.throwError(error);
          }
        );
    } else if (validate.actionIsEmpty) {
      this.errorService.throwStringError(
        'Please enter the ' + validate.actionName + ' fields to agree'
      );
    } else {
      this.errorService.throwStringError(
        'Please enter the comments to disagree'
      );
    }
  }

  getAcknowledgeParam1() {
    this.gridApi.stopEditing();
    const getSelectedRow = this.gridApi.getSelectedRows();
    const rows = [];
    let icdRowAcks = null;
    const icdRows = this.rowData.filter(
      elementicdrow => elementicdrow.type === 'ICD'
    );

    const icdAcknowledgeJson = [];
    if (icdRows) {
      icdRows.forEach(data => {
        const eachdata = {
          coder: data.coder_value
            ? {
                id: data.coder_id,
                rowValue: data.coder_value,
                isActive: data.coder_isActive,
                comments: data.coder_comments,
                parentId: data.coder_parentId
              }
            : null,
          auditor: data.auditor_value
            ? {
                id: data.auditor_id,
                rowValue: data.auditor_value,
                isActive: data.auditor_isActive,
                comments: data.auditor_comments,
                parentId: data.auditor_parentId
              }
            : null,
          l2Auditor: data.l2auditor_value
            ? {
                id: data.l2auditor_id,
                rowValue: data.l2auditor_value,
                isActive: data.l2auditor_isActive,
                comments: data.l2auditor_comments,
                parentId: data.l2auditor_parentId
              }
            : null,
          isAgree: data.isAgree,
          comments: data.comments,
          correctiveAction: data.correctiveAction,
          preventiveAction: data.preventiveAction,
          rootCause: data.rootCause,
          codeType: 'ICD'
        };

        icdAcknowledgeJson.push(eachdata);
      });
      const objICD = {
        acknowledgeJson: icdAcknowledgeJson,
        codingRole: this.codingRole,
        uniqueId: this.uniqueID
      };
      icdRowAcks = objICD;
    }
    let rowValueAcks = null;
    const cptRows = this.rowData.filter(
      elementcptrow => elementcptrow.type === 'CPT'
    );
    const cptAcknowledgeJson = [];

    if (cptRows) {
      cptRows.forEach(data => {
        const eachdata = {
          coder: data.coder_value
            ? {
                id: data.coder_id,
                rowValue: data.coder_value,
                isActive: data.coder_isActive,
                comments: data.coder_comments,
                parentId: data.coder_parentId
              }
            : null,
          auditor: data.auditor_value
            ? {
                id: data.auditor_id,
                rowValue: data.auditor_value,
                isActive: data.auditor_isActive,
                comments: data.auditor_comments,
                parentId: data.auditor_parentId
              }
            : null,
          l2Auditor: data.l2auditor_value
            ? {
                id: data.l2auditor_id,
                rowValue: data.l2auditor_value,
                isActive: data.l2auditor_isActive,
                comments: data.l2auditor_comments,
                parentId: data.l2auditor_parentId
              }
            : null,
          isAgree: data.isAgree,
          comments: data.comments,
          correctiveAction: data.correctiveAction,
          preventiveAction: data.preventiveAction,
          rootCause: data.rootCause,
          codeType: 'CPT'
        };

        cptAcknowledgeJson.push(eachdata);
      });

      const objCPT = {
        acknowledgeJson: cptAcknowledgeJson,
        codingRole: this.codingRole,
        uniqueId: this.uniqueID
      };
      rowValueAcks = objCPT;
    }

    const checkIfDisAgree = this.rowData.filter(
      datadisagree => datadisagree.isAgree === false
    );
    if (checkIfDisAgree && checkIfDisAgree.length > 0) {
      this.updateAcknowledge = false;
    }
    const updateAckParam = {
      [this.acknowledgedOn]: Date.now(),
      [this.acknowledged]: this.updateAcknowledge,
      uniqueId: this.uniqueID,
      updatedBy: this.userName,
      updatedOn: Date.now()
    };

    return { icdRowAcks, rowValueAcks, updateAckParam };
  }

  getAcknowledgeParam() {
    this.gridApi.stopEditing();
    const getSelectedRow = this.gridApi.getSelectedRows();
    let uniqueID;
    let rowValue = {};
    let icdRow = {};
    let returnParam;
    this.rowData.forEach(cpt => {
      if (cpt.type === 'CPT') {
        const acknowledgeJson = [];
        if (cpt && cpt.rowD) {
          uniqueID = cpt.uniqueId;
          cpt.rowD.forEach(cptData => {
            acknowledgeJson.push({
              isAgree: cptData.isAgree,
              comments: cptData.comments,
              correctiveAction: cptData.correctiveAction,
              fieldName: cptData.fieldName,
              coder: cptData.coder,
              auditor: cptData.auditor,
              preventiveAction: cptData.preventiveAction,
              rootCause: cptData.rootCause
            });
          });
          rowValue = {
            uniqueId: cpt.uniqueId,
            codingRole: this.codingRole,
            acknowledgeJson
          };
          if (acknowledgeJson && acknowledgeJson.length > 0) {
            acknowledgeJson.forEach(ack => {
              if (ack.isAgree === false) {
                this.updateAcknowledge = false;
              }
            });
          }
        }
      } else {
        const acknowledgeJson = [];
        if (cpt && cpt.rowD) {
          cpt.rowD.forEach(data => {
            acknowledgeJson.push({
              isAgree: data.isAgree,
              comments: data.comments,
              correctiveAction: data.correctiveAction,
              fieldName: data.fieldName,
              coder: data.coder,
              auditor: data.auditor,
              preventiveAction: data.preventiveAction,
              rootCause: data.rootCause
            });
          });
          icdRow = {
            uniqueId: cpt.uniqueId,
            codingRole: this.codingRole,
            acknowledgeJson
          };
          if (acknowledgeJson && acknowledgeJson.length > 0) {
            acknowledgeJson.forEach(ele => {
              if (ele.isAgree === false) {
                this.updateAcknowledge = false;
              }
            });
          }
        }
      }
    });

    const updateAckParam = {
      [this.acknowledgedOn]: Date.now(),
      [this.acknowledged]: this.updateAcknowledge,
      uniqueId: this.uniqueID,
      updatedBy: this.userName,
      updatedOn: Date.now()
    };

    return (returnParam = {
      icdRow,
      rowValue,
      updateAckParam
    });
  }

  checkAllRow() {
    if (this.gridApi) {
      this.gridApi.forEachNode(function(node) {
        node.setSelected(true);
      });
    }
  }

  GridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
    if (!this.errorFeedBack) {
      this.focusDesiredCell();
    }
  }

  focusDesiredCell() {
    setTimeout(() => {
      this.gridApi.setFocusedCell(0, 'comments');
      this.gridApi.startEditingCell({
        rowIndex: 0,
        colKey: 'comments'
      });
    }, 10);
  }

  callbackFromRendererComp(NodeID, isVisible) {
    const rowNode = this.gridApi.getRowNode(parseInt(NodeID, 10));
    if (isVisible) {
      rowNode.setDataValue('comments', '');
    } else {
      rowNode.setDataValue('rootCause', '');
      rowNode.setDataValue('correctiveAction', '');
      rowNode.setDataValue('preventiveAction', '');
    }
  }

  saveL2Acknowledge() {
    const updateAckParam = {
      [this.acknowledgedOn]: Date.now(),
      [this.acknowledged]: this.updateAcknowledge,
      uniqueId: this.uniqueID,
      updatedBy: this.userName,
      updatedOn: Date.now()
    };
    this.auditAcknowledgeService
      .saveL2AuditAcknowledge(updateAckParam)
      .subscribe(
        res => {
          if (res) {
            this.errorService.throwSuccess('Chart saved successful.');
            this.dialogRef.close(true);
          } else {
            this.errorService.throwStringError('Chart not saved.');
          }
        },
        error => {
          this.errorService.throwError(error);
        }
      );
  }

  cancel() {
    this.dialogRef.close(false);
  }

  saveAcknowledgeFeedBack() {
    const param = {
      uniqueId: this.uniqueID,
      updatedBy: this.userName,
      updatedOn: Date.now(),
      coderErrorFound: this.codingRole === 'coder' ? true : false,
      auditorErrorFound: this.codingRole === 'auditor' ? true : false
    };
    this.auditAcknowledgeService.saveFeedBackAcknowledge(param).subscribe(
      res => {
        if (res === 1) {
          this.errorService.throwSuccess('Chart saved successful.');
          this.dialogRef.close(true);
        } else {
          this.errorService.throwStringError('Chart not saved.');
        }
      },
      error => {
        this.errorService.throwError(error);
      }
    );
  }

  getfeedBackRowData() {
    const rows = [];
    let cptAckFilterData = [];
    let icdAckFilterData = [];
    if (this.cptData) {
      if (this.codingRole === 'coder') {
        const coderAckData = this.cptData.filter(
          cptAck =>
            cptAck.tlAck === 'Auditor Correct' ||
            cptAck.tlAck === 'Both Incorrect' ||
            cptAck.tlAck === 'Newly Added'
        );
        cptAckFilterData = this.getRowsCoderFeedBack(coderAckData);
      }
      if (this.codingRole === 'auditor') {
        const auditorAckData = this.cptData.filter(
          cptAck =>
            cptAck.tlAck === 'Coder Correct' ||
            cptAck.tlAck === 'Both Incorrect' ||
            cptAck.tlAck === 'Newly Added'
        );
        cptAckFilterData = this.getRowsAuditorFeedBack(auditorAckData);
      }
    }
    if (this.icdData) {
      if (this.codingRole === 'coder') {
        const coderAckData = this.icdData.filter(
          icdAck =>
            icdAck.tlAck === 'Auditor Correct' ||
            icdAck.tlAck === 'Both Incorrect' ||
            icdAck.tlAck === 'Newly Added'
        );
        icdAckFilterData = this.getRowsCoderFeedBack(coderAckData);
      }
      if (this.codingRole === 'auditor') {
        const auditorAckData = this.icdData.filter(
          icdAck =>
            icdAck.tlAck === 'Coder Correct' ||
            icdAck.tlAck === 'Both Incorrect' ||
            icdAck.tlAck === 'Newly Added'
        );
        icdAckFilterData = this.getRowsAuditorFeedBack(auditorAckData);
      }
    }

    this.rowData =
      cptAckFilterData.length > 0
        ? cptAckFilterData.concat(icdAckFilterData)
        : icdAckFilterData;
    const audiCon = this.rowData.filter(ele => ele.auditor_value !== null);
    this.auditorConflict = audiCon
      ? audiCon.length > 0
        ? true
        : false
      : false;
    const l2AudiCon = this.rowData.filter(ele => ele.l2auditor_value !== null);
    this.l2auditorConflict = l2AudiCon
      ? l2AudiCon.length > 0
        ? true
        : false
      : false;
  }

  getRows(AckData) {
    const rows = [];
    if (AckData) {
      AckData.forEach(ackdatarow => {
        const data = {
          type: ackdatarow.codeType,
          uniqueID: this.uniqueID,
          fieldName: ackdatarow.codeType,
          coder_id: ackdatarow.coder ? ackdatarow.coder.id : null,
          coder_value: ackdatarow.coder ? ackdatarow.coder.rowValue : null,
          coder_comments: ackdatarow.coder ? ackdatarow.coder.comments : null,
          auditor_id: ackdatarow.auditor ? ackdatarow.auditor.id : null,
          auditor_value: ackdatarow.auditor
            ? ackdatarow.auditor.rowValue
            : null,
          auditor_comments: ackdatarow.auditor
            ? ackdatarow.auditor.comments
            : null,
          isAgree: false,
          preventiveAction: '',
          correctiveAction: '',
          rootCause: '',
          comments: ackdatarow.tlComments ? ackdatarow.tlComments : null,
          coder_isActive: ackdatarow.coder ? ackdatarow.coder.isActive : null,
          auditor_isActive: ackdatarow.auditor
            ? ackdatarow.auditor.isActive
            : null,
          coder_parentId: null, // ackdatarow.coder ? ackdatarow.coder.parentId : null ,
          auditor_parentId: null, // ackdatarow.auditor ? ackdatarow.auditor.isActive : null ,
          l2auditor_id: ackdatarow.l2Auditor ? ackdatarow.l2Auditor.id : null,
          l2auditor_value: ackdatarow.l2Auditor
            ? ackdatarow.l2Auditor.rowValue
            : null,
          l2auditor_comments: ackdatarow.l2Auditor
            ? ackdatarow.l2Auditor.comments
            : null,
          l2auditor_isActive: ackdatarow.l2Auditor
            ? ackdatarow.l2Auditor.isActive
            : null,
          l2auditor_parentId: null, //  ackdatarow.l2Auditor ? ackdatarow.l2Auditor.parentId : null ,
          oldValue:
            this.codingRole === 'coder'
              ? ackdatarow.coder
                ? ackdatarow.coder.rowValue
                : null
              : this.codingRole === 'auditor'
              ? ackdatarow.auditor
                ? ackdatarow.auditor.rowValue
                : null
              : null,
          oldValueIsActive:
            this.codingRole === 'coder'
              ? ackdatarow.coder
                ? ackdatarow.coder.isActive
                : null
              : this.codingRole === 'auditor'
              ? ackdatarow.auditor
                ? ackdatarow.auditor.isActive
                : null
              : null,
          newValue:
            this.codingRole === 'coder'
              ? ackdatarow.tlCode
                ? ackdatarow.tlCode.rowValue
                : ackdatarow.l2Auditor
                ? ackdatarow.l2Auditor.rowValue
                : ackdatarow.auditor
                ? ackdatarow.auditor.rowValue
                : null
              : this.codingRole === 'auditor'
              ? ackdatarow.tlCode
                ? ackdatarow.tlCode.rowValue
                : ackdatarow.l2Auditor
                ? ackdatarow.l2Auditor.rowValue
                : null
              : null,
          oldValueComments:
            this.codingRole === 'coder'
              ? ackdatarow.coder
                ? ackdatarow.coder.comments
                : null
              : this.codingRole === 'auditor'
              ? ackdatarow.auditor
                ? ackdatarow.auditor.comments
                : null
              : null,
          newValueComments:
            this.codingRole === 'coder'
              ? ackdatarow.tlCode
                ? ackdatarow.tlCode.comments
                : ackdatarow.l2Auditor
                ? ackdatarow.l2Auditor.comments
                : ackdatarow.auditor
                ? ackdatarow.auditor.comments
                : null
              : this.codingRole === 'auditor'
              ? ackdatarow.tlCode
                ? ackdatarow.tlCode.comments
                : ackdatarow.l2Auditor
                ? ackdatarow.l2Auditor.comments
                : null
              : null
        };
        rows.push(data);
      });
    }
    return rows;
  }

  getRowsCoderFeedBack(AckData) {
    // Auditor correct and both wrong
    const rows = [];
    if (AckData) {
      AckData.forEach(ackdatarow => {
        const checkRow =
          (ackdatarow.tlAck === 'Both Incorrect' &&
            ackdatarow.coder === null) ||
          (ackdatarow.tlAck === 'Newly Added' && ackdatarow.tlCode === null)
            ? false
            : true;
        if (checkRow) {
          const data = {
            type: ackdatarow.codeType,
            uniqueID: this.uniqueID,
            fieldName: ackdatarow.codeType,
            coder_id: ackdatarow.coder ? ackdatarow.coder.id : null,
            coder_value: ackdatarow.coder ? ackdatarow.coder.rowValue : null,
            coder_comments: ackdatarow.coder ? ackdatarow.coder.comments : null,
            auditor_id: ackdatarow.auditor ? ackdatarow.auditor.id : null,
            auditor_value: ackdatarow.auditor
              ? ackdatarow.auditor.rowValue
              : null,
            auditor_comments: ackdatarow.auditor
              ? ackdatarow.auditor.comments
              : null,
            isAgree: false,
            preventiveAction: '',
            correctiveAction: '',
            rootCause: '',
            comments: ackdatarow.tlComments ? ackdatarow.tlComments : null,
            coder_isActive: ackdatarow.coder ? ackdatarow.coder.isActive : null,
            auditor_isActive: ackdatarow.auditor
              ? ackdatarow.auditor.isActive
              : null,
            coder_parentId: null, // ackdatarow.coder ? ackdatarow.coder.parentId : null ,
            auditor_parentId: null, // ackdatarow.auditor ? ackdatarow.auditor.isActive : null ,
            l2auditor_id: ackdatarow.l2Auditor ? ackdatarow.l2Auditor.id : null,
            l2auditor_value: ackdatarow.l2Auditor
              ? ackdatarow.l2Auditor.rowValue
              : null,
            l2auditor_comments: ackdatarow.l2Auditor
              ? ackdatarow.l2Auditor.comments
              : null,
            l2auditor_isActive: ackdatarow.l2Auditor
              ? ackdatarow.l2Auditor.isActive
              : null,
            l2auditor_parentId: null, //  ackdatarow.l2Auditor ? ackdatarow.l2Auditor.parentId : null ,
            oldValue:
              ackdatarow.tlAck === 'Auditor Correct'
                ? ackdatarow.coder
                  ? ackdatarow.coder.rowValue
                  : null
                : ackdatarow.tlAck === 'Both Incorrect'
                ? ackdatarow.coder
                  ? ackdatarow.coder.rowValue
                  : null
                : null,
            oldValueIsActive:
              ackdatarow.tlAck === 'Auditor Correct'
                ? ackdatarow.coder
                  ? ackdatarow.coder.isActive
                  : null
                : ackdatarow.tlAck === 'Both Incorrect'
                ? ackdatarow.coder
                  ? ackdatarow.coder.isActive
                  : null
                : null,
            newValue:
              ackdatarow.tlAck === 'Auditor Correct'
                ? ackdatarow.auditor
                  ? ackdatarow.auditor.rowValue
                  : null
                : ackdatarow.tlAck === 'Both Incorrect' ||
                  ackdatarow.tlAck === 'Newly Added'
                ? ackdatarow.tlCode
                  ? ackdatarow.tlCode.rowValue
                  : null
                : null,
            oldValueComments:
              ackdatarow.tlAck === 'Auditor Correct'
                ? ackdatarow.coder
                  ? ackdatarow.coder.comments
                  : null
                : ackdatarow.tlAck === 'Both Incorrect'
                ? ackdatarow.coder
                  ? ackdatarow.coder.comments
                  : null
                : null,
            newValueComments:
              ackdatarow.tlAck === 'Auditor Correct'
                ? ackdatarow.auditor
                  ? ackdatarow.auditor.comments
                  : null
                : ackdatarow.tlAck === 'Both Incorrect' ||
                  ackdatarow.tlAck === 'Newly Added'
                ? ackdatarow.tlCode
                  ? ackdatarow.tlCode.comments
                  : null
                : null
          };
          rows.push(data);
        }
      });
    }
    return rows;
  }

  getRowsAuditorFeedBack(AckData) {
    // Coder correct and both wrong
    const rows = [];
    if (AckData) {
      AckData.forEach(ackdatarow => {
        const checkRow =
          (ackdatarow.tlAck === 'Both Incorrect' &&
            ackdatarow.auditor === null) ||
          (ackdatarow.tlAck === 'Newly Added' && ackdatarow.tlCode === null)
            ? false
            : true;
        if (checkRow) {
          const data = {
            type: ackdatarow.codeType,
            uniqueID: this.uniqueID,
            fieldName: ackdatarow.codeType,
            coder_id: ackdatarow.coder ? ackdatarow.coder.id : null,
            coder_value: ackdatarow.coder ? ackdatarow.coder.rowValue : null,
            coder_comments: ackdatarow.coder ? ackdatarow.coder.comments : null,
            auditor_id: ackdatarow.auditor ? ackdatarow.auditor.id : null,
            auditor_value: ackdatarow.auditor
              ? ackdatarow.auditor.rowValue
              : null,
            auditor_comments: ackdatarow.auditor
              ? ackdatarow.auditor.comments
              : null,
            isAgree: false,
            preventiveAction: '',
            correctiveAction: '',
            rootCause: '',
            comments: ackdatarow.tlComments ? ackdatarow.tlComments : null,
            coder_isActive: ackdatarow.coder ? ackdatarow.coder.isActive : null,
            auditor_isActive: ackdatarow.auditor
              ? ackdatarow.auditor.isActive
              : null,
            coder_parentId: null, // ackdatarow.coder ? ackdatarow.coder.parentId : null ,
            auditor_parentId: null, // ackdatarow.auditor ? ackdatarow.auditor.isActive : null ,
            l2auditor_id: ackdatarow.l2Auditor ? ackdatarow.l2Auditor.id : null,
            l2auditor_value: ackdatarow.l2Auditor
              ? ackdatarow.l2Auditor.rowValue
              : null,
            l2auditor_comments: ackdatarow.l2Auditor
              ? ackdatarow.l2Auditor.comments
              : null,
            l2auditor_isActive: ackdatarow.l2Auditor
              ? ackdatarow.l2Auditor.isActive
              : null,
            l2auditor_parentId: null, //  ackdatarow.l2Auditor ? ackdatarow.l2Auditor.parentId : null ,
            oldValue:
              ackdatarow.tlAck === 'Coder Correct'
                ? ackdatarow.auditor
                  ? ackdatarow.auditor.rowValue
                  : null
                : ackdatarow.tlAck === 'Both Incorrect'
                ? ackdatarow.auditor
                  ? ackdatarow.auditor.rowValue
                  : null
                : null,
            oldValueIsActive:
              ackdatarow.tlAck === 'Coder Correct'
                ? ackdatarow.auditor
                  ? ackdatarow.auditor.isActive
                  : null
                : ackdatarow.tlAck === 'Both Incorrect'
                ? ackdatarow.auditor
                  ? ackdatarow.auditor.isActive
                  : null
                : null,
            newValue:
              ackdatarow.tlAck === 'Coder Correct'
                ? ackdatarow.coder
                  ? ackdatarow.coder.rowValue
                  : null
                : ackdatarow.tlAck === 'Both Incorrect' ||
                  ackdatarow.tlAck === 'Newly Added'
                ? ackdatarow.tlCode
                  ? ackdatarow.tlCode.rowValue
                  : null
                : null,
            oldValueComments:
              ackdatarow.tlAck === 'Coder Correct'
                ? ackdatarow.auditor
                  ? ackdatarow.auditor.comments
                  : null
                : ackdatarow.tlAck === 'Both Incorrect'
                ? ackdatarow.auditor
                  ? ackdatarow.auditor.comments
                  : null
                : null,
            newValueComments:
              ackdatarow.tlAck === 'Coder Correct'
                ? ackdatarow.coder
                  ? ackdatarow.coder.comments
                  : null
                : ackdatarow.tlAck === 'Both Incorrect' ||
                  ackdatarow.tlAck === 'Newly Added'
                ? ackdatarow.tlCode
                  ? ackdatarow.tlCode.comments
                  : null
                : null
          };
          rows.push(data);
        }
      });
    }
    return rows;
  }
}
