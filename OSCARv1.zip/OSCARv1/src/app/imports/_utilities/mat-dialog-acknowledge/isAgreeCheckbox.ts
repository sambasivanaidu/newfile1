import { Component, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
@Component({
    selector: 'checkbox-cell',
    template: `<mat-slide-toggle [checked]='params.value' labelPosition="after" (change)='onChange($event)' *ngIf='isVisible'>{{ params.value === true ? 'Agree' : 'Disagree' }}</mat-slide-toggle>`,
})
export class IsAgreeCheckboxComponent implements ICellRendererAngularComp {

    @ViewChild('.checkbox') checkbox: ElementRef;
    checkboxIsDisable: boolean = true;
    isVisible: boolean = true;
    public params: any;
    agInit(params: any): void {
        if (params.value === 'key') {
            this.isVisible = false;
        }
        this.params = params;
    }

    constructor() { }

    refresh(): boolean {
        return false;
    }

    public onChange(event: any) {
        const gridRef = this.params.context.componentParent.gridOptions.api;
        this.params.data[this.params.colDef.field] = event.checked;
        const isVisible = event.checked;
        this.params.context.componentParent.callbackFromRendererComp(
            `${this.params.node.data.count}`,
            isVisible
        );
    }
}
