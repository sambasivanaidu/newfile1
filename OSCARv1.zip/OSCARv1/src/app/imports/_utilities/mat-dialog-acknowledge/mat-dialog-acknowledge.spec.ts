import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AuditAcknowledgeDialogComponent } from './mat-dialog-acknowledge.component';
import {
  MatDialogModule,
  MatDialogRef,
  MAT_DIALOG_DATA,
  MatDialog
} from '@angular/material';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpModule } from '@angular/http';
import { AuditAcknowledgeService } from './mat-dialog-acknowledge.service';
import { HeaderAuthenticationToken } from '../../../auth/authetication-header';
import { ToastsManager, ToastOptions } from 'ng2-toastr';
import { RouterTestingModule } from '@angular/router/testing';
import { RouterModule } from '@angular/router';
import * as params from 'assets/testMockData/paramsAcknowledge.json';
import { of } from 'rxjs/observable/of';
import { AgGridModule } from 'ag-grid-angular';
import { IsAgreeCheckboxComponent } from './isAgreeCheckbox';
import { ErrorHandlingServices } from '../../../services/error-handling.services';

describe('AuditAcknowledgeDialogComponent', () => {
  let component: AuditAcknowledgeDialogComponent;
  let fixture: ComponentFixture<AuditAcknowledgeDialogComponent>;
  let elementRefference;
  let originalTimeout;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AuditAcknowledgeDialogComponent, IsAgreeCheckboxComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        MatDialogModule,
        FormsModule,
        HttpModule,
        HttpClientTestingModule,
        RouterModule,
        RouterTestingModule,
        AgGridModule.withComponents([IsAgreeCheckboxComponent])
      ],
      providers: [
        AuditAcknowledgeService,
        HeaderAuthenticationToken,
        ToastsManager,
        ToastOptions,
        ErrorHandlingServices,
        { provide: MatDialogRef, useValue: { close: (boolean?) => {} } },
        { provide: MAT_DIALOG_DATA, useValue: {} }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 5000;
    fixture = TestBed.createComponent(AuditAcknowledgeDialogComponent);
    component = fixture.componentInstance;
    elementRefference = fixture.debugElement;

    fixture.detectChanges();
  });

  afterEach(()=> {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = originalTimeout;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('OnInit(), if isProcessed is false and errorFeedBack is false should enable #saveL1Ack', () => {
    component.isProcessed = false;
    component.errorFeedBack = false;
    fixture.detectChanges();

    expect(
      elementRefference.nativeElement.querySelector('#saveL1Ack').disabled
    ).toBeFalsy();
  });

  it('OnInit(), if isProcessed is true and errorFeedBack is false should enable  #saveL2Ack ', () => {
    component.isProcessed = true;
    component.errorFeedBack = false;
    fixture.detectChanges();
    expect(
      elementRefference.nativeElement.querySelector('#saveL2Ack').disabled
    ).toBeFalsy();
  });

  it('OnInit(), if errorFeedBack is true should enable  #saveErrorFeedBack ', () => {
    component.errorFeedBack = true;
    fixture.detectChanges();
    expect(
      elementRefference.nativeElement.querySelector('#saveErrorFeedBack')
        .disabled
    ).toBeFalsy();
  });

  it('OnInit(), if errorFeedBack is true call #getfeedBackRowData()', () => {
    component.errorFeedBack = true;
    fixture.detectChanges();

    spyOn(component, 'getfeedBackRowData');
    component.getfeedBackRowData();
    expect(component.getfeedBackRowData).toHaveBeenCalled();
  });

  it('#getfeedBackRowData() gets rows for FeedBack for coder', () => {
    component.codingRole = 'coder';
    const cptAckFilterData = params['cptFeedBackRows'];
    const icdAckFilterData = params['icdFeedBackRows'];
    component.cptData = params['cptCode'];
    component.icdData = params['icdCode'];
    component.rowData = cptAckFilterData.concat(icdAckFilterData);
    fixture.detectChanges();

    let spy1 = spyOn(component, 'getRowsCoderFeedBack').and.returnValue(
      cptAckFilterData
    );
    component.getRowsCoderFeedBack(component.cptData);
    expect(component.getRowsCoderFeedBack(component.cptData)).toEqual(
      cptAckFilterData
    );

    spy1.and.returnValue(icdAckFilterData);
    component.getRowsCoderFeedBack(component.icdData);
    expect(component.getRowsCoderFeedBack(component.icdData)).toEqual(
      icdAckFilterData
    );

    expect(component.rowData).toEqual(params['icdcptFeedBackConcatedRows']);
  });

  it('OnInit(), if errorFeedBack is false call #getRowDataAcknowledge()', () => {
    component.errorFeedBack = false;
    fixture.detectChanges();

    spyOn(component, 'getRowDataAcknowledge');
    component.getRowDataAcknowledge();
    expect(component.getRowDataAcknowledge).toHaveBeenCalled();
  });

  it('#getRowDataAcknowledge() gets rows for Acknowledge', () => {
    component.codingRole = 'coder';
    component.cptData = params['cptDataAck'];
    component.icdData = params['icdDataAck'];
    component.rowData = params['cpticdAckRows'];
    fixture.detectChanges();

    expect(component.rowData).toEqual(params['cpticdAckRows']);
  });

  it('#getfeedBackRowData() gets rows for FeedBack for auditor', () => {
    component.codingRole = 'coder';
    const cptAckFilterData = params['cptFeedBackAuditor'];
    const icdAckFilterData = params['icdFeedBackAuditor'];
    component.cptData = params['cptDataAuditor'];
    component.icdData = params['icdDataAuditor'];
    component.rowData = cptAckFilterData.concat(icdAckFilterData);
    fixture.detectChanges();

    let spy1 = spyOn(component, 'getRowsCoderFeedBack').and.returnValue(
      cptAckFilterData
    );
    component.getRowsCoderFeedBack(component.cptData);
    expect(component.getRowsCoderFeedBack(component.cptData)).toEqual(
      cptAckFilterData
    );

    spy1.and.returnValue(icdAckFilterData);
    component.getRowsCoderFeedBack(component.icdData);
    expect(component.getRowsCoderFeedBack(component.icdData)).toEqual(
      icdAckFilterData
    );

    expect(component.rowData).toEqual(params['icdcptAuditorFeedBack']);
  });

  it('#saveAcknowledge1() to be called when #saveL1Ack is clicked', () => {
    component.isProcessed = false;
    component.errorFeedBack = false;
    fixture.detectChanges();
    spyOn(component, 'saveAcknowledge1');
    elementRefference.nativeElement.querySelector('#saveL1Ack').click();
    expect(component.saveAcknowledge1).toHaveBeenCalled();
  });

  it('on #saveAcknowledge1() function call', () => {
    let param = params['ackParam_saveAcknowledge1'];
    const validate = params['validate'];
    const response = [0, 0, 1];

    fixture.detectChanges();
    expect(component.gridOptions.api).toBeTruthy();
    component.gridApi = component.gridOptions.api;

    fixture.detectChanges();

    spyOn(component, 'checkAllRow');
    component.checkAllRow();
    expect(component.checkAllRow).toHaveBeenCalled();

    spyOn(component, 'getAcknowledgeParam1').and.returnValue(param);

    param = component.getAcknowledgeParam1();
    expect(component.getAcknowledgeParam1).toHaveBeenCalled();

    spyOn(
      component.auditAcknowledgeService,
      'validateMandatoryFields'
    ).and.returnValue(validate);
    component.auditAcknowledgeService.validateMandatoryFields(
      param['rowValueAcks'],
      param['icdRowAcks']
    );
    expect(
      component.auditAcknowledgeService.validateMandatoryFields(
        param['rowValueAcks'],
        param['icdRowAcks']
      )
    ).toEqual(validate);

    expect(validate['actionIsEmpty']).toBeFalsy();
    expect(validate['commentsIsEmpty']).toBeFalsy();

    spyOn(
      component.auditAcknowledgeService,
      'saveAuditAcknowledge'
    ).and.returnValue(of(response));
    component.auditAcknowledgeService
      .saveAuditAcknowledge(
        param['icdRowAcks'],
        param['rowValueAcks'],
        param['updateAckParam']
      )
      .subscribe(data => {
        expect(data).not.toBeNull();
        spyOn(component.dialogRef, 'close');
        component.dialogRef.close(true);
        expect(component.dialogRef.close).toHaveBeenCalled();
      });
  });

  it('#saveL2Acknowledge() should have been called when #saveL2Ack is clicked', () => {
    component.isProcessed = true;
    component.errorFeedBack = false;
    fixture.detectChanges();
    spyOn(component, 'saveL2Acknowledge');
    elementRefference.nativeElement.querySelector('#saveL2Ack').click();
    expect(component.saveL2Acknowledge).toHaveBeenCalled();
  });

  it('On #saveL2Acknowledge() function call', () => {
    component.acknowledgedOn = 'coder' + 'Acknowledged';
    component.acknowledgedOn = 'coder' + 'AcknowledgeOn';
    component.updateAcknowledge = false; // if coder then false else true
    component.uniqueID = 'M001039969~4105747001~2016-02-06 00:00:00.0';
    component.userName = 'jyotsnak';
    const updateAckParam = {
      [component.acknowledgedOn]: Date.now(),
      [component.acknowledged]: component.updateAcknowledge,
      uniqueId: component.uniqueID,
      updatedBy: component.userName,
      updatedOn: Date.now()
    };
    fixture.detectChanges();

    spyOn(
      component.auditAcknowledgeService,
      'saveL2AuditAcknowledge'
    ).and.returnValue(of(1));
    component.auditAcknowledgeService
      .saveL2AuditAcknowledge(updateAckParam)
      .subscribe(res => {
        if (res) {
          expect(res).not.toBeNull();
          spyOn(component.dialogRef, 'close');
          component.dialogRef.close(true);
          expect(component.dialogRef.close).toHaveBeenCalled();
        }
      });
  });

  it('#saveAcknowledgeFeedBack() should have been called when #saveErrorFeedBack button clicked', () => {
    component.errorFeedBack = true;
    fixture.detectChanges();
    spyOn(component, 'saveAcknowledgeFeedBack');
    elementRefference.nativeElement.querySelector('#saveErrorFeedBack').click();
    expect(component.saveAcknowledgeFeedBack).toHaveBeenCalled();
  });

  it('On #saveAcknowledgeFeedBack() on function call', () => {
    component.codingRole = 'coder';
    component.updateAcknowledge = false; // if coder then false else true
    component.uniqueID = 'M001039969~4105747001~2016-02-06 00:00:00.0';
    component.userName = 'jyotsnak';
    const param = {
      uniqueId: component.uniqueID,
      updatedBy: component.userName,
      updatedOn: Date.now(),
      coderErrorFound: component.codingRole === 'coder' ? true : false,
      auditorErrorFound: component.codingRole === 'auditor' ? true : false
    };
    fixture.detectChanges();

    spyOn(
      component.auditAcknowledgeService,
      'saveFeedBackAcknowledge'
    ).and.returnValue(of(1));
    component.auditAcknowledgeService
      .saveFeedBackAcknowledge(param)
      .subscribe(res => {
        expect(res).toEqual(1);
        spyOn(component.dialogRef, 'close');
        component.dialogRef.close(true);
        expect(component.dialogRef.close).toHaveBeenCalled();
      });
  });

  it('#cancel() should have been called when #closeDialog button is clicked', () => {
    spyOn(component, 'cancel');
    elementRefference.nativeElement.querySelector('#closeDialog').click();
    expect(component.cancel).toHaveBeenCalled();
  });

  it('On #cancel() function call', () => {
    spyOn(component.dialogRef, 'close');
    component.dialogRef.close(false);
    expect(component.dialogRef.close).toHaveBeenCalled();
  });
});
