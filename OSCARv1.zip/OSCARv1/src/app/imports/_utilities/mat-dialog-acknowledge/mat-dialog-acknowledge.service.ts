import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../../../environments/environment';
import { Http } from '@angular/http';
import { HeaderAuthenticationToken } from '../../../auth/authetication-header';
import * as _ from 'lodash';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class AuditAcknowledgeService {
  public httpOption;
  public envURL = environment.URL;
  public userName;

  constructor(
    private http: Http,
    private httpClient: HttpClient,
    private httpHeader: HeaderAuthenticationToken
  ) {
    this.httpOption = this.httpHeader.setHeaderToken();
  }

  saveAuditAcknowledge(icd, cpt, updateAcknowledge) {
    const cptUrl = this.envURL + 'chartcptinfo/saveAcknowledge';
    const icdUrl = this.envURL + 'charticdinfo/saveAcknowledge';
    const updateAckURL = this.envURL + 'chartinformation/updateAcknowledge';

    return Observable.forkJoin(
      this.http.post(cptUrl, cpt, this.httpOption).map(data => data.json()),
      this.http.post(icdUrl, icd, this.httpOption).map(data => data.json()),
      this.http.post(updateAckURL, updateAcknowledge, this.httpOption).map(data => data.json())
    );
  }

  saveL2AuditAcknowledge(params) {
    const updateAckURL = this.envURL + 'chartinformation/updateAcknowledge';
    return this.http
      .post(updateAckURL, params, this.httpOption)
      .map(data => data.json());
  }

  validateMandatoryFields1(icd, cpt) {
    let actionIsEmpty = false;
    let commentsIsEmpty = false;
    icd.forEach(element => {
      if (element.isAgree) {
        actionIsEmpty =
          element.correctiveAction === '' ||
          element.preventiveAction === '' ||
          element.rootCause === ''
            ? true
            : false;
      } else {
        commentsIsEmpty = element.comments === '' ? true : false;
      }
    });
    cpt.forEach(element => {
      if (element.isAgree) {
        actionIsEmpty =
          element.correctiveAction === '' ||
          element.preventiveAction === '' ||
          element.rootCause === ''
            ? true
            : false;
      } else {
        commentsIsEmpty = element.comments === '' ? true : false;
      }
    });
    const param = {
      actionIsEmpty,
      commentsIsEmpty
    };
    return param;
  }

  validateMandatoryFields(icdInfo, cptInfo) {
    let actionIsEmpty = false;
    let commentsIsEmpty = false;
    let actionName = '';
    if (icdInfo.acknowledgeJson && icdInfo.acknowledgeJson.length > 0) {
      icdInfo.acknowledgeJson.forEach(element => {
        if (element.isAgree) {
          actionIsEmpty =
            element.correctiveAction === '' ||
            element.preventiveAction === '' ||
            element.rootCause === ''
              ? true
              : false;
              actionName =  element.correctiveAction === '' ? 'corrective action' : (element.preventiveAction === '' ? 'preventive action' : (element.rootCause === '' ? 'root cause' : ''));
        } else {
          commentsIsEmpty = element.comments === '' ? true : false;
        }
      });
    }

    if (cptInfo.acknowledgeJson && cptInfo.acknowledgeJson.length > 0) {
      cptInfo.acknowledgeJson.forEach((element, i) => {
        if (element.isAgree) {
          actionIsEmpty =
            element.correctiveAction === '' ||
            element.preventiveAction === '' ||
            element.rootCause === ''
              ? true
              : false;
              actionName =  element.correctiveAction === '' ? 'corrective action' : (element.preventiveAction === '' ? 'preventive action' : (element.rootCause === '' ? 'root cause' : ''));
        } else {
          commentsIsEmpty = element.comments === '' ? true : false;
        }
      });
    }

    const param = {
      actionIsEmpty,
      commentsIsEmpty,
      actionName
    };
    return param;
  }

  saveFeedBackAcknowledge(params) {
    const updateAckURL = this.envURL + 'chartinformation/updateAcknowledge';
    return this.http
      .post(updateAckURL, params, this.httpOption)
      .map(data => data.json());
  }
}
