import { MaterialModule } from './../../material.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TimeoutModalComponent } from './timeout-modal.component';

@NgModule({
  imports: [
    CommonModule,
    MaterialModule
  ],
  declarations: [TimeoutModalComponent],
  entryComponents: [
    TimeoutModalComponent
  ]
})
export class TimeoutModalModule { }
