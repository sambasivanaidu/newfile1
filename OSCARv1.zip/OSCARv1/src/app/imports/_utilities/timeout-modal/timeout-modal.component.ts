import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Router } from '@angular/router';
import * as CryptoJS from 'crypto-js';
import { HomeComponentService } from '../../../home/home.component.service';
import { environment } from '../../../../environments/environment';
import { Subject } from 'rxjs/Subject';
import { UserService } from '../../../users/shared/user.service';

@Component({
  selector: 'app-timeout-modal',
  templateUrl: './timeout-modal.component.html',
  styleUrls: ['./timeout-modal.component.scss'],
  providers: [HomeComponentService, UserService]
})
export class TimeoutModalComponent implements OnInit {
  /** Subject that emits when the component has been destroyed. */
  public _onDestroy = new Subject<void>();
  public idleState: string;
  public timeOut: boolean;
  public closeModal;
  public idle;
  public timedOut = false;
  public countdown: number = 100;
  public bufferValue: number = 10;
  private userName;
  public storage: Storage = environment.storage;
  public progressbar;
  public dialog;
  public userRole;

  constructor(
    private _router: Router,
    private _userService: UserService,
    public dialogRef: MatDialogRef<TimeoutModalComponent>,
    private homecomponentService: HomeComponentService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {
    this.progressbar = 100;
    this.userName = this.storage.getItem('UserName');
    this.idleState = this.data.idleState;
    this.idle = this.data.idle;
    this.dialog = this.data.dialog;
    this.userRole = this.data.role;

    this.idle.onIdleEnd.subscribe(() => {
      this.dialogRef.close();
    });

    this.idle.onTimeout.subscribe(() => {
      this.clearChats();
    });

    this.idle.onTimeoutWarning.subscribe((countdown, i) => {
      this.countdown = countdown;
      if (this.countdown === 1) {
        this.idle.onTimeout.subscribe(() => {
          this.timedOut = true;
        });
      } else {
        this.progressbar = this.countdown * 10;
        this.idleState =
          'You will be timed out in ' + this.countdown + ' seconds!';
      }
    });
  }

  logout() {
    // this._router.navigate(['/login']);
    location.reload();
  }

  private clearChats() {
    this.clearAllocationCharts();
  }

  public clearAllocationCharts() {
    this.homecomponentService
      .clearCharts(this.userName, this.userRole)
      .subscribe(success => {
        const param = {
          userid: this.userName,
          updatedby: this.userName
        }
        this._userService.userForceLogout(param).subscribe(data => {
          this.idle.stop();
          this.idle.ngOnDestroy();
          this.storage.clear();
          this.idleState = 'Your Session has expired';
          this.timedOut = true;
        });
      });
  }
}
