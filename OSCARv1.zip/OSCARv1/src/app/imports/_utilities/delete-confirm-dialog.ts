import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
    selector: 'app-delete-confirm-dialog',
    template:
        `
        <div mat-dialog-content class="text-center">
            <h3>Are you sure to delete ?</h3>
        </div>
        <div mat-dialog-actions class="col-md-12">
            <button mat-button (click)="onNoClick()" class="col-md-6 m-0">No Thanks</button>
            <button mat-button [mat-dialog-close]="data" class="col-md-6 m-0" cdkFocusInitial> Yes, Delete It </button>
        </div>
    `,
    styles: [`
        h3{
            font-size: 1.17em !important;
            font-family: 'Noto Sans JP', sans-serif !important;
        }
    `]
})
export class DeleteConfirmDialogComponent implements OnInit {

    constructor(
        public dialogRef: MatDialogRef<DeleteConfirmDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any
    ) { }

    ngOnInit() { }

    onNoClick() {
        this.dialogRef.close();
    }
}
