import { Component, Output, EventEmitter, ViewChild, ElementRef, Input } from '@angular/core';
@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.scss']
})
export class FileUploadComponent {

  // @Input() accept: string;
  @Output() fileSelect: EventEmitter<File[]> = new EventEmitter();
  @Input() disabledField: boolean;
  // @ViewChild('inputFile') nativeInputFile: ElementRef;

  // private _files: File[];

  // get fileCount(): number { return this._files && this._files.length || 0; }

  // onNativeInputFileSelect($event) {
  //     this._files = $event.srcElement.files;
  //     this.onFileSelect.emit(this._files);
  // }

  // selectFile() {
  //     this.nativeInputFile.nativeElement.click();
  // }

  onFileChanged(event) {
    const file = event.target.files[0];
    this.fileSelect.emit(file);
  }
}
