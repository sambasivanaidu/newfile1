// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { MipsDialogComponent } from './mips-dialog.component';

// describe('MipsDialogComponent', () => {
//   let component: MipsDialogComponent;
//   let fixture: ComponentFixture<MipsDialogComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ MipsDialogComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(MipsDialogComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
