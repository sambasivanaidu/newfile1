import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-mips-dialog',
  templateUrl: './mips-dialog.component.html',
  styleUrls: ['./mips-dialog.component.scss']
})
export class MipsDialogComponent implements OnInit {
  private mipsData: any;
  mipsDisplayedColumns: string[] = ['cpt', 'major', 'ancillaryCodes'];
  lcdDisplayedColumns: string[] = ['icdCode', 'icdCheckStatus'];
  cciDisplayedColumns: string[] = ['cpt', 'cciModifier'];
  mipsDataSource: any;
  cciDataSource: any;
  lcdDataSource: any;

  constructor(
    public dialogRef: MatDialogRef<MipsDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) { }

  ngOnInit() {
    this.mipsData = this.data;
    this.mipsDataSource = this.data.mipsData;
    this.cciDataSource = this.data.cciData;
    this.lcdDataSource = this.data.lcdData;
  }
}
