import { Component, Inject, OnInit, ViewContainerRef, AfterViewInit, SecurityContext, ChangeDetectorRef, AfterViewChecked } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormControl, FormBuilder, FormGroup } from '@angular/forms';
import { MatModalService } from './mat-modal.service';
import { Router } from '@angular/router';
import * as CryptoJS from 'crypto-js';
import { ToastsManager } from 'ng2-toastr';
import { environment } from '../../../../environments/environment';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-mat-dialog-overview',
  templateUrl: './mat-dialog-overview.component.html',
  styleUrls: ['./mat-dialog-overview.component.scss'],
  providers: [MatModalService]
})
export class MatDialogOverviewComponent implements OnInit, AfterViewChecked {
  public storage: Storage = environment.storage;
  public facilityModel: any[];
  public reasonData = [];
  public facilityOptionsModel = [];
  public title = '';
  public uniqueID = '';
  public userName;
  public platform;
  public closeModal;
  public cptInfo: any;
  public icdInfo: any;
  public raiCategoryList = [];
  public overviewForm: FormGroup;
  public isSaved;
  public modality;
  userRole: any;
  constructor(
    private _router: Router,
    public _matModalService: MatModalService,
    public dialogRef: MatDialogRef<MatDialogOverviewComponent>,
    // private viewContainerRef: ViewContainerRef,
    public toaster: ToastsManager,
    private formBuilder: FormBuilder,
    private _sanitizer: DomSanitizer,
    private changeDetector : ChangeDetectorRef,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    // this.toaster.setRootViewContainerRef(viewContainerRef);
    this.userName = this.storage.getItem('UserName');
    this.prepareDropdown();
    this.getRaiCategoryDropdown();
    this.initializeOverViewForm();
  }

  ngOnInit() {
    this.platform = this.data.platform;
    this.title = this.data.reason;
    this.uniqueID = this.data.uniqueId;
    this.closeModal = this.data.closeParam;
    this.icdInfo = this.data.icdInfo;
    this.cptInfo = this.data.cptInfo;
    this.isSaved = this.data.isSaved;
    this.modality = this.data.modality;
    this.userRole = this.data.userRole;
  }

  public initializeOverViewForm() {
    this.overviewForm = this.formBuilder.group({
      reason: new FormControl(null),
      category: new FormControl(null),
      comments: new FormControl('')
    });
  }

  public prepareDropdown() {
    this.reasonData = [];
    if (this.data.dataList.length > 0) {
      for (let i = 0; i < this.data.dataList.length; i++) {
        this.reasonData.push({
          id: this.data.dataList[i].masterCode,
          name: this.data.dataList[i].masterSubType
        });
      }
    }
  }

  public getRaiCategoryDropdown() {
    this.raiCategoryList = [];
    this._matModalService.getRaiCategoryJSON().subscribe(
      (data : any) => {
        if (data) {
          this.raiCategoryList = data.category.map((elemnt, index) => {
            return { id: index, name: elemnt };
          });
        }
      }
    );
  }

  saveRerouteCoderPlatform(param, icd, cpt){
    this._matModalService
    .savePlatformsCommentsCoder(param, icd, cpt)
    .subscribe(
      responseList => {
        if (responseList) {
          if (this.closeModal) {
            this.dialogRef.close(false);
          } else {
            this.dialogRef.close(true);
          }
        }
      }
    );
  }

  public saveWithSingleAPI() {
    const clientObj = this.storage.getItem('clientSelectionObject');
    const obj = JSON.parse(
      CryptoJS.AES.decrypt(clientObj, 'oscar').toString(CryptoJS.enc.Utf8)
    );
    let sanitizedComment = this._sanitizer.sanitize(SecurityContext.HTML, this.overviewForm.controls.comments.value);
    const param = {
      uniqueId: this.uniqueID,
      chartStatus: this.title.toLowerCase(),
      chartReasonCode: this.overviewForm.controls.reason.value
        ? this.overviewForm.controls.reason.value.id
        : '',
      chartRemarks: this.title + ': ' + sanitizedComment,
      updatedBy: this.userName,
      role: obj.workRole.role,
      raiCategory: this.overviewForm.controls.category.value
        ? this.overviewForm.controls.category.value.name
        : '',
        modality: this.modality,
        userRole: this.userRole
    };
    if (this.isSaved){
      this.saveRerouteCoderPlatform(param, this.icdInfo, this.cptInfo); // to sustain ids of icds and cpts
    } else{
      this._matModalService.saveDiscardRerouteSuspandChart(param, this.icdInfo, this.cptInfo) // removes ids of icds and cpts
      .subscribe(
        responseList => {
          if (responseList) {
            if (this.closeModal) {
              this.dialogRef.close(false);
            } else {
              this.dialogRef.close(true);
            }
          }
        }
      );
    }
  }

  onNoClick(param): void {
    this.dialogRef.close(param);
  }

  ngAfterViewChecked() {
    this.changeDetector.detectChanges();
  }
}
