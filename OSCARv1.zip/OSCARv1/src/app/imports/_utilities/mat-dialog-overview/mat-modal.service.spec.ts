// import { TestBed, inject } from '@angular/core/testing';

// import { MatModalService } from './mat-modal.service';

// describe('MatModalService', () => {
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       providers: [MatModalService]
//     });
//   });

//   it('should be created', inject([MatModalService], (service: MatModalService) => {
//     expect(service).toBeTruthy();
//   }));
// });
