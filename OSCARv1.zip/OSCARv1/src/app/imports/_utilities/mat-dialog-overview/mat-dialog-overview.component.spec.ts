// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { MatDialogOverviewComponent } from './mat-dialog-overview.component';

// describe('MatDialogOverviewComponent', () => {
//   let component: MatDialogOverviewComponent;
//   let fixture: ComponentFixture<MatDialogOverviewComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ MatDialogOverviewComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(MatDialogOverviewComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
