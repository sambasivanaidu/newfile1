import { Injectable } from '@angular/core';
import { environment } from '../../../../environments/environment';
import 'rxjs/add/operator/map';
import { HeaderAuthenticationToken } from '../../../auth/authetication-header';
import { CommonCodeService } from '../../../_shared-services/common-code.services';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { PlatformService } from '../../../services/main-pages/paltform-services/platform-service.service';

@Injectable()
export class MatModalService {
  public httpOption;
  public envURL = environment.URL;
  public userName;
  private userRole: any;
  public storage: Storage = environment.storage;
  constructor(
    private __httpHeader: HeaderAuthenticationToken,
    private platformService: PlatformService,
    private _commonCode: CommonCodeService,
    private httpClient: HttpClient
  ) {
    this.httpOption = this.__httpHeader.setHeaderToken();
    this.userName = this.storage.getItem('UserName');
    const clientObj = this._commonCode.get_ConfidenceColor_Clientselection('clientSelectionObject');
    this.userRole = clientObj.workRole.code;
  }

  savePlatformsCommentsCoder(params, icdInfo, cptInfo) {
    const IcdArrParam = this.platformService.coderHandleICDReroute(
      icdInfo,
      this.userRole,
      params.uniqueId,
      this.userName
    );
    const CptArrParam = this.platformService.coderHandleCPTReroute(
      cptInfo,
      this.userRole,
      params.uniqueId,
      this.userName
    );

    // return Observable.forkJoin(
    //   this.httpClient
    //     .post(this.envURL + 'charticdinfo/save/', IcdArrParam, this.httpOption)
    //     .pipe(
    //               map(res => {
    //                 if (res) {
    //                   return res;
    //                 }
    //               })
    //             ),
    //   this.httpClient
    //     .post(this.envURL + 'chartcptinfo/save/', CptArrParam, this.httpOption)
    //     .pipe(
    //       map(res => {
    //         if (res) {
    //           return res;
    //         }
    //       })
    //     ),
    //   this.httpClient
    //     .post(
    //       this.envURL + 'chartinformation/updateDiscard',
    //       params,
    //       this.httpOption
    //     )
    //     .pipe(
    //       map(res => {
    //         if (res) {
    //           return res;
    //         }
    //       })
    //     )
    // );

    const discardInput = {
      icdInfo: IcdArrParam,
      cptInfo: CptArrParam,
      chartInfo: params
    };
    return this.httpClient
      .post(
        this.envURL + 'chartinformation/saveDiscardCharts',
        discardInput,
        this.httpOption
      )
      .pipe(
        map(res => {
          if (res) {
            return res;
          }
        })
      );
  }

  saveDiscardRerouteSuspandChart(params, icdInfo, cptInfo) {
    let IcdArrParam, CptArrParam;
    if (params.userRole === 'l2auditor') {
      IcdArrParam = this.platformService.auditorHandleICD(
        icdInfo,
        params.uniqueId,
        params.userRole
      );
      CptArrParam = this.platformService.auditorHandleCPT(
        cptInfo,
        params.uniqueId,
        params.userRole
      );
    } else {
      IcdArrParam =
        this.userRole === 'tl'
          ? icdInfo
          : this.userRole === 'auditor' || this.userRole === 'sme'
          ? this.platformService.auditorHandleICD(
              icdInfo,
              params.uniqueId,
              this.userRole
            )
          : this.platformService.coderHandleICD(
              icdInfo,
              this.userRole,
              params.uniqueId,
              this.userName
            );
      CptArrParam =
        this.userRole === 'tl'
          ? cptInfo
          : this.userRole === 'auditor' || this.userRole === 'sme'
          ? this.platformService.auditorHandleCPT(
              cptInfo,
              params.uniqueId,
              this.userRole
            )
          : this.platformService.coderHandleCPT(
              cptInfo,
              this.userRole,
              params.uniqueId,
              this.userName
            );
    }
    const discardInput = {
      icdInfo: IcdArrParam,
      cptInfo: CptArrParam,
      chartInfo: params
    };
    return this.httpClient
      .post(
        this.envURL + 'chartinformation/saveDiscardCharts',
        discardInput,
        this.httpOption
      )
      .pipe(
        map(res => {
          if (res) {
            return res;
          }
        })
      );
  }

  public getRaiCategoryJSON() {
    return this.httpClient.get('./assets/rai.json');
  }

  savePlatFormCommentsForL2Auditor(params) {
    const URL = this.envURL + 'chartinformation/updatel2auditordetails';
    return this.httpClient.post(URL, params, this.httpOption).pipe(
      map( res => {
        if (res) {
          return res;
        }
      })
    );
  }
}
