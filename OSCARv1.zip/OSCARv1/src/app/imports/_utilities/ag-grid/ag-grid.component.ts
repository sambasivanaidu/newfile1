import { Component, OnInit, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { GridOptions } from 'ag-grid';

@Component({
  selector: 'app-ag-grid',
  templateUrl: './ag-grid.component.html',
  styleUrls: ['./ag-grid.component.scss']
})
export class AgGridComponent implements OnInit, OnChanges {

  @Input() style: string;
  @Input() class: string;
  @Input() rowSelection: string;
  @Input() editType: string;
  @Input() rowData = [];
  @Input() columnDefs;
  @Input() columnParam;
  @Input() gridOptions: GridOptions;
  @Input() components: object;
  @Input() frameworkComponents: any;
  @Input() enableColResize: boolean;
  @Input() singleClickEdit: boolean;
  @Input() rowDragManaged: boolean;
  @Input() rowMultiSelectWithClick: boolean;
  @Input() stopEditingWhenGridLosesFocus: boolean;
  @Input() suppressClickEdit: boolean;
  @Input() autoGroupColumnDef: any;

  @Output() cellEditingStarted = new EventEmitter();
  @Output() cellValueChanged = new EventEmitter();
  @Output() gridReady = new EventEmitter();

  public gridApi;
  public gridColumnApi;

  constructor() { }

  ngOnInit() {
    this.GridInit();
  }

  ngOnChanges() {
    if (this.gridOptions && this.columnParam) {
      this.gridOptions.api.setColumnDefs(this.columnParam);
    }
  }

  GridInit() {
    this.gridOptions = <GridOptions>{
      context: {
        componentParent: this
      },
    };
    this.gridOptions.columnDefs = this.columnParam;
    this.rowSelection = 'multiple';
  }

  GridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }
}
