import { Component, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';

@Component({
  selector: 'app-mat-message-dialog',
  templateUrl: './mat-message-dialog.component.html',
  styleUrls: ['./mat-message-dialog.component.scss']
})
export class MatMessageDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<MatMessageDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData
  ) {
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
}

export interface DialogData {
  displayString: string,
  title: string
}
