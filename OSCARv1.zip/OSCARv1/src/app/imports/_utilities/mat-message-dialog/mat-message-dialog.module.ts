import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatMessageDialogComponent } from './mat-message-dialog.component';
import { MaterialModule } from '../../material.module';

@NgModule({
  imports: [
    CommonModule,
    MaterialModule
  ],
  declarations: [MatMessageDialogComponent],
  entryComponents: [MatMessageDialogComponent]
})
export class MatMessageDialogModule { }
