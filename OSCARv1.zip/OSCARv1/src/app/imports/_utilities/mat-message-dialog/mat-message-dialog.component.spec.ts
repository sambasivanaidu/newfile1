import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatMessageDialogComponent } from './mat-message-dialog.component';
import {
  MatDialogRef,
  MatDialogModule,
  MAT_DIALOG_DATA
} from '@angular/material';

describe('MatMessageDialogComponent', () => {
  let component: MatMessageDialogComponent;
  let fixture: ComponentFixture<MatMessageDialogComponent>;
  let elementRefference;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MatMessageDialogComponent],
      providers: [
        { provide: MatDialogRef, useValue: { close: () => {} } },
        {
          provide: MAT_DIALOG_DATA,
          useValue: { displayString: 'Some String', title: 'Some Title' }
        }
      ],
      imports: [MatDialogModule]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MatMessageDialogComponent);
    component = fixture.componentInstance;
    elementRefference = fixture.debugElement;
    // fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('#onNoClick() should have been called when #close button is clicked', () => {
    spyOn(component, 'onNoClick');
    elementRefference.nativeElement.querySelector('#close').click();
    expect(component.onNoClick).toHaveBeenCalled();
  });

  it('On #onNoClick() function call', () => {
    spyOn(component.dialogRef, 'close');
    component.dialogRef.close();
    expect(component.dialogRef.close).toHaveBeenCalled();
  });
});
