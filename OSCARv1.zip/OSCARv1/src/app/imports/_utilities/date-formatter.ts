import { Injectable } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormControl } from '@angular/forms';

@Injectable()
export class DateFormatter {

  constructor(
    private _datePipe: DatePipe
  ) { }

  dateFormatter(params) {
    const filterdate = (params.data.dob ? params.data.dob : params.data.dos);
    const date = new Date(filterdate);
    const dateObject = '0' + (date.getMonth() + 1) + '/' + date.getDate() + '/' + date.getFullYear();
    return dateObject;
  }

  timeFormatter(param) {
    const date = new Date(param);
    // Hours part from the timestamp
    const hours = date.getHours();
    // Minutes part from the timestamp
    const minutes = '0' + date.getMinutes();
    // Seconds part from the timestamp
    const seconds = '0' + date.getSeconds();

    // Will display time in 10:30:23 format
    const formattedTime = hours + 'HH' + ':' + minutes.substr(-2) + 'MM' + ':' + seconds.substr(-2) + 'SS';
    return formattedTime;
  }

  dos(params) {
    const filterdate = (params.data.dob ? params.data.dob : params.data.dos);
    const date = new Date(filterdate);
    const day = date.getDate();
    const month = date.getMonth() + 1;
    const dateObject = (month < 10 ? '0' + month : month) +
      '/' + (day < 10 ? '0' + day : day) + '/' + date.getFullYear();
    return dateObject;
  }

  dob(params) {
    if (params) {

      if (params.data.label === 'DOB' || params.data.label === 'DOS' || params.data.label === 'Date of birth'
        || params.data.label === 'Date of service' || params.data.createdOn || params.data.label === 'Examination Date') {

        const filterdate = params.data.desc;
        const date = new Date(filterdate);
        const dateObject = (date.getMonth() + 1) + '/' + date.getDate() + '/' + date.getFullYear();
        return JSON.stringify(dateObject);
      }
    }
  }

  reportDates(params) {
    if (params) {
      const date = new Date(params);
      const dateObject = (date.getMonth() + 1) + '/' + date.getDate() + '/' + date.getFullYear();
      return dateObject;
    }
  }

  dates(params) {
    if (params) {
      // if(params.colDef.field === 'startDate' || params.colDef.field === 'createdOn' || params.colDef.field === 'endDate') {
      const filterdate = params.value;
      // const date = new Date(filterdate);
      const date = new DatePipe('en-US');
      const dateObject = date.transform(filterdate, 'MM/dd/yyyy');
      return dateObject;
      // }
    }
  }

  updateDates(params) {
    if (params) {
      const date = new DatePipe('en-US');
      const dateObject = date.transform(params, 'MM/dd/yyyy');
      return dateObject;
    }
  }

  getDatetime(date) {
    let d;
    if (date) {
      d = new Date(date);
    }
    return this._datePipe.transform(d, 'yyyy-MM-dd');
  }

  reportDate(params) {

    const filterdate = params.data.date ? params.data.date : (params.data.codedDate ? params.data.codedDate : params.data.qaDate);
    const date = new Date(filterdate);
    const day = date.getDate();
    const month = date.getMonth() + 1;
    const dateObject = (month < 10 ? '0' + month : month) +
      '/' + (day < 10 ? '0' + day : day) + '/' + date.getFullYear();
    return dateObject;
  }

  qaDate(params) {

    const filterdate = params.data.qaDate;
    const date = new Date(filterdate);
    const day = date.getDate();
    const month = date.getMonth() + 1;
    const dateObject = (month < 10 ? '0' + month : month) +
      '/' + (day < 10 ? '0' + day : day) + '/' + date.getFullYear();
    return dateObject;
  }

  public DateValidator(control: FormControl) {
    let controlValue = '';
    if (control.value && control.value._isAMomentObject) {
      const inputElementValue = control.value._i;
      controlValue = (typeof inputElementValue === 'string') ? inputElementValue : control.value.format('MM/DD/YYYY');
    }
    return !controlValue ? null : /^(\d{2}\/\d{2}\/\/d{4}) | (\mm\/dd\/yyy)$/.test(controlValue) ? null : { date: true };
  }
}
