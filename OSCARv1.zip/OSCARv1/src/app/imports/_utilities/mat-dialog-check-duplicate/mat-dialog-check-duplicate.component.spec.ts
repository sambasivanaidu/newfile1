// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { MatDialogCheckDuplicateComponent } from './mat-dialog-check-duplicate.component';

// describe('MatDialogCheckDuplicateComponent', () => {
//   let component: MatDialogCheckDuplicateComponent;
//   let fixture: ComponentFixture<MatDialogCheckDuplicateComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ MatDialogCheckDuplicateComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(MatDialogCheckDuplicateComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
