import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng2-toastr';
import { environment } from '../../../../environments/environment';
import { ErrorHandlingServices } from '../../../services/error-handling.services';
import { PlatformService } from '../../../services/main-pages/paltform-services/platform-service.service';

@Component({
  selector: 'app-mat-dialog-check-duplicate',
  templateUrl: './mat-dialog-check-duplicate.component.html',
  styleUrls: ['./mat-dialog-check-duplicate.component.scss'],
  providers: [PlatformService, ErrorHandlingServices]
})
export class MatDialogCheckDuplicateComponent implements OnInit {
  icdData;
  cptData;
  icdChangedCellNode;
  cptChangedCellNode;
  uniqueId;
  conflictComments;
  modality;
  conflictStatus;
  public storage: Storage = environment.storage;
  chartStatus;
  auditorAllocatedTo;
  platform;
  // onOK = new EventEmitter();
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private _platformService: PlatformService,
    private errorService: ErrorHandlingServices,
    public _toastr: ToastsManager,
    public dialogRef: MatDialogRef<MatDialogCheckDuplicateComponent>
  ) {
  }

  ngOnInit() {
    this.uniqueId = this.data.UniqueID;
    this.icdData = this.data.icdInfo;
    this.cptData = this.data.cptInfo;
    this.conflictStatus = this.data.conflict;
    this.modality = this.data.modality;
    this.chartStatus = this.data.chartStatus;
    this.platform = this.data.platform ? this.data.platform : '';
    if (this.platform === 'L2Auditor') {
      this.auditorAllocatedTo = this.data.auditorAllocatedTo;
    }
  }

  saveNewChangesByAuditor() {
    if (this.platform === 'L2Auditor') {
      this.saveL2auditor();
    } else if (this.platform === 'coder') {
      this.saveCoder();
    } else {
      this.saveAuditor();
    }
  }

  saveCoder() {
    this._platformService
      .saveCodedChart(
        this.cptData,
        this.icdData,
        this.uniqueId,
        this.modality,
        this.conflictStatus
      )
      .subscribe(
        data => {
          if (data) {
            // this._router.navigate(['/index/auditorQueue']);
            this.dialogRef.close(true);
          } else {
            this.errorService.throwInfo('Charts not Saved. Try Later');
          }
        },
        error => {
          this.errorService.throwError(error);
        }
      );
  }

  saveAuditor() {
    const param = {
      ICDInfo: this.icdData,
      CPTInfo: this.cptData,
      UniqueID: this.uniqueId,
      comments: this.conflictComments,
      conflicts: this.conflictStatus,
      chartStatus: this.chartStatus,
      modality: this.modality,
      addToLearning: this.conflictStatus === true ? false : true
    };

    this._platformService.saveAuditorChartInfo(param).subscribe(
      data => {
        if (data) {
          // this._router.navigate(['/index/auditorQueue']);
          this.dialogRef.close(true);
        } else {
          this.errorService.throwInfo('Charts not Saved. Try Later');
        }
      },
      error => {
        this.errorService.throwError(error);
      }
    );
  }

  saveL2auditor() {
    const param: any = {
      ICDInfo: this.icdData,
      CPTInfo: this.cptData,
      comments: this.conflictComments,
      conflicts: this.conflictStatus,
      chartStatus: 'retroed',
      modality: this.modality,
      UniqueID: this.uniqueId,
      updatedOn: Date.now(),
      auditorAllocatedTo: this.auditorAllocatedTo,
      isRetroed: true,
      addToLearning: this.conflictStatus === true ? false : true
    };
    this._platformService.saveL2AuditorChartInfo(param).subscribe(
      data => {
        if (data) {
          this.dialogRef.close(true);
        } else {
          this.errorService.throwInfo('Charts not Saved. Try Later');
        }
      },
      error => {
        this.errorService.throwError(error);
      }
    );
  }

  cancel() {
    this.dialogRef.close(false);
  }
}
