import { Component, OnInit, Inject, ViewContainerRef } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { GridOptions } from 'ag-grid';
import * as _ from 'lodash';
import { ToastsManager } from 'ng2-toastr';
import { ErrorHandlingServices } from '../../../services/error-handling.services';
import { PlatformService } from '../../../services/main-pages/paltform-services/platform-service.service';

@Component({
  selector: 'app-platform-onload-check',
  templateUrl: './platform-onload-check.component.html',
  styleUrls: ['./platform-onload-check.component.scss'],
  providers: [PlatformService]
})
export class PlatformOnloadCheckComponent implements OnInit {
  public item = 'TL Acknowledge';
  public itemCPT;
  public itemICD;
  public GridOptions: GridOptions;
  public columnDefs;
  public rowData: any;
  public gridApi;
  public gridColumnApi;
  public frameworkComponents;
  public rowSelection;
  public editType;
  public paginationPageSize;
  public components;
  public context;
  public tlAction = ['Coder Correct', 'Auditor Correct', 'Both Incorrect'];
  public uniqueId;
  disableBtn = true;
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<PlatformOnloadCheckComponent>,
    private _platformService: PlatformService,
    public _toastr: ToastsManager,
    // private vcr: ViewContainerRef,
    private errorService: ErrorHandlingServices
  ) {
    // this._toastr.setRootViewContainerRef(vcr);
  }

  ngOnInit() {
    this.uniqueId = this.data.uniqueId;
    this.gridInit();
    this.getRowData();
  }

  getRowData() {
    let arr = [];
    arr = this.data.dataList.cpt
      ? this.data.dataList.cpt.concat(this.data.dataList.icd)
      : this.data.dataList.icd;
    this.rowData = arr;
  }

  gridInit() {
    this.GridOptions = <GridOptions>{
      context: {
        componentParent: this
      }
    };

    this.GridOptions.columnDefs = this.columnDefinition();
    this.rowData = [];
    this.rowSelection = 'multiple';
    this.paginationPageSize = 50;
    this.components = {
      _singleSelect: SingleSelect()
    };
  }

  columnDefinition() {
    return [
      {
        headerName: 'Action',
        field: 'tlAck',
        cellEditor: '_singleSelect',
        editable: true,
        cellClass: 'cell-dropdown-icon mat-expansion-indicator',
        checkboxSelection: function(params) {
          return params.node.group === true;
        }
      },
      {
        headerName: 'Field Name',
        field: 'codeType',
        editable: false
      },
      {
        headerName: 'Old Id',
        field: 'coder.id',
        hide: true
      },
      {
        headerName: 'Old Value',
        field: 'coder.rowValue',
        editable: false
      },
      {
        headerName: 'Old Is Active',
        field: 'coder.isActive',
        hide: true
      },
      {
        headerName: 'New Id',
        field: 'auditor.id',
        hide: true
      },
      {
        headerName: 'New Value',
        field: 'auditor.rowValue',
        editable: false
      },
      {
        headerName: 'New Is Active',
        field: 'auditor.isActive',
        hide: true
      },
      {
        headerName: 'TL Comments',
        field: 'tlComments',
        editable: true
      },
      {
        headerName: 'Corrective Action',
        field: 'correctiveAction',
        hide: true
      },
      {
        headerName: 'IsAgree',
        field: 'isAgree',
        hide: true
      },
      {
        headerName: 'Preventive Action',
        field: 'preventiveAction',
        hide: true
      },
      {
        headerName: 'Root Cause',
        field: 'rootCause',
        hide: true
      }
    ];
  }

  OnBodyScroll() {
    this.gridApi.stopEditing();
  }

  onGridSizeChanged() {
    this.gridApi.sizeColumnsToFit();
  }

  autoSizeAll() {
    this.gridApi.sizeColumnsToFit();
  }
  GridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.autoSizeAll();
    this.autoFocus();
  }

  autoFocus() {
    setTimeout(() => {
      this.gridApi.setFocusedCell(0, 'tlAck');
      this.gridApi.startEditingCell({
        rowIndex: 0,
        colKey: 'tlAck'
      });
    }, 10);
  }

  saveAcknowledge() {
    this.checkAllRow();
    this.gridApi.stopEditing();
    const param = this.gridApi.getSelectedRows();
    const isValidAction = param.filter(n => n.tlAck === null || n.tlAck === '').length > 0;
    const isValidCmnts = param.filter(n => n.tlComments === null).length > 0;
    if (!isValidAction && !isValidCmnts) {
      const ackParam = this.getAckParam(param);
      this._platformService
        .saveTlAcknowledge(ackParam.cptChartParam, ackParam.icdChartParam)
        .subscribe(res => {
          if (res) {
            this.disableBtn = false;
            this.dialogRef.close(res);
          }
        });
    } else {
      this.errorService.throwStringError(
        'Action and comments fileds are mandatory'
      );
    }
  }

  getAckParam(param) {
    let addCptArr = [];
    let removeCptArr = [];

    let addIcdArr = [];
    let removeIcdArr = [];

    let returnParam;
    let icdChartParam;
    let cptChartParam;
    const uniqueId = this.uniqueId;
    param.forEach(element => {
      if (element.tlAck === 'Coder Correct') {
        // coder correct
        if (element.codeType === 'CPT') {
          addCptArr.push(element.coder ? element.coder.id : null);
          removeCptArr.push(element.auditor ? element.auditor.id : null);
        } else {
          addIcdArr.push(element.coder ? element.coder.id : null);
          removeIcdArr.push(element.auditor? element.auditor.id : null);
        }
      } else if (element.tlAck === 'Auditor Correct') {
        // auditor correct
        if (element.codeType === 'CPT') {
          addCptArr.push(element.auditor ? element.auditor.id : null);
          removeCptArr.push(element.coder ? element.coder.id : null);
        } else {
          // coder correct
          addIcdArr.push(element.auditor ? element.auditor.id : null);
          removeIcdArr.push(element.coder ? element.coder.id : null);
        }
      } else {
        // Both Incorrect
        if (element.codeType === 'CPT') {
          if (element.auditor) {
            removeCptArr.push(element.auditor ? element.auditor.id : null);
          }
          if (element.coder) {
            removeCptArr.push(element.coder ? element.coder.id : null);
          }
        } else {
          if (element.auditor) {
            removeIcdArr.push(element.auditor ? element.auditor.id : null);
          }
          if (element.coder) {
            removeIcdArr.push(element.coder ? element.coder.id : null);
          }
        }
      }

      icdChartParam = {
        addIds: addIcdArr,
        removeIds: removeIcdArr,
        uniqueId: uniqueId
      };
      cptChartParam = {
        addIds: addCptArr,
        removeIds: removeCptArr,
        uniqueId: uniqueId
      };
    });

    icdChartParam.feedbackJson = _.filter(param, n => n.codeType === 'ICD');
    cptChartParam.feedbackJson = _.filter(param, n => n.codeType === 'CPT');

    returnParam = { icdChartParam, cptChartParam };
    return returnParam;
  }

  checkAllRow() {
    this.gridApi.forEachNode(function(node) {
      node.setSelected(true);
    });
  }
}

function SingleSelect() {
  function SingleSelectDropDown() {}
  SingleSelectDropDown.prototype.getGui = function() {
    return this.eGui;
  };
  SingleSelectDropDown.prototype.getValue = function() {
    let selectedItemValueGridDD;
    for (let i = 0; i < this.eGui.firstChild.selectedOptions.length; i++) {
      selectedItemValueGridDD = this.eGui.firstChild.selectedOptions[i].value;
    }
    this.value = selectedItemValueGridDD;
    return this.value;
  };
  SingleSelectDropDown.prototype.isPopup = function() {
    return true;
  };
  SingleSelectDropDown.prototype.afterGuiAttached = function() {
    const changedWidth = this.colWidth + 'px';
    this.eGui.parentElement.style.width = changedWidth;
  };
  SingleSelectDropDown.prototype.init = function(params) {
    let multiDD: any = [];
    let myarr: any = [];
    let tempElement;
    let tempElementDiv;
    let optionDefault;
    let option;
    this.param = params;
    multiDD = this.param.context.componentParent.tlAction;
    if (multiDD.length > 0) {
      myarr = params.value;
      this.colWidth = this.param.column.actualWidth;

      tempElement = document.createElement('div');
      tempElement.setAttribute('id', 'multiSel');
      tempElement.setAttribute('class', 'multiselect singleSelect');

      tempElementDiv = document.createElement('select');
      tempElementDiv.setAttribute(
        'class',
        'multiselect-ui custom-select form-control'
      );
      tempElementDiv.setAttribute('id', 'multiselect-ui');

      optionDefault = document.createElement('option');
      optionDefault.setAttribute('value', '');
      optionDefault.text = '-- Select --';
      optionDefault.setAttribute('selected', 'selected');
      optionDefault.setAttribute('id', 'defOpt');
      tempElementDiv.appendChild(optionDefault);
      for (let i = 0; i < multiDD.length; i++) {
        option = document.createElement('option');
        option.setAttribute('value', multiDD[i]);
        option.text = multiDD[i];
        if (multiDD[i] === 'Coder Correct') {
          option.setAttribute('selected', 'selected');
        }
        tempElementDiv.appendChild(option);
        tempElement.appendChild(tempElementDiv);
      }
      this.eGui = tempElement;
    } else {
      return false;
    }
  };
  return SingleSelectDropDown;
}
