// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { PlatformOnloadCheckComponent } from './platform-onload-check.component';
// import { AgGridModule } from 'ag-grid-angular';
// import { MatButtonModule, MatIconModule, MatInputModule, MatFormFieldModule, MatAutocompleteModule, MatDialogModule, MatExpansionModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
// import { MaterialModule } from '../../material.module';
// import { HttpModule } from '@angular/http';
// import { HeaderAuthenticationToken } from '../../../auth/authetication-header';
// import { ToastsManager, ToastOptions } from 'ng2-toastr';
// import { RouterTestingModule } from '@angular/router/testing';

// describe('PlatformOnloadCheckComponent', () => {
//   let component: PlatformOnloadCheckComponent;
//   let fixture: ComponentFixture<PlatformOnloadCheckComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ PlatformOnloadCheckComponent ],
//       imports: [
//         HttpModule,
//         MatButtonModule,
//         MatIconModule,
//         MatInputModule,
//         MatFormFieldModule,
//         MatAutocompleteModule,
//         // FormsModule,
//         MaterialModule,
//         // ReactiveFormsModule,
//         MatExpansionModule,
//         AgGridModule.withComponents([PlatformOnloadCheckComponent]),
//         // ContextMenuModule,
//         RouterTestingModule,
//         MatDialogModule,
//         // FlexLayoutModule,
//         // BrowserAnimationsModule,
//         // HttpClientTestingModule,
//         // PerfectScrollbarModule
//       ],
//       providers: [
//         // {provide: APP_BASE_HREF, useValue: '/'},
//         // PlatformService,
//         // LookupDataService,
//         // ErrorHandlingServices,
//         HeaderAuthenticationToken,
//         ToastsManager,
//         ToastOptions,
//         { provide: MAT_DIALOG_DATA, useValue: {} },
//         { provide: MatDialogRef, useValue: {} }
//         // ContextMenuService,
//         // PlatformService,
//         // DateFormatter,
//         // DatePipe,
//         // SMEService
//       ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(PlatformOnloadCheckComponent);
//     component = fixture.componentInstance;
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
