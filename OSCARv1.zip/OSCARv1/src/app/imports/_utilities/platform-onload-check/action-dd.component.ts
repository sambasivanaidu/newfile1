import { Component, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';

@Component({
  selector: 'checkbox-cell',
  template: `
    <mat-form-field>
      <mat-select>
        <mat-option *ngFor='let action of actions' [value]='action'>
          {{ action }}
        </mat-option>
      </mat-select>
    </mat-form-field>
  `
})
export class ActionDDComponent implements ICellRendererAngularComp {
  public actions: any;
  agInit(param: any): void {
    this.actions = param.context.componentParent.tlAction;
  }

  constructor() {}

  refresh(): boolean {
    return false;
  }

  public onChange(event: any) {
    // const gridRef = this.params.context.componentParent.gridOptions.api;
    // this.params.data[this.params.colDef.field] = event.checked;
    // const isVisible = event.checked;
    // this.params.context.componentParent.callbackFromRendererComp(
    //   `${this.params.node.data.count}`,
    //   isVisible
    // );
  }
}
