import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatSearchDdComponent } from './mat-search-dd.component';
import { MaterialModule } from '../../material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';

@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    NgxMatSelectSearchModule
  ],
  declarations: [MatSearchDdComponent],
  exports: [MatSearchDdComponent]
})
export class MatSearchDdModule { }
