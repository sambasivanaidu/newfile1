// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { MatSearchDdComponent } from './mat-search-dd.component';

// describe('MatSearchDdComponent', () => {
//   let component: MatSearchDdComponent;
//   let fixture: ComponentFixture<MatSearchDdComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ MatSearchDdComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(MatSearchDdComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
