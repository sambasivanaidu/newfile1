import { Component, OnInit, EventEmitter, Output, ViewChild, Input, OnChanges, AfterViewInit, OnDestroy } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import { Subject } from 'rxjs/Subject';
import { MatSelect } from '../../../../../node_modules/@angular/material';
import { takeUntil, take } from '../../../../../node_modules/rxjs/operators';

@Component({
  selector: 'app-mat-search-dd',
  templateUrl: './mat-search-dd.component.html',
  styleUrls: ['./mat-search-dd.component.scss']
})
export class MatSearchDdComponent implements OnInit, AfterViewInit, OnDestroy {

  @Input() set optionList(value) {
    this.dropDownValues = value;
    this.filterDropDownList();
  }
  @Input() control: FormControl;
  dropDownValues: string[] = [];
  /** control for the selected facility for multi-selection */
  formSelectModel: FormControl = new FormControl();
  /** control for the MatSelect filter keyword multi-selection */
  private formSearchModel: FormControl = new FormControl();
  /** list of facility filtered by search keyword for multi-selection */
  filteredDropDown: ReplaySubject<string[]> = new ReplaySubject<string[]>(1);

  /** Subject that emits when the component has been destroyed. */
  private _onDestroy = new Subject<void>();
  // @Output() selectedModelData = new EventEmitter();
  @ViewChild('matCheck') matCheck;
  @ViewChild('matUnCheck') matUnCheck;
  @Input() required: string;
  @Input() placeholder;

  @Input() placeholderLabel: string;
  @Input() isMultiSelect: boolean;
  @Input() checkOption: boolean;
  @Input() enableSearch: boolean;
  @Input() icon: string;
  @ViewChild('multiSelect') multiSelect: MatSelect;
  constructor() { }

  ngOnInit() {
    //  if(this.isMultiSelect){
    //   this.applyCSS();
    //  }
    if (!this.isMultiSelect) {
      this.checkOption = this.isMultiSelect;
    }
    this.matUnCheck._element.nativeElement.style.display = 'none';
    this.initialise();
    this.applyCSS();

  }

  initialise() {
    if (this.dropDownValues) {
      // set initial selection
      // this.control.setValue(this.dropDownValues);

      // load the initial bank list
      this.filteredDropDown.next(this.dropDownValues.slice());

    }

    // listen for search field value changes
    this.formSearchModel.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterDropDownList();
      });

  }

  protected filterDropDownList() {
    if (!this.dropDownValues) {
      return;
    }
    // get the search keyword
    let search = this.formSearchModel.value;
    if (!search) {
      this.filteredDropDown.next(this.dropDownValues.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredDropDown.next(
      this.dropDownValues.filter(bank => bank ? (bank.toLowerCase().indexOf(search) > -1) : false)
    );
  }

  //  ngOnChanges() {
  //    if (this.optionList && this.optionList.length > 0) {
  //      this.getDDList();
  //    }
  // }

  applyCSS() {
    this.matUnCheck._element.nativeElement.firstElementChild.style.fontSize = '16px';
    this.matUnCheck._element.nativeElement.firstElementChild.style.fontWeight = 'bold';
    this.matUnCheck._element.nativeElement.firstElementChild.style.marginTop = '3px';
    this.matCheck._element.nativeElement.firstElementChild.style.fontSize = '16px';
    this.matCheck._element.nativeElement.firstElementChild.style.fontWeight = 'bold';
    this.matCheck._element.nativeElement.firstElementChild.style.marginTop = '3px';
    if (this.checkOption === false) {
      this.matCheck._element.nativeElement.style.display = 'none';
      this.matUnCheck._element.nativeElement.style.display = 'none';
    } else {
      this.matUnCheck._element.nativeElement.style.display = 'none';
    }
  }

  //  getDDList() {
  //    this.formOptionDD = this.optionList;
  //    this._matDropdownSearch.multiselectDDInit(this.formOptionList, this.formOptionDD, this.formSearchModel, this._onDestroy);
  //  }

  selectAll(checkAll, select, values) {
    if (select.value.length === 1) {
      let search = this.formSearchModel.value;
      if (search) {
        search = search.toLowerCase();
      }
      this.control.setValue(search ? values.filter(bank => bank.toLowerCase().indexOf(search) > -1) : values);
      // this.selectedModelData.emit(this.control.value);
      this.matCheck._element.nativeElement.style.display = 'none';
      this.matUnCheck._element.nativeElement.style.display = 'block';
    } else {
      this.control.setValue([]);
      // this.selectedModelData.emit(this.control.value);
      this.matUnCheck._element.nativeElement.style.display = 'none';
      this.matCheck._element.nativeElement.style.display = 'block';
    }
  }

  onChangeDD(event, select) {
    const param = this.control;
    if (select) {
      if (select.value.length === 0 || select.value[0] === undefined) {
        // this.selectedModelData.emit(param.value);
      } else {
        // this.selectedModelData.emit(param.value);
      }
    }
  }

  ngAfterViewInit() {
    this.setInitialValue();
  }

  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  protected setInitialValue() {
    this.filteredDropDown
      .pipe(take(1), takeUntil(this._onDestroy))
      .subscribe(() => {
        // setting the compareWith property to a comparison function
        // triggers initializing the selection according to the initial value of
        // the form control (i.e. _initializeSelection())
        // this needs to be done after the filteredBanks are loaded initially
        // and after the mat-option elements are available
        this.multiSelect.compareWith = (a: string, b: string) => a && b && a === b;
      });
  }
}
