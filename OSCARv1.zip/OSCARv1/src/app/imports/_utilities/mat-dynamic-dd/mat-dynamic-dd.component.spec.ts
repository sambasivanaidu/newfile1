import { async, ComponentFixture, TestBed, tick } from '@angular/core/testing';
import { MatDynamicDdComponent } from './mat-dynamic-dd.component';
import { FormsModule, ReactiveFormsModule, NgForm } from '@angular/forms';
import { MaterialModule } from '../../material.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatSelectModule, MatSelect } from '@angular/material';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { By } from '@angular/platform-browser';

describe('MatDynamicDdComponent', () => {
  let component: MatDynamicDdComponent;
  let fixture: ComponentFixture<MatDynamicDdComponent>;
  let elementRefference;
  let checkAllStyle_firstElementChild;
  let uncheckAllstyle_firstElementChild;
  let checkAllStyle_nativeElement;
  let uncheckAllstyle_nativeElement;
  let checkElement;
  let uncheckElement;
  let bankmltiCtrl;
  let matOptionSelect;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MatDynamicDdComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        BrowserAnimationsModule,
        MatSelectModule
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MatDynamicDdComponent);
    component = fixture.componentInstance;
    elementRefference = fixture.debugElement;
    component.id = 'dummy';
    checkAllStyle_firstElementChild =
      fixture.componentInstance.matCheck._element.nativeElement
        .firstElementChild.style;
    uncheckAllstyle_firstElementChild =
      fixture.componentInstance.matUnCheck._element.nativeElement
        .firstElementChild.style;
    checkAllStyle_nativeElement =
      fixture.componentInstance.matCheck._element.nativeElement.style;
    uncheckAllstyle_nativeElement =
      fixture.componentInstance.matUnCheck._element.nativeElement.style;
    checkElement = fixture.componentInstance.matCheck._element
      .nativeElement as HTMLElement;
    uncheckElement = fixture.componentInstance.matUnCheck._element
      .nativeElement as HTMLElement;
    bankmltiCtrl = fixture.componentInstance.multiSelect as MatSelect;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('#applyCSS should add styles to check all and uncheck all option when #checkOption is true', () => {
    component.isMultiSelect = true;
    component.checkOption = true;
    fixture.detectChanges();
    spyOn(component, 'applyCSS');
    component.applyCSS();
    expect(component.applyCSS).toHaveBeenCalled();
    expect(checkAllStyle_firstElementChild.fontSize).toEqual('16px');
    expect(checkAllStyle_firstElementChild.fontWeight).toEqual('bold');
    expect(checkAllStyle_firstElementChild.marginTop).toEqual('3px');
    expect(checkAllStyle_nativeElement.display).toEqual('');
    expect(uncheckAllstyle_firstElementChild.fontSize).toEqual('16px');
    expect(uncheckAllstyle_firstElementChild.fontWeight).toEqual('bold');
    expect(uncheckAllstyle_firstElementChild.marginTop).toEqual('3px');
    expect(uncheckAllstyle_nativeElement.display).toEqual('none');
  });

  it('#applyCSS should add styles to check all and uncheck all option when #checkOption is false', () => {
    component.isMultiSelect = true;
    component.checkOption = false;
    fixture.detectChanges();
    spyOn(component, 'applyCSS');
    component.applyCSS();
    expect(component.applyCSS).toHaveBeenCalled();
    expect(checkAllStyle_firstElementChild.fontSize).toEqual('16px');
    expect(checkAllStyle_firstElementChild.fontWeight).toEqual('bold');
    expect(checkAllStyle_firstElementChild.marginTop).toEqual('3px');
    expect(checkAllStyle_nativeElement.display).toEqual('none');
    expect(uncheckAllstyle_firstElementChild.fontSize).toEqual('16px');
    expect(uncheckAllstyle_firstElementChild.fontWeight).toEqual('bold');
    expect(uncheckAllstyle_firstElementChild.marginTop).toEqual('3px');
    expect(uncheckAllstyle_nativeElement.display).toEqual('none');
  });

  it('.mat-option-0 class button click should call #selectAll', () => {
    spyOn(component, 'selectAll');
    checkElement.click();
    expect(component.selectAll).toHaveBeenCalled();
  });

  it('.mat-option-1 class button click should call #selectAll', () => {
    spyOn(component, 'selectAll');
    uncheckElement.click();
    expect(component.selectAll).toHaveBeenCalled();
  });

  it('#selectAll should select all elements when .mat-option-0 class button is clicked', () => {
    component.banks = [
      {
        name: 'CALSMR2',
        locationId: 'Detroit',
        modality: ['MRI', 'CT', 'X-Ray', 'US', 'MM', 'NM', 'MA']
      },
      {
        name: 'CHSHCF2',
        locationId: 'Detroit',
        modality: ['MRI', 'CT', 'X-Ray', 'US', 'MM', 'NM', 'MA']
      },
      {
        name: 'DETSJANN2',
        locationId: 'Detroit',
        modality: ['MRI', 'CT', 'X-Ray', 'US', 'MM', 'NM', 'MA']
      }
    ];
    component.bankMultiFilterCtrl.setValue('c');
    component.isMultiSelect = true;
    component.bankMultiCtrl.setValue([
      {
        name: 'DETSJANN2',
        locationId: 'Detroit',
        modality: ['MRI', 'CT', 'X-Ray', 'US', 'MM', 'NM', 'MA']
      }
    ]);

    fixture.detectChanges();

    spyOn(component, 'selectAll');
    component.selectAll(true, component.bankMultiCtrl, component.banks);
    expect(component.selectAll).toHaveBeenCalled();
  });

  it('check all with filter', async(() => {
    component.banks = [
      {
        name: 'CALSMR2',
        locationId: 'Detroit',
        modality: ['MRI', 'CT', 'X-Ray', 'US', 'MM', 'NM', 'MA']
      },
      {
        name: 'CHSHCF2',
        locationId: 'Detroit',
        modality: ['MRI', 'CT', 'X-Ray', 'US', 'MM', 'NM', 'MA']
      },
      {
        name: 'DETSJANN2',
        locationId: 'Detroit',
        modality: ['MRI', 'CT', 'X-Ray', 'US', 'MM', 'NM', 'MA']
      }
    ];
    component.isMultiSelect = true;
    component.checkOption = true;
    component.bankMultiFilterCtrl.setValue('d');
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      checkElement.click();
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.bankMultiCtrl.value.length).toEqual(1);
        expect(checkAllStyle_nativeElement.display).toEqual('none');
        expect(uncheckAllstyle_nativeElement.display).toEqual('block');
        component.bankMultiFilterCtrl.setValue('');
        fixture.detectChanges();
        fixture.whenStable().then(() => {
          expect(component.bankMultiCtrl.value.length).toEqual(1);
          expect(checkAllStyle_nativeElement.display).toEqual('block');
          expect(uncheckAllstyle_nativeElement.display).toEqual('none');
        });
      });
    });
  }));

  it('uncheck all with filter', async(() => {
    component.banks = [
      {
        name: 'CALSMR2',
        locationId: 'Detroit',
        modality: ['MRI', 'CT', 'X-Ray', 'US', 'MM', 'NM', 'MA']
      },
      {
        name: 'CHSHCF2',
        locationId: 'Detroit',
        modality: ['MRI', 'CT', 'X-Ray', 'US', 'MM', 'NM', 'MA']
      },
      {
        name: 'DETSJANN2',
        locationId: 'Detroit',
        modality: ['MRI', 'CT', 'X-Ray', 'US', 'MM', 'NM', 'MA']
      }
    ];
    component.isMultiSelect = true;
    component.checkOption = true;
    component.bankMultiFilterCtrl.setValue('d');
    component.bankMultiCtrl.setValue([
      {
        name: 'DETSJANN2',
        locationId: 'Detroit',
        modality: ['MRI', 'CT', 'X-Ray', 'US', 'MM', 'NM', 'MA']
      }
    ]);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      uncheckElement.click();
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.bankMultiCtrl.value.length).toEqual(0);
        expect(checkAllStyle_nativeElement.display).toEqual('block');
        expect(uncheckAllstyle_nativeElement.display).toEqual('none');
      });
    });
  }));

  it('check all without filter', async(() => {
    component.banks = [
      {
        name: 'CALSMR2',
        locationId: 'Detroit',
        modality: ['MRI', 'CT', 'X-Ray', 'US', 'MM', 'NM', 'MA']
      },
      {
        name: 'CHSHCF2',
        locationId: 'Detroit',
        modality: ['MRI', 'CT', 'X-Ray', 'US', 'MM', 'NM', 'MA']
      },
      {
        name: 'DETSJANN2',
        locationId: 'Detroit',
        modality: ['MRI', 'CT', 'X-Ray', 'US', 'MM', 'NM', 'MA']
      }
    ];
    component.isMultiSelect = true;
    component.checkOption = true;
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      checkElement.click();
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.bankMultiCtrl.value.length).toEqual(3);
        expect(checkAllStyle_nativeElement.display).toEqual('none');
        expect(uncheckAllstyle_nativeElement.display).toEqual('block');
      });
    });
  }));

  it('uncheck all with filter', async(() => {
    component.banks = [
      {
        name: 'CALSMR2',
        locationId: 'Detroit',
        modality: ['MRI', 'CT', 'X-Ray', 'US', 'MM', 'NM', 'MA']
      },
      {
        name: 'CHSHCF2',
        locationId: 'Detroit',
        modality: ['MRI', 'CT', 'X-Ray', 'US', 'MM', 'NM', 'MA']
      },
      {
        name: 'DETSJANN2',
        locationId: 'Detroit',
        modality: ['MRI', 'CT', 'X-Ray', 'US', 'MM', 'NM', 'MA']
      }
    ];
    component.isMultiSelect = true;
    component.checkOption = true;
    component.bankMultiCtrl.setValue([
      {
        name: 'CALSMR2',
        locationId: 'Detroit',
        modality: ['MRI', 'CT', 'X-Ray', 'US', 'MM', 'NM', 'MA']
      },
      {
        name: 'CHSHCF2',
        locationId: 'Detroit',
        modality: ['MRI', 'CT', 'X-Ray', 'US', 'MM', 'NM', 'MA']
      },
      {
        name: 'DETSJANN2',
        locationId: 'Detroit',
        modality: ['MRI', 'CT', 'X-Ray', 'US', 'MM', 'NM', 'MA']
      }
    ]);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      uncheckElement.click();
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.bankMultiCtrl.value.length).toEqual(0);
        expect(checkAllStyle_nativeElement.display).toEqual('block');
        expect(uncheckAllstyle_nativeElement.display).toEqual('none');
      });
    });
  }));

  it('single select', async(() => {
    component.isMultiSelect = false;
    component.checkOption = false;
    fixture.detectChanges();
    matOptionSelect =
      fixture.componentInstance.matCheck._element.nativeElement
        .firstElementChild.style;
    expect(matOptionSelect.display).toEqual('');
  }));
});
