import {
  AfterViewInit,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  Input
} from '@angular/core';
import { FormControl } from '@angular/forms';
import { ReplaySubject, Subject } from 'rxjs';
import { take, takeUntil } from 'rxjs/operators';
import { MatSelect } from '@angular/material';

@Component({
  selector: 'app-mat-dynamic-dd',
  templateUrl: './mat-dynamic-dd.component.html',
  styleUrls: ['./mat-dynamic-dd.component.scss']
})
export class MatDynamicDdComponent implements OnInit, OnDestroy {
  banks = [];

  @Input() set listData(Value) {
    if (Value) {
      this.banks = Value;
      this.filteredBanksMulti.next(this.banks.slice());
      this.bankMultiFilterCtrl.valueChanges
        .pipe(takeUntil(this._onDestroy))
        .subscribe(() => {
          this.filterBanksMulti();
        });
    }
  }
  @Input() icon: string;
  @Input() id: string;
  @Input() isMultiSelect: boolean;
  @ViewChild('matCheck') matCheck;
  @ViewChild('matUnCheck') matUnCheck;
  @Input() checkOption: boolean;
  @Input() set parentFormControl(formControl: FormControl) {
    if (formControl) {
      this.bankMultiCtrl = formControl;
    }
  }
  @Input() enableSearch: boolean;
  @Input() placeholder;
  @Input() placeholderLabel: string;
  // @Input() required: string;
  required1 = false;
  @Input() set required(value: boolean) {
    this.required1 = value;
  }
  disableFormControl = false;
  @Input() set disabled(val: boolean) {
    this.disableFormControl = val;
    if (val) {
      this.bankMultiCtrl.disable();
    } else {
      this.bankMultiCtrl.enable();
    }
  }
  /** control for the selected bank for multi-selection */
  public bankMultiCtrl: FormControl = new FormControl();

  /** control for the MatSelect filter keyword multi-selection */
  public bankMultiFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public filteredBanksMulti: ReplaySubject<Object[]> = new ReplaySubject<
    Object[]
  >(1);

  @ViewChild('multiSelect') multiSelect: MatSelect;
  @ViewChild('matOptionSelect') matOptionSelect;

  /** Subject that emits when the component has been destroyed. */
  protected _onDestroy = new Subject<void>();

  constructor() {}

  ngOnInit() {
    // set initial selection
    // this.bankMultiCtrl.setValue([this.banks[10], this.banks[11], this.banks[12]]);

    // load the initial bank list
    this.filteredBanksMulti.next(this.banks.slice());

    // listen for search field value changes
    this.bankMultiFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterBanksMulti();
      });

    if (!this.isMultiSelect) {
      this.checkOption = this.isMultiSelect;
    }
    this.applyCSS();
  }

  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  applyCSS() {
    this.matUnCheck._element.nativeElement.firstElementChild.style.fontSize =
      '16px';
    this.matUnCheck._element.nativeElement.firstElementChild.style.fontWeight =
      'bold';
    this.matUnCheck._element.nativeElement.firstElementChild.style.marginTop =
      '3px';
    this.matCheck._element.nativeElement.firstElementChild.style.fontSize =
      '16px';
    this.matCheck._element.nativeElement.firstElementChild.style.fontWeight =
      'bold';
    this.matCheck._element.nativeElement.firstElementChild.style.marginTop =
      '3px';
    if (this.checkOption === false) {
      this.matCheck._element.nativeElement.style.display = 'none';
      this.matUnCheck._element.nativeElement.style.display = 'none';
    } else {
      this.matUnCheck._element.nativeElement.style.display = 'none';
    }
  }

  selectAll(checkAll, select, values) {
    let search = this.bankMultiFilterCtrl.value;
    let controlValues = select.value;
    controlValues = controlValues.filter(element => element !== undefined);
    if (checkAll) {
      let filterValues;
      if (search) {
        search = search.toLowerCase();
        filterValues = values.filter(
          bank => bank.name.toLowerCase().indexOf(search) > -1
        );
        controlValues.forEach(elemt => {
          if (filterValues.indexOf(elemt) === -1) {
            filterValues.push(elemt);
          }
        });
      }
      this.bankMultiCtrl.setValue(search ? filterValues : values);
      this.matCheck._element.nativeElement.style.display = 'none';
      this.matUnCheck._element.nativeElement.style.display = 'block';
    } else {
      let filterValues;
      if (search) {
        search = search.toLowerCase();
        filterValues = values.filter(
          bank => bank.name.toLowerCase().indexOf(search) > -1
        );
        filterValues.forEach(elemt => {
          const index = controlValues.indexOf(elemt);
          if (index > -1) {
            controlValues.splice(index, 1);
          }
        });
      }
      this.bankMultiCtrl.setValue(search ? controlValues : []);
      this.bankMultiCtrl.clearValidators();
      this.matUnCheck._element.nativeElement.style.display = 'none';
      this.matCheck._element.nativeElement.style.display = 'block';
    }
  }

  protected filterBanksMulti() {
    if (!this.banks) {
      return;
    }
    // get the search keyword
    let search = this.bankMultiFilterCtrl.value;
    if (!search) {
      this.changeLabels();
      this.filteredBanksMulti.next(this.banks.slice());
      return;
    } else {
      search = search.toLowerCase();
    }

    this.changeLabels();

    // filter the banks
    this.filteredBanksMulti.next(
      this.banks.filter(bank => bank.name.toLowerCase().indexOf(search) > -1)
    );
  }

  onChangeDD(event, select) {
    this.bankMultiCtrl.updateValueAndValidity();
    this.changeLabels();
  }

  changeLabels() {
    if (this.isMultiSelect) {
      let search = this.bankMultiFilterCtrl.value;
      if (search) {
        search = search.toLowerCase();
      }
      const lengthOfList = search
        ? this.banks.filter(
            bank => bank.name.toLowerCase().indexOf(search) > -1
          ).length
        : this.banks.length;
      const filteredlist = this.banks.filter(
        bank => bank.name.toLowerCase().indexOf(search) > -1
      );
      let checkList = false;
      if (this.bankMultiCtrl.value.length === lengthOfList) {
        checkList = search ? arrayContainsArray(this.bankMultiCtrl.value, filteredlist) : true;
      } else if (this.bankMultiCtrl.value.length > lengthOfList) {
        checkList = arrayContainsArray(this.bankMultiCtrl.value, filteredlist);
      } else {
        checkList = false;
        // checkList = arrayContainsArray(filteredlist this.bankMultiCtrl.value);
      }

      if (checkList) {
        this.matCheck._element.nativeElement.style.display = 'none';
        this.matUnCheck._element.nativeElement.style.display = 'block';
      } else {
        this.matCheck._element.nativeElement.style.display = 'block';
        this.matUnCheck._element.nativeElement.style.display = 'none';
      }

      if (!this.isMultiSelect || !this.checkOption) {
        this.matCheck._element.nativeElement.style.display = 'none';
        this.matUnCheck._element.nativeElement.style.display = 'none';
      }
    }
  }
}

function arrayContainsArray(superset, subset) {
  if (0 === subset.length) {
    return false;
  }
  return subset.every(function(value) {
    return superset.indexOf(value) >= 0;
  });
}
