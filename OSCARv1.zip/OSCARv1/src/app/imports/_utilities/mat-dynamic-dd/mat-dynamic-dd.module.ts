import { NgModule } from '@angular/core';
import { MatDynamicDdComponent } from './mat-dynamic-dd.component';
import { ReactiveFormsModule} from '@angular/forms';
import { MaterialModule } from '../../material.module';
import { CommonModule } from '@angular/common';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MaterialModule,
    NgxMatSelectSearchModule
  ],
  declarations: [MatDynamicDdComponent],
  exports: [MatDynamicDdComponent]
})
export class MatDynamicDdModule { }
