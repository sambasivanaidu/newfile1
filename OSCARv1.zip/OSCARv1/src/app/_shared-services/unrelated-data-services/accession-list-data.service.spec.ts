// import { TestBed, inject } from '@angular/core/testing';

// import { AccessionListDataService } from './accession-list-data.service';

// describe('AccessionListDataService', () => {
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       providers: [AccessionListDataService]
//     });
//   });

//   it('should be created', inject([AccessionListDataService], (service: AccessionListDataService) => {
//     expect(service).toBeTruthy();
//   }));
// });
