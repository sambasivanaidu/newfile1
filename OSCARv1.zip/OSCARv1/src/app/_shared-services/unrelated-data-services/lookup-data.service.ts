import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HeaderAuthenticationToken } from '../../auth/authetication-header';
import * as _ from 'lodash';
import { DateFormatter } from '../../imports/_utilities/date-formatter';
import { map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
@Injectable()
export class LookupDataService {
  public httpOption;
  public envURL = environment.URL;
  public userName;
  public lookupOptions;
  public storage: Storage = environment.storage;
  constructor(
    private httpClient: HttpClient,
    private __httpHeader: HeaderAuthenticationToken,
    private dateFormatter: DateFormatter
  ) {
    this.httpOption = this.__httpHeader.setHeaderToken();
    this.userName = this.storage.getItem('UserName');
  }
  getLookUpData(userQuery) {
    if (userQuery) {
      this.lookupOptions = userQuery;
    }
    const url = this.envURL + 'codelookup/api/searchV1?query=' + userQuery;
    return this.httpClient.get(url, this.httpOption).pipe(
      map(res => {
        if (res) {
          return res;
        }
      })
    );
  }
  validateBlankRecordCoder(cptInfo, icdInfo) {
    const icdCodeIsEmpty = _.filter(icdInfo, ['predictIcdCode', '']);
    const cptCodeIsEmpty = _.filter(cptInfo, ['predictCptCode', '']);
    const cptAccessionEmpty = _.filter(cptInfo, ['accession', '']);
    const param = {
      cptCodeIsEmpty,
      icdCodeIsEmpty,
      cptAccessionEmpty
    };
    return param;
  }
  validateBlankRecordAuditor(cptInfo, icdInfo) {
    const icdCodeIsEmpty = _.filter(icdInfo, ['icdCode', '']);
    const cptCodeIsEmpty = _.filter(cptInfo, ['cptCode', '']);
    const cptAccessionEmpty = _.filter(cptInfo, ['accessionNo', '']);
    const param = {
      cptCodeIsEmpty,
      icdCodeIsEmpty,
      cptAccessionEmpty
    };
    return param;
  }
  cptDxRefValidationCheck(obj) {
    let param;
    let msg;
    const regex = /^[0-9]+(?:-[0-9]+)?(,[0-9]+(?:-[0-9]+)?)*$/m;
    let checkDxRefEmpty = false;
    obj.forEach(element => {
      if (element.dxRef && !regex.test(element.dxRef)) {
        checkDxRefEmpty = true;
        msg = 'CPT grid ICD Ref value is incorrect';
      }
    });
    param = checkDxRefEmpty
      ? {
          code: 0,
          msg: msg
        }
      : {
          code: 1,
          msg: 'All dxRef value are correct'
        };
    return param;
  }
  public getIcdCptLookUpData(
    userQuery,
    gender,
    dateOfBirth,
    dateoOfService,
    facility,
    codeType
  ) {
    const dob = new Date(this.dateFormatter.updateDates(dateOfBirth));
    const dos = new Date(this.dateFormatter.updateDates(dateoOfService));
    const diffTime = Math.abs(dos.getTime() - dob.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    const url =
      this.envURL +
      'codelookup/api/searchcodeV1?query=' +
      userQuery +
      '&category=' +
      gender +
      '&age=' +
      diffDays +
      '&facilitycode=' +
      facility +
      '&codeType=' +
      codeType;
    return this.httpClient.get(url, this.httpOption).pipe(
      map(res => {
        if (res) {
          return res;
        }
      })
    );
  }
}
