import { Injectable } from '@angular/core';
import * as _moment from 'moment';
import { networkInterfaces } from 'os';

@Injectable()
export class DateService {
  public toDateErrorMessage;
  public fromDateErrorMessage;

  constructor() { }

  public dateValidation(event, fromDateControl, toDateControl, field?: string, from?: string) {
    if (event.type === 'input') {
      const dateFormat = /^\d{1,2}\/\d{1,2}\/\d{4}$/g.test(event.target.value);
      const todate: any = new Date();
      const day = todate.getDate();
      const month = todate.getMonth() + 1;
      const date = _moment(event.target.value, 'MM/DD/YYYY');

      if (event.target.value !== '' && dateFormat) {
        if (field === 'To Date' && fromDateControl.value !== null) {
          fromDateControl.value._f = 'MM/DD/YYYY';
          const fromDate = fromDateControl.value;
          if (date.format('MM/DD/YYYY') === 'Invalid date') {
            toDateControl.setErrors({ invalid: null });
            this.toDateErrorMessage = 'Please enter valid date';
          } else if (date > _moment(new Date())) {
            toDateControl.setErrors({ invalid: true });
            this.toDateErrorMessage = 'Date cannot be greater than today\'s date';
          } else if (date < fromDate) {
            if (date.date() === fromDate.date() &&
              date.month() + 1 === fromDate.month() + 1 && date.year() === fromDate.year()) {
              toDateControl.setErrors(null);
            } else {
              toDateControl.setErrors({ invalid: true });
              this.toDateErrorMessage = from === 'userMapping' ? 'Production date cannot be less than date of joining.' : 'To Date cannot be less than From Date';
            }
          } else if (date >= fromDate) {
            fromDateControl.setErrors(null);
            toDateControl.setErrors(null);
          }
        } else if (field === 'From Date' && toDateControl.value !== null) {
          toDateControl.value._f = 'MM/DD/YYYY';
          const toDate = toDateControl.value;
          if (date.format('MM/DD/YYYY') === 'Invalid date') {
            fromDateControl.setErrors({ invalid: null });
            this.fromDateErrorMessage = 'Please enter valid date';
          } else if (date > _moment(new Date())) {
            fromDateControl.setErrors({ invalid: true });
            this.fromDateErrorMessage = 'Date cannot be greater than today\'s date.';
          } else if (date > toDate) {
            if (date.date() === toDate.date() &&
              date.month() + 1 === toDate.month() + 1 && date.year() === toDate.year()) {
              fromDateControl.setErrors(null);
            } else {
              fromDateControl.setErrors({ invalid: true });
              this.fromDateErrorMessage = from === 'userMapping' ? 'Date of joining cannot be less than production date.' : 'From Date cannot be greater than To Date';
            }
          } else if (date <= toDate) {
            fromDateControl.setErrors(null);
            toDateControl.setErrors(null);
          }
        }
      } else {
        if (field === 'To Date') {
          toDateControl.setErrors({ invalid: true });
          this.toDateErrorMessage = 'Please enter valid date.';
        } else {
          fromDateControl.setErrors({ invalid: true });
          this.fromDateErrorMessage = 'Please enter valid date.';
        }
      }

    } else if (event._isAMomentObject) {
      const date = event;
      if (field === 'To Date') {
        fromDateControl.value._f = 'MM/DD/YYYY';
        const fromDate = fromDateControl.value;
        if (date < fromDate) {
          if (date.date() === fromDate.date() &&
            date.month() + 1 === fromDate.month() + 1 && date.year() === fromDate.year()) {
            toDateControl.setErrors(null);
          } else {
            toDateControl.setErrors({ invalid: true });
            this.toDateErrorMessage = from === 'userMapping' ? 'Production date cannot be less than date of joining.' : 'To Date cannot be less than From Date';
          }
        } else if (date >= fromDate) {
          fromDateControl.setErrors(null);
          toDateControl.setErrors(null);
        }
      } else if (field === 'From Date') {
        toDateControl.value._f = 'MM/DD/YYYY';
        const toDate = toDateControl.value;
        if (date > toDate) {
          if (date.date() === toDate.date() &&
            date.month() + 1 === toDate.month() + 1 && date.year() === toDate.year()) {
            fromDateControl.setErrors(null);
          } else {
            fromDateControl.setErrors({ invalid: true, touched: true });
            this.fromDateErrorMessage = from === 'userMapping' ? 'Date of joining cannot be less than production date.' : 'From Date cannot be greater than To Date';
          }
        } else if (date <= toDate) {
          fromDateControl.setErrors(null);
          toDateControl.setErrors(null);
        }
      }
    }
    const toDateErrorMessage = this.toDateErrorMessage;
    const fromDateErrorMessage = this.fromDateErrorMessage;
    return {
      fromDateControl,
      toDateControl,
      toDateErrorMessage,
      fromDateErrorMessage
    };
  }
}
