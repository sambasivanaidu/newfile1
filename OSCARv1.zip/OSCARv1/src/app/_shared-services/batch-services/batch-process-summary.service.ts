import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/forkJoin';
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';
const EXCEL_TYPE =
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
import { HeaderAuthenticationToken } from '../../auth/authetication-header';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class BatchProcessSummaryService {
  public httpOption;
  public envURL = environment.URL;
  public userName;
  constructor(
    private _httpClient: HttpClient,
    private __httpHeader: HeaderAuthenticationToken
  ) {
    this.httpOption = this.__httpHeader.setHeaderToken();
  }
  getBatchProcess(myObjStr) {
    const url = this.envURL + 'batch/uploadSummaryCounts';
    return this._httpClient.post(url, myObjStr, this.httpOption);
  }

  getBatchData(param, type) {
    const url = this.envURL + 'batchanalysis/batchUploadSummary/' + type;
    return this._httpClient.post(url, param, this.httpOption);
  }
  getProcessedBatchData(param, type) {
    const url = this.envURL + 'chartinformation/batchUploadSummary/' + type;
    return this._httpClient.post(url, param, this.httpOption);
  }
  public batchDownloadExcel(json: any[], excelFileName: string): void {
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(json);
    const workbook: XLSX.WorkBook = {
      Sheets: { data: worksheet },
      SheetNames: ['data']
    };
    const excelBuffer: any = XLSX.write(workbook, {
      bookType: 'xlsx',
      type: 'array'
    });
    this.saveAsExcelFile(excelBuffer, excelFileName);
  }
  private saveAsExcelFile(buffer: any, fileName: string): void {
    const contentType = EXCEL_TYPE;
    const blob = new Blob([buffer], { type: contentType });
    FileSaver.saveAs(blob, fileName + '_' + this.getTimeString() + '.xlsx');
  }
  getTimeString = function() {
    const dateString = new Date().toDateString();
    const timeString = new Date().toTimeString().split(' ')[0];
    const dateTime = dateString + ' - ' + timeString;
    return dateTime;
  };


}
