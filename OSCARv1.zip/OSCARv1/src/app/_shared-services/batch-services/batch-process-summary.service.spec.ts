// import { TestBed, inject } from '@angular/core/testing';

// import { BatchProcessSummaryService } from './batch-process-summary.service';

// describe('BatchProcessSummaryService', () => {
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       providers: [BatchProcessSummaryService]
//     });
//   });

//   it('should be created', inject([BatchProcessSummaryService], (service: BatchProcessSummaryService) => {
//     expect(service).toBeTruthy();
//   }));
// });
