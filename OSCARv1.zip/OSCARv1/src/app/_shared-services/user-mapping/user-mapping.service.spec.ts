import { TestBed, inject, async, ComponentFixture } from '@angular/core/testing';
import { UserMappingService } from './user-mapping.service';
import { HttpClient } from 'selenium-webdriver/http';
import { HttpModule, ConnectionBackend, XHRBackend } from '@angular/http';
import { HttpHandler } from '@angular/common/http';
import { HeaderAuthenticationToken } from '../../auth/authetication-header';
import { ToastsManager, ToastOptions } from 'ng2-toastr';
import { NgProgress } from 'ngx-progressbar';
import { MockBackend } from '@angular/http/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('platformService', () => {
    let component: UserMappingService;
    let fixture: ComponentFixture<UserMappingService>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [],
            imports: [
                HttpClientTestingModule,
            ],
            providers: [
                   UserMappingService,
                   HeaderAuthenticationToken,
                   ToastsManager,
                   ToastOptions
                       ]
        }).compileComponents();
    }));

    it('should be created', inject([UserMappingService], (service: UserMappingService) => {
        expect(service).toBeTruthy();
    }));

    it('#getSelectedFacility', inject([UserMappingService], (service: UserMappingService) => {
        expect(service.getSelectedFacility()).toBeDefined();
    }));

    it('#getSearchClient', inject([UserMappingService], (service: UserMappingService) => {
        expect(service.getSearchClient()).toBeDefined();
    }));
});
