import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { HeaderAuthenticationToken } from '../../auth/authetication-header';
import { environment } from '../../../environments/environment';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { ToastsManager } from 'ng2-toastr';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class UserMappingService {

  userName: any;
  storage: any = environment.storage;
  httpOptions: any;
  envUrl: any = environment.URL;

  constructor(private _httpClient: HttpClient, private __httpHeader: HeaderAuthenticationToken, private toaster: ToastsManager) {
    this.httpOptions = this.__httpHeader.setHeaderToken();
    this.userName = this.storage.getItem('UserName');
   }

    sub = new Subject<any>();
    subFac = new Subject<any>();
    subFacType = new Subject<any>();
    subMod = new Subject<any>();
    subTargetSampling = new Subject<any>();

  getSearchClient(): Observable<any> {
    return this.sub.asObservable();
  }

  setSearchClient(obj: string) {
    this.sub.next({ clientObj: obj });
  }

  getSelectedFacility(): Observable<any> {
    return this.subFac.asObservable();
  }

  setSelectedFacility(obj: string) {
    this.subFac.next(obj);
  }

  getSelectedModality(): Observable<any> {
    return this.subMod.asObservable();
  }
  setSelectedModality(obj: string) {
    this.subMod.next(obj);
  }
  getSelectedFacilityType(): Observable<any> {
    return this.subFacType.asObservable();
  }
  setSelectedFacilityType(obj: string) {
    this.subFacType.next(obj);
  }

  getSearchTargetSampling(): Observable<any> {
    return this.subTargetSampling.asObservable();
  }

  setSearchTargetSampling(obj: string) {
    this.subTargetSampling.next(obj);
  }

   fetchMappedUsers(): Observable<any> {
     const _url = this.envUrl + 'facilitymaster/usermapping?teamLeadId=' + this.userName;
     return this._httpClient.get(_url, this.httpOptions).pipe(
      map((response: any) => {
        if (response) {
          return response;
        }
      })
    );
   }

   fetchUserToUpdate(userId): Observable<any> {
    const _url = this.envUrl + 'usermaster/userId?userId=' + userId;
    return this._httpClient.get(_url, this.httpOptions);
  }

   saveMappedUsers(params): Observable<any> {
    const _url = this.envUrl + 'usermaster/save';
    const userMappedParam = this.userMappingObj(params);
    return this._httpClient.post(_url, userMappedParam, this.httpOptions);
  }

  userMappingObj(user) {

    let UserArray = {};
/*     UserInfo.forEach((user, i) => { */
      const UserObj = {
        userId: user.userId,
        userfirstname: user.userfirstname,
        usermiddlename: user.usermiddlename,
        userlastname: user.userlastname,
        password: user.password,
        userRole: user.userRole,
        teamlead: user.teamlead,
        manager: user.manager,
        defaultRole: user.defaultRole,
        userType: user.userType,
        createdOn: user.createdOn,
        createdBy: user.createdBy,
        updatedOn: user.updatedOn,
        updatedBy: user.updatedBy,
        isActive: user.isActive,
        opsLocation: user.opsLocation,
        internalUser: user.internalUser,
        email: user.email,
        userconfiguration: user.userconfiguration,
        doj: user.doj,
        dop: user.dop,
        targetsampling:  user.targetsampling,
        tlsmemapping: user.tlsmemapping,
        targetsamplingrange: user.targetsamplingrange
      };

      UserArray = UserObj;

    return UserArray;
  }

}
