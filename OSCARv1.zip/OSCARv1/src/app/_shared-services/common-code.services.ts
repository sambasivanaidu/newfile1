import { Injectable } from '@angular/core';
import * as CryptoJS from 'crypto-js';
import { environment } from './../../environments/environment';
@Injectable()
export class CommonCodeService {
  public storage: Storage = environment.storage;
  icdHeaderClickCount: number = 0;
  relatedVisitHeaderClickCount: number = 0;
  cptHeaderClickCount: number = 0;
  pateintrecordcount: number = 0;

  get_ConfidenceColor_Clientselection(param) {
    return JSON.parse(
      CryptoJS.AES.decrypt(
        this.storage.getItem(param),
        'oscar'
      ).toString(CryptoJS.enc.Utf8)
    );

  }

  setMedicalReportHeight(chartRemarks, relatedvisit) {
    this.relatedVisitHeaderClickCount++;
    if (relatedvisit) {
      if (this.relatedVisitHeaderClickCount % 2 !== 0) {
        return 752;
      } else {
        return chartRemarks === '' ? 594 : 536;
      }
    } else {
      if (this.relatedVisitHeaderClickCount % 2 !== 0) {
        return chartRemarks === '' ? 594 : 536;
      } else {
        return 752;
      }
    }
  }

  setCptHeight() {
    this.icdHeaderClickCount++;
    if (this.pateintrecordcount % 2 !== 0) {
      if (this.icdHeaderClickCount % 2 !== 0) {
        return 660;
      } else {
        return 250;
      }
    } else {
      if (this.icdHeaderClickCount % 2 !== 0) {
        return 512;
      } else {
        return 250;
      }
    }
  }

  setIcdHeight() {
    this.cptHeaderClickCount++;
    if (this.pateintrecordcount % 2 !== 0) {
      if (this.cptHeaderClickCount % 2 !== 0) {
        return 660;
      } else {
        return 250;
      }
    } else {
      if (this.cptHeaderClickCount % 2 !== 0) {
        return 512;
      } else {
        return 250;
      }
    }
  }

  pateintRecordInfoHeight() {
    this.pateintrecordcount++;
    if (this.pateintrecordcount % 2 !== 0) {
      return 330;
    } else {
      return 250;
    }
  }

}
