$(function() {
  var $context = $(".context");
  $context.textHighlighter({
    onAfterHighlight: function(arr, element) {}
  });
});
